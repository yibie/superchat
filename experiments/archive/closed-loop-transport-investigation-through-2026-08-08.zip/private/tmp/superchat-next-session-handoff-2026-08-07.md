# Superchat next-session handoff

Date: 2026-08-07

## Next-session focus

Correct the causal diagnosis of Closed-loop Experience Correction v0.4 and
define the smallest identifiable measurement contract for a possible next
experiment. Do not rerun models or build Learning, Memory, or Policy behavior
until that contract passes a deterministic preflight.

Continue solo unless the user explicitly reverses the earlier no-subagent
instruction.

## Current state

- The official v0.4 execution and archive are complete. Its preregistered
  verdict remains `effect_gate_fail`; the independent audit confirmed all hard
  counts, score-matrix arithmetic, hashes, boundary claims, and the fresh ERT
  result.
- The independent audit found two causal-attribution overstatements and one
  sensitivity-label caveat. These findings have not yet been recorded in the
  repository.
- The repository working copy is clean at `oyyuxnvp / eaacd24c`; its parent is
  `urzzmqon / 81197f7c` (`Record closed-loop correction rerun v0.4`).
- No workspace file was changed in the final turn. No model or subagent was
  invoked.

## Source-of-truth artifacts

Treat the repository root as `<repo>` and reference these rather than copying
their contents:

- Official v0.4 handoff:
  `<repo>/experiments/closed-loop-experience-correction-v0/revisions/v0.4/HANDOFF.md`
- Structured and human-readable results:
  `<repo>/experiments/closed-loop-experience-correction-v0/revisions/v0.4/comparison-report.json`
  and `comparison-report.md`
- Verification and boundary records:
  `<repo>/experiments/closed-loop-experience-correction-v0/revisions/v0.4/verification-record.json`
  and `boundary-audit.json`
- Per-run evidence, outcomes, and prompt snapshots:
  `<repo>/experiments/closed-loop-experience-correction-v0/revisions/v0.4/runs/`
- Evaluator prompt and parser/validator implementation:
  `<repo>/experiments/closed-loop-experience-correction-v0/evidence.el`
- Sealed external archive:
  `/private/tmp/closed-loop-experience-correction-v0.4-handoff.zip`
  - SHA-256:
    `dfebb5aefd6f2db89e3a7cce970bb845ea2be5da5cdb22dd9ca23c8ab20ad322`
- Earlier-session context, now superseded by v0.4 where results differ:
  `/private/tmp/superchat-next-session-handoff-2026-08-06.md`

## Corrections established by the independent audit

1. Do not say the v0.4 prompts explicitly instructed the model to treat Claims
   as contestable. Across all 72 prompt snapshots, the auditor found no such
   instruction. The observed stale-arm ceiling is real, but that wording is
   not its cause. An explicit “Claims are hypotheses; verify them against Tape
   facts” rule belongs in a future contract.
2. Do not attribute all `9/24` invalid evaluator outputs to the JSON shape and
   missing score-to-label mapping. Only two were mapping/label mismatches. The
   other seven were truncated JSON documents and their truncation layer is not
   yet diagnosed.
3. In the sensitivity analysis, three of the four invalid documents described
   as declaring score 2 were recovered by regex from truncated output. They
   are valid only as an optimistic sensitivity bound, not as interpretable
   evaluator judgments.
4. Keep the rubric-ambiguity finding: one corrected artifact was penalized for
   saying the evidence did not establish a stable recovery strategy. The
   evaluator treated that negative conclusion as a prohibited strategy claim,
   even though it was the intended correction.

These corrections narrow the diagnosis; they do not alter the frozen official
scores or the `effect_gate_fail` verdict.

## Smallest next investigation

1. Diagnose the seven truncations end to end: provider completion metadata,
   token budget/finish reason, Runtime artifact bytes, and persistence bytes.
   Distinguish provider truncation from local storage or decoding truncation.
2. State the estimand before drafting another protocol. If corrected-current
   receives rebuttal evidence unavailable to controls, the experiment measures
   the value of additional evidence, not Claim correction alone. If every arm
   receives all facts, final correctness may remain ceiling-saturated; use an
   attainable endpoint such as grounded efficiency or non-inferiority plus a
   correction-specific behavioral measure.
3. Make the evaluator contract executable and unambiguous:
   - a strict structured JSON schema;
   - explicit mappings `2 -> fidelity-pass`, `1 -> fidelity-partial`,
     `0 -> fidelity-fail`;
   - no hard-coded example answer presented as the “exact shape”;
   - adequate output budget, truncation detection, and a preregistered
     same-evaluation-attempt repair/retry rule;
   - rubric text stating that “the evidence does not establish a stable
     strategy” is a negative evidentiary conclusion, not a positive strategy
     assertion.
4. Preflight fixtures for scores 0/1/2, malformed JSON, truncated JSON, and
   ceiling-saturated paired outcomes. Reject the protocol if its effect
   threshold is unattainable under plausible control performance.

Stop before model execution. A new experiment is justified only after the
estimand, treatment contrast, evaluator contract, truncation behavior, and
threshold attainability are all deterministic and reviewable.

## OMX blocker

The attempted planning entry point returned:

```json
{"ok":false,"reason":"unsupported_documented_leader_proof"}
```

This came from `omx ralplan preflight --json`. Repository instructions require
stopping Ralplan planning on that result. Re-run the preflight before any
Ralplan state, planning, runtime, HUD, or delegation work; do not fabricate
leader authority or manually write OMX state.

## Suggested skills

- `onevcat-jj` — inspect and record local changes with jj, never git.
- `$analyze` — read-only synthesis if the causal-correction addendum needs to
  be grounded directly from the archived prompts and raw evaluator outputs.
- `diagnose` — trace the seven truncated evaluator outputs to their actual
  layer before proposing a repair.
- `$ralplan` — only after `omx ralplan preflight --json` succeeds; use it to
  review the estimand, treatment contrast, evaluator contract, and gates.
- `ponytail` — keep the next artifact to a diagnosis addendum or one frozen
  contract; do not add runtime abstractions.

## Guardrails

- Preserve the official frozen outcomes and failed attempts; corrections are
  diagnostic annotations, not score rewrites.
- No immediate v0.5 execution and no effectiveness claim from v0.4.
- No product Runtime change is supported by the current evidence.
- Do not expose provider credentials or environment secrets in logs or
  artifacts.
