;;; transport-integration-probe-v0.1.el --- Throwaway load-context wrapper -*- lexical-binding: t; -*-

;; Problem: the frozen base instrument (transport-integration-probe-v0.el,
;; sha 4fcf0f51a15c2029b062101921383b6a69991d2e01299fc1b24f7a0fa50db265)
;; failed in the load context before any measurement: the B0 run died with
;; "Symbol's function definition is void: superchat--update-status" because
;; the base instrument required only the Runtime/LLM/Tape/DB/preset modules
;; and not the full supported product entry, so product-side functions (UI,
;; render, models) were not defined when its Entry ran.
;;
;; M2 statement: the B0 fatal occurred in the load context, before any
;; measurement.  v0.1 only corrects the supported product load context --
;; it requires the full `superchat' entry before loading the frozen base
;; exactly once.  The frozen base instrument sha
;; 4fcf0f51a15c2029b062101921383b6a69991d2e01299fc1b24f7a0fa50db265 is
;; asserted before loading, so v0.1 is a distinct wrapper, not a retry of
;; the base instrument.
;;
;; THROWAWAY: experiment-local wrapper, not a product file.  Nothing loads
;; it; it may be deleted.  It never modifies Runtime/Tape/Closure/Workflow/
;; Workspace/Authority/superchat-llm or any contract/result/product file;
;; it only reads the frozen base and asserts it byte-for-byte, creates ONE
;; sc-b01-load-* temp dir so product-load effects cannot touch the default
;; data directory, registers a kill-emacs-hook cleanup, then delegates to
;; the frozen base instrument (which rebinds its own sc-b0-* runtime
;; directory for its Entry).
;;
;; Run (single command, absolute -L paths):
;;   emacs -Q --batch -L . \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/llm-0.31.1 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-0.9.1 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-event-source-0.1.3 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-media-type-0.2.4 \
;;     -l experiments/closed-loop-experience-correction-v0/transport-integration-probe-v0.1.el

;;; Code:

(defconst transport-integration-probe-v0.1--directory
  (file-name-directory (or load-file-name buffer-file-name)))

(defconst transport-integration-probe-v0.1--base-path
  (expand-file-name "transport-integration-probe-v0.el"
                    transport-integration-probe-v0.1--directory))

(defconst transport-integration-probe-v0.1--base-sha256
  "4fcf0f51a15c2029b062101921383b6a69991d2e01299fc1b24f7a0fa50db265")

(defconst transport-integration-probe-v0.1--wrapper-version "0.1")

(defvar transport-integration-probe-v0.1--temp-dir nil)
(defvar superchat-data-directory)

;;; --- Load-context isolation (runs at load time, never at compile time) ----

(defun transport-integration-probe-v0.1--make-load-dir ()
  "Create the sc-b01-load-* temp dir and point data there.
Must run BEFORE (require superchat) so product-load effects cannot hit
the default data directory."
  (setq transport-integration-probe-v0.1--temp-dir
        (make-temp-file "sc-b01-load-" t))
  (setq superchat-data-directory
        (expand-file-name "data" transport-integration-probe-v0.1--temp-dir))
  (make-directory superchat-data-directory t))

;; M3: this directory covers only the product load; the frozen base
;; instrument's Entry rebinds its own sc-b0-* runtime directory, so the
;; two temp namespaces never overlap.

(defun transport-integration-probe-v0.1--cleanup ()
  "Delete the wrapper temp dir on a clean exit.
M1: deletion is wrapped in condition-case; a SIGKILL or crash may skip
kill-emacs-hook entirely and leave sc-b01-load-* behind for manual/system
cleanup -- one such residual directory is the bounded worst case."
  (when transport-integration-probe-v0.1--temp-dir
    (condition-case nil
        (delete-directory transport-integration-probe-v0.1--temp-dir t)
      (error nil))))

(defun transport-integration-probe-v0.1--assert-functions ()
  "Assert the ten product functions the base Entry needs are fbound."
  (let (missing)
    (dolist (fn '(superchat--update-status
                  superchat--stream-llm-result
                  superchat--process-llm-result
                  superchat--ttft-log
                  superchat--annotate-ttft
                  superchat--is-ollama-backend-p
                  superchat--detect-response-mode
                  superchat--show-response-mode-indicator
                  superchat--get-adjusted-timeout
                  superchat--extend-timeout))
      (unless (fboundp fn)
        (push fn missing)))
    (when missing
      (error "transport-integration-probe-v0.1: product functions not defined after (require 'superchat): %S"
             (nreverse missing)))))

(defun transport-integration-probe-v0.1--assert-base ()
  "Assert the frozen base file is readable and byte-identical to its sha."
  (unless (file-readable-p transport-integration-probe-v0.1--base-path)
    (error "transport-integration-probe-v0.1: base file not readable: %s"
           transport-integration-probe-v0.1--base-path))
  (let ((actual
         (with-temp-buffer
           (insert-file-contents transport-integration-probe-v0.1--base-path)
           (secure-hash 'sha256 (current-buffer)))))
    (unless (equal actual transport-integration-probe-v0.1--base-sha256)
      (error "transport-integration-probe-v0.1: base sha mismatch: expected %s got %s"
             transport-integration-probe-v0.1--base-sha256 actual))))

(defun transport-integration-probe-v0.1--wrapper-source-hash ()
  "Return the wrapper's own sha256 when the source path is known."
  (let ((source (or load-file-name buffer-file-name)))
    (when source
      (with-temp-buffer
        (insert-file-contents (expand-file-name source))
        (secure-hash 'sha256 (current-buffer))))))

(defun transport-integration-probe-v0.1--emit-note ()
  "Emit the single wrapper stderr note with residual cleanup bound."
  (message
   (concat "transport-integration-probe-v0.1: wrapper version %s, "
           "full-product-context (require 'superchat) before frozen base, "
           "base path %s, base sha256 %s, wrapper source sha256 %s; "
           "residual cleanup limit: if kill-emacs-hook is skipped by "
           "SIGKILL/crash, one sc-b01-load-* dir may remain for "
           "manual/system cleanup")
   transport-integration-probe-v0.1--wrapper-version
   transport-integration-probe-v0.1--base-path
   transport-integration-probe-v0.1--base-sha256
   (or (transport-integration-probe-v0.1--wrapper-source-hash) "unknown")))

;;; --- Load sequence --------------------------------------------------------

(defun transport-integration-probe-v0.1--run ()
  "Load the full product context, then run the frozen base exactly once."
  ;; Register cleanup before creation; M1: may be skipped by SIGKILL/crash.
  (add-hook 'kill-emacs-hook #'transport-integration-probe-v0.1--cleanup)
  ;; M3: isolate only product loading; the base creates its own runtime dir.
  (transport-integration-probe-v0.1--make-load-dir)
  (require 'superchat)
  (transport-integration-probe-v0.1--assert-functions)
  (transport-integration-probe-v0.1--assert-base)
  ;; Keep stdout owned by the base JSON record.
  (transport-integration-probe-v0.1--emit-note)
  (load transport-integration-probe-v0.1--base-path nil nil t))

(transport-integration-probe-v0.1--run)

(provide 'transport-integration-probe-v0.1)

;;; transport-integration-probe-v0.1.el ends here
