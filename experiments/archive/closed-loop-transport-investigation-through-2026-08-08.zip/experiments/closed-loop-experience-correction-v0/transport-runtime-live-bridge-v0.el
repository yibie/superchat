;;; transport-runtime-live-bridge-v0.el --- One live Runtime bridge -*- lexical-binding: t; -*-

;; Question: does one real ASCII Ollama response keep the same content bytes
;; through provider NDJSON, llm, Runtime, Tape, and a probe-local Outcome?
;; THROWAWAY: one authorized request only; not product code and not permission
;; to run the held-out experiment.  See the adjacent frozen contract.
;;
;; Run exactly once with the command frozen in
;; transport-runtime-live-bridge-v0-contract.json.

(require 'cl-lib)
(require 'json)
(require 'subr-x)
(require 'llm)
(require 'llm-ollama)

(declare-function superchat-db-close "superchat-db")
(declare-function superchat-preset--create "superchat-preset")
(declare-function superchat-runtime-submit-blocking "superchat-runtime")
(declare-function superchat-tape-replay-events "superchat-tape")
(declare-function transport-runtime-byte-probe-v0--identity nil)
(declare-function transport-runtime-byte-probe-v0--write-read-outcome nil)

(defvar llm-log)
(defvar superchat--active-timeout-timer)
(defvar superchat-closure-shadow-enabled)
(defvar superchat-closure-shadow-functions)
(defvar superchat-closure-terminal-guard-enabled)
(defvar superchat-data-directory)
(defvar superchat-db--connection)
(defvar superchat-db--path)
(defvar superchat-llm-backend)
(defvar superchat-llm-model)
(defvar superchat-llm-reasoning)
(defvar superchat-post-topic-finalized-functions)
(defvar superchat-post-turn-functions)
(defvar superchat-pre-topic-finalized-functions)
(defvar superchat-response-timeout)
(defvar superchat-run-completed-functions)
(defvar superchat-runtime--closure-observations)
(defvar superchat-runtime--runs)
(defvar superchat-show-ttft)
(defvar superchat-turn-completed-functions)

(defconst transport-runtime-live-bridge-v0--directory
  (file-name-directory (or load-file-name buffer-file-name)))
(defconst transport-runtime-live-bridge-v0--source
  (or load-file-name buffer-file-name))
(defconst transport-runtime-live-bridge-v0--contract
  (expand-file-name "transport-runtime-live-bridge-v0-contract.json"
                    transport-runtime-live-bridge-v0--directory))
(defconst transport-runtime-live-bridge-v0--next-contract
  (expand-file-name "next-measurement-contract-v0.json"
                    transport-runtime-live-bridge-v0--directory))
(defconst transport-runtime-live-bridge-v0--model-free-probe
  (expand-file-name "transport-runtime-byte-probe-v0.el"
                    transport-runtime-live-bridge-v0--directory))
(defconst transport-runtime-live-bridge-v0--contract-sha256
  "496648dea327d2c5304b6eb3bf192e49c3e5ad6c350e3f97705aa4b8a910cf6e")
(defconst transport-runtime-live-bridge-v0--model-free-sha256
  "9cde279dc392db5bfb1e7ffe3174dc00123a14e9f02faad05eb7d34038a4396f")
(defconst transport-runtime-live-bridge-v0--schema-sha256
  "bcbc37a0cf42b9def5a906d90201befaea4cf505c208dd21ff6736fac6bf71dd")
(defconst transport-runtime-live-bridge-v0--endpoint
  "http://127.0.0.1:11434/api/chat")
(defconst transport-runtime-live-bridge-v0--model "qwen3.6:latest")
(defconst transport-runtime-live-bridge-v0--session
  "transport-runtime-live-bridge-v0")
(defconst transport-runtime-live-bridge-v0--tee-buffer
  " *transport-runtime-live-bridge-v0-tee*")

(defvar transport-runtime-live-bridge-v0--active nil)
(defvar transport-runtime-live-bridge-v0--captured-url nil)
(defvar transport-runtime-live-bridge-v0--request-body nil)
(defvar transport-runtime-live-bridge-v0--request-count 0)
(defvar transport-runtime-live-bridge-v0--llm-final nil)
(defvar transport-runtime-live-bridge-v0--llm-final-count 0)
(defvar transport-runtime-live-bridge-v0--response-schema nil)
(defvar transport-runtime-live-bridge-v0--ran nil)

(load transport-runtime-live-bridge-v0--model-free-probe nil t)

(defun transport-runtime-live-bridge-v0--hash-file (path)
  "Return SHA-256 of PATH."
  (with-temp-buffer
    (insert-file-contents path)
    (secure-hash 'sha256 (current-buffer))))

(defun transport-runtime-live-bridge-v0--read-json (path)
  "Read PATH as plist JSON with vector arrays."
  (with-temp-buffer
    (insert-file-contents path)
    (json-parse-buffer :object-type 'plist :array-type 'array
                       :null-object nil :false-object :json-false)))

(defun transport-runtime-live-bridge-v0--canonical-key (key)
  "Return KEY as a JSON object key string."
  (if (symbolp key) (symbol-name key) key))

(defun transport-runtime-live-bridge-v0--canonical-json (object)
  "Return canonical JSON for parsed alist OBJECT."
  (cond
   ((eq object :null) "null")
   ((null object) "null")
   ((stringp object) (json-encode-string object))
   ((numberp object) (number-to-string object))
   ((eq object t) "true")
   ((eq object :json-false) "false")
   ((consp object)
    (if (and (consp (car object)) (not (consp (caar object))))
        (concat
         "{"
         (mapconcat
          (lambda (pair)
            (concat
             (json-encode-string
              (transport-runtime-live-bridge-v0--canonical-key (car pair)))
             ":"
             (transport-runtime-live-bridge-v0--canonical-json (cdr pair))))
          (sort (copy-sequence object)
                (lambda (left right)
                  (string<
                   (transport-runtime-live-bridge-v0--canonical-key (car left))
                   (transport-runtime-live-bridge-v0--canonical-key (car right)))))
          ",")
         "}")
      (concat "[" (mapconcat
                    #'transport-runtime-live-bridge-v0--canonical-json
                    object ",") "]")))
   (t (json-encode-string (format "%S" object)))))

(defun transport-runtime-live-bridge-v0--parse-json (string)
  "Parse STRING as alist JSON."
  (json-parse-string string :object-type 'alist :array-type 'list
                     :null-object :null :false-object :json-false))

(defun transport-runtime-live-bridge-v0--schema-hash (request-body)
  "Return canonical response-format hash from REQUEST-BODY."
  (let* ((request (transport-runtime-live-bridge-v0--parse-json request-body))
         (format-object (alist-get 'format request)))
    (when format-object
      (secure-hash
       'sha256
       (encode-coding-string
        (transport-runtime-live-bridge-v0--canonical-json format-object)
        'utf-8)))))

(defun transport-runtime-live-bridge-v0--request-value (path)
  "Return the value at symbol PATH in the captured request JSON."
  (let ((value (transport-runtime-live-bridge-v0--parse-json
                transport-runtime-live-bridge-v0--request-body)))
    (dolist (key path value)
      (setq value (alist-get key value)))))

(defun transport-runtime-live-bridge-v0--tee (process _media-types string)
  "Copy raw /api/chat response bytes before plz decodes STRING."
  (when (and transport-runtime-live-bridge-v0--active
             (processp process)
             (let* ((args (process-get process :plz-args))
                    (url (and (listp args) (nth 1 args))))
               (equal url transport-runtime-live-bridge-v0--endpoint)))
    (with-current-buffer
        (get-buffer-create transport-runtime-live-bridge-v0--tee-buffer)
      (set-buffer-multibyte nil)
      (goto-char (point-max))
      (insert string))))

(defun transport-runtime-live-bridge-v0--capture-request (url &rest args)
  "Capture the exact serialized /api/chat request for URL."
  (when (and transport-runtime-live-bridge-v0--active
             (string-suffix-p "/api/chat" url))
    (cl-incf transport-runtime-live-bridge-v0--request-count)
    (setq transport-runtime-live-bridge-v0--captured-url url
          transport-runtime-live-bridge-v0--request-body
          (json-serialize (plist-get args :data)))))

(defun transport-runtime-live-bridge-v0--capture-llm-final
    (original provider prompt partial-callback response-callback error-callback
              &optional multi-output)
  "Call ORIGINAL and copy its final llm response before Runtime consumes it."
  (funcall
   original provider prompt partial-callback
   (lambda (response)
     (when transport-runtime-live-bridge-v0--active
       (cl-incf transport-runtime-live-bridge-v0--llm-final-count)
       (setq transport-runtime-live-bridge-v0--llm-final response))
     (funcall response-callback response))
   error-callback multi-output))

(defun transport-runtime-live-bridge-v0--inject-format
    (original text tools &optional context preset context-files)
  "Add the frozen response schema to the prompt returned by ORIGINAL."
  (let ((prompt (funcall original text tools context preset context-files)))
    (setf (llm-chat-prompt-response-format prompt)
          transport-runtime-live-bridge-v0--response-schema)
    prompt))

(defun transport-runtime-live-bridge-v0--raw-body ()
  "Return captured raw HTTP body as an unibyte string."
  (with-current-buffer
      (get-buffer-create transport-runtime-live-bridge-v0--tee-buffer)
    (let ((raw (buffer-string)))
      (if (string-match "\r\n\r\n" raw)
          (substring raw (match-end 0))
        raw))))

(defun transport-runtime-live-bridge-v0--provider-record (body)
  "Parse newline-complete NDJSON BODY into provider metadata and content."
  (let ((lines (split-string body "\n" t))
        done done-reason prompt-count eval-count content
        (content-events 0)
        (error-events 0))
    (dolist (line (if (string-suffix-p "\n" body) lines (butlast lines)))
      (let* ((event (transport-runtime-live-bridge-v0--parse-json line))
             (message (alist-get 'message event))
             (part (alist-get 'content message)))
        (when (stringp part)
          (cl-incf content-events)
          (setq content (concat content part)))
        (when (alist-get 'error event) (cl-incf error-events))
        (setq done (alist-get 'done event)
              done-reason (alist-get 'done_reason event)
              prompt-count (or prompt-count (alist-get 'prompt_eval_count event))
              eval-count (or eval-count (alist-get 'eval_count event)))))
    (list :done done :done-reason done-reason
          :prompt-eval-count prompt-count :eval-count eval-count
          :content-events content-events :error-events error-events
          :content (or content ""))))

(defun transport-runtime-live-bridge-v0--ascii-p (string)
  "Return non-nil when STRING contains ASCII only."
  (not (string-match-p "[^\0-\177]" string)))

(defun transport-runtime-live-bridge-v0--remove-curl-processes ()
  "Delete leftover plz curl processes."
  (dolist (process (process-list))
    (when (string-match-p "plz-request-curl" (process-name process))
      (delete-process process))))

(defun transport-runtime-live-bridge-v0-self-check ()
  "Validate the frozen single-run contract without calling a provider."
  (let* ((contract (transport-runtime-live-bridge-v0--read-json
                    transport-runtime-live-bridge-v0--contract))
         (authorization (plist-get contract :authorization))
         (scope (plist-get contract :scope))
         (next (transport-runtime-live-bridge-v0--read-json
                transport-runtime-live-bridge-v0--next-contract)))
    (cl-assert
     (equal transport-runtime-live-bridge-v0--contract-sha256
            (transport-runtime-live-bridge-v0--hash-file
             transport-runtime-live-bridge-v0--contract)))
    (cl-assert
     (equal transport-runtime-live-bridge-v0--model-free-sha256
            (transport-runtime-live-bridge-v0--hash-file
             transport-runtime-live-bridge-v0--model-free-probe)))
    (cl-assert (equal "frozen-single-run" (plist-get contract :status)))
    (cl-assert (eq t (plist-get authorization :single_run_authorized)))
    (cl-assert
     (eq :json-false (plist-get authorization :treatment_execution_authorized)))
    (cl-assert (= 1 (plist-get scope :requests)))
    (cl-assert (= 0 (plist-get scope :retries)))
    (cl-assert (equal transport-runtime-live-bridge-v0--endpoint
                      (plist-get scope :endpoint)))
    (cl-assert (equal transport-runtime-live-bridge-v0--model
                      (plist-get scope :model)))
    (cl-assert (= 2048 (plist-get scope :max_output_tokens)))
    (cl-assert
     (equal transport-runtime-live-bridge-v0--schema-sha256
            (plist-get scope :response_schema_sha256)))
    (setq transport-runtime-live-bridge-v0--response-schema
          (plist-get (plist-get next :evaluator) :response_schema))
    (cl-assert transport-runtime-live-bridge-v0--response-schema)
    (dolist (function '(llm-chat-streaming llm-request-plz-async
                        plz-media-type-process-filter
                        superchat--build-llm-prompt
                        superchat-runtime-submit-blocking))
      (cl-assert (fboundp function) nil "Missing function: %s" function))
    (list :contract-sha256 transport-runtime-live-bridge-v0--contract-sha256
          :single-run-authorized t
          :treatment-execution-authorized nil
          :required-record-count (length (plist-get contract :required_record)))))

(defun transport-runtime-live-bridge-v0-run ()
  "Execute the frozen one-request live bridge and return its evidence."
  (cl-assert (not transport-runtime-live-bridge-v0--ran) nil
             "This process already consumed its one authorized run")
  (setq transport-runtime-live-bridge-v0--ran t)
  (let* ((directory (make-temp-file "superchat-runtime-live-bridge-" t))
         (superchat-data-directory directory)
         (superchat-db--connection nil)
         (superchat-db--path nil)
         (superchat-response-timeout 300)
         (superchat-show-ttft nil)
         (llm-log nil)
         (structure nil)
         (delivered nil)
         result)
    (unwind-protect
        (progn
          (require 'superchat)
          (setq structure (transport-runtime-live-bridge-v0-self-check)
                transport-runtime-live-bridge-v0--captured-url nil
                transport-runtime-live-bridge-v0--request-body nil
                transport-runtime-live-bridge-v0--request-count 0
                transport-runtime-live-bridge-v0--llm-final nil
                transport-runtime-live-bridge-v0--llm-final-count 0)
          (with-current-buffer
              (get-buffer-create transport-runtime-live-bridge-v0--tee-buffer)
            (set-buffer-multibyte nil)
            (erase-buffer))
          (advice-add 'plz-media-type-process-filter :before
                      #'transport-runtime-live-bridge-v0--tee)
          (advice-add 'llm-request-plz-async :before
                      #'transport-runtime-live-bridge-v0--capture-request)
          (advice-add 'llm-chat-streaming :around
                      #'transport-runtime-live-bridge-v0--capture-llm-final)
          (advice-add 'superchat--build-llm-prompt :around
                      #'transport-runtime-live-bridge-v0--inject-format)
          (setq transport-runtime-live-bridge-v0--active t)
          (let* ((superchat-llm-backend
                  (make-llm-ollama :host "127.0.0.1" :port 11434
                                   :chat-model
                                   transport-runtime-live-bridge-v0--model))
                 (superchat-llm-model nil)
                 (superchat-llm-reasoning 'none)
                 (superchat-runtime--runs (make-hash-table :test #'equal))
                 (superchat--active-timeout-timer nil)
                 (superchat-pre-topic-finalized-functions nil)
                 (superchat-post-turn-functions nil)
                 (superchat-post-topic-finalized-functions nil)
                 (superchat-run-completed-functions nil)
                 (superchat-turn-completed-functions nil)
                 (superchat-closure-shadow-enabled nil)
                 (superchat-closure-terminal-guard-enabled nil)
                 (superchat-closure-shadow-functions nil)
                 (superchat-runtime--closure-observations nil)
                 (runtime-response
                  (superchat-runtime-submit-blocking
                   (list
                    :prompt
                    (concat
                     "Return exactly one JSON object using ASCII only. "
                     "Use schema_version closed-loop-evaluator-response-v1, "
                     "abstained false, both scores 2 with matching labels, "
                     "short evidence strings, and an empty missing_evidence. "
                     "No markdown and no text outside the object.")
                    :session-id transport-runtime-live-bridge-v0--session
                    :buffer-name " *superchat-runtime-live-bridge-v0*"
                    :ephemeral-buffer t
                    :record-conversation nil
                    :type :llm-query
                    :tools 'none
                    :topology 'single
                    :authority-policy "default"
                    :preset
                    (superchat-preset--create
                     :name "transport-runtime-live-bridge-v0"
                     :max-tokens 2048 :reasoning 'none :tools 'none)
                    :target-model transport-runtime-live-bridge-v0--model
                    :timeout 300
                    :delivery-function
                    (lambda (value status tape-id)
                      (setq delivered (list value status tape-id))))))
                 (_ (setq transport-runtime-live-bridge-v0--active nil))
                 (raw-body (transport-runtime-live-bridge-v0--raw-body))
                 (provider
                  (transport-runtime-live-bridge-v0--provider-record raw-body))
                 (provider-content (plist-get provider :content))
                 (provider-id
                  (transport-runtime-byte-probe-v0--identity provider-content))
                 (llm-id
                  (transport-runtime-byte-probe-v0--identity
                   transport-runtime-live-bridge-v0--llm-final))
                 (runtime-id
                  (transport-runtime-byte-probe-v0--identity runtime-response))
                 (events
                  (superchat-tape-replay-events
                   transport-runtime-live-bridge-v0--session))
                 (response-event
                  (cl-find "response.completed" events
                           :key (lambda (event) (plist-get event :type))
                           :test #'equal))
                 (payload (plist-get response-event :payload))
                 (storage-id (plist-get response-event :storage-id))
                 (tape-id
                  (list :bytes (plist-get payload :content-size)
                        :sha256 (plist-get payload :content-hash)))
                 (outcome
                  (transport-runtime-byte-probe-v0--write-read-outcome
                   directory runtime-response runtime-id))
                 (outcome-id
                  (list :bytes (plist-get outcome :raw_bytes)
                        :sha256 (plist-get outcome :raw_sha256)))
                 (request-schema-hash
                  (transport-runtime-live-bridge-v0--schema-hash
                   transport-runtime-live-bridge-v0--request-body))
                 (request-max-tokens
                  (transport-runtime-live-bridge-v0--request-value
                   '(options num_predict)))
                 (request-think
                  (transport-runtime-live-bridge-v0--request-value '(think)))
                 (raw-id
                  (list :bytes (string-bytes raw-body)
                        :sha256
                        (concat "sha256:" (secure-hash 'sha256 raw-body)))))
            (cl-assert (= 1 transport-runtime-live-bridge-v0--request-count))
            (cl-assert (= 1 transport-runtime-live-bridge-v0--llm-final-count))
            (cl-assert (equal transport-runtime-live-bridge-v0--endpoint
                              transport-runtime-live-bridge-v0--captured-url))
            (cl-assert (= 2048 request-max-tokens))
            (cl-assert (eq :json-false request-think))
            (cl-assert (equal transport-runtime-live-bridge-v0--schema-sha256
                              request-schema-hash))
            (cl-assert (eq t (plist-get provider :done)))
            (cl-assert (equal "stop" (plist-get provider :done-reason)))
            (cl-assert (zerop (plist-get provider :error-events)))
            (cl-assert (> (plist-get provider :content-events) 0))
            (cl-assert (transport-runtime-live-bridge-v0--ascii-p raw-body))
            (cl-assert (transport-runtime-live-bridge-v0--ascii-p
                        provider-content))
            (cl-assert (equal provider-content
                              transport-runtime-live-bridge-v0--llm-final))
            (cl-assert (equal transport-runtime-live-bridge-v0--llm-final
                              runtime-response))
            (cl-assert (equal provider-id llm-id))
            (cl-assert (equal provider-id runtime-id))
            (cl-assert (equal provider-id tape-id))
            (cl-assert (equal provider-id outcome-id))
            (cl-assert (equal (list runtime-response 'completed storage-id)
                              delivered))
            (cl-assert
             (equal '("intent.received" "run.started" "response.completed"
                      "run.completed" "turn.completed")
                    (mapcar (lambda (event) (plist-get event :type)) events)))
            (cl-assert (file-in-directory-p superchat-db--path directory))
            (setq result
                  (list
                   :schema-version "transport-runtime-live-bridge-v0/result"
                   :status 'passed :throwaway t
                   :treatment-execution-authorized nil
                   :preflight structure
                   :request
                   (list :count transport-runtime-live-bridge-v0--request-count
                         :endpoint transport-runtime-live-bridge-v0--captured-url
                         :max-output-tokens request-max-tokens
                         :response-schema-sha256 request-schema-hash
                         :think request-think)
                   :provider
                   (list :done (plist-get provider :done)
                         :done-reason (plist-get provider :done-reason)
                         :prompt-eval-count
                         (plist-get provider :prompt-eval-count)
                         :eval-count (plist-get provider :eval-count)
                         :raw-body raw-id
                         :content provider-id
                         :content-events (plist-get provider :content-events)
                         :error-events (plist-get provider :error-events))
                   :llm-text llm-id :runtime-response runtime-id
                   :tape tape-id :outcome outcome-id
                   :event-types
                   (mapcar (lambda (event) (plist-get event :type)) events)
                   :proved
                   "one real ASCII provider-to-Outcome byte identity"
                   :not-proved '("UTF-8 behavior" "held-out execution")))))
      (setq transport-runtime-live-bridge-v0--active nil)
      (advice-remove 'plz-media-type-process-filter
                     #'transport-runtime-live-bridge-v0--tee)
      (advice-remove 'llm-request-plz-async
                     #'transport-runtime-live-bridge-v0--capture-request)
      (advice-remove 'llm-chat-streaming
                     #'transport-runtime-live-bridge-v0--capture-llm-final)
      (advice-remove 'superchat--build-llm-prompt
                     #'transport-runtime-live-bridge-v0--inject-format)
      (transport-runtime-live-bridge-v0--remove-curl-processes)
      (when (fboundp 'superchat-db-close) (superchat-db-close))
      (dolist (name (list transport-runtime-live-bridge-v0--tee-buffer
                          " *superchat-runtime-live-bridge-v0*" "*llm-log*"))
        (when (get-buffer name) (kill-buffer name)))
      (delete-directory directory t))
    (setq result
          (plist-put
           result :cleanup
           (list
            :advices-removed
            (cl-every
             #'null
             (list
              (advice-member-p #'transport-runtime-live-bridge-v0--tee
                               'plz-media-type-process-filter)
              (advice-member-p
               #'transport-runtime-live-bridge-v0--capture-request
               'llm-request-plz-async)
              (advice-member-p
               #'transport-runtime-live-bridge-v0--capture-llm-final
               'llm-chat-streaming)
              (advice-member-p #'transport-runtime-live-bridge-v0--inject-format
                               'superchat--build-llm-prompt)))
            :curl-processes-removed
            (null (cl-find-if
                   (lambda (process)
                     (string-match-p "plz-request-curl" (process-name process)))
                   (process-list)))
            :buffers-removed
            (not (or (get-buffer transport-runtime-live-bridge-v0--tee-buffer)
                     (get-buffer " *superchat-runtime-live-bridge-v0*")
                     (get-buffer "*llm-log*")))
            :temp-directory-removed (not (file-exists-p directory)))))
    result))

(provide 'transport-runtime-live-bridge-v0)

;;; transport-runtime-live-bridge-v0.el ends here
