;;; transport-runtime-byte-probe-v0.el --- Throwaway Runtime byte probe -*- lexical-binding: t; -*-

;; Question: can one synthetic llm response cross the real Superchat Runtime
;; and produce identical Runtime, Tape metadata, and probe-local Outcome byte
;; identities without reaching a provider or creating a process?
;;
;; THROWAWAY: this is experiment evidence, not product code.  It authorizes no
;; live execution and proves neither real-provider behavior nor UTF-8 behavior.
;;
;; Run:
;;   emacs -Q --batch -L . \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/llm-0.31.1 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-0.9.1 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-event-source-0.1.3 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-media-type-0.2.4 \
;;     -l experiments/closed-loop-experience-correction-v0/transport-runtime-byte-probe-v0.el \
;;     --eval '(prin1 (transport-runtime-byte-probe-v0-run))'

(require 'cl-lib)
(require 'json)

(declare-function make-llm-ollama "llm-ollama")
(declare-function superchat-db-close "superchat-db")
(declare-function superchat-db-tape-select "superchat-db")
(declare-function superchat-preset--create "superchat-preset")
(declare-function superchat-runtime-submit-blocking "superchat-runtime")
(declare-function superchat-tape-replay-events "superchat-tape")

(defvar superchat--active-timeout-timer)
(defvar superchat-closure-shadow-enabled)
(defvar superchat-closure-shadow-functions)
(defvar superchat-closure-terminal-guard-enabled)
(defvar superchat-data-directory)
(defvar superchat-db--connection)
(defvar superchat-db--path)
(defvar superchat-llm-backend)
(defvar superchat-llm-model)
(defvar superchat-llm-reasoning)
(defvar superchat-post-topic-finalized-functions)
(defvar superchat-post-turn-functions)
(defvar superchat-pre-topic-finalized-functions)
(defvar superchat-run-completed-functions)
(defvar superchat-runtime--closure-observations)
(defvar superchat-runtime--runs)
(defvar superchat-turn-completed-functions)

(defconst transport-runtime-byte-probe-v0--source
  (or load-file-name buffer-file-name))

(defconst transport-runtime-byte-probe-v0--session-id
  "transport-runtime-byte-probe-v0")

(defun transport-runtime-byte-probe-v0--contains-p (tree symbol)
  "Return non-nil when TREE contains SYMBOL."
  (cond ((eq tree symbol) t)
        ((consp tree)
         (or (transport-runtime-byte-probe-v0--contains-p (car tree) symbol)
             (transport-runtime-byte-probe-v0--contains-p (cdr tree) symbol)))))

(defun transport-runtime-byte-probe-v0--protected-submit (tree)
  "Return the CL-LETF in TREE whose non-empty body contains Runtime submit."
  (cond
   ((and (consp tree)
         (eq (car tree) 'cl-letf)
         (cddr tree)
         (transport-runtime-byte-probe-v0--contains-p
          (cddr tree) 'superchat-runtime-submit-blocking))
    tree)
   ((consp tree)
    (or (transport-runtime-byte-probe-v0--protected-submit (car tree))
        (transport-runtime-byte-probe-v0--protected-submit (cdr tree))))))

(defun transport-runtime-byte-probe-v0-self-check ()
  "Prove from source structure that Runtime submit is inside CL-LETF."
  (let (forms form protected)
    (with-temp-buffer
      (insert-file-contents transport-runtime-byte-probe-v0--source)
      (goto-char (point-min))
      (condition-case nil
          (while t (push (read (current-buffer)) forms))
        (end-of-file nil)))
    (setq form
          (cl-find-if
           (lambda (item)
             (and (consp item)
                  (eq (car item) 'defun)
                  (eq (cadr item) 'transport-runtime-byte-probe-v0-run)))
           forms)
          protected (and form
                         (transport-runtime-byte-probe-v0--protected-submit
                          form)))
    (cl-assert protected nil "Runtime submit is outside cl-letf")
    (list :cl-letf-body-count (length (cddr protected))
          :runtime-submit-inside-cl-letf t)))

(defun transport-runtime-byte-probe-v0--response ()
  "Return a valid ASCII evaluator response longer than 500 bytes."
  (concat
   "{\"schema_version\":\"closed-loop-evaluator-response-v1\","
   "\"abstained\":false,\"correction_fidelity\":{\"score\":2,"
   "\"label\":\"fidelity-pass\",\"evidence\":\""
   (make-string 320 ?a)
   "\"},\"research_quality\":{\"score\":2,\"label\":\"accept\","
   "\"evidence\":\"" (make-string 320 ?b)
   "\"},\"missing_evidence\":[]}"))

(defun transport-runtime-byte-probe-v0--identity (text)
  "Return byte length and SHA-256 identity for TEXT."
  (let ((bytes (encode-coding-string text 'utf-8)))
    (list :bytes (string-bytes bytes)
          :sha256 (concat "sha256:" (secure-hash 'sha256 bytes)))))

(defun transport-runtime-byte-probe-v0--write-read-outcome
    (directory response identity)
  "Write and read a probe-local Outcome under DIRECTORY."
  (let ((path (expand-file-name "outcome.json" directory)))
    (with-temp-file path
      (insert
       (json-encode
        `((raw_response . ,response)
          (raw_bytes . ,(plist-get identity :bytes))
          (raw_sha256 . ,(plist-get identity :sha256))))))
    (with-temp-buffer
      (insert-file-contents path)
      (json-parse-buffer :object-type 'plist :array-type 'list))))

(defun transport-runtime-byte-probe-v0-run ()
  "Run the model-free Runtime byte probe and return its Lisp evidence."
  (let* ((structure (transport-runtime-byte-probe-v0-self-check))
         (directory (make-temp-file "superchat-runtime-byte-probe-" t))
         (superchat-data-directory directory)
         (superchat-db--connection nil)
         (superchat-db--path nil)
         (response (transport-runtime-byte-probe-v0--response))
         (identity (transport-runtime-byte-probe-v0--identity response))
         (timer nil)
         (mock-hit nil)
         (t4-hits nil)
         (delivered nil)
         result)
    (unwind-protect
        (progn
          (require 'superchat)
          (require 'llm-ollama)
          (let ((superchat-llm-backend
                 (make-llm-ollama :chat-model "qwen3.6:latest"))
                (superchat-llm-model nil)
                (superchat-llm-reasoning 'none)
                (superchat-runtime--runs (make-hash-table :test #'equal))
                (superchat--active-timeout-timer nil)
                (superchat-pre-topic-finalized-functions nil)
                (superchat-post-turn-functions nil)
                (superchat-post-topic-finalized-functions nil)
                (superchat-run-completed-functions nil)
                (superchat-turn-completed-functions nil)
                (superchat-closure-shadow-enabled nil)
                (superchat-closure-terminal-guard-enabled nil)
                (superchat-closure-shadow-functions nil)
                (superchat-runtime--closure-observations nil))
            (cl-letf
                (((symbol-function 'llm-chat-streaming)
                  (lambda (_provider _prompt partial-callback response-callback
                            _error-callback &optional _multi-output)
                    (setq mock-hit t
                          timer
                          (run-at-time
                           0 nil
                           (lambda ()
                             (funcall partial-callback (substring response 0 100))
                             (funcall partial-callback (substring response 0 300))
                             (funcall partial-callback response)
                             (funcall response-callback response))))
                    '(:synthetic t)))
                 ((symbol-function 'llm-chat-async)
                  (lambda (&rest _)
                    (error "Unexpected non-streaming dispatch")))
                 ((symbol-function 'make-process)
                  (lambda (&rest _)
                    (push 'make-process t4-hits)
                    (error "Process creation blocked")))
                 ((symbol-function 'make-network-process)
                  (lambda (&rest _)
                    (push 'make-network-process t4-hits)
                    (error "Network process creation blocked")))
                 ((symbol-function 'make-pipe-process)
                  (lambda (&rest _)
                    (push 'make-pipe-process t4-hits)
                    (error "Pipe process creation blocked"))))
              (let* ((runtime-response
                      (superchat-runtime-submit-blocking
                       (list
                        :prompt "Model-free Runtime byte probe."
                        :session-id transport-runtime-byte-probe-v0--session-id
                        :buffer-name " *superchat-runtime-byte-probe-v0*"
                        :ephemeral-buffer t
                        :record-conversation nil
                        :type :llm-query
                        :tools 'none
                        :topology 'single
                        :authority-policy "default"
                        :preset (superchat-preset--create
                                 :name "transport-runtime-byte-probe-v0"
                                 :max-tokens 2048
                                 :reasoning 'none
                                 :tools 'none)
                        :target-model "qwen3.6:latest"
                        :timeout 5
                        :delivery-function
                        (lambda (value status tape-id)
                          (setq delivered (list value status tape-id))))))
                     (events
                      (superchat-tape-replay-events
                       transport-runtime-byte-probe-v0--session-id))
                     (response-event
                      (cl-find "response.completed" events
                               :key (lambda (event) (plist-get event :type))
                               :test #'equal))
                     (payload (plist-get response-event :payload))
                     (storage-id (plist-get response-event :storage-id))
                     (stored-summary
                      (caar
                       (superchat-db-tape-select
                        "SELECT content FROM tape WHERE id = ?"
                        (list storage-id))))
                     (outcome
                      (transport-runtime-byte-probe-v0--write-read-outcome
                       directory response identity)))
                (cl-assert mock-hit)
                (cl-assert (null t4-hits))
                (cl-assert (equal response runtime-response))
                (cl-assert (equal (list response 'completed storage-id)
                                  delivered))
                (cl-assert
                 (equal '("intent.received" "run.started" "response.completed"
                          "run.completed" "turn.completed")
                        (mapcar (lambda (event) (plist-get event :type)) events)))
                (cl-assert (equal (plist-get identity :bytes)
                                  (plist-get payload :content-size)))
                (cl-assert (equal (plist-get identity :sha256)
                                  (plist-get payload :content-hash)))
                (cl-assert (equal response (plist-get outcome :raw_response)))
                (cl-assert (equal (plist-get identity :bytes)
                                  (plist-get outcome :raw_bytes)))
                (cl-assert (equal (plist-get identity :sha256)
                                  (plist-get outcome :raw_sha256)))
                (cl-assert
                 (equal (truncate-string-to-width response 500 nil nil "…")
                        stored-summary))
                (cl-assert (file-in-directory-p superchat-db--path directory))
                (setq result
                      (list
                       :schema-version "transport-runtime-byte-probe-v0/result"
                       :status 'passed
                       :throwaway t
                       :execution-authorized nil
                       :structure structure
                       :mock-hit mock-hit
                       :t4-hits t4-hits
                       :event-types
                       (mapcar (lambda (event) (plist-get event :type)) events)
                       :response identity
                       :tape (list :storage-id storage-id
                                   :content-size (plist-get payload :content-size)
                                   :content-hash (plist-get payload :content-hash))
                       :outcome
                       (list :raw-bytes (plist-get outcome :raw_bytes)
                             :raw-sha256 (plist-get outcome :raw_sha256))
                       :proved
                       "ASCII synthetic llm-to-Runtime-to-Tape-to-Outcome byte identity"
                       :not-proved
                       '("real provider through Runtime" "UTF-8 behavior")))))))
      (when (timerp timer) (cancel-timer timer))
      (when (fboundp 'superchat-db-close) (superchat-db-close))
      (dolist (name '(" *superchat-runtime-byte-probe-v0*" "*llm-log*"))
        (when (get-buffer name) (kill-buffer name)))
      (delete-directory directory t))
    (setq result
          (plist-put result :cleanup
                     (list :temp-directory-removed
                           (not (file-exists-p directory))
                           :timer-cancelled
                           (or (null timer) (not (memq timer timer-list))))))
    result))

(provide 'transport-runtime-byte-probe-v0)

;;; transport-runtime-byte-probe-v0.el ends here
