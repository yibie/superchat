# Transport causal diagnosis addendum v0

Status: `diagnostic-annotation-only`. This addendum changes no frozen probe,
result, measurement contract, product Runtime, Tape, Closure, Workflow,
Workspace, or Authority code. It authorizes no model or experiment execution.

## Verdict

The B0/B0.1 transport mock was not bypassed by Superchat, `llm.el`, advice,
generic dispatch, model discovery, or compilation. The frozen base installed
two temporary function cells and immediately restored them without executing a
body. Its Runtime submission occurred after the `cl-letf` extent had ended.

The v0.4 wrapper then failed independently to capture the base JSON because an
outer `standard-output` binding does not propagate into forms evaluated by
`load` on the executed Emacs 31 build. The base fatal JSON went to real stdout;
the wrapper parsed an empty capture buffer.

## Evidence

### 1. Executed bytes are identified

- Frozen base SHA-256:
  `4fcf0f51a15c2029b062101921383b6a69991d2e01299fc1b24f7a0fa50db265`.
- Executed v0.4 wrapper SHA-256:
  `39a446116449d3c6e3b351d3932bf354accc5bf97a40b1231aa6a8bb50ebaaa3`.
- The local Codex session record captured that wrapper SHA at
  `2026-08-07T14:20:06Z`, then captured the sole v0.4 command at
  `2026-08-07T14:26:33Z`; no intervening wrapper edit was recorded.
- The current wrapper has the same SHA. The v0.4 result omitted the wrapper's
  self-SHA, so the session record is required for this historical identity.

### 2. The frozen `cl-letf` has no body

The two replacement bindings are written at
`transport-integration-probe-v0.el:392-450`. The Runtime submission begins at
`transport-integration-probe-v0.el:452`.

Reading the source as Lisp data produced:

```text
cl-letf-form-length = 2
binding-count       = 2
body-count          = 0
```

`syntax-ppss` also places the `cl-letf` form at depth 5 and the Runtime submit
at the same depth. Therefore `llm-chat-streaming` and
`llm-request-plz-async` had already been restored when
`superchat-runtime-submit-blocking` ran.

This explains the observed path without an unknown bypass:

```text
superchat-runtime-submit-blocking
  -> superchat-runtime-submit
  -> superchat--llm-generate-answer
  -> llm-chat-streaming
  -> llm-request-plz-async
  -> plz-media-type-request
  -> plz
  -> make-pipe-process  [v0.4 T4 deny]
```

The product call sites are `superchat-runtime.el:867-883` and
`superchat-llm.el:921-953`. The standard provider continuation is
`llm-provider-utils.el:477-527`; the request adapter continues at
`llm-request-plz.el:122-159`.

### 3. The non-reproduction is explained

The v0.3 diagnostic places its Runtime submission inside the `cl-letf` body at
`transport-integration-probe-v0.3.el:514-547`. Its frozen result consequently
records `mock_hit=true`, `stream_cell_eq=true`, and `plz_hit=null`.

A fresh model-free check against the current product used a real
`llm-ollama` struct, temporary SQLite, the complete blocking Runtime path, and
the same `tools 'none` request shape. It returned:

```text
response = "ok"
events   = ((generate t) (prompt t) (dispatch t))
```

The function cell remained the mock at all three product boundaries. This is
consistent with v0.3 and falsifies a product/generic/advice bypass.

### 4. The v0.4 capture failed at a separate boundary

The wrapper binds `standard-output` around `load` at
`transport-integration-probe-v0.4.el:1029-1033`. On the executed Emacs 31
build, a model-free load check observed the loaded preflight's top-level form
with:

```text
binding-inside-loaded-file = nil
capture-buffer-bytes       = 0
```

The original v0.4 command output contains the base fatal JSON on real stdout,
followed by the wrapper JSON. The wrapper JSON reports
`base_stdout.bytes=0` and `End of file while parsing JSON`, exactly matching
the failed capture boundary. The base did emit evidence; the wrapper discarded
it from its structured result.

## Corrected classification

- `PROVED`: B0/B0.1 reached real transport because the frozen `cl-letf` body
  was empty and the Runtime submit was outside its dynamic extent.
- `PROVED`: v0.4's empty captured stdout was caused by relying on an outer
  `standard-output` binding across `load`.
- `NOT A PRODUCT DEFECT`: current Runtime dispatch respects a correctly scoped
  `cl-letf` replacement.
- `SEPARATE FAILED DIAGNOSTIC`: `transport-dispatch-seam-probe-v0.el` failed
  before dispatch because its response-format setter was macro-expanded before
  `llm` was loaded. It is not evidence about Runtime dispatch.
- `OPEN`: STOP-2, STOP-3, real Ollama semantics, UTF-8 behavior, and the
  intended byte-fidelity subgate remain unproved.

## Smallest admissible next contract

Do not edit or rerun the frozen base or v0.4 wrapper. If STOP-2 is pursued,
freeze one new standalone, model-free Runtime case with these preflight gates:

1. Parse the probe as Lisp data and assert that the Runtime submit form is a
   descendant of `cl-letf`, with `body-count > 0`.
2. Return a Lisp result from a callable entry; do not capture a load-and-exit
   program through an outer `standard-output` binding.
3. Keep terminal T4 denial and temporary DB isolation.
4. Require one synthetic response to match Runtime, Tape metadata, and
   probe-local Outcome bytes/hashes before any provider execution is discussed.

No product Runtime change is supported by this diagnosis.
