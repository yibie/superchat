;;; transport-integration-probe-v0.3.el --- Throwaway egress-identity probe -*- lexical-binding: t; -*-

;; Harness dependency fix: the v0.2 predecessor stopped before diagnosis
;; because make-llm-ollama was void; its result recorded zero diagnostic
;; events (events/t1_t2_result were null).  v0.3 is an independent,
;; self-describing harness with the single loading fix below.
;;
;; Problem: B0.1 (full (require 'superchat) + frozen base) produced curl
;; code 7 (network_attempted=true, zero_network_enforced=false) without
;; recording which upstream symbol actually reached plz/make-process.  The
;; audit (transport-egress-audit-v0.md) leaves the exact upstream caller of
;; the first plz/make-process, the cl-letf failure mechanism, and the
;; llm-models availability path open.  v0.3 is the minimal standalone
;; throwaway diagnostic for that identity question.
;;
;; CONTRACT (header):
;; - HARNESS DEPENDENCY FIX: launch explicitly requires llm-ollama after
;;   superchat and before make-llm-ollama.
;; - v0.2 recorded zero diagnostic events.  This is NOT a v0.2 retry: it does
;;   not load the frozen base, copy Tape/Outcome measurers, or make a
;;   measurement claim.
;; - Pi does not participate in this v0.3 harness-fix task; historical
;;   Luna/Pi provenance is retained unchanged in the report.
;; - THROWAWAY: experiment-local, not a product file; nothing loads it.
;; - NO byte-fidelity claim and NO measurement claim: it only records
;;   which function first reaches which transport symbol, with identity
;;   evidence (symbol-file/symbol-function/advice) and full args.
;; - STOP-2/3 stay open; execution_authorized=false.
;; - This task must NOT run the future command below and must not create a
;;   result artifact.
;; - Frozen SHA (verified read-only before diagnostic execution):
;;   audit        = 14f9c8416b4296cbe0869e1bd417d5e8989d211413d2e065472fb7294bde1268
;;                  (transport-egress-audit-v0.md)
;;   base         = 4fcf0f51a15c2029b062101921383b6a69991d2e01299fc1b24f7a0fa50db265
;;                  (transport-integration-probe-v0.el)
;;   wrapper      = 7210f2790299754f1b59c071977531c0c5a5cc383345ab231fba107514540ebc
;;                  (transport-integration-probe-v0.1.el)
;;   v0.2-source  = 50107bc11f41c931134594007b0c6088905a5bacedb6f9c881ba70ef64e2e6dc
;;                  (transport-integration-probe-v0.2.el)
;;   v0.2-result  = 38d3bc86233ef2882d21da0469a9fbdb7c1c2a80b63feeecc89663d7aa635b33
;;                  (transport-integration-probe-v0.2-result.json)
;; - Top level never require/loads product code; launch lives in a
;;   function, invoked only by the future v0.3 run command below.
;;
;; Sole future run command (this task must NOT run it):
;;   emacs -Q --batch -L . \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/llm-0.31.1 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-0.9.1 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-event-source-0.1.3 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-media-type-0.2.4 \
;;     -l experiments/closed-loop-experience-correction-v0/transport-integration-probe-v0.3.el \
;;     -f transport-integration-probe-v0.3--launch

;;; Code:

(require 'cl-lib)
(require 'json)

;; Compile-time declarations only: the product is never loaded at top level
;; (launch requires it at runtime).  Mirrors frozen base declarations.
(declare-function make-llm-ollama "llm-ollama")
(declare-function superchat-runtime-submit-blocking "superchat")
(declare-function superchat-preset--create "superchat")
(declare-function network-process-p "process" (process))

(defconst transport-integration-probe-v0.3--audit-sha256
  "14f9c8416b4296cbe0869e1bd417d5e8989d211413d2e065472fb7294bde1268")
(defconst transport-integration-probe-v0.3--base-sha256
  "4fcf0f51a15c2029b062101921383b6a69991d2e01299fc1b24f7a0fa50db265")
(defconst transport-integration-probe-v0.3--wrapper-sha256
  "7210f2790299754f1b59c071977531c0c5a5cc383345ab231fba107514540ebc")
(defconst transport-integration-probe-v0.3--predecessor-source-sha256
  "50107bc11f41c931134594007b0c6088905a5bacedb6f9c881ba70ef64e2e6dc")
(defconst transport-integration-probe-v0.3--predecessor-result-sha256
  "38d3bc86233ef2882d21da0469a9fbdb7c1c2a80b63feeecc89663d7aa635b33")
(defconst transport-integration-probe-v0.3--model "qwen3.6:latest")
(defconst transport-integration-probe-v0.3--timeout 300
  "Submit timeout in seconds; mirrors base transport-integration-probe-v0.")

;; T1/T2/T3/T4 symbol constants (audit section 4 rejection list).
(defconst transport-integration-probe-v0.3--t1-symbols
  '(llm-chat-streaming llm-request-plz-async))
(defconst transport-integration-probe-v0.3--t2-symbols
  '(llm-chat-async llm-request-plz-sync))
(defconst transport-integration-probe-v0.3--t3-symbols
  '(superchat--get-available-models llm-models plz plz-media-type-request
    url-retrieve url-retrieve-synchronously url-queue-retrieve
    url-retrieve-internal))
(defconst transport-integration-probe-v0.3--t4-symbols
  '(make-process make-network-process make-pipe-process))

;;; --- Frozen paths and read-only guards -------------------------------------

(defconst transport-integration-probe-v0.3--directory
  (file-name-directory (or load-file-name buffer-file-name)))

(defconst transport-integration-probe-v0.3--audit-path
  (expand-file-name "transport-egress-audit-v0.md"
                    transport-integration-probe-v0.3--directory))
(defconst transport-integration-probe-v0.3--base-path
  (expand-file-name "transport-integration-probe-v0.el"
                    transport-integration-probe-v0.3--directory))
(defconst transport-integration-probe-v0.3--wrapper-path
  (expand-file-name "transport-integration-probe-v0.1.el"
                    transport-integration-probe-v0.3--directory))
(defconst transport-integration-probe-v0.3--predecessor-source-path
  (expand-file-name "transport-integration-probe-v0.2.el"
                    transport-integration-probe-v0.3--directory))
(defconst transport-integration-probe-v0.3--predecessor-result-path
  (expand-file-name "transport-integration-probe-v0.2-result.json"
                    transport-integration-probe-v0.3--directory))
(defconst transport-integration-probe-v0.3--archive-db-path
  "/private/tmp/superchat-v04-final-archive.RAEt87/closed-loop-experience-correction-v0.4-handoff/runtime/superchat.db")
(defconst transport-integration-probe-v0.3--archive-db-hash
  "fc36ccb8cc440a8f2325f05d25be15220abd9cd9d9c09c241b1d16dd8d7d3d02")

(defun transport-integration-probe-v0.3--hash-file (path)
  "Return the sha256 hex of PATH's bytes, or nil when unreadable."
  (when (file-readable-p path)
    (with-temp-buffer
      (insert-file-contents path)
      (secure-hash 'sha256 (current-buffer)))))

(defun transport-integration-probe-v0.3--hash-mtime (path)
  "Return (list :hash H :mtime M) for PATH, or nil when unreadable."
  (when (file-readable-p path)
    (list :hash (transport-integration-probe-v0.3--hash-file path)
          :mtime (nth 5 (file-attributes path)))))

(defun transport-integration-probe-v0.3--assert-frozen ()
  "Assert the five frozen audit/base/wrapper/predecessor SHA values."
  (dolist (entry (list (list "audit" transport-integration-probe-v0.3--audit-path
                             transport-integration-probe-v0.3--audit-sha256)
                       (list "base" transport-integration-probe-v0.3--base-path
                             transport-integration-probe-v0.3--base-sha256)
                       (list "wrapper" transport-integration-probe-v0.3--wrapper-path
                             transport-integration-probe-v0.3--wrapper-sha256)
                       (list "v0.2-source"
                             transport-integration-probe-v0.3--predecessor-source-path
                             transport-integration-probe-v0.3--predecessor-source-sha256)
                       (list "v0.2-result"
                             transport-integration-probe-v0.3--predecessor-result-path
                             transport-integration-probe-v0.3--predecessor-result-sha256)))
    (let ((actual (transport-integration-probe-v0.3--hash-file (nth 1 entry))))
      (unless (equal actual (nth 2 entry))
        (error "transport-integration-probe-v0.3: frozen %s sha mismatch: expected %s got %s"
               (nth 0 entry) (nth 2 entry) actual)))))

(defun transport-integration-probe-v0.3--default-db-path ()
  "Return the default superchat DB path (may not exist)."
  (expand-file-name "superchat.db"
                    (expand-file-name "superchat/" user-emacs-directory)))

(defun transport-integration-probe-v0.3--guards-snapshot ()
  "Read-only hash/mtime snapshot of default DB and archive DB."
  (list :default_db (transport-integration-probe-v0.3--hash-mtime
                     (transport-integration-probe-v0.3--default-db-path))
        :archive_db (transport-integration-probe-v0.3--hash-mtime
                     transport-integration-probe-v0.3--archive-db-path)))

(defun transport-integration-probe-v0.3--assert-functions ()
  "Assert the ten product functions are fbound after requiring superchat."
  (let (missing)
    (dolist (fn '(superchat--update-status
                  superchat--stream-llm-result
                  superchat--process-llm-result
                  superchat--ttft-log
                  superchat--annotate-ttft
                  superchat--is-ollama-backend-p
                  superchat--detect-response-mode
                  superchat--show-response-mode-indicator
                  superchat--get-adjusted-timeout
                  superchat--extend-timeout))
      (unless (fboundp fn)
        (push fn missing)))
    (when missing
      (error "transport-integration-probe-v0.3: product functions not defined after (require 'superchat): %S"
             (nreverse missing)))))

(defun transport-integration-probe-v0.3--process-snapshot ()
  "Snapshot every process: name/status/command/network-process-p.
A single failing process must not break the loop."
  (let (out)
    (dolist (p (process-list))
      (push (condition-case err
                (list :name (process-name p)
                      :status (process-status p)
                      :command (ignore-errors (process-command p))
                      :network (ignore-errors (network-process-p p)))
              (error (list :name (ignore-errors (process-name p))
                           :snapshot_error (error-message-string err))))
            out))
    (nreverse out)))

;;; --- Minimal event-record state and helpers ---------------------------------

(defvar transport-integration-probe-v0.3--events nil
  "Accumulated diagnostic events; each is a plist.")
(defvar transport-integration-probe-v0.3--t4-hit nil
  "Non-nil once any T4 guard blocks a process creation.")
(defvar transport-integration-probe-v0.3--advice-table
  (make-hash-table :test #'eq)
  "Maps each advised symbol to its exact installed closure.")
(defvar transport-integration-probe-v0.3--advice-leftover nil
  "(symbol . closure) pairs still present after removal, per advice-member-p;
nil means every installed advice was removed.")
(defvar transport-integration-probe-v0.3--temp-dir nil)
(defvar transport-integration-probe-v0.3--timer nil
  "run-at-time timer object of the synthetic stream replay, if any.")
(defvar transport-integration-probe-v0.3--cleanup-evidence nil
  "Cleanup evidence plist: killed buffers, timer/advice/hook/temp-dir state.")
(defvar superchat-data-directory)
;; Special-variable declarations for the isolated Runtime state used by
;; --run-t1-t2 (same pattern as frozen base); compile-time only, no
;; semantics.
(defvar superchat-llm-backend)
(defvar superchat-llm-model)
(defvar superchat-llm-reasoning)
(defvar superchat-runtime--runs)
(defvar superchat-buffer-name)
(defvar superchat--active-timeout-timer)
(defvar superchat-pre-topic-finalized-functions)
(defvar superchat-post-turn-functions)
(defvar superchat-post-topic-finalized-functions)
(defvar superchat-run-completed-functions)
(defvar superchat-turn-completed-functions)
(defvar superchat-closure-shadow-enabled)
(defvar superchat-closure-terminal-guard-enabled)
(defvar superchat-closure-shadow-functions)
(defvar superchat-runtime--closure-observations)

(defun transport-integration-probe-v0.3--safe-backtrace ()
  "Return the current backtrace as a string; never signals."
  (condition-case err
      (with-output-to-string (backtrace))
    (error (format "(backtrace unavailable: %S)" (error-message-string err)))))

(defun transport-integration-probe-v0.3--identity (symbol)
  "Return the function-cell/advice identity snapshot of SYMBOL.
Each advice entry carries :advice (prin1) and :member (advice-member-p)."
  (condition-case err
      (let (found)
        (advice-mapc (lambda (ad _fn)
                       (push (list :advice (prin1-to-string ad)
                                   :member (advice-member-p ad symbol))
                             found))
                     symbol)
        (list :symbol symbol
              :symbol-file (and (fboundp symbol) (symbol-file symbol))
              :symbol-function (and (fboundp symbol)
                                    (prin1-to-string (symbol-function symbol)))
              :advices (nreverse found)))
    (error (list :symbol symbol
                 :identity_error (error-message-string err)))))

(defun transport-integration-probe-v0.3--json-normalize (obj)
  "Normalize OBJ for json-encode (plists -> alists, vectors -> vectors,
unknown objects -> prin1-to-string)."
  (cond
   ((null obj) nil)
   ((eq obj :json-false) :json-false)
   ((stringp obj) obj)
   ((numberp obj) obj)
   ((eq obj t) t)
   ((keywordp obj) (symbol-name obj))
   ((symbolp obj) (symbol-name obj))
   ((vectorp obj)
    (apply #'vector (mapcar #'transport-integration-probe-v0.3--json-normalize
                            (append obj nil))))
   ((consp obj)
    (cond
     ((keywordp (car obj))
      (let (out)
        (while obj
          (setq out (cons (cons (substring (symbol-name (car obj)) 1)
                                (transport-integration-probe-v0.3--json-normalize (cadr obj)))
                          out))
          (setq obj (cddr obj)))
        (nreverse out)))
     ((and (consp (car obj)) (stringp (caar obj)))
      (mapcar (lambda (pair)
                (cons (car pair)
                      (transport-integration-probe-v0.3--json-normalize (cdr pair))))
              obj))
     (t (apply #'vector (mapcar #'transport-integration-probe-v0.3--json-normalize obj)))))
   (t (prin1-to-string obj))))

(defun transport-integration-probe-v0.3--record (kind symbol args)
  "Record one event: KIND, SYMBOL, full ARGS (prin1), backtrace, identity."
  (push (list :kind kind
              :symbol symbol
              :args (mapcar #'prin1-to-string args)
              :backtrace (transport-integration-probe-v0.3--safe-backtrace)
              :identity (transport-integration-probe-v0.3--identity symbol))
        transport-integration-probe-v0.3--events))

;;; --- T3/T4 advice install/remove -------------------------------------------

(defun transport-integration-probe-v0.3--install-t3 ()
  "Install :around advice on T3 symbols: record, then call through."
  (dolist (s transport-integration-probe-v0.3--t3-symbols)
    (when (fboundp s)
      (let ((target s))            ; fresh lexical binding per round; the
        (let ((closure (lambda (orig &rest args)   ; closure must not capture
                         (transport-integration-probe-v0.3--record :t3 target args)
                         (apply orig args))))      ; the shared dolist var
          (puthash target closure transport-integration-probe-v0.3--advice-table)
          (advice-add target :around closure))))))

(defun transport-integration-probe-v0.3--install-t4 ()
  "Install :around advice on T4 primitives: record, mark hit, error.
Never calls the original function, so no process is ever created."
  (dolist (s transport-integration-probe-v0.3--t4-symbols)
    (when (fboundp s)
      (let ((target s))
        (let ((closure (lambda (_orig &rest args) ; _orig consumed, not logged
                         (setq transport-integration-probe-v0.3--t4-hit t)
                         (transport-integration-probe-v0.3--record :t4 target args)
                         (error "transport-integration-probe-v0.3: %s called; process creation blocked"
                                target))))
          (puthash target closure transport-integration-probe-v0.3--advice-table)
          (advice-add target :around closure))))))

(defun transport-integration-probe-v0.3--remove-advice ()
  "Remove every installed T3/T4 advice; never signals.
Returns the list of (symbol . closure) pairs still present per
advice-member-p after removal (empty means full removal)."
  (let (leftover)
    (maphash (lambda (symbol closure)
               (ignore-errors (advice-remove symbol closure))
               (when (advice-member-p closure symbol)
                 (push (cons symbol closure) leftover)))
             transport-integration-probe-v0.3--advice-table)
    (clrhash transport-integration-probe-v0.3--advice-table)
    leftover))

(defun transport-integration-probe-v0.3--cleanup ()
  "kill-emacs cleanup: kill probe buffers, cancel timer, remove advice/hook,
delete the temp dir, and record evidence into --cleanup-evidence.
Each claimed removal is re-verified (get-buffer / advice-member-p /
file-exists-p) before it is reported as done."
  (let ((temp-path transport-integration-probe-v0.3--temp-dir)
        (killed nil))
    ;; probe buffers: kill, then verify absence with get-buffer.
    (dolist (name '(" *superchat-b0-probe*" "*llm-log*"))
      (when (get-buffer name)
        (ignore-errors (kill-buffer name))
        (push name killed)))
    (when (timerp transport-integration-probe-v0.3--timer)
      (cancel-timer transport-integration-probe-v0.3--timer))
    (setq transport-integration-probe-v0.3--timer nil)
    ;; advice: remove, then verify each pair with advice-member-p.
    (setq transport-integration-probe-v0.3--advice-leftover
          (transport-integration-probe-v0.3--remove-advice))
    (remove-hook 'kill-emacs-hook #'transport-integration-probe-v0.3--cleanup)
    ;; temp dir: delete, then verify with file-exists-p on the saved path.
    (when temp-path
      (ignore-errors (delete-directory temp-path t)))
    (setq transport-integration-probe-v0.3--temp-dir nil)
    (setq transport-integration-probe-v0.3--cleanup-evidence
          (list :killed_buffers (nreverse killed)
                :buffers_absent
                (not (or (get-buffer " *superchat-b0-probe*")
                         (get-buffer "*llm-log*")))
                :timer_cancelled (null transport-integration-probe-v0.3--timer)
                :advice_removed (null transport-integration-probe-v0.3--advice-leftover)
                :hook_absent
                (not (memq 'transport-integration-probe-v0.3--cleanup kill-emacs-hook))
                :temp_dir_removed
                (or (null temp-path) (not (file-exists-p temp-path)))))))

;;; --- Implementation status ------------------------------------------------
;;; T1: DONE -- stream-mock + plz-block bound nil in let*, then built with
;;;     setq so each closure self-references its real lexical binding;
;;;     installed via cl-letf; mocks record args/identity, assert the current
;;;     function cell eq the saved object (stream-cell-eq / plz-cell-eq),
;;;     replay base's synthetic async callback order and return value.
;;; T2: DONE -- llm-chat-async / llm-request-plz-sync replaced by record+error
;;;     under the same cl-letf extent.
;;; T3/T4: DONE -- install-t3/remove-advice above.
;;; Identity of both T1 symbols recorded at extent-before / submit-before /
;;; mock-inside (stream or plz, per hit) / extent-after (after cl-letf fully
;;; exited).  Stream replay timer kept in --timer, cancelled by cleanup.
;;; One frozen-shape superchat-runtime-submit-blocking call (mirrors base
;;; 451-467); sc-b02-* temp data dir configured BEFORE (require superchat);
;;; 10-function fboundp gate; default DB + archive DB hash guards before/
;;; after; process-list detective before/after; all captured into variables.
;;; Verdict/report/launch: DONE -- --verdict, --build-report, --launch below:
;;; cleanup always, exactly one stdout JSON (same schema for success and
;;; fatal errors), kill-emacs 0/1.

;;; --- T1/T2: synthetic response, saved mocks, one frozen submit ------------

(defvar transport-integration-probe-v0.3--guards-before nil
  "Guards snapshot taken before the T1/T2 region.")
(defvar transport-integration-probe-v0.3--process-before nil
  "process-list snapshot before the T1/T2 region.")
(defvar transport-integration-probe-v0.3--process-after nil
  "process-list snapshot after the T1/T2 region.")
(defvar transport-integration-probe-v0.3--process-before-captured nil
  "Non-nil once --process-before holds a real snapshot (even if empty).")
(defvar transport-integration-probe-v0.3--process-after-captured nil
  "Non-nil once --process-after holds a real snapshot (even if empty).")
(defvar transport-integration-probe-v0.3--guards-after nil
  "Guards snapshot taken after the T1/T2 region.")
(defvar transport-integration-probe-v0.3--result nil
  "Captured T1/T2 run: :blocking_result, :blocking_error, :mock_hit,
:mock_partials, :final_string_count, :final_string_value, :stream_cell_eq,
:plz_hit, :plz_cell_eq, :t2_hits.  Captured only; adjudicated by --verdict.")
(defvar transport-integration-probe-v0.3--t1-identities nil
  "Identity of both T1 symbols at extent-before/submit-before/mock-inside/
extent-after.")

(defun transport-integration-probe-v0.3--synthetic-response ()
  "Return the ASCII, >500-byte, frozen-schema-valid synthetic response S.
Content is identical to base transport-integration-probe-v0--synthetic-response."
  (json-serialize
   (list :schema_version "closed-loop-evaluator-response-v1"
         :abstained :false
         :correction_fidelity
         (list :score 2 :label "fidelity-pass"
               :evidence (make-string 320 ?a))
         :research_quality
         (list :score 2 :label "accept"
               :evidence (make-string 320 ?b))
         :missing_evidence (vector))))

(defun transport-integration-probe-v0.3--record-t1-identity (timepoint)
  "Append the identity of both T1 symbols at TIMEPOINT."
  (push (list :timepoint timepoint
              :symbols (mapcar #'transport-integration-probe-v0.3--identity
                               transport-integration-probe-v0.3--t1-symbols))
        transport-integration-probe-v0.3--t1-identities))

(defun transport-integration-probe-v0.3--run-t1-t2 ()
  "T1/T2 region: saved stream-mock + plz-block under cl-letf, one
frozen-shape submit.  Captures into --result; never prints JSON, never
calls kill-emacs."
  (let* ((S (transport-integration-probe-v0.3--synthetic-response))
         (full-bytes (string-bytes (encode-coding-string S 'utf-8)))
         (backend (make-llm-ollama :chat-model transport-integration-probe-v0.3--model))
         (blocking-result nil)
         (blocking-error nil)
         (mock-hit nil)
         (plz-hit nil)
         (t2-hits nil)
         (stream-cell-eq nil)
         (plz-cell-eq nil)
         (mock-partials nil)
         (final-string-count 0)
         (final-string-value nil)
         (stream-mock nil)
         (plz-block nil))
    ;; (1) closures built via setq AFTER the let* bindings exist, so each
    ;; closure's self-reference captures the real lexical binding (a let*
    ;; init form cannot self-reference its own binding).
    (setq stream-mock
          (lambda (provider prompt partial-callback response-callback
                            error-callback &optional multi-output)
            (setq mock-hit t)
            ;; (C1) record args/identity first.
            (transport-integration-probe-v0.3--record
             :t1-stream 'llm-chat-streaming
             (list provider prompt partial-callback response-callback
                   error-callback multi-output))
            (transport-integration-probe-v0.3--record-t1-identity
             "mock-inside/stream")
            ;; (C2) the current function cell must be the saved mock object.
            (setq stream-cell-eq
                  (eq (symbol-function 'llm-chat-streaming) stream-mock))
            ;; (C3) base synthetic async callback order and return value.
            (setq mock-partials (list 100 300 full-bytes))
            (setq transport-integration-probe-v0.3--timer
                  (run-at-time 0 nil
                               (lambda ()
                                 (funcall partial-callback (substring S 0 100))
                                 (funcall partial-callback (substring S 0 300))
                                 (funcall partial-callback S)
                                 (setq final-string-count (1+ final-string-count))
                                 (setq final-string-value S)
                                 (funcall response-callback S))))
            (list :synthetic t)))
    (setq plz-block
          (lambda (&rest args)
            (setq plz-hit t)
            ;; record full args/identity first.
            (transport-integration-probe-v0.3--record
             :t1-plz 'llm-request-plz-async args)
            (transport-integration-probe-v0.3--record-t1-identity
             "mock-inside/plz")
            ;; the current function cell must be the saved block object.
            (setq plz-cell-eq
                  (eq (symbol-function 'llm-request-plz-async) plz-block))
            ;; Base original error text, kept verbatim.
            (error "network blocked in transport-integration-probe-v0")))
    (transport-integration-probe-v0.3--record-t1-identity "extent-before")
    ;; (E) Runtime dynamic isolation, copied from base 369-384.
    (let ((superchat-llm-backend backend)
          (superchat-llm-model nil)
          (superchat-llm-reasoning 'none)
          (superchat-runtime--runs (make-hash-table :test #'equal))
          (superchat-buffer-name " *superchat-b0-probe*")
          (superchat--active-timeout-timer nil)
          (superchat-pre-topic-finalized-functions nil)
          (superchat-post-turn-functions nil)
          (superchat-post-topic-finalized-functions nil)
          (superchat-run-completed-functions nil)
          (superchat-turn-completed-functions nil)
          (superchat-closure-shadow-enabled nil)
          (superchat-closure-terminal-guard-enabled nil)
          (superchat-closure-shadow-functions nil)
          (superchat-runtime--closure-observations nil))
      ;; (B) cl-letf transport replacement: T1 mock/block, T2 record+error.
      (cl-letf (((symbol-function 'llm-chat-streaming) stream-mock)
                ((symbol-function 'llm-request-plz-async) plz-block)
                ((symbol-function 'llm-chat-async)
                 (lambda (&rest args)
                   (push 'llm-chat-async t2-hits)
                   (transport-integration-probe-v0.3--record :t2 'llm-chat-async args)
                   (error "transport-integration-probe-v0.3: llm-chat-async called; sync transport blocked")))
                ((symbol-function 'llm-request-plz-sync)
                 (lambda (&rest args)
                   (push 'llm-request-plz-sync t2-hits)
                   (transport-integration-probe-v0.3--record :t2 'llm-request-plz-sync args)
                   (error "transport-integration-probe-v0.3: llm-request-plz-sync called; sync transport blocked"))))
        (transport-integration-probe-v0.3--record-t1-identity "submit-before")
        ;; (E) one frozen-shape submit, mirroring base 451-467.
        (setq blocking-result
              (condition-case err
                  (superchat-runtime-submit-blocking
                   (list :prompt "Phase B0 integration probe input."
                         :session-id "b0-probe-session"
                         :buffer-name " *superchat-b0-probe*"
                         :ephemeral-buffer t
                         :record-conversation nil
                         :type :llm-query
                         :tools 'none
                         :topology 'single
                         :authority-policy "default"
                         :preset (superchat-preset--create
                                  :name "b0"
                                  :max-tokens 2048
                                  :reasoning 'none
                                  :tools 'none)
                         :target-model transport-integration-probe-v0.3--model
                         :timeout transport-integration-probe-v0.3--timeout))
                (error (setq blocking-error (error-message-string err)) nil))))
    ;; (3) extent-after identity is taken after cl-letf has fully exited, so
    ;; the function cells are the real product functions again.
    (transport-integration-probe-v0.3--record-t1-identity "extent-after"))
    ;; (F) capture only: no verdict, no JSON, no kill-emacs.
    (setq transport-integration-probe-v0.3--result
          (list :blocking_result blocking-result
                :blocking_error blocking-error
                :mock_hit mock-hit
                :mock_partials mock-partials
                :final_string_count final-string-count
                :final_string_value final-string-value
                :stream_cell_eq stream-cell-eq
                :plz_hit plz-hit
                :plz_cell_eq plz-cell-eq
                :t2_hits (nreverse t2-hits)))))

;;; --- Verdict, report, and launch ------------------------------------------

(defun transport-integration-probe-v0.3--new-processes ()
  "Return after-snapshot entries whose name+command pair is new.
Status changes of pre-existing processes are not new processes.  When
either snapshot was not captured, return the string \"not_proved\";
captured-but-empty snapshots compare normally (no new processes)."
  (let ((before transport-integration-probe-v0.3--process-before)
        (after transport-integration-probe-v0.3--process-after))
    (if (and transport-integration-probe-v0.3--process-before-captured
             transport-integration-probe-v0.3--process-after-captured)
        (cl-remove-if
         (lambda (entry)
           (cl-member (list (plist-get entry :name) (plist-get entry :command))
                      before
                      :key (lambda (e)
                             (list (plist-get e :name) (plist-get e :command)))
                      :test #'equal))
         after)
      "not_proved")))

(defun transport-integration-probe-v0.3--verdict ()
  "Strict verdict over :mock_hit and the T4 hit flag.
non-reproduction | third-path | mock-failure-reproduced | inconclusive."
  (let ((mock-hit (plist-get transport-integration-probe-v0.3--result :mock_hit)))
    (cond
     ((and mock-hit (not transport-integration-probe-v0.3--t4-hit))
      "non-reproduction")
     ((and mock-hit transport-integration-probe-v0.3--t4-hit)
      "third-path")
     ((and (not mock-hit) transport-integration-probe-v0.3--t4-hit)
      "mock-failure-reproduced")
     (t "inconclusive"))))

(defun transport-integration-probe-v0.3--cleanup-complete-p ()
  "Non-nil when cleanup ran and every tracked resource is verifiably gone.
Checks the re-verified evidence fields only."
  (let ((ev transport-integration-probe-v0.3--cleanup-evidence))
    (and ev
         (plist-get ev :buffers_absent)
         (plist-get ev :timer_cancelled)
         (plist-get ev :advice_removed)
         (plist-get ev :hook_absent)
         (plist-get ev :temp_dir_removed))))

(defun transport-integration-probe-v0.3--archive-verified-p ()
  "Non-nil when the archive DB hash equals the frozen expected value both
before and after, and the guards snapshots are unchanged."
  (let* ((guards-before transport-integration-probe-v0.3--guards-before)
         (guards-after transport-integration-probe-v0.3--guards-after)
         (before-hash
          (and guards-before
               (plist-get (plist-get guards-before :archive_db) :hash)))
         (after-hash
          (and guards-after
               (plist-get (plist-get guards-after :archive_db) :hash))))
    (and (equal guards-before guards-after)
         (equal before-hash transport-integration-probe-v0.3--archive-db-hash)
         (equal after-hash transport-integration-probe-v0.3--archive-db-hash))))

(defun transport-integration-probe-v0.3--exit-code (fatal-error)
  "Exit 0 only for complete non-reproduction; every finding/failure exits 1."
  (if (and (null fatal-error)
           (equal (transport-integration-probe-v0.3--verdict) "non-reproduction")
           (equal transport-integration-probe-v0.3--guards-before
                  transport-integration-probe-v0.3--guards-after)
           (transport-integration-probe-v0.3--archive-verified-p)
           (transport-integration-probe-v0.3--cleanup-complete-p))
      0
    1))

(defun transport-integration-probe-v0.3--build-report (fatal-error)
  "Assemble the full result report plist (same schema on success and error)."
  (let* ((guards-before transport-integration-probe-v0.3--guards-before)
         (guards-after transport-integration-probe-v0.3--guards-after)
         (guards-unchanged (equal guards-before guards-after))
         (archive-before-hash
          (and guards-before
               (plist-get (plist-get guards-before :archive_db) :hash))))
    (list :schema_version
          "closed-loop-experience-correction-v0/transport-integration-probe-v0.3-result"
          :probe "transport-integration-probe-v0.3"
          :throwaway t
          :execution_authorized :json-false
          :STOP-2 "Superchat integration open"
          :STOP-3 "UTF-8 decision open"
          :measurement_claim "none"
          :byte_fidelity_claim "none"
          :frozen_shas (list :audit transport-integration-probe-v0.3--audit-sha256
                             :base transport-integration-probe-v0.3--base-sha256
                             :wrapper transport-integration-probe-v0.3--wrapper-sha256
                             :v0.2_source
                             transport-integration-probe-v0.3--predecessor-source-sha256
                             :v0.2_result
                             transport-integration-probe-v0.3--predecessor-result-sha256)
          :guards (list :before guards-before
                        :after guards-after
                        :unchanged guards-unchanged)
          :archive (list :expected transport-integration-probe-v0.3--archive-db-hash
                         :present (not (null archive-before-hash))
                         :verified (transport-integration-probe-v0.3--archive-verified-p))
          :processes (list :before transport-integration-probe-v0.3--process-before
                           :after transport-integration-probe-v0.3--process-after
                           :new (transport-integration-probe-v0.3--new-processes))
          :events (nreverse transport-integration-probe-v0.3--events)
          :t1_identities (nreverse transport-integration-probe-v0.3--t1-identities)
          :t1_t2_result transport-integration-probe-v0.3--result
          :t4_hit transport-integration-probe-v0.3--t4-hit
          :verdict (transport-integration-probe-v0.3--verdict)
          :cleanup (or transport-integration-probe-v0.3--cleanup-evidence
                       "not_proved")
          :cleanup_complete (transport-integration-probe-v0.3--cleanup-complete-p)
          :provenance
          (list :predecessor_probe "v0.2"
                :predecessor_source_sha256
                transport-integration-probe-v0.3--predecessor-source-sha256
                :predecessor_result_sha256
                transport-integration-probe-v0.3--predecessor-result-sha256
                :harness_fix "explicit require llm-ollama after superchat"
                :not_retry t
                :executor_comparison "inconclusive"
                :executor_comparison_note
                "Luna produced two zero-output stalls; no model-capability judgment possible"
                :recovery_executor "Pi"
                :recovery_executor_note
                "Pi executed the recovery that produced this v0.2 diagnostic")
          :fatal_error (or fatal-error "none")
          :not_proved (vector "measurement" "byte_fidelity"))))

(defun transport-integration-probe-v0.3--launch ()
  "Run the diagnostic: always cleanup, exactly one stdout JSON, then exit.
Sole caller is the run command in the header."
  (let (fatal-error)
    ;; reset global evidence for a fresh run
    (setq transport-integration-probe-v0.3--events nil
          transport-integration-probe-v0.3--t4-hit nil
          transport-integration-probe-v0.3--advice-table
          (make-hash-table :test #'eq)
          transport-integration-probe-v0.3--advice-leftover nil
          transport-integration-probe-v0.3--temp-dir nil
          transport-integration-probe-v0.3--timer nil
          transport-integration-probe-v0.3--cleanup-evidence nil
          transport-integration-probe-v0.3--guards-before nil
          transport-integration-probe-v0.3--process-before nil
          transport-integration-probe-v0.3--process-after nil
          transport-integration-probe-v0.3--process-before-captured nil
          transport-integration-probe-v0.3--process-after-captured nil
          transport-integration-probe-v0.3--guards-after nil
          transport-integration-probe-v0.3--result nil
          transport-integration-probe-v0.3--t1-identities nil)
    (let ((guards-before (transport-integration-probe-v0.3--guards-snapshot)))
      (setq transport-integration-probe-v0.3--guards-before guards-before)
      (unwind-protect
          (condition-case err
              (progn
                ;; sc-b02-* temp isolation BEFORE (require 'superchat):
                ;; product-load effects must not touch the default data dir.
                (setq transport-integration-probe-v0.3--temp-dir
                      (make-temp-file "sc-b02-" t))
                (setq superchat-data-directory
                      (expand-file-name "data"
                                        transport-integration-probe-v0.3--temp-dir))
                (make-directory superchat-data-directory t)
                (add-hook 'kill-emacs-hook #'transport-integration-probe-v0.3--cleanup)
                (require 'superchat)
                (require 'llm-ollama)
                (transport-integration-probe-v0.3--assert-frozen)
                (transport-integration-probe-v0.3--assert-functions)
                (transport-integration-probe-v0.3--install-t4)
                (transport-integration-probe-v0.3--install-t3)
                ;; T1/T2 region with T3/T4 installed across it.
                (setq transport-integration-probe-v0.3--process-before
                      (transport-integration-probe-v0.3--process-snapshot))
                (setq transport-integration-probe-v0.3--process-before-captured t)
                (transport-integration-probe-v0.3--run-t1-t2)
                (setq transport-integration-probe-v0.3--process-after
                      (transport-integration-probe-v0.3--process-snapshot))
                (setq transport-integration-probe-v0.3--process-after-captured t)
                (setq transport-integration-probe-v0.3--guards-after
                      (transport-integration-probe-v0.3--guards-snapshot)))
            (error (setq fatal-error (error-message-string err))))
        ;; cleanup on success AND error paths; a failing cleanup must not
        ;; suppress the report.
        (condition-case err
            (transport-integration-probe-v0.3--cleanup)
          (error
           (setq fatal-error
                 (concat (or fatal-error "cleanup failed: ")
                         (error-message-string err))))))
      ;; after-snapshots may have been skipped by an error: take them now.
      (unless transport-integration-probe-v0.3--process-after-captured
        (setq transport-integration-probe-v0.3--process-after
              (transport-integration-probe-v0.3--process-snapshot))
        (setq transport-integration-probe-v0.3--process-after-captured t))
      (unless transport-integration-probe-v0.3--guards-after
        (setq transport-integration-probe-v0.3--guards-after
              (transport-integration-probe-v0.3--guards-snapshot)))
      ;; exactly one stdout JSON, then exit 0/1.
      (condition-case err
          (let ((report (transport-integration-probe-v0.3--build-report fatal-error)))
            (princ (json-encode
                    (transport-integration-probe-v0.3--json-normalize report)))
            (terpri)
            (kill-emacs (transport-integration-probe-v0.3--exit-code fatal-error)))
        (error
         ;; minimal same-schema fallback; never a half-printed line.
         (princ
          (format (concat "{\"schema_version\":\"closed-loop-experience-"
                          "correction-v0/transport-integration-probe-v0.3-result\","
                          "\"probe\":\"transport-integration-probe-v0.3\","
                          "\"throwaway\":true,\"execution_authorized\":false,"
                          "\"STOP-2\":\"Superchat integration open\","
                          "\"STOP-3\":\"UTF-8 decision open\","
                          "\"verdict\":\"inconclusive\","
                          "\"fatal_error\":%s,\"not_proved\":[\"report\"]}")
                  (json-encode-string (error-message-string err))))
         (terpri)
         (kill-emacs 1))))))

(provide 'transport-integration-probe-v0.3)

;;; transport-integration-probe-v0.3.el ends here
