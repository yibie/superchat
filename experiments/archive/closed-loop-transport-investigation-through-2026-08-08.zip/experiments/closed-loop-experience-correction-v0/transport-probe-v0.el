;;; transport-probe-v0.el --- Throwaway transport qualification prototype -*- lexical-binding: t; -*-

;; Problem: the frozen next-measurement contract keeps execution_authorized
;; false because provider transport capability is unproven.  This throwaway
;; prototype probes whether the real llm 0.31.1 path (curl subprocess ->
;; plz-media-type NDJSON filter -> JSON decode -> llm streaming callback)
;; behaves correctly against a LOCAL fake Ollama HTTP server on 127.0.0.1.
;; No real Ollama, no external network, no superchat, no Runtime, no product
;; file is touched; it only reads the contract JSON (frozen bytes) and the
;; archive DB path it names.

;; THROWAWAY: this file is an experiment-local self-check, not a product file.
;; Nothing loads it; it may be deleted.  Do not require it from product code.

;; Run (single command, absolute -L paths):
;;   emacs -Q --batch -L . \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/llm-0.31.1 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-0.9.1 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-event-source-0.1.3 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-media-type-0.2.4 \
;;     -l experiments/closed-loop-experience-correction-v0/transport-probe-v0.el

;;; Code:

(require 'cl-lib)
(require 'eieio)
(require 'json)
(require 'seq)
(require 'subr-x)

(defconst transport-probe-v0--directory
  (file-name-directory (or load-file-name buffer-file-name)))

(defconst transport-probe-v0--contract-path
  (expand-file-name "next-measurement-contract-v0.json"
                    transport-probe-v0--directory))

(defconst transport-probe-v0--elpa-root
  "/Users/chenyibin/.config/nova-emacs/elpa")

(defconst transport-probe-v0--llm-dir
  (expand-file-name "llm-0.31.1" transport-probe-v0--elpa-root))

(defconst transport-probe-v0--plz-dir
  (expand-file-name "plz-0.9.1" transport-probe-v0--elpa-root))

(defconst transport-probe-v0--plz-event-source-dir
  (expand-file-name "plz-event-source-0.1.3" transport-probe-v0--elpa-root))

(defconst transport-probe-v0--plz-media-type-dir
  (expand-file-name "plz-media-type-0.2.4" transport-probe-v0--elpa-root))

(defconst transport-probe-v0--tee-buffer-name "*transport-probe-v0-tee*")
(defconst transport-probe-v0--timeout 8)
(defconst transport-probe-v0--chat-model "transport-probe-v0-model")

(defvar transport-probe-v0--contract nil)
(defvar transport-probe-v0--response-format nil)
(defvar transport-probe-v0--archive-db-path nil)
(defvar transport-probe-v0--tee-active nil
  "Non-nil while one probe llm-chat-streaming request is in flight.")
(defvar transport-probe-v0--tee-port nil
  "Server port of the in-flight probe request, for tee gating.")

;;; --- Contract loading (read-only) and source dependency loading ----------

(defun transport-probe-v0--read-json-file (path &rest parse-args)
  "Read PATH as JSON with PARSE-ARGS passed to json-parse-buffer."
  (with-temp-buffer
    (insert-file-contents path)
    (apply #'json-parse-buffer parse-args)))

(defun transport-probe-v0--load-sources ()
  "Load the frozen llm 0.31.1 / plz dependency SOURCES in dependency order.
Loading .el sources (not the .elc) matches the hashes frozen in the
contract.  Errors propagate as blocker evidence."
  (dolist (file (list
                 (expand-file-name "plz.el" transport-probe-v0--plz-dir)
                 (expand-file-name "plz-media-type.el" transport-probe-v0--plz-media-type-dir)
                 (expand-file-name "plz-event-source.el" transport-probe-v0--plz-event-source-dir)
                 (expand-file-name "llm.el" transport-probe-v0--llm-dir)
                 (expand-file-name "llm-models.el" transport-probe-v0--llm-dir)
                 (expand-file-name "llm-request-plz.el" transport-probe-v0--llm-dir)
                 (expand-file-name "llm-provider-utils.el" transport-probe-v0--llm-dir)
                 (expand-file-name "llm-ollama.el" transport-probe-v0--llm-dir)))
    (load file)))

(defvar transport-probe-v0--source-load-evidence nil
  "Evidence when loading dependency .el sources was infeasible.")

(defun transport-probe-v0--load-dependencies ()
  "Load dependencies, preferring the frozen .el sources.
When source loading is infeasible under this batch environment, record the
minimal failure evidence and fall back to the release-compiled .elc artifacts
of the same versions so the transport path can still be measured."
  (condition-case err
      (transport-probe-v0--load-sources)
    (error
     (setq transport-probe-v0--source-load-evidence (error-message-string err))
     (dolist (feature '(plz plz-media-type plz-event-source llm llm-models
                            llm-request-plz llm-provider-utils llm-ollama))
       (require feature)))))

(defun transport-probe-v0--hash-file (path)
  "Return the sha256 hex of the file at PATH, or nil when unreadable."
  (when (file-readable-p path)
    (with-temp-buffer
      (insert-file-contents path)
      (secure-hash 'sha256 (current-buffer)))))

(defun transport-probe-v0--llm-pkg-version ()
  "Return the version declared by the loaded llm package descriptor."
  (with-temp-buffer
    (insert-file-contents (expand-file-name "llm-pkg.el" transport-probe-v0--llm-dir))
    (when (re-search-forward "define-package \"llm\" \"\\([0-9.]+\\)\"" nil t)
      (match-string 1))))

(defun transport-probe-v0--locate-el (library)
  "Return the absolute .el path for LIBRARY on the load path, or nil."
  (locate-file (concat library ".el") load-path))

(defun transport-probe-v0--load-contract ()
  "Read the frozen contract into variables (plist object type).
Arrays stay as vectors (:array-type 'array): llm-provider-utils-
convert-to-serializable then passes them through unchanged instead of
partitioning them as plists."
  (setq transport-probe-v0--contract
        (transport-probe-v0--read-json-file
         transport-probe-v0--contract-path
         :object-type 'plist :array-type 'array
         :null-object nil :false-object :json-false))
  (setq transport-probe-v0--response-format
        (plist-get (plist-get transport-probe-v0--contract :evaluator)
                   :response_schema))
  (setq transport-probe-v0--archive-db-path
        (plist-get
         (plist-get (plist-get transport-probe-v0--contract :v0_4_diagnosis_addendum)
                    :tape_outcome_equality)
         :archive_session_path)))

;;; --- Raw body octet tee (advice, gated, unwind-protect removed) ----------

(defvar transport-probe-v0--matrix-guard-errors nil
  "Errors captured by the split-matrix measurement guard.")

(defun transport-probe-v0--matrix-guard (orig process media-types string)
  "Split-matrix measurement :around guard for the plz media-type filter.
Installed ONLY around the split-matrix loop.  Byte-level splits inside a
multibyte UTF-8 character make the real filter path signal an error; in
batch mode an uncaught process-filter error terminates the run, so this
guard catches it to let the matrix record the loss.  It CHANGES error
propagation and is used for observation only; it is not a re-split or
re-decode shim.  Captured errors carry their type and stage."
  (condition-case e
      (funcall orig process media-types string)
    (error
     (push (list :error (error-message-string e)
                 :stage :filter
                 :process (process-name process))
           transport-probe-v0--matrix-guard-errors)
     nil)))

(defun transport-probe-v0--record-split-decode-crash (guard-errors)
  "Record the observed split-matrix filter errors as a finding.
Only fires when GUARD-ERRORS is non-empty; the evidence is built from the
actual captured errors (type/stage), so zero errors produce no finding."
  (when guard-errors
    (push (cons "split-matrix-filter-error"
                (list :status "observed"
                      :errors (mapcar (lambda (e) (plist-get e :error))
                                      guard-errors)
                      :stages (mapcar (lambda (e) (substring (symbol-name (plist-get e :stage)) 1))
                                      guard-errors)
                      :evidence "byte-level splits inside a multibyte UTF-8 character make the real filter path signal an error; the split-matrix measurement guard (installed only around the matrix loop, changing error propagation for observation only) captured type/stage and let the loss be measured; no re-split or re-decode shim"))
          transport-probe-v0--failures)))

(defun transport-probe-v0--tee-raw (process _media-types string)
  "Append raw response octets from PROCESS to the tee buffer.
Gated: only while a probe request is in flight AND the plz process targets
the probe's local server port.  Bytes are captured before any JSON decode."
  (when (and transport-probe-v0--tee-active
             (processp process)
             (let* ((args (process-get process :plz-args))
                    (url (and (listp args) (nth 1 args))))
               (and (stringp url)
                    (string-match-p
                     (format "127\\.0\\.0\\.1:%d" transport-probe-v0--tee-port)
                     url))))
    (with-current-buffer (get-buffer-create transport-probe-v0--tee-buffer-name)
      (set-buffer-multibyte nil)
      (goto-char (point-max))
      (insert string))))

;;; --- Local fake Ollama HTTP server ---------------------------------------

(defun transport-probe-v0--make-server (response-body &rest options)
  "Create a local HTTP server answering RESPONSE-BODY.
OPTIONS plist:
 :content-length -- override the Content-Length header (premature close case)
 :split-at       -- send the body in two writes, pausing at SPLIT-AT bytes
 :status-line    -- HTTP status line, default \"HTTP/1.1 200 OK\"
Returns a state plist (:server :port :response-bytes :request-bytes
:request-body :content-length :split-at :status-line)."
  (let* ((state (list :response-bytes response-body
                      :request-bytes nil :request-body nil
                      :content-length (plist-get options :content-length)
                      :split-at (plist-get options :split-at)
                      :status-line (or (plist-get options :status-line)
                                       "HTTP/1.1 200 OK")))
         (server
          (make-network-process
           :name "transport-probe-v0-server"
           :server t
           :host "127.0.0.1"
           :service 0
           :family 'ipv4
           :noquery t
           :filter (lambda (client string)
                     (condition-case nil
                         (transport-probe-v0--handle-request state client string)
                       (error nil))))))
    (setf (plist-get state :server) server)
    (setf (plist-get state :port) (process-contact server :service))
    state))

(defun transport-probe-v0--handle-request (state client string)
  "Accumulate the HTTP request on CLIENT and respond when complete.
Guarded against late filter calls on a closed connection (the response
path deletes CLIENT after sending; a trailing data chunk must not touch
the dead process)."
  (when (eq 'open (process-status client))
    (unless (process-get client :transport-probe-v0-ready)
      (set-process-coding-system client 'utf-8-unix 'utf-8-unix)
      (process-put client :transport-probe-v0-ready t))
    (unless (string-empty-p string)
    (let ((acc (or (process-get client :transport-probe-v0-acc)
                   (progn (process-put client :transport-probe-v0-acc
                                       (list :bytes "" :expected nil :rest ""))
                          (process-get client :transport-probe-v0-acc)))))
      (setf (plist-get acc :bytes) (concat (plist-get acc :bytes) string))
      (let ((bytes (plist-get acc :bytes)))
        (when (and (null (plist-get acc :expected))
                   (string-match "\r\n\r\n" bytes))
          (let* ((end (match-end 0))
                 (headers (substring bytes 0 (match-beginning 0)))
                 (clen (when (string-match "Content-Length: *\\([0-9]+\\)" headers)
                         (string-to-number (match-string 1 headers)))))
            (setf (plist-get acc :expected) (or clen 0))
            (setf (plist-get acc :rest) (substring bytes end))))
        (when (and (plist-get acc :expected)
                   (>= (length (plist-get acc :rest))
                       (plist-get acc :expected)))
          (setf (plist-get state :request-bytes) bytes)
          (setf (plist-get state :request-body)
                (substring (plist-get acc :rest) 0 (plist-get acc :expected)))
          (transport-probe-v0--send-response state client)))))))

(defun transport-probe-v0--send-response (state client)
  "Send the scripted HTTP response to CLIENT.
The split-at offset is a BYTE offset into the utf-8 encoded body, so the
matrix exercises true byte-level splits including mid-multibyte cuts.  The
connection is NOT deleted here: the peer closes after EOF and late filter
calls are guarded; leftover processes are reaped by --cleanup-processes."
  (when (eq 'open (process-status client))
    (let* ((body (string-to-unibyte (plist-get state :response-bytes)))
           (clen (or (plist-get state :content-length) (length body)))
           (head (concat (plist-get state :status-line) "\r\n"
                         "Content-Type: application/x-ndjson\r\n"
                         (format "Content-Length: %d\r\n" clen)
                         "Connection: close\r\n\r\n")))
      (if (plist-get state :split-at)
          (progn
            (process-send-string client (concat head (substring body 0 (plist-get state :split-at))))
            (sleep-for 0.05)
            (process-send-string client (substring body (plist-get state :split-at))))
        (process-send-string client (concat head body)))
      (delete-process client))))

;;; --- Canonical JSON (normalized schema hash) ------------------------------

(defun transport-probe-v0--canonical-key (key)
  "Return KEY as a string for canonical JSON (symbol keys allowed)."
  (if (symbolp key) (symbol-name key) key))

(defun transport-probe-v0--canonical-json (object)
  "Return a canonical JSON string for OBJECT (alist objects, list arrays).
Object keys are sorted recursively; this is the normalization used for the
request_response_schema_sha256 computed from the actual request body."
  (cond
   ((eq object :null) "null")
   ((null object) "null")
   ((stringp object) (json-encode-string object))
   ((numberp object) (number-to-string object))
   ((eq object t) "true")
   ((eq object :json-false) "false")
   ((consp object)
    (if (and (consp (car object)) (not (consp (caar object))))
        ;; alist: pairs whose keys are symbols/strings, not lists
        (concat "{"
                (mapconcat
                 (lambda (pair)
                   (concat (json-encode-string
                            (transport-probe-v0--canonical-key (car pair)))
                           ":"
                           (transport-probe-v0--canonical-json (cdr pair))))
                 (sort (copy-sequence object)
                       (lambda (left right)
                         (string< (transport-probe-v0--canonical-key (car left))
                                  (transport-probe-v0--canonical-key (car right)))))
                 ",")
                "}")
      ;; array (possibly of objects)
      (concat "["
              (mapconcat #'transport-probe-v0--canonical-json object ",")
              "]")))
   (t (json-encode-string (format "%S" object)))))

(defun transport-probe-v0--sha256 (string)
  "Return the sha256 hex of STRING's bytes."
  (secure-hash 'sha256 (encode-coding-string string 'utf-8)))

;;; --- Tee parsing (provider records derived from raw body) -----------------

(defun transport-probe-v0--tee-total ()
  "Return the full raw response captured in the tee buffer (unibyte)."
  (when (get-buffer transport-probe-v0--tee-buffer-name)
    (with-current-buffer (get-buffer transport-probe-v0--tee-buffer-name)
      (buffer-string))))

(defun transport-probe-v0--tee-body (total)
  "Return the body portion of the raw tee TOTAL (after the header block)."
  (if (string-match "\r\n\r\n" total)
      (substring total (match-end 0))
    total))

(defun transport-probe-v0--parse-json-alist (string)
  "Parse STRING as JSON into alist objects and list arrays."
  (json-parse-string string :object-type 'alist :array-type 'list
                     :null-object :null :false-object :json-false))

(defun transport-probe-v0--parse-events (body)
  "Parse NDJSON BODY into a list of alist events.
Consumes only newline-terminated complete lines, matching the plz
x-ndjson line semantics: a final segment without a trailing newline is
dropped whether or not it parses as JSON, so a mid-line premature close
never raises here and cannot mask the real llm/curl callbacks."
  (let* ((ends-with-newline (string-suffix-p "\n" body))
         (lines (split-string body "\n" t))
         (complete-lines (if ends-with-newline lines (butlast lines)))
         events)
    (dolist (line complete-lines)
      (unless (string-empty-p (string-trim line))
        (condition-case nil
            (push (transport-probe-v0--parse-json-alist line) events)
          (json-parse-error nil)
          (json-end-of-file nil))))
    (nreverse events)))

(defun transport-probe-v0--provider-records (body)
  "Derive the probe-visible provider record from the raw NDJSON BODY.
Returns a plist with :done :done_reason :prompt_eval_count :eval_count
:error_events and :content_events.  NOTE: this Emacs's json-parse-string
with :object-type 'alist returns SYMBOL keys, so alist keys are symbols."
  (let ((events (transport-probe-v0--parse-events body))
        (content 0) (error-events 0) done done-reason pe ec)
    (dolist (event events)
      (when (alist-get 'content (alist-get 'message event))
        (cl-incf content))
      (when (alist-get 'error event)
        (cl-incf error-events))
      (setq done (alist-get 'done event)
            done-reason (alist-get 'done_reason event)
            pe (or pe (alist-get 'prompt_eval_count event))
            ec (or ec (alist-get 'eval_count event))))
    (list :content_events content :error_events error-events
          :done done :done_reason done-reason
          :prompt_eval_count pe :eval_count ec)))

;;; --- Single llm-chat-streaming run against a server -----------------------

(defun transport-probe-v0--make-provider (port)
  "Return an llm-ollama provider pointed at the local server PORT.
llm-ollama is a cl-defstruct, so its constructor is make-llm-ollama."
  (make-llm-ollama :host "127.0.0.1" :port port
                   :chat-model transport-probe-v0--chat-model))

(defun transport-probe-v0--make-prompt ()
  "Return the probe chat prompt (max-tokens drives options.num_predict).
The frozen evaluator response_schema is passed as :response-format; with
:array-type 'array the schema's arrays stay vectors and serialize fine."
  (llm-make-chat-prompt "Transport probe question."
                        :max-tokens 64
                        :response-format transport-probe-v0--response-format))

(defun transport-probe-v0--wait (state &optional timeout)
  "Wait until STATE is settled or TIMEOUT seconds pass.  Returns settled-p.
A non-fatal error surfaced from a process filter is recorded in STATE's
:filter-errors and the wait continues, so a stray filter error never masks
the real llm/curl callbacks."
  (let ((deadline (+ (float-time) (or timeout transport-probe-v0--timeout))))
    (while (and (not (plist-get state :settled))
                (< (float-time) deadline))
      (condition-case e
          (accept-process-output nil 0.05)
        (error
         (push (list :error (error-message-string e)) (plist-get state :filter-errors)))))
    (plist-get state :settled)))

(defun transport-probe-v0--run-request (server-state)
  "Run one llm-chat-streaming against SERVER-STATE.
Returns (list :settled :status :final :error :partials :tee)."
  (let* ((state (list :partials nil :final nil :error nil :settled nil
                      :status nil :filter-errors nil))
         (tee (get-buffer-create transport-probe-v0--tee-buffer-name)))
    (with-current-buffer tee
      (set-buffer-multibyte nil)
      (erase-buffer))
    (setq transport-probe-v0--tee-active t
          transport-probe-v0--tee-port (plist-get server-state :port))
    (unwind-protect
        (progn
          (let ((llm-log nil))
            (llm-chat-streaming
             (transport-probe-v0--make-provider (plist-get server-state :port))
             (transport-probe-v0--make-prompt)
             (lambda (text) (push text (plist-get state :partials)))
             (lambda (text)
               (setf (plist-get state :final) text)
               (setf (plist-get state :status) 'done)
               (setf (plist-get state :settled) t))
             (lambda (type err)
               (setf (plist-get state :error) (list type err))
               (setf (plist-get state :status) 'error)
               (setf (plist-get state :settled) t))))
          (transport-probe-v0--wait state))
      (setq transport-probe-v0--tee-active nil
            transport-probe-v0--tee-port nil))
    (setq state (plist-put state :tee (transport-probe-v0--tee-total)))
    state))

(defun transport-probe-v0--erase-tee ()
  "Erase the tee buffer (per-case fresh capture)."
  (when (get-buffer transport-probe-v0--tee-buffer-name)
    (with-current-buffer (get-buffer transport-probe-v0--tee-buffer-name)
      (erase-buffer))))

;;; --- Recording results ----------------------------------------------------

(defvar transport-probe-v0--failures nil
  "List of (case-name . evidence) failures collected by the probe.")

(defvar transport-probe-v0--notes nil
  "List of (note-id . detail) informational notes (not failures).")

(defconst transport-probe-v0--benign-timer-functions
  '(undo-auto--boundary-timer)
  "Emacs core timer functions that may legitimately exist during the probe.
undo-auto--boundary-timer: owner = Emacs core undo-auto; benign = undo
boundary bookkeeping only, created when buffers are modified.")

(defun transport-probe-v0--record-schema-blocker ()
  "Record the response-format 'json shorthand failure as a note.
The 'json symbol form becomes the keyword :json which json-serialize
rejects before any HTTP request is sent; that is informational and goes to
notes, not failures.  The structured frozen schema is verified serializable
here (arrays are vectors with :array-type 'array); a schema failure would
still be recorded as a failure."
  (when (featurep 'llm-ollama)
    (condition-case err
        (json-serialize (list :format :json))
      (error
       (push (cons "response-format-json-shorthand"
                   (list :status "blocked-shorthand-only"
                         :detail (error-message-string err)
                         :note "the 'json response-format shorthand is rejected by json-serialize on this Emacs; the structured schema form is used instead and is not affected"))
             transport-probe-v0--notes)))
    (when transport-probe-v0--response-format
      (condition-case err
          (json-serialize
           (list :format
                 (llm-provider-utils-convert-to-serializable
                  transport-probe-v0--response-format)))
        (error
         (push (cons "response-format-schema"
                     (list :status "blocked"
                           :evidence (error-message-string err)))
               transport-probe-v0--failures))))))

(defun transport-probe-v0--expect (case-name condition &rest evidence)
  "Record a failure for CASE-NAME when CONDITION is nil, with EVIDENCE."
  (unless condition
    (push (cons case-name evidence) transport-probe-v0--failures))
  condition)

;;; --- Case helpers ---------------------------------------------------------

(defun transport-probe-v0--case (name server-state &optional expect-text)
  "Run one probe case against SERVER-STATE.
Returns a result plist; when EXPECT-TEXT is given the llm final text is
checked against it.  Records failures into transport-probe-v0--failures."
  (condition-case err
      (let* ((run (transport-probe-v0--run-request server-state))
             (tee (plist-get run :tee))
             (tee-body (transport-probe-v0--tee-body tee))
             (records (transport-probe-v0--provider-records tee-body))
             (result (list :name name
                           :settled (plist-get run :settled)
                           :status (plist-get run :status)
                           :final (plist-get run :final)
                           :error (plist-get run :error)
                           :provider records
                           :tee tee
                           :tee_bytes (if tee (string-bytes tee) 0)
                           :tee_sha256 (if tee (transport-probe-v0--sha256 tee) nil)
                           :tee_body_bytes (string-bytes tee-body)
                           :request_body (plist-get server-state :request-body)
                           :filter_errors (plist-get run :filter-errors))))
        (when expect-text
          (transport-probe-v0--expect
           name (and (eq 'done (plist-get run :status))
                     (equal expect-text (plist-get run :final)))
           :expect expect-text :final (plist-get run :final) :status (plist-get run :status)))
        result)
    (error (push (cons name (list :case-error (error-message-string err)))
                 transport-probe-v0--failures)
           (list :name name :status 'case-error
                 :error (error-message-string err)))))

;;; --- The cases ------------------------------------------------------------

(defun transport-probe-v0--content-event (content)
  "Return an NDJSON content event line for CONTENT."
  (format "{\"model\":\"%s\",\"message\":{\"role\":\"assistant\",\"content\":\"%s\"},\"done\":false}\n"
          transport-probe-v0--chat-model content))

(defun transport-probe-v0--done-event (&optional reason prompt-eval eval-count)
  "Return an NDJSON done event line."
  (format "{\"model\":\"%s\",\"message\":{\"role\":\"assistant\",\"content\":\"\"},\"done\":true,\"done_reason\":\"%s\",\"prompt_eval_count\":%d,\"eval_count\":%d}\n"
          transport-probe-v0--chat-model
          (or reason "stop") (or prompt-eval 10) (or eval-count 5)))

(defun transport-probe-v0--run-happy (results)
  "Case 1+2: happy stop, three content events plus a done event."
  (let* ((body (concat (transport-probe-v0--content-event "hello ")
                       (transport-probe-v0--content-event "world ")
                       (transport-probe-v0--content-event "probe")
                       (transport-probe-v0--done-event)))
         (server (transport-probe-v0--make-server body))
         (result (transport-probe-v0--case "happy-stop" server "hello world probe"))
         (req-body (plist-get result :request_body))
         (req-alist (when req-body (transport-probe-v0--parse-json-alist req-body)))
         (format-obj (when req-alist (alist-get 'format req-alist)))
         (num-predict (when req-alist
                        (alist-get 'num_predict (alist-get 'options req-alist))))
         (schema-hash (when format-obj
                        (transport-probe-v0--sha256
                         (transport-probe-v0--canonical-json format-obj))))
         (server-bytes (encode-coding-string body 'utf-8))
         (tee (plist-get result :tee))
         (tee-body (if (stringp tee) (transport-probe-v0--tee-body tee) ""))
         (records (plist-get result :provider)))
    (transport-probe-v0--expect
     "happy-stop" (and req-body num-predict format-obj schema-hash)
     :request_body_present (stringp req-body) :num_predict num-predict
     :format_present (if format-obj t :json-false))
    (transport-probe-v0--expect
     "happy-stop" (eq t (plist-get records :done))
     :done (plist-get records :done))
    (transport-probe-v0--expect
     "happy-stop" (equal "stop" (plist-get records :done_reason))
     :done_reason (plist-get records :done_reason))
    (transport-probe-v0--expect
     "happy-stop" (and (equal 10 (plist-get records :prompt_eval_count))
                       (equal 5 (plist-get records :eval_count)))
     :counts (list (plist-get records :prompt_eval_count)
                   (plist-get records :eval_count)))
    (transport-probe-v0--expect
     "happy-stop" (and (equal server-bytes tee-body)
                       (equal (transport-probe-v0--sha256 server-bytes)
                              (transport-probe-v0--sha256 tee-body)))
     :server_bytes (string-bytes server-bytes) :tee_body_bytes (string-bytes tee-body)
     :server_sha (transport-probe-v0--sha256 server-bytes)
     :tee_body_sha (transport-probe-v0--sha256 tee-body))
    (let ((final (plist-get result :final)))
      (transport-probe-v0--expect
       "happy-stop" (equal "hello world probe" final)
       :final final)
      (setq results (plist-put results :transport_record
                              (list :request_max_output_tokens num-predict
                                    :request_response_schema_sha256 schema-hash
                                    :provider_done (plist-get records :done)
                                    :provider_done_reason (plist-get records :done_reason)
                                    :provider_prompt_eval_count (plist-get records :prompt_eval_count)
                                    :provider_eval_count (plist-get records :eval_count)
                                    :provider_raw_body_bytes (string-bytes tee-body)
                                    :provider_raw_body_sha256 (transport-probe-v0--sha256 tee-body)
                                    :llm_text_bytes (if final (string-bytes final) 0)
                                    :llm_text_sha256 (if final (transport-probe-v0--sha256 final) nil)
                                    :runtime_response_bytes "reused; equality asserted at execution time"
                                    :runtime_response_sha256 "reused; equality asserted at execution time"
                                    :outcome_raw_bytes "reused; equality asserted at execution time"
                                    :outcome_raw_sha256 "reused; equality asserted at execution time")))
    (delete-process (plist-get server :server))
    (push result (plist-get results :cases)))))

(defun transport-probe-v0--run-length (results)
  "Case 3a: completion with done_reason length, distinguishable from stop."
  (let* ((body (concat (transport-probe-v0--content-event "par")
                       (transport-probe-v0--done-event "length" 10 8)))
         (server (transport-probe-v0--make-server body))
         (result (transport-probe-v0--case "length-complete" server "par"))
         (records (plist-get result :provider)))
    (transport-probe-v0--expect
     "length-complete" (equal "length" (plist-get records :done_reason))
     :done_reason (plist-get records :done_reason))
    (transport-probe-v0--expect
     "length-complete" (not (equal "stop" (plist-get records :done_reason)))
     :reason (plist-get records :done_reason))
    (transport-probe-v0--expect
     "length-complete" (equal 8 (plist-get records :eval_count))
     :eval_count (plist-get records :eval_count))
    (delete-process (plist-get server :server))
    (push result (plist-get results :cases))))

(defun transport-probe-v0--run-premature-close (results)
  "Case 3b: mid-line premature close forces a curl error, no hang."
  (let* ((partial (format "{\"model\":\"%s\",\"message\":{\"role\":\"assistant\",\"content\":\"par"
                          transport-probe-v0--chat-model))
         (server (transport-probe-v0--make-server
                  partial :content-length 100000))
         (start (float-time))
         (result (transport-probe-v0--case "premature-close" server))
         (elapsed (- (float-time) start))
         (records (plist-get result :provider)))
    (transport-probe-v0--expect
     "premature-close" (eq 'error (plist-get result :status))
     :status (plist-get result :status) :error (plist-get result :error))
    (transport-probe-v0--expect
     "premature-close" (not (eq t (plist-get records :done)))
     :done (plist-get records :done))
    (transport-probe-v0--expect
     "premature-close" (< elapsed transport-probe-v0--timeout)
     :elapsed elapsed :timeout transport-probe-v0--timeout)
    (delete-process (plist-get server :server))
    (push result (plist-get results :cases))))

(defun transport-probe-v0--run-error-object (results)
  "Case 5: HTTP 200 with an NDJSON error object; record actual llm behavior."
  (let* ((body (format "{\"error\":\"probe simulated model error\"}\n"))
         (server (transport-probe-v0--make-server body))
         (result (transport-probe-v0--case "http-200-error-object" server))
         (records (plist-get result :provider)))
    (transport-probe-v0--expect
     "http-200-error-object" (> (plist-get records :error_events) 0)
     :error_events (plist-get records :error_events))
    (setq result (plist-put result :llm_behavior
                            (list :status (plist-get result :status)
                                  :final (plist-get result :final)
                                  :error (plist-get result :error))))
    (delete-process (plist-get server :server))
    (push result (plist-get results :cases))))

(defun transport-probe-v0--run-split-matrix (results)
  "Case 4a: split the NDJSON body at every byte offset; record integrity.
The measurement guard is installed ONLY around this loop (see
--matrix-guard); it changes error propagation for observation only."
  (let* ((body (transport-probe-v0--content-event "hi\360\237\230\200"))
         (total (string-bytes body))
         (corrupt 0) (pass 0) (offsets ()))
    (setq transport-probe-v0--matrix-guard-errors nil)
    (advice-add 'plz-media-type-process-filter :around
                #'transport-probe-v0--matrix-guard)
    (unwind-protect
        (dotimes (i (1+ total))
          (transport-probe-v0--erase-tee)
          (let* ((server (transport-probe-v0--make-server body :split-at i))
                 (result (transport-probe-v0--case
                          (format "split-offset-%d" i) server
                          (concat "hi" (string #x1f600))))
                 (ok (and (eq 'done (plist-get result :status))
                          (equal (concat "hi" (string #x1f600))
                                 (plist-get result :final)))))
            (if ok (cl-incf pass) (cl-incf corrupt))
            (push (vector i ok (and (eq 'done (plist-get result :status))
                                    (plist-get result :final))) offsets)
            (delete-process (plist-get server :server))))
      (advice-remove 'plz-media-type-process-filter
                     #'transport-probe-v0--matrix-guard))
    (setq results (plist-put results :matrix_ndjson_split
                            (list :offsets_total (1+ total) :pass pass :corrupt corrupt
                                  :guard_installed t
                                  :guard_changes_error_propagation t
                                  :guard_purpose "observation only; no re-split or re-decode shim"
                                  :guard_observed
                                  (nreverse (copy-sequence
                                             transport-probe-v0--matrix-guard-errors))
                                  :offsets (nreverse offsets))))
    (transport-probe-v0--record-split-decode-crash
     transport-probe-v0--matrix-guard-errors)
    (transport-probe-v0--expect
     "split-matrix" (and (= pass (1+ total)) (= corrupt 0))
     :pass pass :corrupt corrupt
     :guard_observed (length transport-probe-v0--matrix-guard-errors))))

(defun transport-probe-v0--run-utf8-matrix (results)
  "Case 4b: a 4-byte UTF-8 char at every content position; record integrity."
  (let ((pairs (list (cons "\360\237\230\200hi" (concat (string #x1f600) "hi"))
                     (cons "h\360\237\230\200i" (concat "h" (string #x1f600) "i"))
                     (cons "hi\360\237\230\200" (concat "hi" (string #x1f600)))))
        (pass 0) (corrupt 0) (rows ()))
    (dolist (pair pairs)
      (let* ((content (car pair))
             (expected (cdr pair))
             (body (transport-probe-v0--content-event content))
             (server (transport-probe-v0--make-server body))
             (result (transport-probe-v0--case
                      (format "utf8-%s" content) server expected))
             (ok (and (eq 'done (plist-get result :status))
                      (equal expected (plist-get result :final)))))
        (if ok (cl-incf pass) (cl-incf corrupt))
        (push (vector content ok (plist-get result :final)) rows)
        (delete-process (plist-get server :server))))
    (setq results (plist-put results :matrix_utf8
                            (list :positions_total (length pairs) :pass pass :corrupt corrupt
                                  :rows (nreverse rows))))
    (transport-probe-v0--expect
     "utf8-matrix" (and (= pass (length pairs)) (= corrupt 0))
     :pass pass :corrupt corrupt)))

;;; --- Cleanup and guards ---------------------------------------------------

(defun transport-probe-v0--cleanup-processes ()
  "Delete any leftover probe/plz processes and the tee buffer."
  (dolist (process (process-list))
    (when (string-match-p
           "transport-probe-v0-server\\|plz-request-curl"
           (process-name process))
      (delete-process process)))
  (when (get-buffer transport-probe-v0--tee-buffer-name)
    (kill-buffer (get-buffer transport-probe-v0--tee-buffer-name)))
  (when (get-buffer "*llm-log*")
    (kill-buffer (get-buffer "*llm-log*"))))

(defun transport-probe-v0--db-state ()
  "Return (list :path P :exists BOOL :hash H :mtime M) for the archive DB."
  (if (and (stringp transport-probe-v0--archive-db-path)
           (file-readable-p transport-probe-v0--archive-db-path))
      (list :path transport-probe-v0--archive-db-path
            :exists t
            :hash (transport-probe-v0--hash-file transport-probe-v0--archive-db-path)
            :mtime (nth 5 (file-attributes transport-probe-v0--archive-db-path)))
    (list :path transport-probe-v0--archive-db-path :exists nil)))

;;; --- Main ----------------------------------------------------------------

(defun transport-probe-v0--verify-frozen-hashes ()
  "Compare contract frozen hashes against the located .el files."
  (let* ((source (plist-get transport-probe-v0--contract :source))
         (ollama (transport-probe-v0--locate-el "llm-ollama"))
         (provider-utils (transport-probe-v0--locate-el "llm-provider-utils"))
         (ollama-hash (and ollama (transport-probe-v0--hash-file ollama)))
         (provider-utils-hash (and provider-utils (transport-probe-v0--hash-file provider-utils))))
    (list :llm_ollama_el ollama
          :llm_ollama_sha256 ollama-hash
          :llm_ollama_sha256_match (equal ollama-hash
                                          (plist-get source :llm_ollama_sha256))
          :llm_provider_utils_el provider-utils
          :llm_provider_utils_sha256 provider-utils-hash
          :llm_provider_utils_sha256_match
          (equal provider-utils-hash
                 (plist-get source :llm_provider_utils_sha256)))))

(defun transport-probe-v0--json-safe-string (s)
  "Return S with raw-byte characters (0x80..0xFF) replaced by U+FFFD.
This build's json-serialize emits invalid overlong UTF-8 for raw-byte chars,
so they are sanitized before encoding."
  (if (string-match-p "[\200-\377]" s)
      (apply #'string
             (mapcar (lambda (ch) (if (<= 128 ch 255) 65533 ch)) s))
    s))

(defun transport-probe-v0--json-normalize (obj)
  "Normalize OBJ for json-encode on this Emacs build.
json-serialize here is unusable for this report (rejects :json-false and
emits invalid UTF-8 for non-ASCII); json-encode handles both but misdetects
lists of plists and keyword plists, so plists become string-keyed alists and
arrays become vectors.  Raw-byte chars are sanitized by --json-safe-string."
  (cond
   ((null obj) nil)
   ((eq obj :json-false) :json-false)
   ((stringp obj) (transport-probe-v0--json-safe-string obj))
   ((numberp obj) obj)
   ((eq obj t) t)
   ((keywordp obj) (symbol-name obj))
   ((symbolp obj) (symbol-name obj))
   ((vectorp obj)
    (apply #'vector (mapcar #'transport-probe-v0--json-normalize (append obj nil))))
   ((consp obj)
    (cond
     ((keywordp (car obj))            ; plist -> string-keyed alist
      (let (out)
        (while obj
          (setq out (cons (cons (substring (symbol-name (car obj)) 1)
                                (transport-probe-v0--json-normalize (cadr obj)))
                          out))
          (setq obj (cddr obj)))
        (nreverse out)))
     ((and (consp (car obj)) (stringp (caar obj)))  ; string-keyed alist
      (mapcar (lambda (pair)
                (cons (car pair)
                      (transport-probe-v0--json-normalize (cdr pair))))
              obj))
     (t (apply #'vector (mapcar #'transport-probe-v0--json-normalize obj)))))
   (t obj)))

(defun transport-probe-v0--locate-elc (library)
  "Return the absolute .elc path for LIBRARY on the load path, or nil."
  (locate-file (concat library ".elc") load-path))

(defun transport-probe-v0--drain-timers (baseline)
  "Drain timers created since BASELINE for a bounded period.
Returns the timers still pending afterwards (leftover)."
  (let ((deadline (+ (float-time) 0.5)))
    (while (and (< (float-time) deadline)
                (cl-set-difference (copy-sequence timer-list) baseline :test #'eq))
      (accept-process-output nil 0.01)))
  (cl-set-difference (copy-sequence timer-list) baseline :test #'eq))

(defun transport-probe-v0--run ()
  "Run the whole throwaway transport probe; print result JSON; exit."
  (let ((results (list :cases (list)))
        (db-before (transport-probe-v0--db-state))
        (timers-baseline (copy-sequence timer-list)))
    (transport-probe-v0--record-schema-blocker)
    (when transport-probe-v0--source-load-evidence
      (push (cons "source-execution-qualified"
                  (list :qualified :json-false
                        :evidence transport-probe-v0--source-load-evidence
                        :note "source hash matches the frozen .el but the bytecode actually executed is the .elc; source execution is not qualified"))
            transport-probe-v0--failures))
    (advice-add 'plz-media-type-process-filter :before #'transport-probe-v0--tee-raw)
    (unwind-protect
        (progn
          (transport-probe-v0--run-happy results)
          (transport-probe-v0--run-length results)
          (transport-probe-v0--run-premature-close results)
          (transport-probe-v0--run-error-object results)
          (transport-probe-v0--run-split-matrix results)
          (transport-probe-v0--run-utf8-matrix results))
      (advice-remove 'plz-media-type-process-filter #'transport-probe-v0--tee-raw)
      (transport-probe-v0--cleanup-processes))
    (let* ((db-after (transport-probe-v0--db-state))
           (timers-new (cl-set-difference (copy-sequence timer-list)
                                          timers-baseline :test #'eq))
           (timers-leftover (transport-probe-v0--drain-timers timers-baseline))
           (hash-check (transport-probe-v0--verify-frozen-hashes))
           (tee-advice-gone (null (advice-member-p
                                   #'transport-probe-v0--tee-raw
                                   'plz-media-type-process-filter)))
           (guard-advice-gone (null (advice-member-p
                                     #'transport-probe-v0--matrix-guard
                                     'plz-media-type-process-filter)))
           (advice-gone (and tee-advice-gone guard-advice-gone))
           (whitelisted-timers
            (cl-remove-if-not
             (lambda (timer)
               (memq (timer--function timer)
                     transport-probe-v0--benign-timer-functions))
             timers-leftover))
           (real-leftover-timers
            (cl-remove-if
             (lambda (timer)
               (memq (timer--function timer)
                     transport-probe-v0--benign-timer-functions))
             timers-leftover))
           (leftover (cl-remove-if
                      (lambda (process)
                        (not (string-match-p
                              "transport-probe-v0-server\\|plz-request-curl"
                              (process-name process))))
                      (process-list)))
           (llm-log-buffer-p (get-buffer "*llm-log*")))
    (when real-leftover-timers
      (push (cons "timer-leak"
                  (list :leftover (mapcar #'prin1-to-string real-leftover-timers)))
            transport-probe-v0--failures))
    (let* ((ollama-elc (transport-probe-v0--locate-elc "llm-ollama"))
           (ollama-el (transport-probe-v0--locate-el "llm-ollama"))
           (output
            (list :probe "transport-probe-v0.1"
                  :problem "provider transport capability unproven"
                  :throwaway t
                  :llm_version (transport-probe-v0--llm-pkg-version)
                  :llm_loaded_source
                  (when (featurep 'llm) (locate-library "llm"))
                  :source_loading
                  (if transport-probe-v0--source-load-evidence
                      (list :succeeded :json-false
                            :evidence transport-probe-v0--source-load-evidence
                            :fallback "release-compiled .elc artifacts of the same versions"
                            :source_execution_qualified :json-false
                            :llm_ollama_symbol_file (symbol-file 'llm-ollama-host)
                            :llm_ollama_el ollama-el
                            :llm_ollama_el_sha256
                            (and ollama-el (transport-probe-v0--hash-file ollama-el))
                            :llm_ollama_elc ollama-elc
                            :llm_ollama_elc_sha256
                            (and ollama-elc (transport-probe-v0--hash-file ollama-elc)))
                    (list :succeeded t :evidence "frozen .el sources loaded"
                          :source_execution_qualified t))
                  :hash_checks hash-check
                  :required_transport_record (plist-get results :transport_record)
                  :cases (nreverse (plist-get results :cases))
                  :matrix_ndjson_split (plist-get results :matrix_ndjson_split)
                  :matrix_utf8 (plist-get results :matrix_utf8)
                  :cleanup (list :advice_tee_removed (if tee-advice-gone t :json-false)
                                 :advice_matrix_guard_removed (if guard-advice-gone t :json-false)
                                 :advice_removed (if advice-gone t :json-false)
                                 :leftover_processes (mapcar #'process-name leftover)
                                 :llm_log_buffer_created (if llm-log-buffer-p t :json-false))
                  :timers (list :baseline (length timers-baseline)
                                :pending_before_drain (length timers-new)
                                :leftover (length timers-leftover)
                                :whitelisted_timers
                                (mapcar (lambda (timer)
                                          (symbol-name (timer--function timer)))
                                        whitelisted-timers)
                                :whitelisted_owner "Emacs core undo-auto"
                                :whitelisted_benign "undo boundary only")
                  :superchat_db (list :path (plist-get db-before :path)
                                      :exists_before (plist-get db-before :exists)
                                      :hash_unchanged (equal (plist-get db-before :hash)
                                                             (plist-get db-after :hash))
                                      :mtime_unchanged (equal (plist-get db-before :mtime)
                                                              (plist-get db-after :mtime)))
                  :superchat_required (featurep 'superchat)
                  :not_proved
                  (list "real Ollama semantics: responses are locally scripted by the probe server, not generated by a real Ollama provider"
                        "Superchat integration: superchat is never required; Runtime/Outcome persistence and runtime_response/outcome_raw equality are not exercised here and must be asserted at execution time"
                        (format "environment variance: ran under emacs %s batch with the nova-emacs elpa checkout; frozen llm-ollama/llm-provider-utils .el hashes match=%s/%s; executed bytecode is the .elc when source loading is infeasible"
                                emacs-version
                                (plist-get hash-check :llm_ollama_sha256_match)
                                (plist-get hash-check :llm_provider_utils_sha256_match))
                        "no effect decision and no unfreeze: execution_authorized stays false in the frozen contract")
                  :notes
                  (apply #'vector
                         (mapcar (lambda (pair)
                                   (list :note_id (car pair)
                                         :detail (cdr pair)))
                                 (nreverse transport-probe-v0--notes)))
                  :failures
                  (apply #'vector
                         (mapcar (lambda (pair)
                                   (list :case_id (car pair)
                                         :evidence (cdr pair)))
                                 (nreverse transport-probe-v0--failures))))))
      (princ (json-encode
              (transport-probe-v0--json-normalize output)))
      (terpri)
      (kill-emacs (if transport-probe-v0--failures 1 0))))))

;;; Entry

(transport-probe-v0--load-dependencies)
(transport-probe-v0--load-contract)
(transport-probe-v0--run)

(provide 'transport-probe-v0)

;;; transport-probe-v0.el ends here
