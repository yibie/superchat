;;; transport-integration-probe-v0.4.el --- Frozen-base byte-fidelity wrapper -*- lexical-binding: t; -*-

;; executor_luna_v04
;;
;; Frozen question: under the full product context, synthetic transport, and
;; T3/T4 rejection net, can one Entry of the frozen base prove request schema,
;; think, num_predict, S -> Runtime -> Tape assertions -> probe-local Outcome
;; byte fidelity, parser validity, and zero process creation at once?
;;
;; This is a wrapper, not a second measurement implementation.  The future
;; launch loads transport-integration-probe-v0.el exactly once; its Entry and
;; kill-emacs behavior are intentionally reused.  This file itself never runs
;; the future command and creates no result or sidecar.
;;
;; CONTRACT:
;; - top level only requires cl-lib/json and defines state/helpers;
;; - the sole future command is the -f launch command below;
;; - Pi does not participate; real Ollama, real transport, and UTF-8 are not
;;   proven; STOP-2/3 remain open and execution_authorized=false;
;; - the independent byte-fidelity subgate is candidate-only and not a retry;
;; - T3 records only symbol counts; T4 records only its first bounded event;
;; - all merge/parse/print work is owned by the kill-emacs :around advice;
;; - kill-emacs-hook performs only idempotent no-error cleanup.
;;
;; Frozen seven-link chain, asserted before the frozen base is loaded:
;;   audit       = 14f9c8416b4296cbe0869e1bd417d5e8989d211413d2e065472fb7294bde1268
;;   base        = 4fcf0f51a15c2029b062101921383b6a69991d2e01299fc1b24f7a0fa50db265
;;   v0.1 wrapper= 7210f2790299754f1b59c071977531c0c5a5cc383345ab231fba107514540ebc
;;   v0.2 source = 50107bc11f41c931134594007b0c6088905a5bacedb6f9c881ba70ef64e2e6dc
;;   v0.2 result = 38d3bc86233ef2882d21da0469a9fbdb7c1c2a80b63feeecc89663d7aa635b33
;;   v0.3 source = 5e7254e75e77bc30b10c5cdae9c2c7de25f334b67ace6b4f4c37b71a463d5df3
;;   v0.3 result = 34e237d5e5f2acf74ececaa91edccf11ee563c14cae326c5c8bfb3bf9a8702ed
;;
;; Sole future command (this task must NOT run it):
;;   emacs -Q --batch -L . \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/llm-0.31.1 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-0.9.1 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-event-source-0.1.3 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-media-type-0.2.4 \
;;     -l experiments/closed-loop-experience-correction-v0/transport-integration-probe-v0.4.el \
;;     -f transport-integration-probe-v0.4--launch

;;; Code:

(require 'cl-lib)
(require 'json)

(defconst transport-integration-probe-v0.4--directory
  (file-name-directory (or load-file-name buffer-file-name)))

(defconst transport-integration-probe-v0.4--audit-path
  (expand-file-name "transport-egress-audit-v0.md"
                    transport-integration-probe-v0.4--directory))
(defconst transport-integration-probe-v0.4--base-path
  (expand-file-name "transport-integration-probe-v0.el"
                    transport-integration-probe-v0.4--directory))
(defconst transport-integration-probe-v0.4--v0.1-wrapper-path
  (expand-file-name "transport-integration-probe-v0.1.el"
                    transport-integration-probe-v0.4--directory))
(defconst transport-integration-probe-v0.4--v0.2-source-path
  (expand-file-name "transport-integration-probe-v0.2.el"
                    transport-integration-probe-v0.4--directory))
(defconst transport-integration-probe-v0.4--v0.2-result-path
  (expand-file-name "transport-integration-probe-v0.2-result.json"
                    transport-integration-probe-v0.4--directory))
(defconst transport-integration-probe-v0.4--v0.3-source-path
  (expand-file-name "transport-integration-probe-v0.3.el"
                    transport-integration-probe-v0.4--directory))
(defconst transport-integration-probe-v0.4--v0.3-result-path
  (expand-file-name "transport-integration-probe-v0.3-result.json"
                    transport-integration-probe-v0.4--directory))

(defconst transport-integration-probe-v0.4--audit-sha256
  "14f9c8416b4296cbe0869e1bd417d5e8989d211413d2e065472fb7294bde1268")
(defconst transport-integration-probe-v0.4--base-sha256
  "4fcf0f51a15c2029b062101921383b6a69991d2e01299fc1b24f7a0fa50db265")
(defconst transport-integration-probe-v0.4--v0.1-wrapper-sha256
  "7210f2790299754f1b59c071977531c0c5a5cc383345ab231fba107514540ebc")
(defconst transport-integration-probe-v0.4--v0.2-source-sha256
  "50107bc11f41c931134594007b0c6088905a5bacedb6f9c881ba70ef64e2e6dc")
(defconst transport-integration-probe-v0.4--v0.2-result-sha256
  "38d3bc86233ef2882d21da0469a9fbdb7c1c2a80b63feeecc89663d7aa635b33")
(defconst transport-integration-probe-v0.4--v0.3-source-sha256
  "5e7254e75e77bc30b10c5cdae9c2c7de25f334b67ace6b4f4c37b71a463d5df3")
(defconst transport-integration-probe-v0.4--v0.3-result-sha256
  "34e237d5e5f2acf74ececaa91edccf11ee563c14cae326c5c8bfb3bf9a8702ed")

;; Frozen base's expected response-format hash.  This is an assertion input,
;; not copied base measurement logic.
(defconst transport-integration-probe-v0.4--expected-schema-sha256
  "bcbc37a0cf42b9def5a906d90201befaea4cf505c208dd21ff6736fac6bf71dd")
(defconst transport-integration-probe-v0.4--output-limit 16384)

(defconst transport-integration-probe-v0.4--t3-symbols
  '(superchat--get-available-models llm-models plz plz-media-type-request
    url-retrieve url-retrieve-synchronously url-queue-retrieve
    url-retrieve-internal))
(defconst transport-integration-probe-v0.4--t4-symbols
  '(make-process make-network-process make-pipe-process))
(defconst transport-integration-probe-v0.4--product-functions
  '(superchat--update-status
    superchat--stream-llm-result
    superchat--process-llm-result
    superchat--ttft-log
    superchat--annotate-ttft
    superchat--is-ollama-backend-p
    superchat--detect-response-mode
    superchat--show-response-mode-indicator
    superchat--get-adjusted-timeout
    superchat--extend-timeout))

(defvar superchat-data-directory)

(defvar transport-integration-probe-v0.4--saved-standard-output nil)
(defvar transport-integration-probe-v0.4--capture-buffer nil)
(defvar transport-integration-probe-v0.4--temp-dir nil)
(defvar transport-integration-probe-v0.4--hook-installed nil)
(defvar transport-integration-probe-v0.4--kill-advice-installed nil)
(defvar transport-integration-probe-v0.4--t3-advice-table nil)
(defvar transport-integration-probe-v0.4--t4-advice-table nil)
(defvar transport-integration-probe-v0.4--t3-advice-leftover nil)
(defvar transport-integration-probe-v0.4--t4-advice-leftover nil)
(defvar transport-integration-probe-v0.4--t3-counts nil)
(defvar transport-integration-probe-v0.4--t4-hit-count 0)
(defvar transport-integration-probe-v0.4--t4-first nil)
(defvar transport-integration-probe-v0.4--guards-before nil)
(defvar transport-integration-probe-v0.4--guards-after nil)
(defvar transport-integration-probe-v0.4--guards-before-captured nil)
(defvar transport-integration-probe-v0.4--guards-after-captured nil)
(defvar transport-integration-probe-v0.4--process-before nil)
(defvar transport-integration-probe-v0.4--process-after nil)
(defvar transport-integration-probe-v0.4--process-before-captured nil)
(defvar transport-integration-probe-v0.4--process-after-captured nil)
(defvar transport-integration-probe-v0.4--base-load-count 0)
(defvar transport-integration-probe-v0.4--base-kill-called nil)
(defvar transport-integration-probe-v0.4--base-exit-status nil)
(defvar transport-integration-probe-v0.4--base-stdout-raw nil)
(defvar transport-integration-probe-v0.4--base-stdout-bytes 0)
(defvar transport-integration-probe-v0.4--base-stdout-sha256 nil)
(defvar transport-integration-probe-v0.4--base-json nil)
(defvar transport-integration-probe-v0.4--base-parsed nil)
(defvar transport-integration-probe-v0.4--base-parse-error nil)
(defvar transport-integration-probe-v0.4--launch-error nil)
(defvar transport-integration-probe-v0.4--finalize-error nil)
(defvar transport-integration-probe-v0.4--cleanup-running nil)
(defvar transport-integration-probe-v0.4--cleanup-complete nil)
(defvar transport-integration-probe-v0.4--cleanup-errors nil)
(defvar transport-integration-probe-v0.4--cleanup-evidence nil)
(defvar transport-integration-probe-v0.4--output-size-ok nil)

(defun transport-integration-probe-v0.4--reset-state ()
  "Reset all wrapper state without loading product code."
  (setq transport-integration-probe-v0.4--capture-buffer nil
        transport-integration-probe-v0.4--temp-dir nil
        transport-integration-probe-v0.4--hook-installed nil
        transport-integration-probe-v0.4--kill-advice-installed nil
        transport-integration-probe-v0.4--t3-advice-table
        (make-hash-table :test #'eq)
        transport-integration-probe-v0.4--t4-advice-table
        (make-hash-table :test #'eq)
        transport-integration-probe-v0.4--t3-advice-leftover nil
        transport-integration-probe-v0.4--t4-advice-leftover nil
        transport-integration-probe-v0.4--t3-counts
        (make-hash-table :test #'eq)
        transport-integration-probe-v0.4--t4-hit-count 0
        transport-integration-probe-v0.4--t4-first nil
        transport-integration-probe-v0.4--guards-before nil
        transport-integration-probe-v0.4--guards-after nil
        transport-integration-probe-v0.4--guards-before-captured nil
        transport-integration-probe-v0.4--guards-after-captured nil
        transport-integration-probe-v0.4--process-before nil
        transport-integration-probe-v0.4--process-after nil
        transport-integration-probe-v0.4--process-before-captured nil
        transport-integration-probe-v0.4--process-after-captured nil
        transport-integration-probe-v0.4--base-load-count 0
        transport-integration-probe-v0.4--base-kill-called nil
        transport-integration-probe-v0.4--base-exit-status nil
        transport-integration-probe-v0.4--base-stdout-raw nil
        transport-integration-probe-v0.4--base-stdout-bytes 0
        transport-integration-probe-v0.4--base-stdout-sha256 nil
        transport-integration-probe-v0.4--base-json nil
        transport-integration-probe-v0.4--base-parsed nil
        transport-integration-probe-v0.4--base-parse-error nil
        transport-integration-probe-v0.4--launch-error nil
        transport-integration-probe-v0.4--finalize-error nil
        transport-integration-probe-v0.4--cleanup-running nil
        transport-integration-probe-v0.4--cleanup-complete nil
        transport-integration-probe-v0.4--cleanup-errors nil
        transport-integration-probe-v0.4--cleanup-evidence nil
        transport-integration-probe-v0.4--output-size-ok nil))

(defun transport-integration-probe-v0.4--sha256-string (string)
  "Return the SHA256 of STRING's UTF-8 bytes."
  (secure-hash 'sha256 (encode-coding-string (or string "") 'utf-8)))

(defun transport-integration-probe-v0.4--hash-file (path)
  "Return the SHA256 of PATH's bytes, or nil when unreadable."
  (when (file-readable-p path)
    (with-temp-buffer
      (insert-file-contents path)
      (secure-hash 'sha256 (current-buffer)))))

(defun transport-integration-probe-v0.4--hash-mtime (path)
  "Return a bounded hash/mtime alist for PATH."
  (when (file-readable-p path)
    (let ((attributes (file-attributes path)))
      (list (cons "hash" (transport-integration-probe-v0.4--hash-file path))
            (cons "mtime" (vconcat (nth 5 attributes)))))))

(defun transport-integration-probe-v0.4--preview (value)
  "Return at most 500 characters of VALUE."
  (let* ((string (if (stringp value) value (format "%s" value)))
         (limit (min 500 (length string))))
    (substring string 0 limit)))

(defun transport-integration-probe-v0.4--frozen-entries ()
  "Return the seven frozen path/SHA triples."
  (list
   (list "audit" transport-integration-probe-v0.4--audit-path
         transport-integration-probe-v0.4--audit-sha256)
   (list "base" transport-integration-probe-v0.4--base-path
         transport-integration-probe-v0.4--base-sha256)
   (list "v0.1-wrapper" transport-integration-probe-v0.4--v0.1-wrapper-path
         transport-integration-probe-v0.4--v0.1-wrapper-sha256)
   (list "v0.2-source" transport-integration-probe-v0.4--v0.2-source-path
         transport-integration-probe-v0.4--v0.2-source-sha256)
   (list "v0.2-result" transport-integration-probe-v0.4--v0.2-result-path
         transport-integration-probe-v0.4--v0.2-result-sha256)
   (list "v0.3-source" transport-integration-probe-v0.4--v0.3-source-path
         transport-integration-probe-v0.4--v0.3-source-sha256)
   (list "v0.3-result" transport-integration-probe-v0.4--v0.3-result-path
         transport-integration-probe-v0.4--v0.3-result-sha256)))

(defun transport-integration-probe-v0.4--assert-frozen ()
  "Assert all seven frozen path bytes before base load."
  (dolist (entry (transport-integration-probe-v0.4--frozen-entries))
    (let ((actual (transport-integration-probe-v0.4--hash-file (nth 1 entry))))
      (unless (equal actual (nth 2 entry))
        (error "transport-integration-probe-v0.4: frozen %s SHA mismatch: expected %s got %s"
               (nth 0 entry) (nth 2 entry) actual)))))

(defun transport-integration-probe-v0.4--assert-product-functions ()
  "Assert the ten product functions required by the frozen base."
  (let (missing)
    (dolist (function transport-integration-probe-v0.4--product-functions)
      (unless (fboundp function)
        (push function missing)))
    (when missing
      (error "transport-integration-probe-v0.4: product functions missing: %S"
             (nreverse missing)))))

(defun transport-integration-probe-v0.4--default-db-path ()
  "Return the default Superchat DB path."
  (expand-file-name "superchat.db"
                    (expand-file-name "superchat/" user-emacs-directory)))

(defun transport-integration-probe-v0.4--guards-snapshot ()
  "Capture only the default and archive DB guards."
  (list
   (cons "default_db"
         (transport-integration-probe-v0.4--hash-mtime
          (transport-integration-probe-v0.4--default-db-path)))
   (cons "archive_db"
         (transport-integration-probe-v0.4--hash-mtime
          "/private/tmp/superchat-v04-final-archive.RAEt87/closed-loop-experience-correction-v0.4-handoff/runtime/superchat.db"))))

(defun transport-integration-probe-v0.4--process-snapshot ()
  "Return the process objects visible at this point."
  (process-list))

(defun transport-integration-probe-v0.4--safe-process-name (process)
  "Return PROCESS's name without signaling."
  (condition-case nil
      (process-name process)
    (error "unknown-process")))

(defun transport-integration-probe-v0.4--new-processes ()
  "Return process objects present after but not before."
  (if (and transport-integration-probe-v0.4--process-before-captured
           transport-integration-probe-v0.4--process-after-captured)
      (cl-remove-if
       (lambda (process)
         (memq process transport-integration-probe-v0.4--process-before))
       transport-integration-probe-v0.4--process-after)
    nil))

(defun transport-integration-probe-v0.4--process-evidence ()
  "Return bounded process evidence with at most eight new names."
  (let* ((captured (and transport-integration-probe-v0.4--process-before-captured
                       transport-integration-probe-v0.4--process-after-captured))
         (new (transport-integration-probe-v0.4--new-processes))
         (names (if captured
                    (mapcar #'transport-integration-probe-v0.4--safe-process-name new)
                  nil)))
    (list
     (cons "before_count"
           (and transport-integration-probe-v0.4--process-before-captured
                (length transport-integration-probe-v0.4--process-before)))
     (cons "after_count"
           (and transport-integration-probe-v0.4--process-after-captured
                (length transport-integration-probe-v0.4--process-after)))
     (cons "new_count" (if captured (length new) -1))
     (cons "new_names"
           (vconcat (mapcar #'transport-integration-probe-v0.4--preview
                            (cl-subseq names 0 (min 8 (length names)))))))))

(defun transport-integration-probe-v0.4--object-value (object key)
  "Return KEY from an alist OBJECT with symbol or string keys."
  (when (listp object)
    (let* ((name (if (symbolp key) (symbol-name key) key))
           (cell (or (and (symbolp key) (assq key object))
                     (assoc name object))))
      (and cell (cdr cell)))))

(defun transport-integration-probe-v0.4--json-safe (value)
  "Convert parsed JSON values to json-encode-friendly values."
  (cond
   ((eq value :json-false) :json-false)
   ((or (null value) (stringp value) (numberp value)) value)
   ((eq value t) t)
   ((symbolp value) (symbol-name value))
   ((vectorp value)
    (apply #'vector
           (mapcar #'transport-integration-probe-v0.4--json-safe
                   (append value nil))))
   ((and (consp value)
         (consp (car value))
         (let ((key (caar value)))
           (or (symbolp key) (stringp key))))
    (mapcar
     (lambda (pair)
       (cons (if (symbolp (car pair))
                 (symbol-name (car pair))
               (car pair))
             (transport-integration-probe-v0.4--json-safe (cdr pair))))
     value))
   ((consp value)
    (vconcat (mapcar #'transport-integration-probe-v0.4--json-safe value)))
   (t (format "%S" value))))

(defun transport-integration-probe-v0.4--json-array (value)
  "Convert a parsed JSON array VALUE to a JSON vector."
  (cond
   ((vectorp value)
    (transport-integration-probe-v0.4--json-safe value))
   ((listp value)
    (vconcat (mapcar #'transport-integration-probe-v0.4--json-safe value)))
   ((null value) (vector))
   (t (vector (transport-integration-probe-v0.4--json-safe value)))))

(defun transport-integration-probe-v0.4--record-t3 (symbol)
  "Increment the bounded count for T3 SYMBOL."
  (puthash symbol
           (1+ (gethash symbol transport-integration-probe-v0.4--t3-counts 0))
           transport-integration-probe-v0.4--t3-counts))

(defun transport-integration-probe-v0.4--t3-json ()
  "Return sorted T3 symbol/count pairs."
  (let (entries)
    (maphash
     (lambda (symbol count)
       (push (vector (symbol-name symbol) count) entries))
     transport-integration-probe-v0.4--t3-counts)
    (vconcat
     (sort entries
           (lambda (left right)
             (string< (aref left 0) (aref right 0)))))))

(defun transport-integration-probe-v0.4--backtrace-string ()
  "Return a backtrace string without signaling."
  (condition-case err
      (with-output-to-string (backtrace))
    (error (format "backtrace unavailable: %s" (error-message-string err)))))

(defun transport-integration-probe-v0.4--record-t4 (symbol args)
  "Record only the first bounded T4 event."
  (setq transport-integration-probe-v0.4--t4-hit-count
        (1+ transport-integration-probe-v0.4--t4-hit-count))
  (unless transport-integration-probe-v0.4--t4-first
    (let* ((args-prin1 (prin1-to-string args))
           (backtrace-prin1
            (transport-integration-probe-v0.4--backtrace-string)))
      (setq transport-integration-probe-v0.4--t4-first
            (list
             (cons "symbol" (symbol-name symbol))
             (cons "args_prin1_sha256"
                   (transport-integration-probe-v0.4--sha256-string args-prin1))
             (cons "args_prin1_preview"
                   (transport-integration-probe-v0.4--preview args-prin1))
             (cons "backtrace_prin1_sha256"
                   (transport-integration-probe-v0.4--sha256-string
                    backtrace-prin1))
             (cons "backtrace_prin1_preview"
                   (transport-integration-probe-v0.4--preview
                    backtrace-prin1)))))))

(defun transport-integration-probe-v0.4--install-t3 ()
  "Install call-through T3 advice on every audited symbol."
  (dolist (symbol transport-integration-probe-v0.4--t3-symbols)
    (unless (fboundp symbol)
      (error "transport-integration-probe-v0.4: T3 symbol missing: %S" symbol))
    (let ((target symbol))
      (let ((advice
             (lambda (original &rest args)
               (transport-integration-probe-v0.4--record-t3 target)
               (apply original args))))
        (advice-add target :around advice)
        (puthash target advice
                 transport-integration-probe-v0.4--t3-advice-table)))))

(defun transport-integration-probe-v0.4--install-t4 ()
  "Install terminal-deny T4 advice on every audited primitive."
  (dolist (symbol transport-integration-probe-v0.4--t4-symbols)
    (unless (fboundp symbol)
      (error "transport-integration-probe-v0.4: T4 symbol missing: %S" symbol))
    (let ((target symbol))
      (let ((advice
             (lambda (_original &rest args)
               (transport-integration-probe-v0.4--record-t4 target args)
               (error "transport-integration-probe-v0.4: %s called; process creation blocked"
                      target))))
        (advice-add target :around advice)
        (puthash target advice
                 transport-integration-probe-v0.4--t4-advice-table)))))

(defun transport-integration-probe-v0.4--remove-advice-table (table)
  "Remove TABLE's advice and return leftover symbol names."
  (let (leftover)
    (when (hash-table-p table)
      (maphash
       (lambda (symbol advice)
         (condition-case err
             (advice-remove symbol advice)
           (error
            (push (format "%s: %s" symbol (error-message-string err))
                  leftover)))
         (condition-case nil
             (when (advice-member-p advice symbol)
               (push (symbol-name symbol) leftover))
           (error
            (push (symbol-name symbol) leftover))))
       table)
      (clrhash table))
    (nreverse leftover)))

(defun transport-integration-probe-v0.4--kill-advice-gone-p ()
  "Return non-nil when this wrapper's kill advice is absent."
  (condition-case nil
      (not (advice-member-p #'transport-integration-probe-v0.4--kill-emacs-around
                            'kill-emacs))
    (error nil)))

(defun transport-integration-probe-v0.4--cleanup-step (label function)
  "Run FUNCTION for cleanup LABEL, recording only a bounded error."
  (condition-case err
      (funcall function)
    (error
     (push (cons label
                 (transport-integration-probe-v0.4--preview
                  (error-message-string err)))
           transport-integration-probe-v0.4--cleanup-errors)
     nil)))

(defun transport-integration-probe-v0.4--cleanup-evidence ()
  "Return the current wrapper cleanup evidence."
  (list
   (cons "complete"
         (if transport-integration-probe-v0.4--cleanup-complete
             t :json-false))
   (cons "kill_advice_gone"
         (if (transport-integration-probe-v0.4--kill-advice-gone-p)
             t :json-false))
   (cons "t3_advice_removed"
         (if (null transport-integration-probe-v0.4--t3-advice-leftover)
             t :json-false))
   (cons "t4_advice_removed"
         (if (null transport-integration-probe-v0.4--t4-advice-leftover)
             t :json-false))
   (cons "capture_buffer_absent"
         (if (not (buffer-live-p transport-integration-probe-v0.4--capture-buffer))
             t :json-false))
   (cons "temp_dir_removed"
         (if (and transport-integration-probe-v0.4--temp-dir
                  (not (file-exists-p
                        transport-integration-probe-v0.4--temp-dir)))
             t :json-false))
   (cons "hook_absent"
         (if (not (memq #'transport-integration-probe-v0.4--cleanup-hook
                        kill-emacs-hook))
             t :json-false))
   (cons "errors"
         (vconcat
          (mapcar (lambda (entry)
                    (format "%s: %s" (car entry) (cdr entry)))
                  (nreverse transport-integration-probe-v0.4--cleanup-errors))))))

(defun transport-integration-probe-v0.4--cleanup ()
  "Idempotently clean wrapper resources; never signal to the hook."
  (unless transport-integration-probe-v0.4--cleanup-complete
    (unless transport-integration-probe-v0.4--cleanup-running
      (setq transport-integration-probe-v0.4--cleanup-running t
            transport-integration-probe-v0.4--cleanup-errors nil)
      (unwind-protect
          (progn
            ;; B3 order: remove own advice first, then take after snapshots.
            (transport-integration-probe-v0.4--cleanup-step
             "kill-emacs-advice"
             (lambda ()
               (when (advice-member-p
                      #'transport-integration-probe-v0.4--kill-emacs-around
                      'kill-emacs)
                 (advice-remove
                  'kill-emacs
                  #'transport-integration-probe-v0.4--kill-emacs-around))
               (setq transport-integration-probe-v0.4--kill-advice-installed nil)))
            (unless transport-integration-probe-v0.4--guards-after-captured
              (transport-integration-probe-v0.4--cleanup-step
               "guards-after"
               (lambda ()
                 (setq transport-integration-probe-v0.4--guards-after
                       (transport-integration-probe-v0.4--guards-snapshot)
                       transport-integration-probe-v0.4--guards-after-captured t))))
            (unless transport-integration-probe-v0.4--process-after-captured
              (transport-integration-probe-v0.4--cleanup-step
               "process-after"
               (lambda ()
                 (setq transport-integration-probe-v0.4--process-after
                       (transport-integration-probe-v0.4--process-snapshot)
                       transport-integration-probe-v0.4--process-after-captured t))))
            (setq transport-integration-probe-v0.4--t3-advice-leftover
                  (transport-integration-probe-v0.4--remove-advice-table
                   transport-integration-probe-v0.4--t3-advice-table))
            (setq transport-integration-probe-v0.4--t4-advice-leftover
                  (transport-integration-probe-v0.4--remove-advice-table
                   transport-integration-probe-v0.4--t4-advice-table))
            (transport-integration-probe-v0.4--cleanup-step
             "capture-buffer"
             (lambda ()
               (when (buffer-live-p
                      transport-integration-probe-v0.4--capture-buffer)
                 (kill-buffer
                  transport-integration-probe-v0.4--capture-buffer))
               (setq transport-integration-probe-v0.4--capture-buffer nil)))
            (transport-integration-probe-v0.4--cleanup-step
             "wrapper-temp"
             (lambda ()
               (when (and transport-integration-probe-v0.4--temp-dir
                          (file-directory-p
                           transport-integration-probe-v0.4--temp-dir))
                 (delete-directory
                  transport-integration-probe-v0.4--temp-dir t))))
            (let ((complete
                   (and (null transport-integration-probe-v0.4--cleanup-errors)
                        (transport-integration-probe-v0.4--kill-advice-gone-p)
                        (null transport-integration-probe-v0.4--t3-advice-leftover)
                        (null transport-integration-probe-v0.4--t4-advice-leftover)
                        (not (buffer-live-p
                              transport-integration-probe-v0.4--capture-buffer))
                        transport-integration-probe-v0.4--temp-dir
                        (not (file-exists-p
                              transport-integration-probe-v0.4--temp-dir))
                        transport-integration-probe-v0.4--guards-after-captured
                        transport-integration-probe-v0.4--process-after-captured)))
              (when complete
                (transport-integration-probe-v0.4--cleanup-step
                 "kill-emacs-hook"
                 (lambda ()
                   (remove-hook
                    'kill-emacs-hook
                    #'transport-integration-probe-v0.4--cleanup-hook)
                   (setq transport-integration-probe-v0.4--hook-installed nil)))
                (setq complete
                      (and complete
                           (not (memq
                                 #'transport-integration-probe-v0.4--cleanup-hook
                                 kill-emacs-hook))))
              (setq transport-integration-probe-v0.4--cleanup-complete complete
                    transport-integration-probe-v0.4--cleanup-evidence
                    (transport-integration-probe-v0.4--cleanup-evidence)))))
        (setq transport-integration-probe-v0.4--cleanup-running nil)))))

(defun transport-integration-probe-v0.4--cleanup-hook ()
  "Compensate incomplete cleanup without output or signaling."
  (condition-case nil
      (transport-integration-probe-v0.4--cleanup)
    (error nil)))

(defun transport-integration-probe-v0.4--capture-base-output ()
  "Save captured base stdout bytes and SHA before buffer cleanup."
  (setq transport-integration-probe-v0.4--base-stdout-raw
        (if (buffer-live-p transport-integration-probe-v0.4--capture-buffer)
            (with-current-buffer
                transport-integration-probe-v0.4--capture-buffer
              (buffer-string))
          ""))
  (setq transport-integration-probe-v0.4--base-stdout-bytes
        (string-bytes
         (encode-coding-string
          transport-integration-probe-v0.4--base-stdout-raw 'utf-8))
        transport-integration-probe-v0.4--base-stdout-sha256
        (transport-integration-probe-v0.4--sha256-string
         transport-integration-probe-v0.4--base-stdout-raw)))

(defun transport-integration-probe-v0.4--parse-base-output ()
  "Parse captured base stdout without retaining raw output in the report."
  (setq transport-integration-probe-v0.4--base-parsed nil
        transport-integration-probe-v0.4--base-json nil
        transport-integration-probe-v0.4--base-parse-error nil)
  (condition-case err
      (progn
        (setq transport-integration-probe-v0.4--base-json
              (json-parse-string
               transport-integration-probe-v0.4--base-stdout-raw
               :object-type 'alist
               :array-type 'list
               :null-object nil
               :false-object :json-false))
        (setq transport-integration-probe-v0.4--base-parsed t))
    (error
     (setq transport-integration-probe-v0.4--base-parse-error
           (transport-integration-probe-v0.4--preview
            (error-message-string err))))))

(defun transport-integration-probe-v0.4--base-field (key)
  "Return KEY from the parsed base object."
  (transport-integration-probe-v0.4--object-value
   transport-integration-probe-v0.4--base-json key))

(defun transport-integration-probe-v0.4--base-failures ()
  "Return the parsed base failures array."
  (transport-integration-probe-v0.4--base-field 'failures))

(defun transport-integration-probe-v0.4--base-failures-empty-p ()
  "Return non-nil when parsed base failures is empty."
  (let ((failures (transport-integration-probe-v0.4--base-failures)))
    (and transport-integration-probe-v0.4--base-parsed
         (or (null failures)
             (and (vectorp failures) (= 0 (length failures)))
             (and (listp failures) (= 0 (length failures)))))))

(defun transport-integration-probe-v0.4--base-success-p ()
  "Return non-nil when base exit and failures prove the base subgate."
  (and transport-integration-probe-v0.4--base-parsed
       (listp transport-integration-probe-v0.4--base-json)
       (equal transport-integration-probe-v0.4--base-exit-status 0)
       transport-integration-probe-v0.4--base-kill-called
       (transport-integration-probe-v0.4--base-failures-empty-p)))

(defun transport-integration-probe-v0.4--base-cleanup-p ()
  "Return non-nil when every selected base cleanup bit is true."
  (let ((cleanup (transport-integration-probe-v0.4--base-field 'cleanup)))
    (and (listp cleanup)
         (cl-every
          (lambda (key)
            (eq (transport-integration-probe-v0.4--object-value cleanup key) t))
          '(advice_gone timer_gone temp_dir_gone db_globals_nil
            probe_buffer_gone llm_log_gone)))))

(defun transport-integration-probe-v0.4--request-record ()
  "Return the selected base transport record."
  (transport-integration-probe-v0.4--base-field 'required_transport_record))

(defun transport-integration-probe-v0.4--request-schema ()
  "Return the base request response-schema SHA."
  (transport-integration-probe-v0.4--object-value
   (transport-integration-probe-v0.4--request-record)
   'request_response_schema_sha256))

(defun transport-integration-probe-v0.4--request-num-predict ()
  "Return the base request num_predict value."
  (transport-integration-probe-v0.4--object-value
   (transport-integration-probe-v0.4--request-record)
   'request_max_output_tokens))

(defun transport-integration-probe-v0.4--request-think ()
  "Return the proven request think value.
The frozen base serializes no separate think field; empty base failures
therefore provide the only allowed indirect proof."
  (if (transport-integration-probe-v0.4--base-success-p)
      :json-false
    nil))

(defun transport-integration-probe-v0.4--byte-fidelity-p ()
  "Return non-nil when selected base byte and SHA fields all agree."
  (let* ((record (transport-integration-probe-v0.4--request-record))
         (llm-bytes (transport-integration-probe-v0.4--object-value
                     record 'llm_text_bytes))
         (runtime-bytes (transport-integration-probe-v0.4--object-value
                         record 'runtime_response_bytes))
         (outcome-bytes (transport-integration-probe-v0.4--object-value
                         record 'outcome_raw_bytes))
         (llm-sha (transport-integration-probe-v0.4--object-value
                   record 'llm_text_sha256))
         (runtime-sha (transport-integration-probe-v0.4--object-value
                       record 'runtime_response_sha256))
         (outcome-sha (transport-integration-probe-v0.4--object-value
                       record 'outcome_raw_sha256)))
    (and (transport-integration-probe-v0.4--base-success-p)
         (numberp llm-bytes)
         (> llm-bytes 0)
         (equal llm-bytes runtime-bytes)
         (equal llm-bytes outcome-bytes)
         (stringp llm-sha)
         (equal llm-sha runtime-sha)
         (equal llm-sha outcome-sha))))

(defun transport-integration-probe-v0.4--guards-unchanged-p ()
  "Return non-nil when both guard snapshots were captured and equal."
  (and transport-integration-probe-v0.4--guards-before-captured
       transport-integration-probe-v0.4--guards-after-captured
       (equal transport-integration-probe-v0.4--guards-before
              transport-integration-probe-v0.4--guards-after)))

(defun transport-integration-probe-v0.4--logical-success-p ()
  "Return non-nil for every pre-output success condition."
  (and (transport-integration-probe-v0.4--base-success-p)
       (= transport-integration-probe-v0.4--base-load-count 1)
       (equal (transport-integration-probe-v0.4--request-schema)
              transport-integration-probe-v0.4--expected-schema-sha256)
       (eq (transport-integration-probe-v0.4--request-think) :json-false)
       (equal (transport-integration-probe-v0.4--request-num-predict) 2048)
       (equal (transport-integration-probe-v0.4--base-field 'parser_class)
              "valid")
       (transport-integration-probe-v0.4--byte-fidelity-p)
       (= transport-integration-probe-v0.4--t4-hit-count 0)
       (= (let ((new (transport-integration-probe-v0.4--new-processes)))
            (if (and transport-integration-probe-v0.4--process-before-captured
                     transport-integration-probe-v0.4--process-after-captured)
                (length new)
              -1))
          0)
       (transport-integration-probe-v0.4--guards-unchanged-p)
       (transport-integration-probe-v0.4--base-cleanup-p)
       transport-integration-probe-v0.4--cleanup-complete
       transport-integration-probe-v0.4--base-kill-called
       (null transport-integration-probe-v0.4--launch-error)
       (null transport-integration-probe-v0.4--cleanup-errors)))

(defun transport-integration-probe-v0.4--base-selected ()
  "Select only the frozen base fields allowed in combined JSON."
  (mapcar
   (lambda (key)
     (cons (symbol-name key)
           (transport-integration-probe-v0.4--json-safe
            (transport-integration-probe-v0.4--base-field key))))
   '(subgate_status STOP-2 STOP-3 execution_authorized parser_class
     required_transport_record failures cleanup not_proved)))

(defun transport-integration-probe-v0.4--process-output ()
  "Return bounded process evidence."
  (transport-integration-probe-v0.4--process-evidence))

(defun transport-integration-probe-v0.4--frozen-output ()
  "Return the seven-link frozen SHA object."
  (list
   (cons "audit" transport-integration-probe-v0.4--audit-sha256)
   (cons "base" transport-integration-probe-v0.4--base-sha256)
   (cons "v0.1_wrapper" transport-integration-probe-v0.4--v0.1-wrapper-sha256)
   (cons "v0.2_source" transport-integration-probe-v0.4--v0.2-source-sha256)
   (cons "v0.2_result" transport-integration-probe-v0.4--v0.2-result-sha256)
   (cons "v0.3_source" transport-integration-probe-v0.4--v0.3-source-sha256)
   (cons "v0.3_result" transport-integration-probe-v0.4--v0.3-result-sha256)))

(defun transport-integration-probe-v0.4--provenance-output ()
  "Return bounded provenance for this independent subgate."
  (list
   (cons "independent_byte_fidelity_subgate" t)
   (cons "not_retry" t)
   (cons "executor" "Luna")
   (cons "pi_participated" :json-false)
   (cons "ascii_synthetic_only" t)
   (cons "real_ollama_and_utf8_proven" :json-false)
   (cons "b0_1_mechanism" "not_proved")))

(defun transport-integration-probe-v0.4--not-proved-output ()
  "Return explicit open claims."
  (vector
   "STOP-2 Superchat integration remains open"
   "STOP-3 UTF-8 decision remains open"
   "real Ollama transport is not proven by the synthetic transport"
   "UTF-8 transport behavior is not proven by this ASCII synthetic payload"
   "B0.1 upstream transport mechanism remains not_proved"
   "Tape content-hash is not emitted independently; its assertion is proven only by empty base failures"))

(defun transport-integration-probe-v0.4--build-report ()
  "Build the bounded combined report without raw base stdout."
  (let ((success (transport-integration-probe-v0.4--logical-success-p)))
    (list
     (cons "schema_version"
           "closed-loop-experience-correction-v0/transport-integration-probe-v0.4-result")
     (cons "probe" "transport-integration-probe-v0.4")
     (cons "throwaway" t)
     (cons "subgate_status"
           (if success "candidate-closed-pending-review" "open"))
     (cons "STOP-2" "Superchat integration open")
     (cons "STOP-3" "UTF-8 decision open")
     (cons "execution_authorized" :json-false)
     (cons "base"
           (transport-integration-probe-v0.4--base-selected))
     (cons "base_stdout"
           (list (cons "bytes"
                       transport-integration-probe-v0.4--base-stdout-bytes)
                 (cons "sha256"
                       transport-integration-probe-v0.4--base-stdout-sha256)))
     (cons "t3"
           (list (cons "symbol_counts"
                       (transport-integration-probe-v0.4--t3-json))))
     (cons "t4"
           (list (cons "hit_count"
                       transport-integration-probe-v0.4--t4-hit-count)
                 (cons "first"
                       (or transport-integration-probe-v0.4--t4-first
                           :json-false))))
     (cons "processes"
           (transport-integration-probe-v0.4--process-output))
     (cons "guards"
           (list (cons "before"
                       (transport-integration-probe-v0.4--json-safe
                        transport-integration-probe-v0.4--guards-before))
                 (cons "after"
                       (transport-integration-probe-v0.4--json-safe
                        transport-integration-probe-v0.4--guards-after))
                 (cons "unchanged"
                       (if (transport-integration-probe-v0.4--guards-unchanged-p)
                           t :json-false))))
     (cons "tape_assertions_proven_by_empty_base_failures"
           (if (transport-integration-probe-v0.4--base-success-p)
               t :json-false))
     (cons "frozen_shas"
           (transport-integration-probe-v0.4--frozen-output))
     (cons "wrapper_cleanup"
           (or transport-integration-probe-v0.4--cleanup-evidence
               (list (cons "complete" :json-false))))
     (cons "provenance"
           (transport-integration-probe-v0.4--provenance-output))
     (cons "fatal_error"
           (or transport-integration-probe-v0.4--launch-error
               transport-integration-probe-v0.4--base-parse-error
               transport-integration-probe-v0.4--finalize-error
               nil))
     (cons "not_proved"
           (transport-integration-probe-v0.4--not-proved-output)))))

(defun transport-integration-probe-v0.4--build-fallback (message)
  "Build a same-schema minimal fallback report."
  (list
   (cons "schema_version"
         "closed-loop-experience-correction-v0/transport-integration-probe-v0.4-result")
   (cons "probe" "transport-integration-probe-v0.4")
   (cons "throwaway" t)
   (cons "subgate_status" "open")
   (cons "STOP-2" "Superchat integration open")
   (cons "STOP-3" "UTF-8 decision open")
   (cons "execution_authorized" :json-false)
   (cons "fatal_error" (transport-integration-probe-v0.4--preview message))
   (cons "frozen_shas" (transport-integration-probe-v0.4--frozen-output))
   (cons "provenance" (transport-integration-probe-v0.4--provenance-output))
   (cons "not_proved"
         (vector "combined report fallback"
                 "B0.1 upstream transport mechanism remains not_proved"
                 "base fields unavailable or report construction failed"))))

(defun transport-integration-probe-v0.4--json-bytes (json)
  "Return UTF-8 bytes in JSON."
  (string-bytes (encode-coding-string json 'utf-8)))

(defun transport-integration-probe-v0.4--encode-bounded (report message)
  "Encode REPORT with exact final stdout_bytes, with bounded fallback."
  (cl-labels
      ((encode-fixed-point (object)
         (let ((guess 0)
               (encoded nil)
               (next nil)
               (stable nil)
               (remaining 16))
           (while (and (> remaining 0) (not stable))
             (setq encoded
                   (json-encode
                    (append object
                            (list (cons "stdout_bytes" guess))))
                   next
                   (1+ (transport-integration-probe-v0.4--json-bytes
                        encoded))
                   stable (= next guess)
                   guess next
                   remaining (1- remaining)))
           (unless stable
             (error "transport-integration-probe-v0.4: stdout_bytes fixed point failed"))
           (cons encoded guess))))
    (let* ((main-fixed (encode-fixed-point report))
           (encoded (car main-fixed))
           (stdout-bytes (cdr main-fixed)))
      (if (<= stdout-bytes transport-integration-probe-v0.4--output-limit)
          (progn
            (setq transport-integration-probe-v0.4--output-size-ok t)
            encoded)
        (setq transport-integration-probe-v0.4--output-size-ok nil)
        (let* ((fallback
                (transport-integration-probe-v0.4--build-fallback
                 (or message "final JSON exceeds 16384 bytes")))
               (fallback-fixed (encode-fixed-point fallback))
               (fallback-encoded (car fallback-fixed))
               (fallback-stdout-bytes (cdr fallback-fixed)))
          (if (<= fallback-stdout-bytes
                  transport-integration-probe-v0.4--output-limit)
              fallback-encoded
            (error "transport-integration-probe-v0.4: fallback exceeds output limit")))))))

(defun transport-integration-probe-v0.4--print-real (encoded)
  "Print one complete JSON line to the saved real stdout."
  (let ((standard-output
         transport-integration-probe-v0.4--saved-standard-output))
    (princ encoded)
    (terpri)))

(defun transport-integration-probe-v0.4--fixed-fallback-json (message)
  "Return a final minimal fallback string without report construction."
  (format
   (concat "{\"schema_version\":\"closed-loop-experience-correction-v0/"
           "transport-integration-probe-v0.4-result\","
           "\"probe\":\"transport-integration-probe-v0.4\","
           "\"throwaway\":true,\"subgate_status\":\"open\","
           "\"STOP-2\":\"Superchat integration open\","
           "\"STOP-3\":\"UTF-8 decision open\","
           "\"execution_authorized\":false,\"fatal_error\":%s,"
           "\"not_proved\":[\"fixed fallback\"]}")
   (json-encode-string (transport-integration-probe-v0.4--preview message))))

(defun transport-integration-probe-v0.4--emit-fallback (message)
  "Emit a bounded same-schema fallback to real stdout."
  (transport-integration-probe-v0.4--print-real
   (transport-integration-probe-v0.4--encode-bounded
    (transport-integration-probe-v0.4--build-fallback message)
    message)))

(defun transport-integration-probe-v0.4--kill-emacs-around (original &optional base-exit)
  "Merge base output, then call ORIGINAL kill-emacs exactly once."
  (setq transport-integration-probe-v0.4--base-kill-called t
        transport-integration-probe-v0.4--base-exit-status base-exit)
  (condition-case nil
      (when (advice-member-p
             #'transport-integration-probe-v0.4--kill-emacs-around 'kill-emacs)
        (advice-remove
         'kill-emacs #'transport-integration-probe-v0.4--kill-emacs-around))
    (error nil))
  (setq transport-integration-probe-v0.4--kill-advice-installed nil)
  (let ((wrapper-exit 1))
    (condition-case err
        (setq wrapper-exit
              (transport-integration-probe-v0.4--finalize base-exit))
      (error
       (setq transport-integration-probe-v0.4--finalize-error
             (transport-integration-probe-v0.4--preview
              (error-message-string err)))
       (condition-case nil
           (transport-integration-probe-v0.4--cleanup)
         (error nil))
       (condition-case nil
           (transport-integration-probe-v0.4--emit-fallback
            transport-integration-probe-v0.4--finalize-error)
         (error
          (transport-integration-probe-v0.4--print-real
           (transport-integration-probe-v0.4--fixed-fallback-json
            transport-integration-probe-v0.4--finalize-error))))
       (setq wrapper-exit 1)))
    ;; The original is called once, after advice removal and final output.
    (let ((standard-output
           transport-integration-probe-v0.4--saved-standard-output))
      (funcall original wrapper-exit))))

(defun transport-integration-probe-v0.4--finalize (_base-exit)
  "Parse/merge/cleanup/print and return the wrapper exit status."
  (transport-integration-probe-v0.4--capture-base-output)
  (transport-integration-probe-v0.4--parse-base-output)
  ;; Cleanup is complete before report construction and real stdout.
  (transport-integration-probe-v0.4--cleanup)
  (let* ((report (transport-integration-probe-v0.4--build-report))
         (encoded
          (transport-integration-probe-v0.4--encode-bounded
           report transport-integration-probe-v0.4--base-parse-error)))
    (transport-integration-probe-v0.4--print-real encoded)
    (if (and (transport-integration-probe-v0.4--logical-success-p)
             transport-integration-probe-v0.4--output-size-ok)
        0
      1)))

(defun transport-integration-probe-v0.4--emit-note ()
  "Emit the one wrapper stderr note."
  (message
   "transport-integration-probe-v0.4: full-product-context; base loaded exactly once; stdout captured; synthetic/T3/T4 bounded evidence"))

(defun transport-integration-probe-v0.4--install-kill-advice ()
  "Install the hard B1 kill-emacs around advice before base load."
  (advice-add 'kill-emacs :around
              #'transport-integration-probe-v0.4--kill-emacs-around)
  (setq transport-integration-probe-v0.4--kill-advice-installed t))

(defun transport-integration-probe-v0.4--launch ()
  "Future-only launch: isolate, guard, install, load base once, and delegate exit."
  (setq transport-integration-probe-v0.4--saved-standard-output standard-output)
  (transport-integration-probe-v0.4--reset-state)
  (condition-case err
      (progn
        (add-hook 'kill-emacs-hook
                  #'transport-integration-probe-v0.4--cleanup-hook)
        (setq transport-integration-probe-v0.4--hook-installed t)
        (setq transport-integration-probe-v0.4--temp-dir
              (make-temp-file "sc-b04-wrapper-" t))
        (setq superchat-data-directory
              (expand-file-name "data"
                                transport-integration-probe-v0.4--temp-dir))
        (make-directory superchat-data-directory t)
        (setq transport-integration-probe-v0.4--capture-buffer
              (generate-new-buffer " *transport-integration-probe-v0.4-capture*"))
        (transport-integration-probe-v0.4--emit-note)
        (require 'superchat)
        (require 'llm-ollama)
        (transport-integration-probe-v0.4--assert-product-functions)
        (transport-integration-probe-v0.4--assert-frozen)
        (setq transport-integration-probe-v0.4--guards-before
              (transport-integration-probe-v0.4--guards-snapshot)
              transport-integration-probe-v0.4--guards-before-captured t
              transport-integration-probe-v0.4--process-before
              (transport-integration-probe-v0.4--process-snapshot)
              transport-integration-probe-v0.4--process-before-captured t)
        (transport-integration-probe-v0.4--install-t3)
        (transport-integration-probe-v0.4--install-t4)
        (transport-integration-probe-v0.4--install-kill-advice)
        (let ((standard-output
               transport-integration-probe-v0.4--capture-buffer))
          (setq transport-integration-probe-v0.4--base-load-count
                (1+ transport-integration-probe-v0.4--base-load-count))
          (load transport-integration-probe-v0.4--base-path nil nil t))
        ;; A normal return means the base violated its Entry contract.
        (setq transport-integration-probe-v0.4--launch-error
              "frozen base returned without calling kill-emacs")
        (kill-emacs 1))
    (error
     (setq transport-integration-probe-v0.4--launch-error
           (transport-integration-probe-v0.4--preview
            (error-message-string err)))
     (if transport-integration-probe-v0.4--kill-advice-installed
         ;; B2: launch errors after advice installation delegate through advice.
         (kill-emacs 1)
       ;; Pre-advice failures own their saved-stdout fatal path.
       (transport-integration-probe-v0.4--cleanup)
       (condition-case nil
           (transport-integration-probe-v0.4--emit-fallback
            transport-integration-probe-v0.4--launch-error)
         (error
          (transport-integration-probe-v0.4--print-real
           (transport-integration-probe-v0.4--fixed-fallback-json
            transport-integration-probe-v0.4--launch-error))))
       (let ((standard-output
              transport-integration-probe-v0.4--saved-standard-output))
         (kill-emacs 1))))))

(provide 'transport-integration-probe-v0.4)

;;; transport-integration-probe-v0.4.el ends here
