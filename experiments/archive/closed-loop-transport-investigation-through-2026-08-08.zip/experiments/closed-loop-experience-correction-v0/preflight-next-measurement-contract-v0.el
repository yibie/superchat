;;; preflight-next-measurement-contract-v0.el --- Model-free contract checks -*- lexical-binding: t; -*-

;; This file validates only frozen bytes and local fixtures.  It must not load
;; a provider, submit a Runtime request, or access held-out tasks.  Passing
;; qualifies the measurement instrument for design, v0.4 history, and repo-local
;; hash consistency only: it proves no provider transport capability and never
;; authorizes execution.

(require 'cl-lib)
(require 'json)
(require 'seq)
(require 'subr-x)

(defconst superchat-closed-loop-next-measurement-contract-v0--directory
  (file-name-directory (or load-file-name buffer-file-name)))

(defconst superchat-closed-loop-next-measurement-contract-v0--contract-path
  (expand-file-name "next-measurement-contract-v0.json"
                    superchat-closed-loop-next-measurement-contract-v0--directory))

(defconst superchat-closed-loop-next-measurement-contract-v0--v04-runs-directory
  (expand-file-name "revisions/v0.4/runs"
                    superchat-closed-loop-next-measurement-contract-v0--directory))

(defun superchat-closed-loop-next-measurement-contract-v0--read-json (path)
  "Read PATH as a plist-backed JSON object."
  (with-temp-buffer
    (insert-file-contents path)
    (json-parse-buffer :object-type 'plist :array-type 'list
                       :null-object nil :false-object :json-false)))

(defun superchat-closed-loop-next-measurement-contract-v0--keys (plist)
  "Return sorted keyword keys from PLIST."
  (sort (cl-loop for (key _value) on plist by #'cddr collect key)
        (lambda (left right)
          (string< (symbol-name left) (symbol-name right)))))

(defun superchat-closed-loop-next-measurement-contract-v0--exact-keys-p
    (plist expected)
  "Return non-nil when PLIST has exactly EXPECTED keys."
  (equal (superchat-closed-loop-next-measurement-contract-v0--keys plist)
         (sort (copy-sequence expected)
               (lambda (left right)
                 (string< (symbol-name left) (symbol-name right))))))

(defun superchat-closed-loop-next-measurement-contract-v0--bounded-string-p
    (value max-length)
  "Return non-nil when VALUE is a non-empty string no longer than MAX-LENGTH."
  (and (stringp value)
       (not (string-empty-p value))
       (<= (length value) max-length)))

(defun superchat-closed-loop-next-measurement-contract-v0--scored-section-p
    (section labels)
  "Return non-nil when SECTION has an exact score-to-label mapping in LABELS."
  (and (listp section)
       (superchat-closed-loop-next-measurement-contract-v0--exact-keys-p
        section '(:score :label :evidence))
       (integerp (plist-get section :score))
       (<= 0 (plist-get section :score) 2)
       (equal (alist-get (plist-get section :score) labels)
              (plist-get section :label))
       (superchat-closed-loop-next-measurement-contract-v0--bounded-string-p
        (plist-get section :evidence) 800)))

(defun superchat-closed-loop-next-measurement-contract-v0--response-valid-p
    (response)
  "Return non-nil when RESPONSE satisfies the frozen evaluator contract."
  (let* ((abstained (plist-get response :abstained))
         (correction (plist-get response :correction_fidelity))
         (quality (plist-get response :research_quality))
         (missing (plist-get response :missing_evidence)))
    (and (listp response)
         (superchat-closed-loop-next-measurement-contract-v0--exact-keys-p
          response
          '(:schema_version :abstained :correction_fidelity
            :research_quality :missing_evidence))
         (equal "closed-loop-evaluator-response-v1"
                (plist-get response :schema_version))
         (memq abstained '(t :json-false))
         (superchat-closed-loop-next-measurement-contract-v0--scored-section-p
          correction
          '((0 . "fidelity-fail")
            (1 . "fidelity-partial")
            (2 . "fidelity-pass")))
         (superchat-closed-loop-next-measurement-contract-v0--scored-section-p
          quality '((0 . "reject") (1 . "revise") (2 . "accept")))
         (listp missing)
         (<= (length missing) 8)
         (cl-every
          (lambda (item)
            (superchat-closed-loop-next-measurement-contract-v0--bounded-string-p
             item 200))
          missing)
         (or (eq abstained :json-false)
             (and (= 0 (plist-get correction :score))
                  (= 0 (plist-get quality :score))
                  missing)))))

(defun superchat-closed-loop-next-measurement-contract-v0--classify-json
    (raw &optional validate-schema)
  "Classify RAW, applying the response schema when VALIDATE-SCHEMA is non-nil."
  (condition-case nil
      (let ((parsed
             (json-parse-string raw :object-type 'plist :array-type 'list
                                :null-object nil :false-object :json-false)))
        (if (and validate-schema
                 (not
                  (superchat-closed-loop-next-measurement-contract-v0--response-valid-p
                   parsed)))
            'schema-invalid
          'valid))
    (json-end-of-file 'eof-incomplete)
    (json-parse-error 'syntax-invalid)))

(defun superchat-closed-loop-next-measurement-contract-v0--fixture-response
    (score)
  "Return a valid evaluator response fixture for SCORE."
  (list :schema_version "closed-loop-evaluator-response-v1"
        :abstained :json-false
        :correction_fidelity
        (list :score score
              :label (alist-get score
                                '((0 . "fidelity-fail")
                                  (1 . "fidelity-partial")
                                  (2 . "fidelity-pass")))
              :evidence "fixture evidence")
        :research_quality
        (list :score score
              :label (alist-get score
                                '((0 . "reject")
                                  (1 . "revise")
                                  (2 . "accept")))
              :evidence "fixture evidence")
        :missing_evidence '()))

(defun superchat-closed-loop-next-measurement-contract-v0--v04-invalid-records ()
  "Return byte identities and parser classes for v0.4 invalid Outcomes."
  (let (records)
    (dolist (directory
             (directory-files
              superchat-closed-loop-next-measurement-contract-v0--v04-runs-directory
              t "^[^.].*"))
      (let ((path (expand-file-name "outcome-record.json" directory)))
        (when (file-readable-p path)
          (let ((outcome
                 (superchat-closed-loop-next-measurement-contract-v0--read-json
                  path)))
            (when (equal "invalid" (plist-get outcome :evaluation_status))
              (let* ((raw (plist-get outcome :raw_response))
                     (encoded (encode-coding-string raw 'utf-8))
                     (parser-class
                      (superchat-closed-loop-next-measurement-contract-v0--classify-json
                       raw))
                     (class (if (eq parser-class 'valid)
                                'schema-invalid
                              parser-class)))
                (push (list :assignment_id (plist-get outcome :assignment_id)
                            :class (symbol-name class)
                            :raw_bytes (string-bytes encoded)
                            :outcome_raw_sha256
                            (secure-hash 'sha256 encoded))
                      records)))))))
    (sort records
          (lambda (left right)
            (string< (plist-get left :assignment_id)
                     (plist-get right :assignment_id))))))

(defun superchat-closed-loop-next-measurement-contract-v0--record-identity
    (record)
  "Return the frozen identity fields from invalid Outcome RECORD."
  (list :assignment_id (plist-get record :assignment_id)
        :class (plist-get record :class)
        :raw_bytes (plist-get record :raw_bytes)
        :outcome_raw_sha256 (plist-get record :outcome_raw_sha256)))

(defun superchat-closed-loop-next-measurement-contract-v0--prompt-counts ()
  "Return frozen v0.4 Prompt counts for contestability and arm visibility."
  (let ((snapshots 0)
        (contestable 0)
        (arm-visible 0))
    (dolist (directory
             (directory-files
              superchat-closed-loop-next-measurement-contract-v0--v04-runs-directory
              t "^[^.].*"))
      (let ((path (expand-file-name "evidence-bundle.json" directory)))
        (when (file-readable-p path)
          (dolist (snapshot
                   (plist-get
                    (superchat-closed-loop-next-measurement-contract-v0--read-json
                     path)
                    :prompt_snapshots))
            (cl-incf snapshots)
            (when (string-match-p
                   (regexp-quote "Treat Claims as contestable interpretations")
                   (plist-get snapshot :system_prompt))
              (cl-incf contestable))
            (when (string-match-p
                   "assignment [^;]*\\(?:no-claim\\|stale-claim\\|corrected-current\\)"
                   (plist-get snapshot :model_prompt))
              (cl-incf arm-visible))))))
    (list :snapshots snapshots
          :contestable contestable
          :arm-visible arm-visible)))

(defun superchat-closed-loop-next-measurement-contract-v0--repo-root ()
  "Return the repository root that owns this experiment."
  (expand-file-name "../.."
                    superchat-closed-loop-next-measurement-contract-v0--directory))

(defun superchat-closed-loop-next-measurement-contract-v0--hash-file (path)
  "Return the sha256 hex of the file at PATH, or nil when unreadable."
  (when (file-readable-p path)
    (with-temp-buffer
      (insert-file-contents path)
      (secure-hash 'sha256 (current-buffer)))))

(defconst superchat-closed-loop-next-measurement-contract-v0--frozen-source-map
  '(("superchat_runtime_sha256" . "superchat-runtime.el")
    ("superchat_llm_sha256" . "superchat-llm.el")
    ("evaluator_implementation_sha256"
     . "experiments/closed-loop-experience-correction-v0/evidence.el")))

(defun superchat-closed-loop-next-measurement-contract-v0--verify-frozen-source-hashes
    (contract)
  "Verify repo-local frozen source hashes of CONTRACT.
Returns the number of matched hashes.  Non-repo-local hashes (llm-ollama,
llm-provider-utils) are asserted absent from the repo so they can never be
faked as verified; the prompt-snapshots bundle hash is external and unverified."
  (let ((matched 0))
    (dolist (entry superchat-closed-loop-next-measurement-contract-v0--frozen-source-map)
      (let* ((key (car entry))
             (path (expand-file-name
                    (cdr entry)
                    (superchat-closed-loop-next-measurement-contract-v0--repo-root)))
             (frozen (plist-get (plist-get contract :source)
                                (intern (concat ":" key))))
             (actual (superchat-closed-loop-next-measurement-contract-v0--hash-file path)))
        (cl-assert (stringp frozen))
        (cl-assert (equal frozen actual) nil "frozen source hash mismatch: %s" key))
      (cl-incf matched))
    (dolist (entry '(("llm_ollama_sha256" . "llm-ollama.el")
                     ("llm_provider_utils_sha256" . "llm-provider-utils.el")))
      (cl-assert
       (not (file-exists-p
             (expand-file-name
              (cdr entry)
              (superchat-closed-loop-next-measurement-contract-v0--repo-root))))
       nil "%s unexpectedly repo-local; reclassify the frozen hash" (car entry)))
    matched))

(defun superchat-closed-loop-next-measurement-contract-v0--run-hash-anchor ()
  "Verify every repo-local file listed in RUNS_SHA256SUMS.
Anchor paths are repository-root relative.  Returns the number of verified
entries; any mismatch or missing file fails the preflight."
  (let ((anchor-path
         (expand-file-name
          "RUNS_SHA256SUMS"
          superchat-closed-loop-next-measurement-contract-v0--directory))
        (verified 0))
    (cl-assert (file-readable-p anchor-path))
    (with-temp-buffer
      (insert-file-contents anchor-path)
      (goto-char (point-min))
      (while (re-search-forward
              "^\\([0-9a-f]\\{64\\}\\)  \\(.+?\\)[ \\t]*$" nil t)
        (let* ((expected (match-string 1))
               (path (expand-file-name
                      (match-string 2)
                      (superchat-closed-loop-next-measurement-contract-v0--repo-root)))
               (actual (superchat-closed-loop-next-measurement-contract-v0--hash-file path)))
          (cl-assert (equal expected actual) nil "RUNS anchor mismatch: %s" path)
          (cl-incf verified))))
    verified))

(defun superchat-closed-loop-next-measurement-contract-v0--durable-reached (scores)
  "Return (list :reached BOOL :stage STAGE) for correction SCORES.
SCORES holds the ordered correction_fidelity scores for collector, analyst,
and reviewer.  A stage is reached durably when its score is 2 and every later
stage, including the reviewer, is also 2; :stage is the earliest such stage
symbol, or nil when none is reached."
  (let ((stages '(collector analyst reviewer))
        (reached nil)
        (stage nil))
    (dotimes (index (length scores))
      (when (and (null stage)
                 (= 2 (nth index scores))
                 (cl-every (lambda (score) (= 2 score))
                           (seq-drop scores index)))
        (setq reached t
              stage (nth index stages))))
    (list :reached reached :stage stage)))

(defun superchat-closed-loop-next-measurement-contract-v0--stage-index (stage)
  "Return the index of STAGE (1=collector, 2=analyst, 3=reviewer)."
  (alist-get stage '((collector . 1) (analyst . 2) (reviewer . 3))))

(defun superchat-closed-loop-next-measurement-contract-v0--paired-stage-gain
    (comparator intervention)
  "Return the stage-index gain, or nil when either arm did not reach.
COMPARATOR and INTERVENTION are :durable-reached results; the gain is defined
only when both arms reached."
  (if (and (plist-get comparator :reached)
           (plist-get intervention :reached))
      (- (superchat-closed-loop-next-measurement-contract-v0--stage-index
          (plist-get comparator :stage))
         (superchat-closed-loop-next-measurement-contract-v0--stage-index
          (plist-get intervention :stage)))
    nil))

(defun superchat-closed-loop-next-measurement-contract-v0--same-attempt-repair-outcome
    (original-class repaired-class)
  "Model-free image of the single same-attempt repair rule.
Returns the caliber under which this artifact's evaluation counts, matching
evaluator.missing_evaluation_definition.calibers: :original-only when the
original response validated on the first parse, :repaired when the original
was invalid and the repaired response validates, or :missing when the original
was invalid and the repaired response does not validate or no repair exists."
  (cond ((eq original-class 'valid) :original-only)
        ((eq repaired-class 'valid) :repaired)
        (t :missing)))

(defun superchat-closed-loop-next-measurement-contract-v0--archive-db-probe (contract)
  "Probe the external v0.4 archive DB named by CONTRACT.
Returns (list :available BOOL :hash_match BOOL).  This verifies availability
and sha256 equality only; it never replays the Tape and never self-claims
Tape-to-Outcome byte equality."
  (let* ((equality
          (plist-get
           (plist-get contract :v0_4_diagnosis_addendum)
           :tape_outcome_equality))
         (path (plist-get equality :archive_session_path))
         (expected (plist-get equality :working_database_sha256)))
    (if (and (stringp path) (file-readable-p path))
        (list :available t
              :hash_match (equal expected
                                 (superchat-closed-loop-next-measurement-contract-v0--hash-file
                                  path)))
      (list :available :json-false :hash_match :json-false))))

(defun superchat-closed-loop-next-measurement-contract-v0-self-check ()
  "Run the complete model-free next-measurement preflight."
  (let* ((contract
          (superchat-closed-loop-next-measurement-contract-v0--read-json
           superchat-closed-loop-next-measurement-contract-v0--contract-path))
         (invalid-records
          (superchat-closed-loop-next-measurement-contract-v0--v04-invalid-records))
         (contract-invalid-records
          (mapcar
           #'superchat-closed-loop-next-measurement-contract-v0--record-identity
           (plist-get
            (plist-get
             (plist-get contract :v0_4_diagnosis_addendum)
             :invalid_outcomes)
            :records)))
         (prompt-counts
          (superchat-closed-loop-next-measurement-contract-v0--prompt-counts)))
    (cl-assert (equal "frozen-preflight-only" (plist-get contract :status)))
    (cl-assert (eq :json-false (plist-get contract :execution_authorized)))
    (cl-assert
     (equal "measurement-instrument qualification"
            (plist-get (plist-get contract :qualification_scope)
                       :contract_kind)))
    ;; Design fixtures: valid scores, score-label mismatch, parse classes.
    (dolist (score '(0 1 2))
      (let ((raw (json-encode
                  (superchat-closed-loop-next-measurement-contract-v0--fixture-response
                   score))))
        (cl-assert
         (eq 'valid
             (superchat-closed-loop-next-measurement-contract-v0--classify-json
              raw t)))))
    (let ((mismatch
           (superchat-closed-loop-next-measurement-contract-v0--fixture-response
            2)))
      (setf (plist-get (plist-get mismatch :correction_fidelity) :label)
            "accept")
      (cl-assert
       (eq 'schema-invalid
           (superchat-closed-loop-next-measurement-contract-v0--classify-json
            (json-encode mismatch) t))))
    (cl-assert
     (eq 'syntax-invalid
         (superchat-closed-loop-next-measurement-contract-v0--classify-json
          "{\"schema_version\":\ninvalid" t)))
    (cl-assert
     (eq 'eof-incomplete
         (superchat-closed-loop-next-measurement-contract-v0--classify-json
          "{\"schema_version\":\"closed-loop-evaluator-response-v1\"" t)))
    ;; Legal abstention: abstained with scores 0 and evidence recorded.
    (let ((legal (superchat-closed-loop-next-measurement-contract-v0--fixture-response
                  0)))
      (setf (plist-get legal :abstained) t
            (plist-get legal :missing_evidence) '("insufficient evidence"))
      (cl-assert
       (eq 'valid
           (superchat-closed-loop-next-measurement-contract-v0--classify-json
            (json-encode legal) t))))
    ;; Illegal abstention: empty missing_evidence, or scores above zero.
    (let ((empty (superchat-closed-loop-next-measurement-contract-v0--fixture-response 0))
          (scored (superchat-closed-loop-next-measurement-contract-v0--fixture-response 2)))
      (setf (plist-get empty :abstained) t)
      (cl-assert
       (eq 'schema-invalid
           (superchat-closed-loop-next-measurement-contract-v0--classify-json
            (json-encode empty) t)))
      (setf (plist-get scored :abstained) t
            (plist-get scored :missing_evidence) '("x"))
      (cl-assert
       (eq 'schema-invalid
           (superchat-closed-loop-next-measurement-contract-v0--classify-json
            (json-encode scored) t))))
    ;; Extra key and missing key fixtures.
    (let ((extra (superchat-closed-loop-next-measurement-contract-v0--fixture-response 2))
          (missing (superchat-closed-loop-next-measurement-contract-v0--fixture-response 2)))
      (setq extra (plist-put extra :extra "x"))
      (cl-assert
       (eq 'schema-invalid
           (superchat-closed-loop-next-measurement-contract-v0--classify-json
            (json-encode extra) t)))
      (setq missing
            (cl-loop for (key value) on missing by #'cddr
                     unless (eq key :schema_version)
                     append (list key value)))
      (cl-assert
       (eq 'schema-invalid
           (superchat-closed-loop-next-measurement-contract-v0--classify-json
            (json-encode missing) t))))
    ;; Stage durable/reached and stage=null encoding.
    (cl-assert
     (equal '(:reached t :stage collector)
            (superchat-closed-loop-next-measurement-contract-v0--durable-reached
             '(2 2 2))))
    (cl-assert
     (equal '(:reached t :stage analyst)
            (superchat-closed-loop-next-measurement-contract-v0--durable-reached
             '(1 2 2))))
    (cl-assert
     (equal '(:reached t :stage reviewer)
            (superchat-closed-loop-next-measurement-contract-v0--durable-reached
             '(0 0 2))))
    (cl-assert
     (equal '(:reached t :stage reviewer)
            (superchat-closed-loop-next-measurement-contract-v0--durable-reached
             '(2 1 2))))
    (cl-assert
     (equal '(:reached nil :stage nil)
            (superchat-closed-loop-next-measurement-contract-v0--durable-reached
             '(0 1 0))))
    ;; stage_gain is defined only when both arms reached.
    (cl-assert
     (= 1
        (superchat-closed-loop-next-measurement-contract-v0--paired-stage-gain
         (superchat-closed-loop-next-measurement-contract-v0--durable-reached
          '(0 0 2))
         (superchat-closed-loop-next-measurement-contract-v0--durable-reached
          '(1 2 2)))))
    (cl-assert
     (null
      (superchat-closed-loop-next-measurement-contract-v0--paired-stage-gain
       (superchat-closed-loop-next-measurement-contract-v0--durable-reached
        '(0 0 2))
       (superchat-closed-loop-next-measurement-contract-v0--durable-reached
        '(0 1 0)))))
    ;; Same-attempt repair rule image: original-only / repaired / missing.
    (cl-assert
     (eq :original-only
         (superchat-closed-loop-next-measurement-contract-v0--same-attempt-repair-outcome
          'valid 'eof-incomplete)))
    (cl-assert
     (eq :repaired
         (superchat-closed-loop-next-measurement-contract-v0--same-attempt-repair-outcome
          'syntax-invalid 'valid)))
    (cl-assert
     (eq :missing
         (superchat-closed-loop-next-measurement-contract-v0--same-attempt-repair-outcome
          'eof-incomplete 'schema-invalid)))
    ;; v0.4 historical consistency: nine invalid outputs (5/2/2) and prompts.
    (cl-assert (equal contract-invalid-records invalid-records))
    (cl-assert (= 5 (cl-count "eof-incomplete" invalid-records
                              :key (lambda (record) (plist-get record :class))
                              :test #'equal)))
    (cl-assert (= 2 (cl-count "syntax-invalid" invalid-records
                              :key (lambda (record) (plist-get record :class))
                              :test #'equal)))
    (cl-assert (= 2 (cl-count "schema-invalid" invalid-records
                              :key (lambda (record) (plist-get record :class))
                              :test #'equal)))
    (cl-assert (equal '(:snapshots 72 :contestable 72 :arm-visible 72)
                      prompt-counts))
    ;; Repo-local frozen source hashes and the run hash anchor.
    (cl-assert
     (= 3 (superchat-closed-loop-next-measurement-contract-v0--verify-frozen-source-hashes
           contract)))
    (cl-assert
     (= 48 (superchat-closed-loop-next-measurement-contract-v0--run-hash-anchor)))
    ;; External archive DB probe: availability and hash equality only.
    (cl-assert
     (equal (plist-get (plist-get contract :source) :working_database_sha256)
            (plist-get
             (plist-get (plist-get contract :v0_4_diagnosis_addendum)
                        :tape_outcome_equality)
             :working_database_sha256)))
    (let ((probe (superchat-closed-loop-next-measurement-contract-v0--archive-db-probe
                  contract)))
      (if (plist-get probe :available)
          (cl-assert (plist-get probe :hash_match))
        (message
         "closed-loop archive DB unavailable: no replay or Tape/Outcome equality claim made")))
    (message
     "closed-loop preflight passed: design fixtures, history 9 (5/2/2) + prompts 72/72/72, source hashes 3 + RUNS anchor 48, archive DB probe; transport unprobed, execution_authorized=false")
    t))

(superchat-closed-loop-next-measurement-contract-v0-self-check)

(provide 'superchat-closed-loop-next-measurement-contract-v0-preflight)

;;; preflight-next-measurement-contract-v0.el ends here
