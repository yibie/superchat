# Static transport egress audit v0

状态：`static-only`，`pre-freeze revision 1`。本审计没有运行 Emacs、probe、batch、产品 Elisp、模型调用或联网。

## 约束与冻结事实

- 本次唯一新增文件是本文档。
- 冻结 probe 哈希已由只读 `shasum -a 256` 核对：
  - `experiments/closed-loop-experience-correction-v0/transport-integration-probe-v0.el`：`4fcf0f51a15c2029b062101921383b6a69991d2e01299fc1b24f7a0fa50db265`。
  - `experiments/closed-loop-experience-correction-v0/transport-integration-probe-v0.1.el`：`7210f2790299754f1b59c071977531c0c5a5cc383345ab231fba107514540ebc`。
- B0：kernel-only 加载因 `superchat--update-status` 为 void 失败；事实记录在 `transport-integration-probe-v0.1.el:3-17`。
- B0.1：完整 `(require 'superchat)` 后出现 curl code 7；结果记录为 `network_attempted=true`、`zero_network_enforced=false`、`execution_authorized=false`，见 `transport-integration-probe-v0.1-result.json:42-48`。该结果没有提供触发 egress 的 Emacs backtrace 或实际上游符号。
- STOP-2/STOP-3 仍为 open；本文件不把静态候选路径冒充 B0.1 的已证实根因。

## 1. 从 `superchat-runtime-submit-blocking` 的可达链

### 1.1 冻结请求的主链

对 B0 请求，静态可达链是：

```text
superchat-runtime-submit-blocking
  -> superchat-runtime-submit
  -> superchat--llm-generate-answer
  -> superchat--collect-llm-tools  ==> nil (`:tools 'none`)
  -> streaming-request-p       ==> t
  -> llm-chat-streaming
  -> llm-provider-utils 的标准 provider `llm-chat-streaming` 方法
  -> llm-request-plz-async
  -> plz-media-type-request
  -> plz
  -> make-process，command 含 curl
```

精确证据如下：

1. `superchat-runtime-submit-blocking` 在 `superchat-runtime.el:900` 定义，在 `superchat-runtime.el:922` 调用 `superchat-runtime-submit`，并在 `superchat-runtime.el:923-926` 用 `accept-process-output` 等待；它在 `superchat-runtime.el:932-934` 返回 terminal response。
2. `superchat-runtime-submit` 在 `superchat-runtime.el:867` 调用 `superchat--llm-generate-answer`，并在 `superchat-runtime.el:879-883` 传入 target model、context、request tools、system prompt、preset。
3. `superchat--llm-generate-answer` 在 `superchat-llm.el:597-620` 收集请求状态、工具、超时和 effective backend；工具收集调用在 `superchat-llm.el:602-604`。`superchat--collect-llm-tools` 对符号 `none` 保持显式空集语义，见 `superchat-llm.el:143-155`。
4. 没有工具时，`streaming-request-p` 在 `superchat-llm.el:621-630` 为真；prompt 在 `superchat-llm.el:631-632` 构造。发送函数在 `superchat-llm.el:921-945`，其中真分支在 `superchat-llm.el:925-931` 调用 `llm-chat-streaming`，否则分支在 `superchat-llm.el:932-936` 才调用 `llm-chat-async`。
5. 本地 `llm-provider-utils.el:477-527` 的标准 provider `llm-chat-streaming` 方法在 `llm-provider-utils.el:482` 调用 `llm-request-plz-async`，并在 `llm-provider-utils.el:483-500` 组装 URL、请求体和媒体处理器。
6. 本地 `llm-request-plz.el:122-159` 定义 `llm-request-plz-async`；其实际请求调用在 `llm-request-plz.el:143-159`，核心是 `plz-media-type-request`（`llm-request-plz.el:143`），不是一个独立的网络实现。
7. `plz-media-type-request` 在 `plz-media-type.el:593-615` 定义；它在 `plz-media-type.el:720-769` 调用 `plz`，并传入异步 `:then`/`:else` 回调。
8. `plz` 在 `plz.el:326-332` 定义；其异步/同步差异由是否提供 `:then` 回调决定，见 `plz.el:372-377`，不是名为 `plz-async` 的另一个函数。
9. `plz` 在 `plz.el:512-525` 创建 curl 进程；其中 `plz.el:517-525` 的 `make-process` 使用 `:command`，首项来自 `plz-curl-program`，而 `plz-curl-program` 的默认值是 `"curl"`，见 `plz.el:229-230`。curl code 7 的错误文本映射在 `plz.el:141-150`。

Runtime 完成/失败回传不是额外网络出口：terminal Tape/event/status/delivery 由 `superchat-runtime--finish` 在 `superchat-runtime.el:495-576` 完成；网络错误回调在 `superchat-llm.el:771-823` 进入 finalize/error 处理。

### 1.2 全部相关出口与可达性

| 符号/原语 | 静态状态（从冻结请求入口） | 证据与边界 |
|---|---|---|
| `llm-chat-streaming` | 可达；本请求的实际产品入口 | `superchat-llm.el:925-931`；标准 provider 实现继续到 `llm-provider-utils.el:477-500`。 |
| `llm-chat-async` | 定义但本请求不可达 | 产品 false 分支在 `superchat-llm.el:932-936`；无工具使其不选中。其标准 provider 实现会在 `llm-provider-utils.el:403-436` 调用 `llm-request-plz-async`。 |
| `llm-request-plz-async` | 可达；标准 provider chat 的异步请求点 | `llm-provider-utils.el:482`；定义及 `plz-media-type-request` 调用在 `llm-request-plz.el:122-159`。 |
| `llm-request-plz-sync` | 定义但本请求不可达 | 同步实现见 `llm-request-plz.el:53-95`，它调用 `plz-media-type-request` 于 `llm-request-plz.el:64-70`；冻结 Runtime 链没有调用者。 |
| `plz-media-type-request` | 可达（经 `llm-request-plz-async`） | `plz-media-type.el:720-769` 调用 `plz`。 |
| `plz` | 可达；真正启动 curl 的公共函数 | 定义/回调语义 `plz.el:326-377`；进程创建 `plz.el:517-525`。 |
| `plz-async` | 不存在于本次审计范围内的源引用/定义；不可达 | `plz` 的异步模型是 `:then`，见 `plz.el:372-377`。只读文本搜索未找到 `plz-async` 符号；不能把它当作实际调用层。 |
| `make-process` | 可达，间接经 `plz` | curl command 的 `make-process` 在 `plz.el:517-525`。 |
| `make-pipe-process` | 在 `plz` 中定义/可执行为辅助管道，但不是网络出口；本请求不是由它发起网络连接 | stderr 辅助进程位置见 `plz.el:512-516`；curl 网络命令仍是 `plz.el:517-525`。 |
| `make-network-process` | 本次审计范围内无引用；不可达性只能作静态结论 | 只读搜索未找到该符号；已知实际 `plz` 路径使用 `make-process`，见 `plz.el:517-525`。未执行时不能对所有 Emacs 动态 advice 作更强断言。 |
| `url-retrieve`、`url-retrieve-synchronously`、`url-queue-retrieve`、`url-retrieve-internal` | 本次审计范围内无调用/定义引用；不可达性只能作静态结论 | 只读搜索未找到这些符号。`llm-request-plz.el:28` 仅 `require 'url-http`，`llm-request-plz.el:90` 使用 `url-http-codes` 做状态码名称映射，不是 URL retrieval。 |
| `plz-event-source-open` | 定义但不在本请求链中可达 | `plz-event-source.el:390-407` 通过 `plz-media-type-request` 提供通用 event-source 路径；Ollama 标准 chat 直接使用 `llm-provider-utils.el:477-500`。 |
| `llm-models` / Ollama `/api/tags` | 定义了另一条可能 egress 的模型可用性路径；不从已证明的 Runtime 主链可达 | `superchat-models.el:93-135` 的 availability 查询可调用 `llm-models`；Ollama 实现直接 `plz 'get` 于 `llm-ollama.el:323-329`。UI 调用点是 `superchat.el:1361-1368`、`superchat.el:2424-2438`、`superchat.el:2522-2532`，不是 `superchat-runtime-submit-blocking` 的直接调用点。B0.1 是否实际触发它是 open。 |

结论：从 `superchat-runtime-submit-blocking` 直接展开，已证实的网络原语全集是 `plz` 最终通过 `make-process` 启动 curl；`plz-async`、URL retrieval 系列、`make-network-process` 在审计范围内没有实际调用。另有 `llm-models -> plz` 的 `/api/tags` 路径，但它不是主链的静态可达节点，必须由 B 判定是否在 B0.1 发生。

## 2. B0.1 bypass：已证实部分与 open 边界

### 2.1 curl 的实际启动点

可以静态精确到：`plz` 的 `make-process`，函数/原语位置为 `plz.el:512-525`；命令首项由 `plz-curl-program` 提供，默认值为 `"curl"`，位置为 `plz.el:229-230`。因此 B0.1 的 curl code 7 与 `plz` 的 curl 错误映射一致，位置为 `plz.el:141-150`。

### 2.2 两处 `cl-letf` 能覆盖什么、不能覆盖什么

冻结 probe 的替换范围精确是：`llm-chat-streaming` 的 `cl-letf` 在 `transport-integration-probe-v0.el:392-446`，`llm-request-plz-async` 的阻断替换在 `transport-integration-probe-v0.el:447-450`。它们不是对 `plz`、`make-process` 或所有模型查询入口的进程级拒绝。

静态已知的 bypass 类别是 Ollama 模型列表：`superchat-models.el:112-123` 可进入 provider 的 `llm-models`，而 `llm-ollama.el:323-329` 直接调用 `plz 'get`；该路径绕过上述两个被替换符号。这解释了“若实际调用者是模型列表查询，为何两处 `cl-letf` 不覆盖”，但没有证明该路径就是 B0.1 的实际调用者。

相反，若 B0.1 的 curl 来自冻结请求的标准 chat 主链，源码语义显示它应先经过 `llm-chat-streaming`（`superchat-llm.el:925-931`）和 `llm-request-plz-async`（`llm-provider-utils.el:477-500`、`llm-request-plz.el:122-159`），按 probe 的替换本应被拦截。B0.1 结果只证明发生了真实 curl，见 `transport-integration-probe-v0.1-result.json:42-48`，没有调用栈、函数身份、advice 状态或实际 URL。

因此：**B0.1 的精确 upstream bypass 及“两处 `cl-letf` 为何在该次运行中未覆盖”是 `open, to be resolved by B`。** 不能在当前静态证据下断言是模型列表路径，也不能猜测 byte-compile、advice 或加载顺序是原因。产品对 `llm-request-plz-async` 的 callback-error advice 仅在 `superchat-llm.el:527-532` 安装；它是否改变了 B0.1 运行时的函数身份/调用关系同样没有被静态证据证明。

任务 B 的最窄诊断问题：**在同一次完整 require + Runtime entry 中，哪个实际函数调用栈首先到达 `plz`/`make-process`？该时刻 `symbol-function`、`advice-member-p`、`symbol-file` 分别显示什么；是否先执行了 `superchat--get-available-models`/`llm-models`？** 只需该栈、函数身份和 curl command 即可关闭 open，不需要重跑其他 probe。

## 3. 冻结请求形状与 Ollama 入口

冻结 probe 构造 Ollama backend 的位置是 `transport-integration-probe-v0.el:350-362`；模型字符串为 `qwen3.6:latest`，定义于 `transport-integration-probe-v0.el:71`。请求绑定 `superchat-llm-backend`、全局 model、reasoning `none` 的位置是 `transport-integration-probe-v0.el:372-387`。

- `tools = none`：Runtime request 明确传入 `:tools 'none`，见 `transport-integration-probe-v0.el:451-460`；preset 也传入 `:tools 'none`，见 `transport-integration-probe-v0.el:463-467`。产品工具收集对 `none` 返回显式空集，见 `superchat-llm.el:143-155`。因此 prompt 不附带 tools；`superchat-llm.el:428-429` 只有非空 tools 才追加 `:tools`。
- `reasoning = none`：preset 传入 `:reasoning 'none`，见 `transport-integration-probe-v0.el:463-467`；产品 prompt 的 preset/global reasoning 选择及 `:reasoning` 传递见 `superchat-llm.el:417-442`。Ollama provider 对已识别模型将 `none` 编成 `:think :false`，见 `llm-ollama.el:220-232`；`qwen3.6` 的本地能力/模型记录见 `llm-models.el:475-479`。
- `max-tokens = 2048`：preset 值见 `transport-integration-probe-v0.el:463-467`，prompt 侧传递见 `superchat-llm.el:435-437`，Ollama body 的 `:num_predict` 见 `llm-ollama.el:233-236`。
- 实际 `llm-chat` 入口是 `llm-chat-streaming`，不是 `llm-chat-async`：无工具使 `streaming-request-p` 为真，证据为 `superchat-llm.el:621-630`；真分支调用为 `superchat-llm.el:925-931`。标准 Ollama provider 继续到 `llm-request-plz-async`，证据为 `llm-provider-utils.el:477-500`。
- 默认 Ollama chat URL 的静态形状是 `http://localhost:11434/api/chat`：Ollama 默认 scheme/host/port 见 `llm-ollama.el:50-64`，URL 拼接见 `llm-ollama.el:96-105`。B0.1 的实际 URL 仍未被结果记录，故具体运行时地址为 open。
- `superchat-models` 的 model-list/availability 查询：定义路径可走 `superchat-models.el:93-135`，Ollama provider 查询 `/api/tags` 的直接 `plz` 在 `llm-ollama.el:323-329`。但从 `superchat-runtime-submit-blocking` 的静态主链没有该调用；可见调用点位于 `superchat.el:1361-1368`、`superchat.el:2424-2438`、`superchat.el:2522-2532`。**B0.1 是否触发了 availability 查询是 `open, to be resolved by B`，静态不能从其结果反推。**

## 4. 任务 B：最小正向拒绝清单

B 只需要在完整 require 后、Runtime entry 前安装一次拒绝/记录，并在 entry 返回后检查；不要只替换两个高层 chat 符号。

### Elisp 符号拒绝点

对以下精确符号安装“调用即记录 backtrace 并 error”的拒绝：

1. `llm-chat-streaming`、`llm-chat-async`：确认产品入口及是否发生 fallback；入口证据分别为 `superchat-llm.el:925-936`。
2. `llm-request-plz-async`、`llm-request-plz-sync`：确认 request adapter 是否被绕过；定义/调用证据为 `llm-request-plz.el:53-95`、`llm-request-plz.el:122-159`。
3. `superchat--get-available-models`、`llm-models`：排除/确认 `/api/tags` 路径；调用定义证据为 `superchat-models.el:93-135`、`llm-ollama.el:323-329`。
4. `plz-media-type-request`、`plz`：在所有高层替换失效时，第一时间捕获真实上游栈；下游关系为 `plz-media-type.el:720-769`、`plz.el:326-377`。
5. `url-retrieve`、`url-retrieve-synchronously`、`url-queue-retrieve`、`url-retrieve-internal`、`make-network-process`：本次静态未发现调用，但 B 用拒绝点把“未发现”提升为运行时证据。
6. `make-process`：必须在完整 require 后、Runtime entry 前安装为 preventive guard；在该 Runtime entry 的动态范围内，`make-process` 没有合法用途，任何调用都应记录 backtrace、`symbol-file`、`symbol-function`、完整参数后立即 error。它是连接发生前的拒绝点，而非事后进程观察；静态对应的 curl 创建点为 `plz.el:517-525`。

### 进程级断言（detective-only 后备）

进程级断言只能作为 preventive `make-process` guard 未命中时的 detective-only 后备，不能替代连接前拒绝。仅在 Runtime entry 返回后比较 `process-list`，并断言：

- 不得出现新增 process name `plz-request-curl`；该名称来自 `plz.el:517`。
- 不得出现新增 process name `plz-request-curl-stderr`；stderr process 位置为 `plz.el:512-516`。
- 不得出现新增 `process-command` 的首项等于 `plz-curl-program`（默认 `"curl"`，见 `plz.el:229-230`）；command 由 `make-process` 传入，见 `plz.el:517-525`。
- 不得出现新增由 `make-pipe-process` 创建的进程；它是辅助 stderr 管道位置 `plz.el:512-516` 的后备检查，不是 preventive guard。
- 不得出现新增 `network-process-p` 为真或任何 `make-network-process` 拒绝命中。

一旦任一拒绝点命中，B 必须记录：命中符号、`backtrace`、`symbol-file`、`symbol-function`/advice 身份，以及 process name/command；这四类信息足以回答上一节的最窄问题。未命中高层符号但命中 `plz` 或 process 级断言时，直接以该栈定位第三路径，不再扩大替换面。

## 5. Open ledger：只保留静态不能判定的项

以下均为 `open, to be resolved by B`：

1. **B0.1 的真实 upstream caller**：是冻结请求的 `llm-chat-streaming -> llm-request-plz-async`，还是 `llm-models -> plz`，或其他完整加载副作用？B 的窄问题见 `transport-egress-audit-v0.md` 本节 2.2；所需证据是首个 `plz`/`make-process` backtrace。
2. **两处 `cl-letf` 的具体失效机制**：若命中 chat 符号，需 B 给出运行时 `symbol-function`/advice/加载文件证据；源码本身对该路径的语义是应被覆盖，见 `superchat-llm.el:925-931`、`llm-provider-utils.el:477-500`。本审计不猜 advice、编译或加载顺序。
3. **B0.1 是否执行 model availability 查询**：静态存在该路径，见 `superchat-models.el:112-123` 与 `llm-ollama.el:323-329`，但没有从 Runtime 主链到它的调用；B 只需报告 `superchat--get-available-models`/`llm-models` 是否命中。
4. **B0.1 实际 URL、curl 参数及进程数量**：默认值可由 `llm-ollama.el:50-105` 与 `plz.el:425-440` 推导，但结果没有实际 command；B 记录 `process-command` 即可。
5. **URL retrieval / `make-network-process` 的运行时命中情况**：静态审计范围没有引用；B 的符号拒绝和 process snapshot 负责给出运行时否证。

## 6. 本阶段验证与边界

- 已做只读文本读取/搜索：Runtime、LLM adapter、product top-level、models、preset、Tape、DB、core；本机 llm 0.31.1 的 `llm.el`、Ollama/provider/request/model sources；plz 0.9.1、plz-media-type 0.2.4、plz-event-source 0.1.3；以及本 experiment 目录。没有加载这些 Elisp。
- 已做只读哈希核对：两份冻结 probe 与任务给定 SHA 完全一致。
- 已做只读工作树核对：`git status --short --untracked-files=all` 显示已有实验改动；本文档是本阶段唯一新增路径。
- Commander 已在主 pane 成功运行只读 `jj diff --name-only`，确认本阶段新增路径仅为 `experiments/closed-loop-experience-correction-v0/transport-egress-audit-v0.md`；其余列出的实验文件均为既有改动。
- `jj diff --summary` 尝试失败于工作副本 snapshot：权限拒绝，无法在 `.git/objects` 创建临时对象。没有因此修改任何文件；该限制留给 Commander 复核。

停止条件已满足：本文档已写入，未执行禁止操作，B0.1 矛盾路径明确保持 open，后续动作仅由任务 B 运行时诊断决定。
