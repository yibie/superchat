;;; transport-live-smoke-v0.3.el --- Throwaway live Ollama smoke v0.3 -*- lexical-binding: t; -*-

;; Problem: the frozen next-measurement contract keeps execution_authorized
;; false because provider transport capability is unproven.  The fake-server
;; probe (transport-probe-v0.el) measured the llm 0.31.1 path locally; this
;; throwaway smoke qualifies the REAL local Ollama (qwen3.6:latest) end to
;; end with exactly one llm-chat-streaming request, no retries, a hard
;; 300s timeout per request, the same response-format vector mechanism and
;; the same real POST serialization.
;;
;; THROWAWAY: experiment-local self-check, not a product file.  Nothing
;; loads it; it may be deleted.  It never requires superchat and never
;; touches the contract/preflight/probe files.
;;
;; v0.2 delta vs v0.1: :reasoning 'none native prompt (no default thinking);
;; actual request body think presence/value recorded and asserted top-level
;; false; raw provider records content_events/content_bytes/content_sha256,
;; thinking_events/thinking_bytes/thinking_sha256, error_events (content hash
;; over each NDJSON event's message.content concatenated in stream order);
;; partial_callback_count per request; output records its own source hash,
;; derived_from v0.1 (path+sha256 7fdb9a59d5c557fa2bcd86c56343e2d98248b6e93c39498eb7ba22b4773f0411),
;; and the v0.1 result artifact; guards also cover the v0.1 source and result.
;; v0.3 delta vs v0.2: single A2-only length-leg request (num_predict 8,
;; reasoning none, self-contained prompt, same frozen response schema);
;; --run rewritten for exactly one request; asserts think present false,
;; zero thinking, content > 0, provider done true with done_reason length
;; and eval_count 8, final parser classification either eof-incomplete or
;; syntax-invalid (provider done_reason=length is the truncation ground
;; truth), content_sha == llm_final_sha,
;; schema hash, ASCII tee, capture_count 1, guards/cleanup; does NOT
;; require schema validity, does NOT invoke the repair rule, does NOT send
;; an A1 request.  The stop leg is inherited from the frozen v0.2 execution.
;; Derived from transport-live-smoke-v0.2.el
;; (sha256 e4abbeeb2726a5319542080b5b8980289cf50107d0b3065469ff8fbc08db4442).
;;
;; Run (single command, absolute -L paths):
;;   emacs -Q --batch -L . \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/llm-0.31.1 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-0.9.1 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-event-source-0.1.3 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-media-type-0.2.4 \
;;     -l experiments/closed-loop-experience-correction-v0/transport-live-smoke-v0.3.el

;;; Code:

(require 'cl-lib)
(require 'json)
(require 'seq)
(require 'subr-x)

(defvar llm-log nil
  "llm.el logging flag; bound around requests to suppress logging.")

(defconst transport-live-smoke-v0--directory
  (file-name-directory (or load-file-name buffer-file-name)))

(defconst transport-live-smoke-v0--contract-path
  (expand-file-name "next-measurement-contract-v0.json"
                    transport-live-smoke-v0--directory))

(defconst transport-live-smoke-v0--probe-path
  (expand-file-name "transport-probe-v0.el"
                    transport-live-smoke-v0--directory))

(defconst transport-live-smoke-v0--elpa-root
  "/Users/chenyibin/.config/nova-emacs/elpa")

(defconst transport-live-smoke-v0--llm-dir
  (expand-file-name "llm-0.31.1" transport-live-smoke-v0--elpa-root))

(defconst transport-live-smoke-v0--plz-dir
  (expand-file-name "plz-0.9.1" transport-live-smoke-v0--elpa-root))

(defconst transport-live-smoke-v0--plz-event-source-dir
  (expand-file-name "plz-event-source-0.1.3" transport-live-smoke-v0--elpa-root))

(defconst transport-live-smoke-v0--plz-media-type-dir
  (expand-file-name "plz-media-type-0.2.4" transport-live-smoke-v0--elpa-root))

(defconst transport-live-smoke-v0--tee-buffer-name "*transport-live-smoke-v0-tee*")
(defconst transport-live-smoke-v0--timeout 300)
(defconst transport-live-smoke-v0--model "qwen3.6:latest")
(defconst transport-live-smoke-v0--expected-schema-sha256
  "bcbc37a0cf42b9def5a906d90201befaea4cf505c208dd21ff6736fac6bf71dd")

(defvar transport-live-smoke-v0--contract nil)
(defvar transport-live-smoke-v0--response-format nil)
(defvar transport-live-smoke-v0--score-mappings nil)
(defvar transport-live-smoke-v0--archive-db-path nil)
(defvar transport-live-smoke-v0--source-load-evidence nil)
(defvar transport-live-smoke-v0--tee-active nil)
(defvar transport-live-smoke-v0--captured-request nil)
(defvar transport-live-smoke-v0--capture-count 0
  "Count of captured /api/chat POST bodies (H1).")

;;; --- Contract loading (read-only) and dependency loading ------------------

(defun transport-live-smoke-v0--read-json-file (path &rest parse-args)
  "Read PATH as JSON with PARSE-ARGS passed to json-parse-buffer."
  (with-temp-buffer
    (insert-file-contents path)
    (apply #'json-parse-buffer parse-args)))

(defun transport-live-smoke-v0--load-sources ()
  "Load the frozen llm 0.31.1 / plz dependency SOURCES in dependency order.
Errors propagate as evidence (fallback to .elc in --load-dependencies)."
  (dolist (file (list
                 (expand-file-name "plz.el" transport-live-smoke-v0--plz-dir)
                 (expand-file-name "plz-media-type.el" transport-live-smoke-v0--plz-media-type-dir)
                 (expand-file-name "plz-event-source.el" transport-live-smoke-v0--plz-event-source-dir)
                 (expand-file-name "llm.el" transport-live-smoke-v0--llm-dir)
                 (expand-file-name "llm-models.el" transport-live-smoke-v0--llm-dir)
                 (expand-file-name "llm-request-plz.el" transport-live-smoke-v0--llm-dir)
                 (expand-file-name "llm-provider-utils.el" transport-live-smoke-v0--llm-dir)
                 (expand-file-name "llm-ollama.el" transport-live-smoke-v0--llm-dir)))
    (load file)))

(defun transport-live-smoke-v0--load-dependencies ()
  "Load dependencies, preferring the frozen .el sources; fall back to the
same-version .elc artifacts when source loading is infeasible, keeping the
minimal failure evidence."
  (condition-case err
      (transport-live-smoke-v0--load-sources)
    (error
     (setq transport-live-smoke-v0--source-load-evidence (error-message-string err))
     (dolist (feature '(plz plz-media-type plz-event-source llm llm-models
                            llm-request-plz llm-provider-utils llm-ollama))
       (require feature)))))

(defun transport-live-smoke-v0--hash-file (path)
  "Return the sha256 hex of the file at PATH, or nil when unreadable."
  (when (file-readable-p path)
    (with-temp-buffer
      (insert-file-contents path)
      (secure-hash 'sha256 (current-buffer)))))

(defun transport-live-smoke-v0--load-contract ()
  "Read the frozen contract (plist objects, vector arrays, like v0.1)."
  (setq transport-live-smoke-v0--contract
        (transport-live-smoke-v0--read-json-file
         transport-live-smoke-v0--contract-path
         :object-type 'plist :array-type 'array
         :null-object nil :false-object :json-false))
  (setq transport-live-smoke-v0--response-format
        (plist-get (plist-get transport-live-smoke-v0--contract :evaluator)
                   :response_schema))
  (setq transport-live-smoke-v0--score-mappings
        (plist-get (plist-get transport-live-smoke-v0--contract :evaluator)
                   :score_label_mappings))
  (setq transport-live-smoke-v0--archive-db-path
        (plist-get
         (plist-get (plist-get transport-live-smoke-v0--contract :v0_4_diagnosis_addendum)
                    :tape_outcome_equality)
         :archive_session_path)))

;;; --- Raw body tee and request capture (read-only advices, gated) ----------

(defun transport-live-smoke-v0--tee-raw (process _media-types string)
  "Append raw response octets from the live /api/chat plz process.
Gated: only while a smoke request is in flight AND the plz process targets
/api/chat.  Bytes are captured before any JSON decode; no filter guard, no
UTF-8 shim."
  (when (and transport-live-smoke-v0--tee-active
             (processp process)
             (let* ((args (process-get process :plz-args))
                    (url (and (listp args) (nth 1 args))))
               (and (stringp url) (string-match-p "/api/chat" url))))
    (with-current-buffer (get-buffer-create transport-live-smoke-v0--tee-buffer-name)
      (set-buffer-multibyte nil)
      (goto-char (point-max))
      (insert string))))

(defun transport-live-smoke-v0--capture-request (url &rest args)
  "Capture the actual POST body llm serializes for a /api/chat request.
ARGS is the keyword argument list after URL; plist-get scans it directly."
  (when (and (stringp url) (string-match-p "/api/chat" url))
    (let ((data (plist-get args :data)))
      (when data
        (cl-incf transport-live-smoke-v0--capture-count)
        (setq transport-live-smoke-v0--captured-request
              (json-serialize data))))))

;;; --- Tee parsing (provider records from raw body) -------------------------

(defun transport-live-smoke-v0--tee-total ()
  "Return the raw response captured in the tee buffer (unibyte)."
  (when (get-buffer transport-live-smoke-v0--tee-buffer-name)
    (with-current-buffer (get-buffer transport-live-smoke-v0--tee-buffer-name)
      (buffer-string))))

(defun transport-live-smoke-v0--tee-body (total)
  "Return the body portion of the raw tee TOTAL."
  (if (string-match "\r\n\r\n" total)
      (substring total (match-end 0))
    total))

(defun transport-live-smoke-v0--tee-body-ascii-p (tee-total)
  "Return t when the NDJSON body of TEE-TOTAL (unibyte raw tee) contains no
octet in 0x80..0xFF.  This is the UTF-8 contamination measurement; no shim
is applied, the raw bytes are judged as-is."
  (let ((body (transport-live-smoke-v0--tee-body tee-total)))
    (not (string-match-p "[\200-\377]" body))))

(defun transport-live-smoke-v0--parse-json-alist (string)
  "Parse STRING as JSON into alist objects and list arrays."
  (json-parse-string string :object-type 'alist :array-type 'list
                     :null-object :null :false-object :json-false))

(defun transport-live-smoke-v0--parse-events (body)
  "Parse NDJSON BODY into events, consuming only newline-terminated lines;
a final segment without a trailing newline is dropped (plz x-ndjson line
semantics)."
  (let* ((ends-with-newline (string-suffix-p "\n" body))
         (lines (split-string body "\n" t))
         (complete-lines (if ends-with-newline lines (butlast lines)))
         events)
    (dolist (line complete-lines)
      (unless (string-empty-p (string-trim line))
        (condition-case nil
            (push (transport-live-smoke-v0--parse-json-alist line) events)
          (json-parse-error nil)
          (json-end-of-file nil))))
    (nreverse events)))

(defun transport-live-smoke-v0--provider-records (body)
  "Derive provider records from the raw NDJSON BODY: done/done_reason/
counts plus content/thinking/error statistics.  Content and thinking
hashes are computed over each event's message.content / message.thinking
concatenated in stream order."
  (let ((events (transport-live-smoke-v0--parse-events body))
        done done-reason pe ec
        (content-events 0) (thinking-events 0) (error-events 0)
        content-text thinking-text)
    (dolist (event events)
      (let ((message (alist-get 'message event)))
        (when (alist-get 'content message)
          (cl-incf content-events)
          (setq content-text (concat content-text (alist-get 'content message))))
        (when (alist-get 'thinking message)
          (cl-incf thinking-events)
          (setq thinking-text (concat thinking-text (alist-get 'thinking message)))))
      (when (alist-get 'error event)
        (cl-incf error-events))
      (setq done (alist-get 'done event)
            done-reason (alist-get 'done_reason event)
            pe (or pe (alist-get 'prompt_eval_count event))
            ec (or ec (alist-get 'eval_count event))))
    (list :done done :done_reason done-reason
          :prompt_eval_count pe :eval_count ec
          :content_events content-events
          :content_bytes (string-bytes (or content-text ""))
          :content_sha256 (transport-live-smoke-v0--sha256 (or content-text ""))
          :thinking_events thinking-events
          :thinking_bytes (string-bytes (or thinking-text ""))
          :thinking_sha256 (transport-live-smoke-v0--sha256 (or thinking-text ""))
          :error_events error-events)))

;;; --- Canonical JSON (schema hash from the actual request body) ------------

(defun transport-live-smoke-v0--canonical-key (key)
  "Return KEY as a string for canonical JSON (symbol keys allowed)."
  (if (symbolp key) (symbol-name key) key))

(defun transport-live-smoke-v0--canonical-json (object)
  "Return a canonical JSON string for OBJECT (alist objects, list arrays).
Object keys sorted recursively; same normalization as transport-probe-v0."
  (cond
   ((eq object :null) "null")
   ((null object) "null")
   ((stringp object) (json-encode-string object))
   ((numberp object) (number-to-string object))
   ((eq object t) "true")
   ((eq object :json-false) "false")
   ((consp object)
    (if (and (consp (car object)) (not (consp (caar object))))
        (concat "{"
                (mapconcat
                 (lambda (pair)
                   (concat (json-encode-string
                            (transport-live-smoke-v0--canonical-key (car pair)))
                           ":"
                           (transport-live-smoke-v0--canonical-json (cdr pair))))
                 (sort (copy-sequence object)
                       (lambda (left right)
                         (string< (transport-live-smoke-v0--canonical-key (car left))
                                  (transport-live-smoke-v0--canonical-key (car right)))))
                 ",")
                "}")
      (concat "["
              (mapconcat #'transport-live-smoke-v0--canonical-json object ",")
              "]")))
   (t (json-encode-string (format "%S" object)))))

(defun transport-live-smoke-v0--sha256 (string)
  "Return the sha256 hex of STRING's bytes."
  (secure-hash 'sha256 (encode-coding-string string 'utf-8)))

(defun transport-live-smoke-v0--schema-sha256 (request-body)
  "Re-canonicalize the format sub-object of the actual POST body; return
the sha256, or nil when no format is present."
  (condition-case nil
      (let* ((req (transport-live-smoke-v0--parse-json-alist request-body))
             (format-obj (alist-get 'format req)))
        (when format-obj
          (transport-live-smoke-v0--sha256
           (transport-live-smoke-v0--canonical-json format-obj))))
    (error nil)))

(defun transport-live-smoke-v0--num-predict (request-body)
  "Return options.num_predict from the actual POST body, or nil."
  (condition-case nil
      (let ((req (transport-live-smoke-v0--parse-json-alist request-body)))
        (alist-get 'num_predict (alist-get 'options req)))
    (error nil)))

;;; --- One live llm-chat-streaming request ----------------------------------

(defun transport-live-smoke-v0--think-value (request-body)
  "Return the top-level think value of the actual POST body (:json-false,
t, or nil when absent)."
  (condition-case nil
      (let ((req (transport-live-smoke-v0--parse-json-alist request-body)))
        (alist-get 'think req))
    (error nil)))

(defun transport-live-smoke-v0--think-present (request-body)
  "Return t when the actual POST body has a top-level think key."
  (condition-case nil
      (let ((req (transport-live-smoke-v0--parse-json-alist request-body)))
        (assq 'think req))
    (error nil)))

(defun transport-live-smoke-v0--make-provider ()
  "Return an llm-ollama provider for the local Ollama daemon."
  (make-llm-ollama :host "127.0.0.1" :port 11434
                   :chat-model transport-live-smoke-v0--model))

(defun transport-live-smoke-v0--make-prompt (user-text num-predict)
  "Return a chat prompt with USER-TEXT and NUM-PREDICT, carrying the frozen
response-format schema (vector arrays, same mechanism as v0.1)."
  (llm-make-chat-prompt user-text
                        :max-tokens num-predict
                        :reasoning 'none
                        :response-format transport-live-smoke-v0--response-format))

(defun transport-live-smoke-v0--wait (state &optional timeout)
  "Wait until STATE is settled or TIMEOUT seconds pass.  Returns settled-p."
  (let ((deadline (+ (float-time) (or timeout transport-live-smoke-v0--timeout))))
    (while (and (not (plist-get state :settled))
                (< (float-time) deadline))
      (condition-case e
          (accept-process-output nil 0.05)
        (error (push (list :error (error-message-string e))
                     (plist-get state :filter-errors)))))
    (plist-get state :settled)))

(defvar transport-live-smoke-v0--failures nil)

(defun transport-live-smoke-v0--run-request (user-text num-predict)
  "Run one live llm-chat-streaming; return a result plist.
Saves the async request object; at the hard timeout it calls
llm-cancel-request (when the object is non-nil) and always deletes any live
plz/curl processes, marking status timeout and settled.  The tee buffer and
captured request body are reset before each request; tee-active covers
exactly this single request window."
  (let* ((state (list :final nil :error nil :settled nil :status nil
                      :filter-errors nil))
         (tee (get-buffer-create transport-live-smoke-v0--tee-buffer-name))
         (request-obj nil)
         (partial-count 0)
         (timed-out nil))
    (with-current-buffer tee
      (set-buffer-multibyte nil)
      (erase-buffer))
    (setq transport-live-smoke-v0--tee-active t
          transport-live-smoke-v0--captured-request nil)
    (unwind-protect
        (progn
          (let ((llm-log nil))
            (setq request-obj
                  (llm-chat-streaming
                   (transport-live-smoke-v0--make-provider)
                   (transport-live-smoke-v0--make-prompt user-text num-predict)
                   (lambda (_text) (cl-incf partial-count))
                   (lambda (text)
                     (setf (plist-get state :final) text)
                     (setf (plist-get state :status) 'done)
                     (setf (plist-get state :settled) t))
                   (lambda (type err)
                     (setf (plist-get state :error) (list type err))
                     (setf (plist-get state :status) 'error)
                     (setf (plist-get state :settled) t)))))
          (unless (transport-live-smoke-v0--wait state)
            (setq timed-out t)
            (when request-obj
              (condition-case nil (llm-cancel-request request-obj) (error nil)))
            (dolist (p (process-list))
              (when (string-match-p "plz-request-curl" (process-name p))
                (delete-process p)))
            (setf (plist-get state :status) 'timeout)
            (setf (plist-get state :settled) t)))
      (setq transport-live-smoke-v0--tee-active nil))
    (let ((tee-total (transport-live-smoke-v0--tee-total)))
      (list :settled (plist-get state :settled)
            :status (plist-get state :status)
            :final (plist-get state :final)
            :error (plist-get state :error)
            :timed_out timed-out
            :filter_errors (plist-get state :filter-errors)
            :request_body transport-live-smoke-v0--captured-request
            :partial_callback_count partial-count
            :tee (or tee-total "")
            :provider (transport-live-smoke-v0--provider-records
                       (transport-live-smoke-v0--tee-body (or tee-total "")))))))

(defun transport-live-smoke-v0--validate-against-schema (obj)
  "Return violation strings for OBJ (alist object, list arrays) against the
frozen evaluator schema.  Required keys are checked for PRESENCE via assq
(an empty array parses to nil, so value-based checks would wrongly flag
missing_evidence: []).  Nested sections require score/label/evidence keys;
score must be an integer 0..2, label a string equal to the frozen mapping,
evidence a string of length 1..800.  missing_evidence must be present; nil
is a legal empty list, otherwise it must be a list of 1..200-char strings,
at most 8.  abstained=true requires integer zero scores and non-empty
missing_evidence."
  (let (violations)
    (dolist (key '("schema_version" "abstained" "correction_fidelity"
                   "research_quality" "missing_evidence"))
      (unless (assq (intern key) obj)
        (push (format "missing required %s" key) violations)))
    (unless (equal "closed-loop-evaluator-response-v1"
                   (alist-get 'schema_version obj))
      (push "schema_version != const" violations))
    (unless (memq (alist-get 'abstained obj) '(t :json-false))
      (push "abstained not boolean" violations))
    (dolist (section '(correction_fidelity research_quality))
      (let ((sec (alist-get section obj))
            (mapping (plist-get transport-live-smoke-v0--score-mappings
                                (intern (format ":%S" section)))))
        (unless (assq 'score sec)
          (push (format "%S missing score" section) violations))
        (unless (assq 'label sec)
          (push (format "%S missing label" section) violations))
        (unless (assq 'evidence sec)
          (push (format "%S missing evidence" section) violations))
        (let ((score (alist-get 'score sec)))
          (unless (and (integerp score) (<= 0 score 2))
            (push (format "%S score not integer 0..2" section) violations))
          (when (and (integerp score) (<= 0 score 2) mapping)
            (let ((expected-label
                   (plist-get mapping (intern (format ":%d" score)))))
              (unless (and (stringp (alist-get 'label sec))
                           (equal expected-label (alist-get 'label sec)))
                (push (format "%S label %S != frozen mapping %S for score %d"
                              section (alist-get 'label sec) expected-label
                              score)
                      violations)))))
        (let ((evidence (alist-get 'evidence sec)))
          (unless (and (stringp evidence)
                       (<= 1 (length evidence) 800))
            (push (format "%S evidence not string 1..800" section) violations)))))
    (when (assq 'missing_evidence obj)
      (let ((missing (alist-get 'missing_evidence obj)))
        (unless (or (null missing)
                    (and (listp missing)
                         (<= (length missing) 8)
                         (cl-every (lambda (item)
                                     (and (stringp item)
                                          (<= 1 (length item) 200)))
                                   missing)))
          (push "missing_evidence invalid (want [] or strings 1..200, max 8)"
                 violations))))
    (when (eq t (alist-get 'abstained obj))
      (let ((cs (alist-get 'score (alist-get 'correction_fidelity obj)))
            (rs (alist-get 'score (alist-get 'research_quality obj))))
        (unless (and (integerp cs) (= 0 cs)
                     (integerp rs) (= 0 rs))
          (push "abstained without integer zero scores" violations)))
      (unless (alist-get 'missing_evidence obj)
        (push "abstained with empty missing_evidence" violations)))
    (nreverse violations)))

(defun transport-live-smoke-v0--hash-mtime (path)
  "Return (list :hash H :mtime M) for PATH, or nil when unreadable."
  (when (and (stringp path) (file-readable-p path))
    (list :hash (transport-live-smoke-v0--hash-file path)
          :mtime (nth 5 (file-attributes path)))))

(defun transport-live-smoke-v0--guarded-files ()
  "Return alist of guarded paths with their hash/mtime."
  (list (cons "contract" (transport-live-smoke-v0--hash-mtime
                          transport-live-smoke-v0--contract-path))
        (cons "probe" (transport-live-smoke-v0--hash-mtime
                       transport-live-smoke-v0--probe-path))
        (cons "archive-db" (transport-live-smoke-v0--hash-mtime
                            transport-live-smoke-v0--archive-db-path))
        (cons "v0.1-source" (transport-live-smoke-v0--hash-mtime
                             (expand-file-name "transport-live-smoke-v0.el"
                                               transport-live-smoke-v0--directory)))
        (cons "v0.1-result" (transport-live-smoke-v0--hash-mtime
                             (expand-file-name "transport-live-smoke-v0.1-result.json"
                                               transport-live-smoke-v0--directory)))
        (cons "v0.2-source" (transport-live-smoke-v0--hash-mtime
                             (expand-file-name "transport-live-smoke-v0.2.el"
                                               transport-live-smoke-v0--directory)))
        (cons "v0.2-result" (transport-live-smoke-v0--hash-mtime
                             (expand-file-name "transport-live-smoke-v0.2-result.json"
                                               transport-live-smoke-v0--directory)))))

(defun transport-live-smoke-v0--cleanup ()
  "Delete leftover plz/curl processes and probe buffers."
  (dolist (process (process-list))
    (when (string-match-p
           "plz-request-curl\\|transport-live-smoke-v0"
           (process-name process))
      (delete-process process)))
  (when (get-buffer transport-live-smoke-v0--tee-buffer-name)
    (kill-buffer (get-buffer transport-live-smoke-v0--tee-buffer-name)))
  (when (get-buffer "*llm-log*")
    (kill-buffer (get-buffer "*llm-log*"))))

(defun transport-live-smoke-v0--cleanup-proof ()
  "Return a plist of residual checks after cleanup (all must be true)."
  (list :advice_tee_gone
        (null (advice-member-p #'transport-live-smoke-v0--tee-raw
                               'plz-media-type-process-filter))
        :advice_capture_gone
        (null (advice-member-p #'transport-live-smoke-v0--capture-request
                               'llm-request-plz-async))
        :plz_processes_gone
        (null (cl-remove-if-not
               (lambda (p)
                 (string-match-p "plz-request-curl" (process-name p)))
               (process-list)))
        :tee_buffer_gone
        (null (get-buffer transport-live-smoke-v0--tee-buffer-name))
        :llm_log_buffer_gone
        (null (get-buffer "*llm-log*"))))

(defun transport-live-smoke-v0--json-safe-string (s)
  "Return S with raw-byte characters (0x80..0xFF) replaced by U+FFFD."
  (if (string-match-p "[\\200-\\377]" s)
      (apply #'string
             (mapcar (lambda (ch) (if (<= 128 ch 255) 65533 ch)) s))
    s))

(defun transport-live-smoke-v0--json-normalize (obj)
  "Normalize OBJ for json-encode on this Emacs build (plists -> alists,
arrays -> vectors, raw-byte chars sanitized)."
  (cond
   ((null obj) nil)
   ((eq obj :json-false) :json-false)
   ((stringp obj) (transport-live-smoke-v0--json-safe-string obj))
   ((numberp obj) obj)
   ((eq obj t) t)
   ((keywordp obj) (symbol-name obj))
   ((symbolp obj) (symbol-name obj))
   ((vectorp obj)
    (apply #'vector (mapcar #'transport-live-smoke-v0--json-normalize
                            (append obj nil))))
   ((consp obj)
    (cond
     ((keywordp (car obj))
      (let (out)
        (while obj
          (setq out (cons (cons (substring (symbol-name (car obj)) 1)
                                (transport-live-smoke-v0--json-normalize (cadr obj)))
                          out))
          (setq obj (cddr obj)))
        (nreverse out)))
     ((and (consp (car obj)) (stringp (caar obj)))
      (mapcar (lambda (pair)
                (cons (car pair)
                      (transport-live-smoke-v0--json-normalize (cdr pair))))
              obj))
     (t (apply #'vector (mapcar #'transport-live-smoke-v0--json-normalize obj)))))
   (t obj)))

(defvar transport-live-smoke-v0--failures nil)

(defun transport-live-smoke-v0--expect (case-id condition &rest evidence)
  "Record a failure for CASE-ID when CONDITION is nil."
  (unless condition
    (push (cons case-id evidence) transport-live-smoke-v0--failures))
  condition)

(defun transport-live-smoke-v0--a2-only-text ()
  "Self-contained length-leg prompt (no reference to any other prompt)."
  (concat "Reply with ONLY a JSON object satisfying this schema. "
          "Required keys: schema_version (const "
          "\"closed-loop-evaluator-response-v1\"), abstained (false), "
          "correction_fidelity (object with integer score 0..2, label "
          "fidelity-pass/fidelity-partial/fidelity-fail matching the "
          "score, evidence string), research_quality (object with "
          "integer score 0..2, label accept/revise/reject matching the "
          "score, evidence string), missing_evidence (array of short "
          "strings). Provide a VERY long ASCII evidence string of at "
          "least 2000 characters in both evidence fields. Output the "
          "object and nothing else."))

(defun transport-live-smoke-v0--run (guards-before)
  "Run the single A2-only length-leg live smoke; print result JSON; exit.
This file deliberately exercises ONLY the length leg: one request,
num_predict 8, reasoning none, self-contained A2-only prompt, same frozen
response schema.  The stop leg is covered by the frozen v0.2 execution
(transport-live-smoke-v0.2-result.json); this file does not gate on A1,
does not require schema validity, and does not invoke the repair rule."
  (let ((run-result nil))
    (setq transport-live-smoke-v0--capture-count 0)
    (advice-add 'plz-media-type-process-filter :before
                #'transport-live-smoke-v0--tee-raw)
    (advice-add 'llm-request-plz-async :before
                #'transport-live-smoke-v0--capture-request)
    (unwind-protect
        (setq run-result
              (transport-live-smoke-v0--run-request
               (transport-live-smoke-v0--a2-only-text) 8))
      (advice-remove 'plz-media-type-process-filter
                     #'transport-live-smoke-v0--tee-raw)
      (advice-remove 'llm-request-plz-async
                     #'transport-live-smoke-v0--capture-request)
      (transport-live-smoke-v0--cleanup))
    (let* ((provider (plist-get run-result :provider))
           (body (plist-get run-result :request_body))
           (final (plist-get run-result :final))
           (sha (transport-live-smoke-v0--schema-sha256 body))
           (parse (condition-case e
                      (transport-live-smoke-v0--parse-json-alist final)
                    (json-end-of-file :eof-incomplete)
                    (json-parse-error :syntax-invalid)
                    (error (list :parse-error (error-message-string e)))))
           (guards-after (transport-live-smoke-v0--guarded-files))
           (cleanup-proof (transport-live-smoke-v0--cleanup-proof))
           (guards-unchanged
            (cl-every (lambda (entry)
                        (equal (cdr (assoc (car entry) guards-before))
                               (cdr entry)))
                      guards-after)))
      (transport-live-smoke-v0--expect
       "A2-only" (and (plist-get run-result :settled)
                      (eq 'done (plist-get run-result :status)))
       :status (plist-get run-result :status)
       :error (plist-get run-result :error)
       :filter_errors (plist-get run-result :filter_errors))
      (transport-live-smoke-v0--expect
       "A2-only" (eq t (plist-get provider :done))
       :done (plist-get provider :done))
      (transport-live-smoke-v0--expect
       "A2-only" (equal "length" (plist-get provider :done_reason))
       :done_reason (plist-get provider :done_reason))
      (transport-live-smoke-v0--expect
       "A2-only" (equal 8 (plist-get provider :eval_count))
       :eval_count (plist-get provider :eval_count))
      (transport-live-smoke-v0--expect
       "A2-only" (eq :json-false (transport-live-smoke-v0--think-value body))
       :think_present (if (transport-live-smoke-v0--think-present body) t :json-false)
       :think_value (transport-live-smoke-v0--think-value body)
       :note "reasoning none: top-level think must be false")
      (transport-live-smoke-v0--expect
       "A2-only" (zerop (plist-get provider :thinking_bytes))
       :thinking_bytes (plist-get provider :thinking_bytes)
       :thinking_events (plist-get provider :thinking_events))
      (transport-live-smoke-v0--expect
       "A2-only" (> (plist-get provider :content_bytes) 0)
       :content_bytes (plist-get provider :content_bytes)
       :content_events (plist-get provider :content_events))
      (transport-live-smoke-v0--expect
       "A2-only" (zerop (plist-get provider :error_events))
       :error_events (plist-get provider :error_events)
       :note "done/length frame must not hide provider error events")
      (transport-live-smoke-v0--expect
       "A2-only" (equal (plist-get provider :content_sha256)
                        (transport-live-smoke-v0--sha256 (or final "")))
       :content_sha256 (plist-get provider :content_sha256)
       :llm_final_sha256 (if final (transport-live-smoke-v0--sha256 final) nil))
      (transport-live-smoke-v0--expect
       "A2-only" (memq parse '(:eof-incomplete :syntax-invalid))
       :final final :parse parse)
      (transport-live-smoke-v0--expect
       "A2-only" (equal transport-live-smoke-v0--expected-schema-sha256 sha)
       :schema_sha256 sha :expected transport-live-smoke-v0--expected-schema-sha256)
      (transport-live-smoke-v0--expect
       "A2-only" (transport-live-smoke-v0--tee-body-ascii-p (plist-get run-result :tee))
       :raw_ascii_only (if (transport-live-smoke-v0--tee-body-ascii-p (plist-get run-result :tee)) t :json-false)
       :note "UTF-8 contamination: raw body contains octets 0x80..0xFF; measured, no shim")
      (transport-live-smoke-v0--expect
       "H1" (= 1 transport-live-smoke-v0--capture-count)
       :capture_count transport-live-smoke-v0--capture-count)
      (transport-live-smoke-v0--expect
       "guards" guards-unchanged :guards guards-after)
      (transport-live-smoke-v0--expect
       "cleanup" (cl-every #'identity
                           (list (plist-get cleanup-proof :advice_tee_gone)
                                 (plist-get cleanup-proof :advice_capture_gone)
                                 (plist-get cleanup-proof :plz_processes_gone)
                                 (plist-get cleanup-proof :tee_buffer_gone)
                                 (plist-get cleanup-proof :llm_log_buffer_gone)))
       :cleanup_proof cleanup-proof)
      (let ((req
             (list
              (list :id "A2-only"
                    :num_predict (transport-live-smoke-v0--num-predict body)
                    :schema_sha256 sha
                    :provider provider
                    :think_present (if (transport-live-smoke-v0--think-present body) t :json-false)
                    :think_value (transport-live-smoke-v0--think-value body)
                    :partial_callback_count (plist-get run-result :partial_callback_count)
                    :content_events (plist-get provider :content_events)
                    :content_bytes (plist-get provider :content_bytes)
                    :content_sha256 (plist-get provider :content_sha256)
                    :thinking_events (plist-get provider :thinking_events)
                    :thinking_bytes (plist-get provider :thinking_bytes)
                    :thinking_sha256 (plist-get provider :thinking_sha256)
                    :error_events (plist-get provider :error_events)
                    :raw_ascii_only (if (transport-live-smoke-v0--tee-body-ascii-p
                                         (plist-get run-result :tee))
                                        t :json-false)
                    :raw_bytes (string-bytes (plist-get run-result :tee))
                    :raw_sha256 (transport-live-smoke-v0--sha256 (plist-get run-result :tee))
                    :llm_final_bytes (if final (string-bytes final) 0)
                    :llm_final_sha256 (if final (transport-live-smoke-v0--sha256 final) nil)
                    :status (plist-get run-result :status)))))
        (let ((output
               (list :probe "transport-live-smoke-v0.3"
                     :throwaway t
                     :source_sha256 (transport-live-smoke-v0--hash-file
                                     (or load-file-name buffer-file-name))
                     :derived_from (list :path "transport-live-smoke-v0.2.el"
                                         :sha256 "e4abbeeb2726a5319542080b5b8980289cf50107d0b3065469ff8fbc08db4442")
                     :v0_2_result (list :path "transport-live-smoke-v0.2-result.json"
                                        :sha256 "b157d21d4ac726dd8450ecbf304015b37af0cb58a70e436bfdf5b0635a1b82b0")
                     :model transport-live-smoke-v0--model
                     :expected_schema_sha256 transport-live-smoke-v0--expected-schema-sha256
                     :capture_count transport-live-smoke-v0--capture-count
                     :source_loading
                     (if transport-live-smoke-v0--source-load-evidence
                         (list :succeeded :json-false
                               :evidence transport-live-smoke-v0--source-load-evidence
                               :fallback "release-compiled .elc artifacts of the same versions")
                       (list :succeeded t :evidence "frozen .el sources loaded"))
                     :requests req
                     :guards (list :unchanged (if guards-unchanged t :json-false)
                                   :contract (cdr (assoc "contract" guards-after))
                                   :probe (cdr (assoc "probe" guards-after))
                                   :archive_db (cdr (assoc "archive-db" guards-after))
                                   :v0_1_source (cdr (assoc "v0.1-source" guards-after))
                                   :v0_1_result (cdr (assoc "v0.1-result" guards-after))
                                   :v0_2_source (cdr (assoc "v0.2-source" guards-after))
                                   :v0_2_result (cdr (assoc "v0.2-result" guards-after)))
                     :cleanup_proof cleanup-proof
                     :failures
                     (apply #'vector
                            (mapcar (lambda (pair)
                                      (list :case_id (car pair)
                                            :evidence (cdr pair)))
                                    (nreverse transport-live-smoke-v0--failures)))
                     :not_proved
                     (list "this file proves ONLY the length leg (single request, num_predict 8; the observed parser class is the content classification, not the truncation ground truth)"
                           "the stop leg is inherited from the frozen v0.2 execution (transport-live-smoke-v0.2-result.json), not re-proven here"
                           "Superchat integration: superchat never required; Runtime/Outcome persistence and runtime_response/outcome_raw equality not exercised"
                           (format "environment variance: emacs %s batch; executed bytecode is .elc when source loading is infeasible" emacs-version)
                           "no effect decision and no unfreeze: execution_authorized stays false"))))
          (princ (json-encode (transport-live-smoke-v0--json-normalize output)))
          (terpri)
          (kill-emacs (if transport-live-smoke-v0--failures 1 0)))))))

;;; Entry

(condition-case err
    (progn
      (transport-live-smoke-v0--load-dependencies)
      (transport-live-smoke-v0--load-contract)
      (transport-live-smoke-v0--run (transport-live-smoke-v0--guarded-files)))
  (error
   (let ((out (list :probe "transport-live-smoke-v0.3"
                    :throwaway t
                    :fatal_error (error-message-string err)
                    :failures (vector (list :case_id "fatal"
                                            :evidence (error-message-string err))))))
     (princ (json-encode (transport-live-smoke-v0--json-normalize out)))
     (terpri)
     (kill-emacs 1))))

(provide 'transport-live-smoke-v0)

;;; transport-live-smoke-v0.el ends here
