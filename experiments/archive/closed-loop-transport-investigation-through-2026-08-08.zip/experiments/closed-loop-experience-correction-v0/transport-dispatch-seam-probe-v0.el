;;; transport-dispatch-seam-probe-v0.el --- Direct dispatch diagnostic -*- lexical-binding: t; -*-
;; Throwaway, model-free diagnostic: observe the direct transport seam with
;; tools disabled and response-format enabled.  See the `--launch' function.
(require 'cl-lib)
(require 'json)
(defconst transport-dispatch-seam-probe-v0--directory (file-name-directory (or load-file-name buffer-file-name)))
(defconst transport-dispatch-seam-probe-v0--contract
  (expand-file-name "next-measurement-contract-v0.json"
                    transport-dispatch-seam-probe-v0--directory))
(defconst transport-dispatch-seam-probe-v0--model "qwen3.6:latest")
(defconst transport-dispatch-seam-probe-v0--buffer " *sc-dispatch-probe*")
(defvar superchat-data-directory)
(defun transport-dispatch-seam-probe-v0--schema ()
  "Read the frozen evaluator response schema."
  (with-temp-buffer
    (insert-file-contents transport-dispatch-seam-probe-v0--contract)
    (let ((json (json-parse-buffer :object-type 'plist :array-type 'array
                                   :null-object nil :false-object :json-false)))
      (plist-get (plist-get json :evaluator) :response_schema))))
(defun transport-dispatch-seam-probe-v0--frame-names (frames)
  "Return at most eight function names from FRAMES."
  (let (names)
    (while (and frames (< (length names) 8))
      (when (symbolp (nth 1 (car frames))) (push (symbol-name (nth 1 (car frames))) names))
      (setq frames (cdr frames)))
    (nreverse names)))
(defun transport-dispatch-seam-probe-v0--classification (first fatal)
  "Classify FIRST, or FALL back to FATAL/no-observable."
  (cond ((eq first 'llm-chat-streaming) "stream-mock")
        ((eq first 'llm-chat-async) "async-seam")
        ((memq first '(llm-request-plz-async llm-request-plz-sync
                       plz-media-type-request plz)) "plz-seam")
        ((memq first '(make-process make-network-process make-pipe-process)) "t4-seam")
        (fatal "fatal")
        (t "no-observable")))
(defun transport-dispatch-seam-probe-v0--emit (result)
  "Emit RESULT as the single bounded JSON line."
  (let ((encoded
         (json-encode
          (append
           '((schema_version . "transport-dispatch-seam-probe-v0/result")
             (probe . "transport-dispatch-seam-probe-v0") (throwaway . t))
           result
           '((execution_authorized . :json-false)
             (STOP-2 . "open") (STOP-3 . "open")
             (claim . "dispatch-only; no Runtime/Tape/DB/Outcome/model/network capability"))))))
    (when (> (string-bytes encoded) 4095)
      (setq encoded "{\"probe\":\"transport-dispatch-seam-probe-v0\",\"classification\":\"fatal\",\"error\":\"result exceeded 4095 bytes\",\"execution_authorized\":false}"))
    (princ encoded)
    (terpri)))
(defun transport-dispatch-seam-probe-v0--run (schema)
  "Run the single direct dispatch case with response-format SCHEMA."
  (let (first (cell-eq "none") events final fatal stream advice
              (stream-count 0))
    (cl-labels
        ((record
          (symbol &optional cell)
          (let* ((snapshot (backtrace-frames)) (normalized (or cell "none")))
            (unless first (setq first symbol cell-eq normalized))
            (when (< (length events) 8)
              (push `((symbol . ,(symbol-name symbol)) (cell_eq . ,normalized)
                      (frames . ,(vconcat (transport-dispatch-seam-probe-v0--frame-names snapshot)))
                      (frames_sha256 . ,(secure-hash 'sha256 (prin1-to-string snapshot))))
                    events))))
         (deny
          (symbol)
          (lambda (&rest _args)
            (record symbol)
            (error "transport-dispatch-seam-probe-v0 denied %s" symbol))))
      (setq stream
            (lambda (_provider _prompt partial response _error &optional _multi)
              (record 'llm-chat-streaming
                      (if (eq (symbol-function 'llm-chat-streaming) stream)
                          t :json-false))
              (setq final "ok")
              (funcall partial "ok")
              (funcall response "ok")
              'synthetic)
            advice
            (lambda (original text tools &optional context preset files)
              (let ((prompt (funcall original text tools context preset files)))
                (setf (llm-chat-prompt-response-format prompt) schema)
                prompt)))
      (advice-add 'superchat--build-llm-prompt :around advice)
      (unwind-protect
          (condition-case err
              (let ((superchat-llm-backend
                     (make-llm-ollama
                      :chat-model transport-dispatch-seam-probe-v0--model))
                    (superchat-llm-model nil)
                    (superchat-llm-reasoning 'none)
                    (superchat-buffer-name transport-dispatch-seam-probe-v0--buffer))
                (cl-letf (((symbol-function 'llm-chat-streaming) stream)
                          ((symbol-function 'llm-chat-async) (deny 'llm-chat-async))
                          ((symbol-function 'llm-request-plz-async) (deny 'llm-request-plz-async))
                          ((symbol-function 'llm-request-plz-sync) (deny 'llm-request-plz-sync))
                          ((symbol-function 'plz-media-type-request) (deny 'plz-media-type-request))
                          ((symbol-function 'plz) (deny 'plz))
                          ((symbol-function 'make-process) (deny 'make-process))
                          ((symbol-function 'make-network-process) (deny 'make-network-process))
                          ((symbol-function 'make-pipe-process) (deny 'make-pipe-process)))
                  (superchat--llm-generate-answer
                   "Phase B0 integration probe input." #'ignore
                   (lambda (_chunk) (setq stream-count (1+ stream-count)))
                   transport-dispatch-seam-probe-v0--model nil 'none nil
                   (superchat-preset--create :name "dispatch" :max-tokens 2048
                                             :reasoning 'none :tools 'none))))
            (error
             (setq fatal (substring (error-message-string err) 0
                                    (min 240 (length (error-message-string err)))))))
        (advice-remove 'superchat--build-llm-prompt advice)))
    `((classification . ,(transport-dispatch-seam-probe-v0--classification first fatal))
      (first . ,(and first (symbol-name first))) (cell_eq . ,cell-eq)
      (final_bytes . ,(if final (string-bytes final) 0))
      (final_sha256 . ,(and final (secure-hash 'sha256 final)))
      (stream_count . ,stream-count) (events . ,(vconcat (nreverse events))) (error . ,fatal))))
(defun transport-dispatch-seam-probe-v0--launch ()
  "Future-only batch entry point."
  (let ((temp (make-temp-file "sc-dispatch-" t)) result cleanup)
    (setq superchat-data-directory (expand-file-name "data" temp))
    (unwind-protect
        (condition-case err
            (progn
              (make-directory superchat-data-directory t)
              (require 'superchat) (require 'llm-ollama)
              (setq result (transport-dispatch-seam-probe-v0--run (transport-dispatch-seam-probe-v0--schema))))
          (error
           (setq result `((classification . "fatal") (first . nil)
                          (error . ,(error-message-string err))))))
      (let ((buffer (get-buffer transport-dispatch-seam-probe-v0--buffer))) (when buffer (kill-buffer buffer)))
      (ignore-errors (delete-directory temp t))
      (setq cleanup (and (not (file-exists-p temp))
                         (not (get-buffer transport-dispatch-seam-probe-v0--buffer)))))
    (setq result (append result `((cleanup . ,cleanup))))
    (transport-dispatch-seam-probe-v0--emit result)
    (kill-emacs (if (member (alist-get 'classification result) '("fatal" "no-observable")) 1 0))))
(provide 'transport-dispatch-seam-probe-v0)
;;; transport-dispatch-seam-probe-v0.el ends here
