;;; transport-integration-probe-v0.el --- Throwaway Runtime integration probe -*- lexical-binding: t; -*-

;; Problem: the frozen next-measurement contract keeps execution_authorized
;; false; the live-smoke artifacts (v0.2/v0.3-result.json) proved provider
;; stop/length observability and content/llm-text byte fidelity on the REAL
;; transport, but Superchat Runtime/Tape/DB integration was never exercised.
;; This throwaway probe drives the REAL superchat-runtime-submit-blocking ->
;; superchat--build-llm-prompt -> llm-chat-streaming -> Runtime finish ->
;; Tape -> temp SQLite path with ZERO network (llm-chat-streaming is
;; cl-letf'd to a synthetic async transport; llm-request-plz-async is
;; blocked).  It is Phase B0 of the gate amendment: integration with the
;; product transport seam, not a provider measurement.
;;
;; THROWAWAY: experiment-local self-check, not a product file.  Nothing
;; loads it; it may be deleted.  It never modifies Runtime/Tape/Closure/
;; Workflow/Workspace/Authority/superchat-llm or any contract/result file;
;; it only reads frozen files and the archive DB hash, and writes a temp
;; data directory and temp SQLite plus one probe-local Outcome record there.
;; stdout is intentionally the only persistent probe evidence.
;;
;; Run (single command, absolute -L paths):
;;   emacs -Q --batch -L . \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/llm-0.31.1 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-0.9.1 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-event-source-0.1.3 \
;;     -L /Users/chenyibin/.config/nova-emacs/elpa/plz-media-type-0.2.4 \
;;     -l experiments/closed-loop-experience-correction-v0/transport-integration-probe-v0.el

;;; Code:

(require 'cl-lib)
(require 'json)
(require 'seq)
(require 'subr-x)
(require 'llm-ollama)
(require 'superchat-runtime)
(require 'superchat-llm)
(require 'superchat-tape)
(require 'superchat-db)
(require 'superchat-preset)

(declare-function
 superchat-closed-loop-next-measurement-contract-v0--classify-json
 "preflight-next-measurement-contract-v0" (raw &optional validate-schema))

(defconst transport-integration-probe-v0--directory
  (file-name-directory (or load-file-name buffer-file-name)))

(defconst transport-integration-probe-v0--contract-path
  (expand-file-name "next-measurement-contract-v0.json"
                    transport-integration-probe-v0--directory))

(defconst transport-integration-probe-v0--probe-path
  (expand-file-name "transport-probe-v0.el"
                    transport-integration-probe-v0--directory))

(defconst transport-integration-probe-v0--preflight-path
  (expand-file-name "preflight-next-measurement-contract-v0.el"
                    transport-integration-probe-v0--directory))

(defconst transport-integration-probe-v0--expected-schema-sha256
  "bcbc37a0cf42b9def5a906d90201befaea4cf505c208dd21ff6736fac6bf71dd")

(defconst transport-integration-probe-v0--archive-db-path
  "/private/tmp/superchat-v04-final-archive.RAEt87/closed-loop-experience-correction-v0.4-handoff/runtime/superchat.db")

(defconst transport-integration-probe-v0--archive-db-hash
  "fc36ccb8cc440a8f2325f05d25be15220abd9cd9d9c09c241b1d16dd8d7d3d02")

(defconst transport-integration-probe-v0--timeout 300)
(defconst transport-integration-probe-v0--model "qwen3.6:latest")
(defconst transport-integration-probe-v0--stop1-result-path
  "transport-live-smoke-v0.3-result.json")
(defconst transport-integration-probe-v0--stop1-result-sha256
  "871ce033d3deb34bd3a269fa4b371a5cc2216a6ff8167912789ba941429bd7dd")

(defvar transport-integration-probe-v0--contract nil)
(defvar transport-integration-probe-v0--response-format nil)
(defvar transport-integration-probe-v0--failures nil)
(defvar transport-integration-probe-v0--temp-dir nil)
(defvar transport-integration-probe-v0--timer nil)
;; Special-variable declarations for the isolated Runtime state (same pattern
;; as test-runtime.el's isolation macro); compile-time only, no semantics.
(defvar superchat-llm-backend)
(defvar superchat-llm-model)
(defvar superchat-llm-reasoning)
(defvar superchat-buffer-name)
(defvar superchat--active-timeout-timer)

;;; --- Read-only helpers ----------------------------------------------------

(defun transport-integration-probe-v0--read-json-file (path &rest parse-args)
  "Read PATH as JSON with PARSE-ARGS passed to json-parse-buffer."
  (with-temp-buffer
    (insert-file-contents path)
    (apply #'json-parse-buffer parse-args)))

(defun transport-integration-probe-v0--hash-file (path)
  "Return the sha256 hex of the file at PATH, or nil when unreadable."
  (when (file-readable-p path)
    (with-temp-buffer
      (insert-file-contents path)
      (secure-hash 'sha256 (current-buffer)))))

(defun transport-integration-probe-v0--sha256 (string)
  "Return the sha256 hex of STRING's bytes."
  (secure-hash 'sha256 (encode-coding-string string 'utf-8)))

(defun transport-integration-probe-v0--hash-mtime (path)
  "Return (list :hash H :mtime M) for PATH, or nil when unreadable."
  (when (and (stringp path) (file-readable-p path))
    (list :hash (transport-integration-probe-v0--hash-file path)
          :mtime (nth 5 (file-attributes path)))))

(defun transport-integration-probe-v0--load-contract ()
  "Read the frozen contract (plist objects, vector arrays)."
  (setq transport-integration-probe-v0--contract
        (transport-integration-probe-v0--read-json-file
         transport-integration-probe-v0--contract-path
         :object-type 'plist :array-type 'array
         :null-object nil :false-object :json-false))
  (setq transport-integration-probe-v0--response-format
        (plist-get (plist-get transport-integration-probe-v0--contract :evaluator)
                   :response_schema))
  ;; Load the exact frozen preflight file; its self-check is model-free and
  ;; read-only by design.  The frozen classifier is then reused, not copied.
  (load transport-integration-probe-v0--preflight-path nil nil t))

;;; --- Canonical schema hashing (copied minimal, as allowed) -----------------

(defun transport-integration-probe-v0--canonical-key (key)
  "Return KEY as a string for canonical JSON (symbol keys allowed)."
  (if (symbolp key) (symbol-name key) key))

(defun transport-integration-probe-v0--canonical-json (object)
  "Return a canonical JSON string for OBJECT (alist objects, list arrays)."
  (cond
   ((eq object :null) "null")
   ((null object) "null")
   ((stringp object) (json-encode-string object))
   ((numberp object) (number-to-string object))
   ((eq object t) "true")
   ((eq object :json-false) "false")
   ((consp object)
    (if (and (consp (car object)) (not (consp (caar object))))
        (concat "{"
                (mapconcat
                 (lambda (pair)
                   (concat (json-encode-string
                            (transport-integration-probe-v0--canonical-key (car pair)))
                           ":"
                           (transport-integration-probe-v0--canonical-json (cdr pair))))
                 (sort (copy-sequence object)
                       (lambda (left right)
                         (string< (transport-integration-probe-v0--canonical-key (car left))
                                  (transport-integration-probe-v0--canonical-key (car right)))))
                 ",")
                "}")
      (concat "["
              (mapconcat #'transport-integration-probe-v0--canonical-json object ",")
              "]")))
   (t (json-encode-string (format "%S" object)))))

(defun transport-integration-probe-v0--schema-sha256 (request-body)
  "Re-canonicalize the format sub-object of the actual POST body."
  (condition-case nil
      (let* ((req (json-parse-string request-body :object-type 'alist :array-type 'list
                                     :null-object :null :false-object :json-false))
             (format-obj (alist-get 'format req)))
        (when format-obj
          (transport-integration-probe-v0--sha256
           (transport-integration-probe-v0--canonical-json format-obj))))
    (error nil)))

(defun transport-integration-probe-v0--num-predict (request-body)
  "Return options.num_predict from the actual POST body, or nil."
  (condition-case nil
      (let ((req (json-parse-string request-body :object-type 'alist :array-type 'list
                                    :null-object :null :false-object :json-false)))
        (alist-get 'num_predict (alist-get 'options req)))
    (error nil)))

(defun transport-integration-probe-v0--think-value (request-body)
  "Return the top-level think value of the actual POST body."
  (condition-case nil
      (let ((req (json-parse-string request-body :object-type 'alist :array-type 'list
                                    :null-object :null :false-object :json-false)))
        (alist-get 'think req))
    (error nil)))

(defun transport-integration-probe-v0--classify (raw)
  "Unconditionally classify RAW with the frozen preflight classifier.
No repair, no retry: the class is computed once and serialized."
  (superchat-closed-loop-next-measurement-contract-v0--classify-json raw t))

;;; --- STOP-1 provider reference (inherited-by-reference, never replayed) ---

(defun transport-integration-probe-v0--stop1-provider-ref ()
  "Return provider fields read from the frozen STOP-1 v0.3-result artifact.
The values are inherited by reference from that frozen artifact; no provider
bytes are fabricated and nothing is replayed from this probe."
  (let* ((result (transport-integration-probe-v0--read-json-file
                  (expand-file-name transport-integration-probe-v0--stop1-result-path
                                    transport-integration-probe-v0--directory)
                  :object-type 'alist :array-type 'list))
         (record (alist-get 'stdout_record result))
         (request (car (alist-get 'requests record)))
         (provider (alist-get 'provider request)))
    (list :provider_done (alist-get 'done provider)
          :provider_done_reason (alist-get 'done_reason provider)
          :provider_prompt_eval_count (alist-get 'prompt_eval_count provider)
          :provider_eval_count (alist-get 'eval_count provider)
          :provider_raw_body_bytes (alist-get 'raw_bytes request)
          :provider_raw_body_sha256 (alist-get 'raw_sha256 request)
          :provider_reference
          (concat "inherited-by-reference from STOP-1 " transport-integration-probe-v0--stop1-result-path
                  " (" transport-integration-probe-v0--stop1-result-sha256 "); not replayed; no fabricated provider bytes"))))

;;; --- Synthetic transport payload (S) --------------------------------------

(defun transport-integration-probe-v0--synthetic-response ()
  "Return an ASCII, >500-byte, frozen-schema-valid synthetic response S."
  (json-serialize
   (list :schema_version "closed-loop-evaluator-response-v1"
         :abstained :false
         :correction_fidelity
         (list :score 2 :label "fidelity-pass"
               :evidence (make-string 320 ?a))
         :research_quality
         (list :score 2 :label "accept"
               :evidence (make-string 320 ?b))
         :missing_evidence (vector))))

;;; --- Guards (frozen files, default DB, archive DB) ------------------------

(defun transport-integration-probe-v0--guards-before ()
  "Capture hash/mtime of every guarded path (nil = absent)."
  (list (cons "contract" (transport-integration-probe-v0--hash-mtime
                          transport-integration-probe-v0--contract-path))
        (cons "preflight" (transport-integration-probe-v0--hash-mtime
                           transport-integration-probe-v0--preflight-path))
        (cons "probe" (transport-integration-probe-v0--hash-mtime
                       transport-integration-probe-v0--probe-path))
        (cons "transport-probe-source"
              (transport-integration-probe-v0--hash-mtime
               (expand-file-name "transport-probe-v0.el"
                                 transport-integration-probe-v0--directory)))
        (cons "v0.1-source" (transport-integration-probe-v0--hash-mtime
                             (expand-file-name "transport-live-smoke-v0.el"
                                               transport-integration-probe-v0--directory)))
        (cons "v0.1-result" (transport-integration-probe-v0--hash-mtime
                             (expand-file-name "transport-live-smoke-v0.1-result.json"
                                               transport-integration-probe-v0--directory)))
        (cons "v0.2-source" (transport-integration-probe-v0--hash-mtime
                             (expand-file-name "transport-live-smoke-v0.2.el"
                                               transport-integration-probe-v0--directory)))
        (cons "v0.2-result" (transport-integration-probe-v0--hash-mtime
                             (expand-file-name "transport-live-smoke-v0.2-result.json"
                                               transport-integration-probe-v0--directory)))
        (cons "v0.3-source" (transport-integration-probe-v0--hash-mtime
                             (expand-file-name "transport-live-smoke-v0.3.el"
                                               transport-integration-probe-v0--directory)))
        (cons "v0.3-result" (transport-integration-probe-v0--hash-mtime
                             (expand-file-name transport-integration-probe-v0--stop1-result-path
                                               transport-integration-probe-v0--directory)))
        (cons "integration-probe-source"
              (transport-integration-probe-v0--hash-mtime
               (or load-file-name buffer-file-name)))
        (cons "default-superchat-db"
              (transport-integration-probe-v0--hash-mtime
               (expand-file-name "superchat.db"
                                 (expand-file-name "superchat/" user-emacs-directory))))
        (cons "archive-db" (transport-integration-probe-v0--hash-mtime
                            transport-integration-probe-v0--archive-db-path))))

(defun transport-integration-probe-v0--guards-unchanged-p (before after)
  "Return t when every guard BEFORE equals its AFTER state."
  (cl-every (lambda (entry)
              (equal (cdr (assoc (car entry) before))
                     (cdr entry)))
            after))

;;; --- Outcome persistence (probe-local, temp dir) --------------------------

(defun transport-integration-probe-v0--write-outcome (dir raw class)
  "Write the probe-local next-measurement Outcome record into DIR.
This is the next-measurement persistence SHAPE only, not product Outcome
semantics."
  (let* ((encoded (encode-coding-string raw 'utf-8))
         (record (list :probe "transport-integration-probe-v0"
                       :raw_response raw
                       :parser_class (symbol-name class)
                       :raw_bytes (string-bytes encoded)
                       :raw_sha256 (transport-integration-probe-v0--sha256 raw)
                       :note "probe-local next-measurement persistence shape; not product Outcome semantics"))
         (path (expand-file-name "outcome-record.json" dir)))
    (with-temp-file path
      (insert (json-encode record)))
    path))

(defun transport-integration-probe-v0--read-outcome (path)
  "Read the probe-local Outcome record at PATH (alist)."
  (json-parse-string (with-temp-buffer
                       (insert-file-contents path)
                       (buffer-string))
                     :object-type 'alist :array-type 'list
                     :null-object nil :false-object :json-false))

;;; --- The integration run --------------------------------------------------

(defun transport-integration-probe-v0--expect (case-id condition &rest evidence)
  "Record a failure for CASE-ID when CONDITION is nil."
  (unless condition
    (push (cons case-id evidence) transport-integration-probe-v0--failures))
  condition)

(defun transport-integration-probe-v0--json-normalize (obj)
  "Normalize OBJ for json-encode (plists -> alists, arrays -> vectors)."
  (cond
   ((null obj) nil)
   ((eq obj :json-false) :json-false)
   ((stringp obj) obj)
   ((numberp obj) obj)
   ((eq obj t) t)
   ((keywordp obj) (symbol-name obj))
   ((symbolp obj) (symbol-name obj))
   ((vectorp obj)
    (apply #'vector (mapcar #'transport-integration-probe-v0--json-normalize
                            (append obj nil))))
   ((consp obj)
    (cond
     ((keywordp (car obj))
      (let (out)
        (while obj
          (setq out (cons (cons (substring (symbol-name (car obj)) 1)
                                (transport-integration-probe-v0--json-normalize (cadr obj)))
                          out))
          (setq obj (cddr obj)))
        (nreverse out)))
     ((and (consp (car obj)) (stringp (caar obj)))
      (mapcar (lambda (pair)
                (cons (car pair)
                      (transport-integration-probe-v0--json-normalize (cdr pair))))
              obj))
     (t (apply #'vector (mapcar #'transport-integration-probe-v0--json-normalize obj)))))
   (t obj)))

(defun transport-integration-probe-v0--run (guards-before)
  "Run the integration probe; print result JSON; exit 0/1."
  (let* ((S (transport-integration-probe-v0--synthetic-response))
         (full-bytes (string-bytes (encode-coding-string S 'utf-8)))
         (blocking-response nil)
         (outcome-path nil)
         (outcome-record-captured nil)
         (prompt-captured nil)
         (request-body-captured nil)
         (network-calls 0)
         (final-string-count 0)
         (final-string-value nil)
         (mock-partials nil)
         (db-evidence nil)
         (backend (make-llm-ollama :chat-model transport-integration-probe-v0--model))
         ;; (4) let-bound lambda closure, used identically for add/remove/member
         (advice
          (lambda (orig text tools &optional context preset context-files)
            (let ((prompt (funcall orig text tools context preset context-files)))
              (setq prompt-captured prompt)
              ;; capability_absent_in_product=true, injection_prototype_only=true
              (setf (llm-chat-prompt-response-format prompt)
                    transport-integration-probe-v0--response-format)
              prompt))))
    ;; (2) isolated Runtime state: backend, runs, timers, hooks, closure guards
    (let ((superchat-llm-backend backend)
          (superchat-llm-model nil)
          (superchat-llm-reasoning 'none)
          (superchat-runtime--runs (make-hash-table :test #'equal))
          (superchat-buffer-name " *superchat-b0-probe*")
          (superchat--active-timeout-timer nil)
          (superchat-pre-topic-finalized-functions nil)
          (superchat-post-turn-functions nil)
          (superchat-post-topic-finalized-functions nil)
          (superchat-run-completed-functions nil)
          (superchat-turn-completed-functions nil)
          (superchat-closure-shadow-enabled nil)
          (superchat-closure-terminal-guard-enabled nil)
          (superchat-closure-shadow-functions nil)
          (superchat-runtime--closure-observations nil))
      (advice-add 'superchat--build-llm-prompt :around advice)
      (unwind-protect
          (progn
            ;; cl-letf transport only: synthetic llm-chat-streaming, blocked plz
            (cl-letf (((symbol-function 'llm-chat-streaming)
                       (lambda (provider prompt partial-callback response-callback
                                         error-callback &optional multi-output)
                         (transport-integration-probe-v0--expect
                          "transport-shapes" (and (llm-ollama-p provider)
                                                  (llm-chat-prompt-p prompt))
                          :provider (type-of provider)
                          :prompt (type-of prompt))
                         (transport-integration-probe-v0--expect
                          "transport-shapes" (null multi-output)
                          :multi_output multi-output)
                         (transport-integration-probe-v0--expect
                          "transport-shapes" (null (llm-chat-prompt-tools prompt))
                          :prompt_tools (llm-chat-prompt-tools prompt))
                         (transport-integration-probe-v0--expect
                          "transport-shapes" (functionp partial-callback)
                          :partial (type-of partial-callback))
                         (transport-integration-probe-v0--expect
                          "transport-shapes" (functionp response-callback)
                          :response (type-of response-callback))
                         (transport-integration-probe-v0--expect
                          "transport-shapes" (functionp error-callback)
                          :error (type-of error-callback))
                         ;; (3) pure zero-network request construction
                         (let* ((body (json-serialize
                                       (llm-provider-chat-request provider prompt t)))
                                (sha (transport-integration-probe-v0--schema-sha256 body)))
                           (setq request-body-captured body)
                           (transport-integration-probe-v0--expect
                            "request-body" (equal transport-integration-probe-v0--expected-schema-sha256 sha)
                            :schema_sha256 sha
                            :expected transport-integration-probe-v0--expected-schema-sha256)
                           (transport-integration-probe-v0--expect
                            "request-body" (eq :json-false
                                               (transport-integration-probe-v0--think-value body))
                            :think (transport-integration-probe-v0--think-value body))
                           (transport-integration-probe-v0--expect
                            "request-body" (equal 2048
                                                  (transport-integration-probe-v0--num-predict body))
                            :num_predict (transport-integration-probe-v0--num-predict body)))
                         ;; (6) async invoke of the synthetic transport:
                         ;; partials [100, 300, full] then exactly one final
                         (setq mock-partials (list 100 300 full-bytes))
                         (setq transport-integration-probe-v0--timer
                               (run-at-time 0 nil
                                            (lambda ()
                                              (funcall partial-callback
                                                       (substring S 0 100))
                                              (funcall partial-callback
                                                       (substring S 0 300))
                                              (funcall partial-callback S)
                                              (setq final-string-count (1+ final-string-count))
                                              (setq final-string-value S)
                                              (funcall response-callback S))))
                         (list :synthetic t)))
                      ((symbol-function 'llm-request-plz-async)
                       (lambda (&rest _)
                         (setq network-calls (1+ network-calls))
                         (error "network blocked in transport-integration-probe-v0")))))
              ;; (1)(5) real Runtime submit-blocking with the full request shape
              (setq blocking-response
                    (superchat-runtime-submit-blocking
                     (list :prompt "Phase B0 integration probe input."
                           :session-id "b0-probe-session"
                           :buffer-name " *superchat-b0-probe*"
                           :ephemeral-buffer t
                           :record-conversation nil
                           :type :llm-query
                           :tools 'none
                           :topology 'single
                           :authority-policy "default"
                           :preset (superchat-preset--create
                                    :name "b0"
                                    :max-tokens 2048
                                    :reasoning 'none
                                    :tools 'none)
                           :target-model transport-integration-probe-v0--model
                           :timeout transport-integration-probe-v0--timeout)))
              (transport-integration-probe-v0--expect
               "network" (= 0 network-calls)
               :network_calls network-calls)
              (transport-integration-probe-v0--expect
               "prompt-captured" (not (null prompt-captured))
               :prompt_captured (not (null prompt-captured)))
              (transport-integration-probe-v0--expect
               "llm-text" (equal S blocking-response)
               :llm_text_bytes full-bytes
               :llm_text_sha256 (transport-integration-probe-v0--sha256 S)
               :runtime_response_bytes (if blocking-response
                                           (string-bytes blocking-response) 0))
              (transport-integration-probe-v0--expect
               "mock-partials" (equal mock-partials (list 100 300 full-bytes))
               :mock_partial_lengths mock-partials
               :expected (list 100 300 full-bytes))
              (transport-integration-probe-v0--expect
               "final-string" (and (equal 1 final-string-count)
                                    (stringp final-string-value)
                                    (equal S final-string-value))
               :final_string_count final-string-count
               :final_string_type (type-of final-string-value)
               :final_string_sha256
               (and (stringp final-string-value)
                    (transport-integration-probe-v0--sha256 final-string-value)))
              ;; (5) Tape evidence for this session (stable session-id), by
              ;; response-event :storage-id -- never the latest row
              (let* ((sid "b0-probe-session")
                     (events (superchat-tape-replay-events sid))
                     (response-event
                      (cl-find "response.completed" events
                               :key (lambda (e) (plist-get e :type))
                               :test #'equal))
                     (storage-id (and response-event
                                      (plist-get response-event :storage-id)))
                     (db-content
                      (and storage-id
                           (caar (superchat-db-tape-select
                                  "SELECT content FROM tape WHERE id = ?"
                                  (list storage-id))))))
                (transport-integration-probe-v0--expect
                 "tape-response-event" (not (null response-event))
                 :event (and response-event (plist-get response-event :type))
                 :storage_id storage-id)
                (when response-event
                  (let* ((payload (plist-get response-event :payload))
                         (size (and (listp payload)
                                    (plist-get payload :content-size)))
                         (hash (and (listp payload)
                                    (plist-get payload :content-hash))))
                    (transport-integration-probe-v0--expect
                     "tape-payload" (equal full-bytes size)
                     :content_size size
                     :expected full-bytes)
                    (transport-integration-probe-v0--expect
                     "tape-payload" (equal (concat "sha256:"
                                                   (transport-integration-probe-v0--sha256 S))
                                           hash)
                     :content_hash hash)))
                ;; (10) raw DB content = tape--summary truncation semantics
                (transport-integration-probe-v0--expect
                 "tape-truncation" (equal (truncate-string-to-width
                                           S 500 nil nil "…")
                                          db-content)
                 :db_content_bytes (if db-content (string-bytes db-content) 0)
                 :expected_bytes (string-bytes
                                  (truncate-string-to-width S 500 nil nil "…"))))
              ;; probe-local Outcome record (next-measurement shape only)
              (setq outcome-path
                    (transport-integration-probe-v0--write-outcome
                     transport-integration-probe-v0--temp-dir
                     S (transport-integration-probe-v0--classify S)))
              (setq outcome-record-captured
                    (transport-integration-probe-v0--read-outcome outcome-path))
              (let ((outcome outcome-record-captured))
                (transport-integration-probe-v0--expect
                 "outcome" (equal S (alist-get 'raw_response outcome))
                 :raw_bytes (alist-get 'raw_bytes outcome)
                 :raw_sha256 (alist-get 'raw_sha256 outcome))
                (transport-integration-probe-v0--expect
                 "outcome" (equal "valid" (alist-get 'parser_class outcome))
                 :parser_class (alist-get 'parser_class outcome))))
        ;; cleanup: advice, timer, buffers, processes, DB, temp dir
        (advice-remove 'superchat--build-llm-prompt advice)
        (when transport-integration-probe-v0--timer
          (cancel-timer transport-integration-probe-v0--timer)
          (setq transport-integration-probe-v0--timer nil))
        (dolist (process (process-list))
          (when (string-match-p "transport-integration-probe-v0" (process-name process))
            (delete-process process)))
        ;; (7) close first so SQLite folds WAL state into the DB, then hash.
        (when superchat-db--connection
          (let ((path superchat-db--path))
            (superchat-db-close)
            (when (and path (file-readable-p path))
              (setq db-evidence
                    (list :path path
                          :hash (transport-integration-probe-v0--hash-file path)
                          :size (nth 7 (file-attributes path)))))))
        (setq superchat-db--connection nil superchat-db--path nil)
        (dolist (name '(" *superchat-b0-probe*" "*llm-log*"))
          (when-let* ((buffer (get-buffer name)))
            (kill-buffer buffer)))
        (when transport-integration-probe-v0--temp-dir
          (condition-case nil
              (delete-directory transport-integration-probe-v0--temp-dir t)
            (error nil))))
    ;; report
    (let* ((guards-after (transport-integration-probe-v0--guards-before))
           (guards-unchanged
            (transport-integration-probe-v0--guards-unchanged-p guards-before guards-after))
           (advice-gone
            (null (advice-member-p advice 'superchat--build-llm-prompt)))
           (no-timer-leftover
            (null transport-integration-probe-v0--timer))
           (temp-dir-gone (and transport-integration-probe-v0--temp-dir
                               (not (file-exists-p transport-integration-probe-v0--temp-dir))))
           (db-globals-nil (and (null superchat-db--connection)
                                (null superchat-db--path)))
           (probe-buffer-gone (null (get-buffer " *superchat-b0-probe*")))
           (llm-log-gone (null (get-buffer "*llm-log*")))
           (archive (cdr (assoc "archive-db" guards-after)))
           (archive-present (and archive (plist-get archive :hash)))
           (archive-verified (and archive-present
                                  (equal (plist-get archive :hash)
                                         transport-integration-probe-v0--archive-db-hash)))
           (stop1-hash
            (transport-integration-probe-v0--hash-file
             (expand-file-name transport-integration-probe-v0--stop1-result-path
                               transport-integration-probe-v0--directory)))
           (stop1-verified
            (equal stop1-hash transport-integration-probe-v0--stop1-result-sha256))
           (provider-ref (transport-integration-probe-v0--stop1-provider-ref)))
      (transport-integration-probe-v0--expect
       "guards" guards-unchanged :guards guards-after)
      (transport-integration-probe-v0--expect
       "archive" (and archive-present archive-verified)
       :present (if archive-present t :json-false)
       :verified (if archive-verified t :json-false)
       :hash (and archive (plist-get archive :hash))
       :expected transport-integration-probe-v0--archive-db-hash)
      (transport-integration-probe-v0--expect
       "stop1-artifact" stop1-verified
       :hash stop1-hash
       :expected transport-integration-probe-v0--stop1-result-sha256)
      (transport-integration-probe-v0--expect
       "cleanup" (and advice-gone no-timer-leftover temp-dir-gone
                      db-globals-nil probe-buffer-gone llm-log-gone)
       :advice_gone advice-gone
       :timer_gone no-timer-leftover
       :temp_dir_gone (if temp-dir-gone t :json-false)
       :db_globals_nil (if db-globals-nil t :json-false)
       :probe_buffer_gone (if probe-buffer-gone t :json-false)
       :llm_log_gone (if llm-log-gone t :json-false))
      (let ((output
             (list :probe "transport-integration-probe-v0"
                   :throwaway t
                   :capability_absent_in_product t
                   :injection_prototype_only t
                   :subgate_status "candidate-closed-pending-review"
                   :STOP-2 "Superchat integration open"
                   :STOP-3 "UTF-8 decision open"
                   :execution_authorized :json-false
                   :synthetic_payload_bytes full-bytes
                   :parser_class (symbol-name (transport-integration-probe-v0--classify S))
                   :required_transport_record
                   (list :request_max_output_tokens
                         (transport-integration-probe-v0--num-predict request-body-captured)
                         :request_response_schema_sha256
                         (transport-integration-probe-v0--schema-sha256 request-body-captured)
                         :provider_done (plist-get provider-ref :provider_done)
                         :provider_done_reason (plist-get provider-ref :provider_done_reason)
                         :provider_prompt_eval_count (plist-get provider-ref :provider_prompt_eval_count)
                         :provider_eval_count (plist-get provider-ref :provider_eval_count)
                         :provider_raw_body_bytes (plist-get provider-ref :provider_raw_body_bytes)
                         :provider_raw_body_sha256 (plist-get provider-ref :provider_raw_body_sha256)
                         :llm_text_bytes (if (stringp final-string-value)
                                             (string-bytes final-string-value) 0)
                         :llm_text_sha256 (and (stringp final-string-value)
                                               (transport-integration-probe-v0--sha256
                                                final-string-value))
                         :runtime_response_bytes (if blocking-response
                                                    (string-bytes blocking-response) 0)
                         :runtime_response_sha256 (if blocking-response
                                                     (transport-integration-probe-v0--sha256 blocking-response) nil)
                         :outcome_raw_bytes
                         (alist-get 'raw_bytes outcome-record-captured)
                         :outcome_raw_sha256
                         (alist-get 'raw_sha256 outcome-record-captured))
                   :required_transport_record_provenance
                   (list :kind "composite"
                         :provider_fields "reference-only from verified STOP-1 artifact"
                         :downstream_fields "synthetic B0 Runtime integration path"
                         :provider_reference (plist-get provider-ref :provider_reference))
                   :stop1_artifact (list :path transport-integration-probe-v0--stop1-result-path
                                         :sha256 stop1-hash
                                         :verified (if stop1-verified t :json-false))
                   :network_call_count network-calls
                   :request_body_captured (not (null request-body-captured))
                   :mock_partial_lengths mock-partials
                   :final_string_count final-string-count
                   :temp_db (if db-evidence db-evidence :json-false)
                   :archive_db (list :present (if archive-present t :json-false)
                                     :verified (if archive-verified t :json-false)
                                     :hash (and archive (plist-get archive :hash)))
                   :source_sha256 (transport-integration-probe-v0--hash-file
                                   (or load-file-name buffer-file-name))
                   :guards (list :unchanged (if guards-unchanged t :json-false)
                                 :before guards-before
                                 :after guards-after)
                   :cleanup (list :advice_gone (if advice-gone t :json-false)
                                  :timer_gone (if no-timer-leftover t :json-false)
                                  :temp_dir_gone (if temp-dir-gone t :json-false)
                                  :db_globals_nil (if db-globals-nil t :json-false)
                                  :probe_buffer_gone (if probe-buffer-gone t :json-false)
                                  :llm_log_gone (if llm-log-gone t :json-false))
                   :failures
                   (apply #'vector
                          (mapcar (lambda (pair)
                                    (list :case_id (car pair)
                                          :evidence (cdr pair)))
                                  (nreverse transport-integration-probe-v0--failures)))
                   :not_proved
                   (list "provider fields are inherited-by-reference from STOP-1 (v0.3-result.json); read from that frozen artifact, not replayed; no fabricated provider bytes"
                         "this probe does not prove product Outcome semantics; the Outcome record is the next-measurement persistence shape only"
                         "the synthetic transport replaces llm-chat-streaming; network transport remains proven only by STOP-1 artifacts"
                         "execution_authorized stays false"))))
        (princ (json-encode (transport-integration-probe-v0--json-normalize output)))
        (terpri)
        (kill-emacs (if transport-integration-probe-v0--failures 1 0)))))))

;;; Entry

(condition-case err
    (progn
      (transport-integration-probe-v0--load-contract)
      (let ((guards-before (transport-integration-probe-v0--guards-before)))
        ;; (1) isolated temp data directory + temp SQLite
        (setq transport-integration-probe-v0--temp-dir
              (make-temp-file "sc-b0-" t))
        (setq superchat-data-directory
              (expand-file-name "data" transport-integration-probe-v0--temp-dir))
        (make-directory superchat-data-directory t)
        (superchat-db-open
         (expand-file-name "probe.db" transport-integration-probe-v0--temp-dir))
        (transport-integration-probe-v0--run guards-before)))
  (error
   (when transport-integration-probe-v0--timer
     (cancel-timer transport-integration-probe-v0--timer)
     (setq transport-integration-probe-v0--timer nil))
   (when superchat-db--connection
     (superchat-db-close))
   (setq superchat-db--connection nil superchat-db--path nil)
   (dolist (name '(" *superchat-b0-probe*" "*llm-log*"))
     (when-let* ((buffer (get-buffer name)))
       (kill-buffer buffer)))
   (when (and transport-integration-probe-v0--temp-dir
              (file-directory-p transport-integration-probe-v0--temp-dir))
     (ignore-errors
       (delete-directory transport-integration-probe-v0--temp-dir t)))
   (let ((out (list :probe "transport-integration-probe-v0"
                    :throwaway t
                    :subgate_status "open"
                    :STOP-2 "Superchat integration open"
                    :STOP-3 "UTF-8 decision open"
                    :execution_authorized :json-false
                    :fatal_error (error-message-string err)
                    :failures (vector (list :case_id "fatal"
                                            :evidence (error-message-string err))))))
     (princ (json-encode (transport-integration-probe-v0--json-normalize out)))
     (terpri)
     (kill-emacs 1))))

(provide 'transport-integration-probe-v0)

;;; transport-integration-probe-v0.el ends here
