;;; canary-closure-live.el --- Live canary for Closure shadow/guard -*- lexical-binding: t; -*-

;; Real SQLite Tape + real Runtime/Authority/Closure stack; only the LLM
;; transport is stubbed.  Run:
;;   emacs -Q --batch -L . -l test/canary-closure-live.el

;;; Code:

(require 'superchat)

(defvar canary--failures nil)
(defvar canary--session "canary-session")
(defvar canary--provider-plan nil)
(defvar canary--terminal nil)
(defvar canary--late-callback nil)
(defvar canary--late-result nil)

(defun canary-check (label expected actual)
  "Report LABEL as PASS when EXPECTED equals ACTUAL, else record failure."
  (if (equal expected actual)
      (message "PASS  %s" label)
    (push (list label expected actual) canary--failures)
    (message "FAIL  %s\n      expected: %S\n      actual:   %S"
             label expected actual)))

(defun canary--submit ()
  "Submit one Run through Runtime and return its handle."
  (superchat-runtime-submit
   (list :type :llm-query
         :input "hi" :clean-input "hi" :prompt "User question: hi"
         :session-id canary--session
         :buffer-name " *canary*"
         :delivery-function (lambda (_response _status _tape-id) nil))))

(defun canary--tool (name fn args &rest extra-context)
  "Execute one tool through Authority inside the live Run context."
  (superchat-tool-execute
   name fn args
   :context (append extra-context
                    (bound-and-true-p superchat--tool-execution-context))))

(defun canary--replay ()
  "Replay the whole canary Session from the real Tape."
  (superchat-tape-replay-events canary--session))

(defun canary--run-events (run-id)
  "Return this Run's in-scope event types from the real Tape."
  (mapcar (lambda (event) (plist-get event :type))
          (cl-remove-if-not
           (lambda (event) (equal run-id (plist-get event :run-id)))
           (canary--replay))))

(defun canary--verdict (kind run-id &optional turn-id terminal-kind)
  "Judge KIND for RUN-ID from the real Tape and return the verdict."
  (plist-get
   (superchat-closure-judge
    (append (list :kind kind :run-id run-id)
            (when turn-id (list :turn-id turn-id))
            (when terminal-kind (list :terminal-kind terminal-kind)))
   (canary--replay))
   :verdict))

(defun canary--status (handle)
  "Return the public status plist for HANDLE."
  (superchat-runtime-status (plist-get handle :run-id)))

(unless (and (fboundp 'sqlite-available-p) (sqlite-available-p))
  (message "SQLite unavailable; canary skipped")
  (kill-emacs 0))

(let* ((directory (make-temp-file "superchat-canary-" t))
       (superchat-data-directory directory)
       (superchat-runtime--runs (make-hash-table :test #'equal))
       (superchat-buffer-name " *canary*")
       (superchat--active-timeout-timer nil)
       (superchat-pre-topic-finalized-functions nil)
       (superchat-post-turn-functions nil)
       (superchat-post-topic-finalized-functions nil)
       (superchat-run-completed-functions nil)
       (superchat-turn-completed-functions nil)
       (superchat-closure-shadow-enabled t)
       (superchat-closure-terminal-guard-enabled t)
       (superchat-closure-shadow-functions nil)
       (superchat-runtime--closure-observations nil))
  (superchat-db-close)
  (unwind-protect
      (cl-letf (((symbol-function 'superchat--update-status) #'ignore)
                ((symbol-function 'superchat--llm-generate-answer)
                 (lambda (&rest _args)
                   (when canary--provider-plan
                     (funcall canary--provider-plan))
                   (when canary--terminal
                     (funcall superchat--llm-runtime-observer
                              'terminal canary--terminal))
                   'provider-request)))

        (message "=== S1: plain completed Run (shadow + guard ON) ===")
        (let* ((canary--provider-plan nil)
               (canary--terminal '(:status completed :response "answer"))
               (handle (canary--submit))
               (run-id (plist-get handle :run-id))
               (turn-id (plist-get (canary--status handle) :turn-id)))
          (canary-check "S1 status" 'completed
                        (plist-get (canary--status handle) :status))
          (canary-check "S1 tape"
                        '("intent.received" "run.started"
                          "response.completed" "run.completed"
                          "turn.completed")
                        (canary--run-events run-id))
          (canary-check "S1 trace-well-formed" 'valid
                        (canary--verdict 'trace-well-formed run-id))
          (canary-check "S1 durable-run-terminal" 'proved
                        (canary--verdict 'durable-run-terminal run-id))
          (canary-check "S1 durable-turn-terminal" 'proved
                        (canary--verdict 'durable-turn-terminal
                                         run-id turn-id)))

        (message "=== S2: approved write-file Tool, then completion ===")
        (let* ((tool-result nil)
               (canary--provider-plan
                (lambda ()
                  (setq tool-result
                        (canary--tool
                         "write-file" (lambda (&rest _args) "written")
                         '("out.txt" "body")
                         :approval-function (lambda (_request) t)))))
               (canary--terminal '(:status completed :response "done"))
               (handle (canary--submit))
               (run-id (plist-get handle :run-id)))
          (canary-check "S2 tool result" "written" tool-result)
          (canary-check "S2 tape"
                        '("intent.received" "run.started" "tool.requested"
                          "approval.requested" "approval.decided"
                          "tool.execution.started" "tool.completed"
                          "response.completed" "run.completed"
                          "turn.completed")
                        (canary--run-events run-id))
          (canary-check "S2 durable-run-terminal" 'proved
                        (canary--verdict 'durable-run-terminal run-id))
          (canary-check "S2 pending-effects" 'proved
                        (canary--verdict 'pending-effects run-id))
          (canary-check "S2 pending-approvals" 'proved
                        (canary--verdict 'pending-approvals run-id)))

        (message "=== S3: user denies the Approval prompt ===")
        (let* ((tool-result nil)
               (canary--provider-plan
                (lambda ()
                  (setq tool-result
                        (canary--tool
                         "write-file" (lambda (&rest _args) "written")
                         '("out.txt" "body")
                         :approval-function (lambda (_request) nil)))))
               (canary--terminal '(:status completed :response "ok anyway"))
               (handle (canary--submit))
               (run-id (plist-get handle :run-id)))
          (canary-check "S3 tool result" "[Tool call cancelled by user]"
                        tool-result)
          (canary-check "S3 tape"
                        '("intent.received" "run.started" "tool.requested"
                          "approval.requested" "approval.decided"
                          "tool.failed" "response.completed"
                          "run.completed" "turn.completed")
                        (canary--run-events run-id))
          (canary-check "S3 durable-run-terminal" 'proved
                        (canary--verdict 'durable-run-terminal run-id))
          (canary-check "S3 pending-effects" 'proved
                        (canary--verdict 'pending-effects run-id)))

        (message "=== S4: Authority policy denies the Tool ===")
        (let* ((tool-result nil)
               (canary--provider-plan
                (lambda ()
                  (setq tool-result
                        (canary--tool
                         "write-file" (lambda (&rest _args) "written")
                         '("out.txt" "body")))))
               (canary--terminal '(:status completed :response "ok anyway"))
               handle run-id)
          (cl-letf (((symbol-function 'superchat--agent-check-permission)
                     (lambda (_tool _args) 'deny)))
            (setq handle (canary--submit)))
          (setq run-id (plist-get handle :run-id))
          (canary-check "S4 tool result"
                        "[Tool call denied by authority policy]" tool-result)
          (canary-check "S4 tape"
                        '("intent.received" "run.started" "tool.requested"
                          "tool.failed" "response.completed"
                          "run.completed" "turn.completed")
                        (canary--run-events run-id))
          (canary-check "S4 durable-run-terminal" 'proved
                        (canary--verdict 'durable-run-terminal run-id)))

        (message "=== S5: Tool raises an error mid-execution ===")
        (let* ((tool-result nil)
               (canary--provider-plan
                (lambda ()
                  (setq tool-result
                        (canary--tool
                         "write-file" (lambda (&rest _args) (error "boom"))
                         '("out.txt" "body")
                         :approval-function (lambda (_request) t)))))
               (canary--terminal '(:status completed :response "recovered"))
               (handle (canary--submit))
               (run-id (plist-get handle :run-id)))
          (canary-check "S5 tool mentions failure" t
                        (and (stringp tool-result)
                             (string-match-p "Tool call failed" tool-result)
                             t))
          (canary-check "S5 durable-run-terminal" 'proved
                        (canary--verdict 'durable-run-terminal run-id))
          (canary-check "S5 pending-effects" 'proved
                        (canary--verdict 'pending-effects run-id)))

        (message "=== S6: guardrail blocks the Tool before decision ===")
        (let* ((tool-result nil)
               (canary--provider-plan
                (lambda ()
                  (setq tool-result
                        (canary--tool
                         "write-file" (lambda (&rest _args) "written")
                         '("out.txt" "body")
                         :block "call limit"))))
               (canary--terminal '(:status completed :response "ok"))
               (handle (canary--submit))
               (run-id (plist-get handle :run-id)))
          (canary-check "S6 tool result" "[Tool call blocked: call limit]"
                        tool-result)
          (canary-check "S6 tape"
                        '("intent.received" "run.started" "tool.requested"
                          "tool.failed" "response.completed"
                          "run.completed" "turn.completed")
                        (canary--run-events run-id))
          (canary-check "S6 durable-run-terminal" 'proved
                        (canary--verdict 'durable-run-terminal run-id)))

        (message "=== S7: cancel while an async Tool is still executing ===")
        (let* ((canary--provider-plan
                (lambda ()
                  (superchat-tool-execute
                   "write-file"
                   (lambda (callback &rest _args)
                     (setq canary--late-callback callback))
                   '("out.txt" "body")
                   :async t
                   :callback (lambda (result)
                               (setq canary--late-result result))
                   :context
                   (append
                    (list :approval-function (lambda (_request) t))
                    (bound-and-true-p superchat--tool-execution-context)))))
               (canary--terminal nil)
               (handle (canary--submit))
               (run-id (plist-get handle :run-id))
               (turn-id (plist-get (canary--status handle) :turn-id)))
          (canary-check "S7 still running" 'running-model
                        (plist-get (canary--status handle) :status))
          (canary-check "S7 tape before cancel"
                        '("intent.received" "run.started" "tool.requested"
                          "approval.requested" "approval.decided"
                          "tool.execution.started")
                        (canary--run-events run-id))
          (canary-check "S7 cancel returns t" t
                        (and (superchat-runtime-cancel run-id) t))
          (canary-check "S7 guard forces audit-incomplete" 'audit-incomplete
                        (plist-get (canary--status handle) :status))
          (canary-check "S7 no cancelled seal on Tape"
                        '("intent.received" "run.started" "tool.requested"
                          "approval.requested" "approval.decided"
                          "tool.execution.started")
                        (canary--run-events run-id))
          (canary-check "S7 trace-well-formed" 'valid
                        (canary--verdict 'trace-well-formed run-id))
          (canary-check "S7 durable-run-terminal stays open" 'open
                        (canary--verdict 'durable-run-terminal run-id))
          (canary-check "S7 residual-boundary open" 'open
                        (canary--verdict 'residual-boundary run-id))
          ;; The provider flushes the async Tool after the Run is gone.
          (funcall canary--late-callback "late result")
          (canary-check "S7 late callback delivered" "late result"
                        canary--late-result)
          (canary-check "S7 late tool.completed keeps trace valid" 'valid
                        (canary--verdict 'trace-well-formed run-id))
          (canary-check "S7 effect accounted after late flush" 'proved
                        (canary--verdict 'residual-boundary run-id))
          (canary-check "S7 run terminal still open" 'open
                        (canary--verdict 'durable-run-terminal run-id))
          (canary-check "S7 turn terminal open" 'open
                        (canary--verdict 'durable-turn-terminal
                                         run-id turn-id)))

        (message "=== S8: provider times out ===")
        (let* ((canary--provider-plan nil)
               (canary--terminal '(:status timed-out :response "too slow"))
               (handle (canary--submit))
               (run-id (plist-get handle :run-id)))
          (canary-check "S8 status" 'timed-out
                        (plist-get (canary--status handle) :status))
          (canary-check "S8 tape"
                        '("intent.received" "run.started"
                          "response.completed" "run.failed"
                          "turn.completed")
                        (canary--run-events run-id))
          (canary-check "S8 durable-run-terminal" 'proved
                        (canary--verdict 'durable-run-terminal run-id))
          (canary-check "S8 terminal kind" 'timed-out
                        (plist-get
                         (plist-get
                          (superchat-closure-judge
                           (list :kind 'durable-run-terminal :run-id run-id)
                           (canary--replay))
                          :judgment)
                         :terminal-kind)))

        (message "=== S9: cross-Run scope on one shared Session Tape ===")
        (let* ((first-run
                (car (cl-remove-if-not
                      (lambda (event)
                        (equal "intent.received" (plist-get event :type)))
                      (canary--replay))))
               (run-1 (plist-get first-run :run-id))
               (well-formed
                (superchat-closure-judge
                 (list :kind 'trace-well-formed :run-id run-1)
                 (canary--replay))))
          (canary-check "S9 first Run terminal still proved" 'proved
                        (canary--verdict 'durable-run-terminal run-1))
          (canary-check "S9 trace valid with foreign Runs present" 'valid
                        (plist-get well-formed :verdict))
          (canary-check "S9 out-of-scope events classified" t
                        (and (plist-get (plist-get well-formed :witness)
                                        :out-of-scope-event-ids)
                             t)))

        (message "=== Ledger: full ===")
        (dolist (observation (superchat-runtime-closure-observations))
          (message "  %s" observation))
        (message "=== Ledger: anomalies only ===")
        (let ((anomalies (superchat-runtime-closure-observations t)))
          (dolist (observation anomalies)
            (message "  %s" observation))
          (canary-check "ledger has exactly one anomaly" 1
                        (length anomalies))
          (canary-check "anomaly is the S7 guard rejection" 'rejected
                        (plist-get (car anomalies) :decision)))
        (message "=== Canary done: %d failure(s) ==="
                 (length canary--failures)))
    (superchat-db-close)
    (delete-directory directory t)))

(kill-emacs (if canary--failures 1 0))

;;; canary-closure-live.el ends here
