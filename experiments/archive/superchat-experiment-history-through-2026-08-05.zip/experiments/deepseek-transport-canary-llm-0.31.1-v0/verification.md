# Verification

- `llm.el`: 0.31.1, loaded from `/Users/chenyibin/.config/nova-emacs/elpa/llm-0.31.1/llm.elc`.
- Installed source SHA-256: `fe169df78471fad559ddea32009f6e00dee53b570b980a58c5d3ed68a45e0dd6`; identical to the source extracted from the frozen GNU ELPA archive.
- Fresh Nova load-path check: resolves 0.31.1 with `llm-request-plz-connect-timeout=30`; 0.31.0 remains installed.
- The already-running Emacs server still has 0.31.0 loaded (with the 30-second connection timeout); restart is required before that process uses 0.31.1.
- Live Transport Canary: 4/4 success, 0 transport errors, strict gate `pass`.
- Independent record check: four unique success records, no error fields, no response plaintext, source hash and transport settings match.
- Project ERT: 578 tests; 572 expected results, 0 unexpected, 6 skipped.

One preflight invocation stopped before provider construction because the
experiment reader used the invalid JSON array selector `vector`.  The reader
was corrected to `array`; no network request from that preflight invocation is
included in the four Transport samples.

This verifies only the observed four-request transport sample.  It does not
prove that intermittent TLS failures are eliminated and makes no Agent,
effectiveness, or learning claim.
