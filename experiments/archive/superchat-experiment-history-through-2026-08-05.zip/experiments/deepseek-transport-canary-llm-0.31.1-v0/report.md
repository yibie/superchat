# DeepSeek Transport Canary — llm.el 0.31.1

- Strict gate: **pass**
- Transport successes: **4/4**
- Scope: direct non-streaming `llm-chat-async`; no Runtime, tools, retries, Artifacts, or quality scoring.
- Claim boundary: a pass validates only this four-request transport sample.

| Attempt | Status | Latency ms | Failure class | Error |
|---|---:|---:|---|---|
| transport-01 | success | 1646 | — | — |
| transport-02 | success | 1580 | — | — |
| transport-03 | success | 1703 | — | — |
| transport-04 | success | 1722 | — | — |
