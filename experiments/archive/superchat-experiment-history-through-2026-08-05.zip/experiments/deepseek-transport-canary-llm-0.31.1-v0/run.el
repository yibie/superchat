;;; run.el --- Minimal DeepSeek transport canary  -*- lexical-binding: t; -*-

;;; Commentary:

;; Four sequential, non-streaming requests.  No Superchat Runtime, tools,
;; retries, Artifacts, or response-quality judgment participate.

;;; Code:

(require 'package)
(setq package-user-dir "/Users/chenyibin/.config/nova-emacs/elpa")
(package-initialize)

(require 'cl-lib)
(require 'json)
(require 'subr-x)
(require 'llm)
(require 'llm-deepseek)
(require 'llm-request-plz)

(defconst superchat-deepseek-transport-canary--directory
  (file-name-directory (or load-file-name buffer-file-name)))

(defconst superchat-deepseek-transport-canary--manifest-path
  (expand-file-name "manifest.json"
                    superchat-deepseek-transport-canary--directory))

(defconst superchat-deepseek-transport-canary--record-path
  (expand-file-name "transport-record.json"
                    superchat-deepseek-transport-canary--directory))

(defconst superchat-deepseek-transport-canary--report-path
  (expand-file-name "report.md"
                    superchat-deepseek-transport-canary--directory))

(defconst superchat-deepseek-transport-canary--expected-llm-version "0.31.1")
(defconst superchat-deepseek-transport-canary--attempts 4)
(defconst superchat-deepseek-transport-canary--watchdog-seconds 180)
(defconst superchat-deepseek-transport-canary--prompt "Reply exactly: OK")

(setq llm-request-plz-connect-timeout 30
      llm-request-plz-timeout nil
      llm-log nil
      llm-warn-on-nonfree nil)

(defun superchat-deepseek-transport-canary--timestamp ()
  "Return the current UTC time in RFC 3339 form."
  (format-time-string "%Y-%m-%dT%H:%M:%SZ" nil t))

(defun superchat-deepseek-transport-canary--sha256-string (value)
  "Return the protocol-prefixed SHA-256 of VALUE."
  (concat "sha256:" (secure-hash 'sha256 value)))

(defun superchat-deepseek-transport-canary--read-json (path)
  "Read JSON from PATH as an alist."
  (with-temp-buffer
    (insert-file-contents path)
    (json-parse-buffer :object-type 'alist :array-type 'array
                       :null-object nil :false-object :false)))

(defun superchat-deepseek-transport-canary--write-json (path value)
  "Write VALUE as JSON to PATH."
  (with-temp-file path
    (insert (json-serialize value :null-object nil :false-object :false))
    (insert "\n")))

(defun superchat-deepseek-transport-canary--llm-version ()
  "Return the selected llm package version."
  (when-let* ((entry (assq 'llm package-alist))
              (descriptor (cadr entry)))
    (package-version-join (package-desc-version descriptor))))

(defun superchat-deepseek-transport-canary--classify-error (type message)
  "Return a bounded transport classification for TYPE and MESSAGE."
  (let ((text (downcase (or message ""))))
    (cond
     ((or (string-match-p "curl error code 35" text)
          (string-match-p "ssl connect" text)
          (string-match-p "tls" text))
      "tls_handshake_error")
     ((or (eq type 'llm-request-timeout)
          (string-match-p "timeout" text))
      "operation_timeout")
     ((memq type '(llm-request-authentication-error
                   llm-request-bad-request))
      "api_rejection")
     (t "transport_error"))))

(defun superchat-deepseek-transport-canary--run-one (provider number)
  "Run attempt NUMBER through PROVIDER and return its evidence record."
  (let* ((attempt-id (format "transport-%02d" number))
         (started-at (superchat-deepseek-transport-canary--timestamp))
         (started-seconds (float-time))
         (deadline (+ started-seconds
                      superchat-deepseek-transport-canary--watchdog-seconds))
         done response error-type error-message request)
    (condition-case err
        (setq request
              (llm-chat-async
               provider
               (llm-make-chat-prompt
                superchat-deepseek-transport-canary--prompt
                :temperature 0
                :max-tokens 4
                :reasoning 'none)
               (lambda (value)
                 (setq response value
                       done t))
               (lambda (type message)
                 (setq error-type type
                       error-message (format "%s" message)
                       done t))))
      (error
       (setq error-type (car err)
             error-message (error-message-string err)
             done t)))
    (while (and (not done) (< (float-time) deadline))
      (accept-process-output nil 0.1))
    (unless done
      (when request
        (ignore-errors (llm-cancel-request request)))
      (setq error-type 'experiment-watchdog-timeout
            error-message
            (format "No callback within %d seconds"
                    superchat-deepseek-transport-canary--watchdog-seconds)
            done t))
    (let* ((ended-at (superchat-deepseek-transport-canary--timestamp))
           (latency-ms (round (* 1000 (- (float-time) started-seconds))))
           (response-text (and response (format "%s" response)))
           (success (and response (not error-type)))
           (record
            `((attempt_id . ,attempt-id)
              (started_at . ,started-at)
              (ended_at . ,ended-at)
              (latency_ms . ,latency-ms)
              (transport_status . ,(if success "success" "error"))
              (failure_class . ,(unless success
                                  (superchat-deepseek-transport-canary--classify-error
                                   error-type error-message)))
              (error_type . ,(and error-type (symbol-name error-type)))
              (error_message . ,error-message)
              (response_length . ,(and response-text (length response-text)))
              (response_sha256 . ,(and response-text
                                       (superchat-deepseek-transport-canary--sha256-string
                                        response-text))))))
      (princ (format "%s %s %dms%s\n"
                     attempt-id
                     (alist-get 'transport_status record)
                     latency-ms
                     (if error-message
                         (format " (%s)" error-message)
                       "")))
      record)))

(defun superchat-deepseek-transport-canary--markdown-cell (value)
  "Return VALUE escaped for a Markdown table cell."
  (replace-regexp-in-string
   "[\n|]" " " (if value (format "%s" value) "—")))

(defun superchat-deepseek-transport-canary--write-report
    (records success-count strict-gate)
  "Write the Markdown report for RECORDS, SUCCESS-COUNT, and STRICT-GATE."
  (with-temp-file superchat-deepseek-transport-canary--report-path
    (insert "# DeepSeek Transport Canary — llm.el 0.31.1\n\n")
    (insert (format "- Strict gate: **%s**\n" strict-gate))
    (insert (format "- Transport successes: **%d/%d**\n"
                    success-count superchat-deepseek-transport-canary--attempts))
    (insert "- Scope: direct non-streaming `llm-chat-async`; no Runtime, tools, retries, Artifacts, or quality scoring.\n")
    (insert "- Claim boundary: a pass validates only this four-request transport sample.\n\n")
    (insert "| Attempt | Status | Latency ms | Failure class | Error |\n")
    (insert "|---|---:|---:|---|---|\n")
    (dolist (record records)
      (insert
       (format "| %s | %s | %s | %s | %s |\n"
               (alist-get 'attempt_id record)
               (alist-get 'transport_status record)
               (alist-get 'latency_ms record)
               (superchat-deepseek-transport-canary--markdown-cell
                (alist-get 'failure_class record))
               (superchat-deepseek-transport-canary--markdown-cell
                (alist-get 'error_message record)))))))

(defun superchat-deepseek-transport-canary-run ()
  "Execute the frozen four-request transport canary."
  (let* ((manifest
          (superchat-deepseek-transport-canary--read-json
           superchat-deepseek-transport-canary--manifest-path))
         (llm-version (superchat-deepseek-transport-canary--llm-version))
         (llm-path (locate-library "llm"))
         (key (getenv "DEEPSEEK_API_KEY")))
    (unless (equal "authorized" (alist-get 'status manifest))
      (error "Transport Canary is not authorized"))
    (unless (and key (not (string-empty-p key)))
      (error "DEEPSEEK_API_KEY is not configured"))
    (unless (equal superchat-deepseek-transport-canary--expected-llm-version
                   llm-version)
      (error "Expected llm %s, loaded %s"
             superchat-deepseek-transport-canary--expected-llm-version
             llm-version))
    (unless (and llm-path (string-match-p "/llm-0\\.31\\.1/" llm-path))
      (error "Unexpected llm library path: %s" llm-path))
    (unless (and (= superchat-deepseek-transport-canary--attempts
                    (alist-get 'attempts manifest))
                 (= llm-request-plz-connect-timeout
                    (alist-get 'connect_timeout_seconds manifest)))
      (error "Frozen Transport Canary inputs changed"))
    (let* ((provider
            (make-llm-deepseek
             :key (lambda () (getenv "DEEPSEEK_API_KEY"))
             :chat-model "deepseek-v4-pro"
             :default-chat-temperature 0
             :default-chat-max-tokens 4))
           (records
            (cl-loop for number from 1 to superchat-deepseek-transport-canary--attempts
                     collect (superchat-deepseek-transport-canary--run-one
                              provider number)))
           (success-count
            (cl-count "success" records
                      :key (lambda (record)
                             (alist-get 'transport_status record))
                      :test #'equal))
           (strict-gate
            (if (= success-count superchat-deepseek-transport-canary--attempts)
                "pass"
              "blocked"))
           (record
            `((experiment_id . ,(alist-get 'experiment_id manifest))
              (completed_at . ,(superchat-deepseek-transport-canary--timestamp))
              (environment
               . ((emacs_version . ,emacs-version)
                  (llm_version . ,llm-version)
                  (llm_library_path . ,llm-path)
                  (llm_source_sha256
                   . ,(superchat-deepseek-transport-canary--sha256-string
                       (with-temp-buffer
                         (insert-file-contents
                          (expand-file-name "llm.el"
                                            (file-name-directory llm-path)))
                         (buffer-string))))
                  (provider . "llm-deepseek")
                  (model . "deepseek-v4-pro")
                  (reasoning . "none")
                  (connect_timeout_seconds . ,llm-request-plz-connect-timeout)
                  (request_timeout_seconds . nil)
                  (watchdog_seconds
                   . ,superchat-deepseek-transport-canary--watchdog-seconds)
                  (api_key_present . t)))
              (attempts . ,(vconcat records))
              (summary
               . ((attempt_count . ,(length records))
                  (success_count . ,success-count)
                  (failure_count . ,(- (length records) success-count))
                  (strict_gate . ,strict-gate)
                  (response_content_evaluated . :false)
                  (effectiveness_claim . "not_applicable")
                  (learning_claim . "prohibited"))))))
      (superchat-deepseek-transport-canary--write-json
       superchat-deepseek-transport-canary--record-path record)
      (superchat-deepseek-transport-canary--write-report
       records success-count strict-gate)
      (princ (format "strict-gate=%s success=%d/%d\n"
                     strict-gate success-count
                     superchat-deepseek-transport-canary--attempts)))))

(superchat-deepseek-transport-canary-run)

;;; run.el ends here
