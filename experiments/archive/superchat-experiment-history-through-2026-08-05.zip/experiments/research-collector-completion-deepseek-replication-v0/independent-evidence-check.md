# DeepSeek Collector Completion Replication v0 — Independent Evidence Check

## Verdict

The preregistered Replication Gate is **blocked**: `2/4` samples passed, while
the Manifest requires `4/4`. Repeatability is therefore `not-demonstrated`.

This is an end-to-end pipeline result. It is not evidence that DeepSeek failed
the application completion instruction twice: both blocked samples ended with
explicit provider-transport errors.

## Samples

| Sample | Research | Publish | Terminal | Artifact | Gate |
| --- | --- | --- | --- | --- | --- |
| `deepseek-rep-01` | 2 searches / 5 reads | 1/1 | completed | deliverable | pass |
| `deepseek-rep-02` | 3 searches / 5 reads | 1/1 | completed | deliverable | pass |
| `deepseek-rep-03` | 2 searches / 2 reads | 0/0 | failed: `Operation timeout` | absent | blocked |
| `deepseek-rep-04` | 2 searches / 4 reads | 1/1 | failed: curl 56 receive error | present, rejected | blocked |

All four Prior Gates passed: model `deepseek-v4-pro`, reasoning `none`, the
same system-prompt hash, the same question hash, and the same exact seven-tool
surface were observed. All tool identities and scopes were valid, and no
`tool.failed` event occurred.

## Failure provenance

`deepseek-rep-03` completed the minimum search/read activity and then received
`[API error: Operation timeout.]` before publication. Its lack of an Artifact
is censored by transport failure and cannot be classified as a clean
`model_did_not_select_workspace_publish` observation.

`deepseek-rep-04` completed `workspace_publish`; the generated file still
exists and its SHA-256
`6621bca6407bccc3f069489236ed279253c5d088d723a9c882842d5acc639428`
matches the recorded Artifact revision. The following model request failed
with `[API error: curl error code 56: Failure in receiving network data.]`.
The producer Run therefore has a proved `failed` terminal, so Artifact Delivery
correctly rejects the otherwise intact file.

The error strings originate from `plz`/curl error codes 28 and 56. Current
evidence does not include a provider request identifier or network trace, so it
cannot distinguish a DeepSeek service failure from a local proxy/network/curl
failure.

## Boundary

- Zero retries, continuations, recoveries, substitutions, or historical sample
  imports occurred.
- The two failed facts are preserved and were not repaired or reclassified as
  successful samples.
- Outcome quality, comparative model effectiveness, broad stability, Pattern,
  and Learning remain unevaluated or prohibited.
- The SQLite Tape snapshot passed `PRAGMA integrity_check`.

