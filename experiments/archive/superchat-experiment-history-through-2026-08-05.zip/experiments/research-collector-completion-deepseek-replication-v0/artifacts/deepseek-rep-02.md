# Rollback-Journal vs. Write-Ahead Log (WAL) in SQLite: Reader/Writer Behavior and Crash Recovery

## Sources

All information in this document is drawn from the official SQLite documentation at sqlite.org:

1. **Write-Ahead Logging** — https://www.sqlite.org/wal.html (last updated 2026-04-13)
2. **Isolation In SQLite** — https://sqlite.org/isolation.html (last updated 2022-04-18)
3. **File Locking And Concurrency In SQLite Version 3** — https://www.sqlite.org/lockingv3.html (last updated 2025-05-31)
4. **Atomic Commit In SQLite** — https://www.sqlite.org/atomiccommit.html
5. **PRAGMA Statements (synchronous, journal_mode)** — https://www.sqlite.org/pragma.html (last updated 2026-06-04)
6. **WAL-mode File Format** — https://www.sqlite.org/walformat.html

---

## 1. Fundamental Mechanical Difference

### Rollback-Journal Mode (the default, a.k.a. DELETE/TRUNCATE/PERSIST)

The traditional rollback journal works by writing a copy of the **original unchanged database content** into a separate rollback journal file and then writing changes **directly into the database file**. In the event of a crash or ROLLBACK, the original content contained in the rollback journal is played back into the database file to revert it to its original state. **The COMMIT occurs when the rollback journal is deleted** (or, for TRUNCATE/PERSIST, truncated or its header zeroed).

— Source: https://www.sqlite.org/wal.html, §2 "How WAL Works"

### WAL Mode (available since 3.7.0, 2010-07-21)

The WAL approach **inverts** the rollback model. The **original content is preserved** in the database file and the **changes are appended into a separate WAL file**. A COMMIT occurs when a special record indicating a commit is appended to the WAL. Thus a COMMIT can happen without ever writing to the original database, which allows readers to continue operating from the original unaltered database while changes are simultaneously being committed into the WAL. Multiple transactions can be appended to a single WAL file.

— Source: https://www.sqlite.org/wal.html, §2 "How WAL Works"

Another way to think about the difference: in the rollback-journal approach there are **two** primitive operations (reading and writing), whereas with WAL there are **three** (reading, writing, and checkpointing).

— Source: https://www.sqlite.org/wal.html, §2.1 "Checkpointing"

---

## 2. Reader/Writer Behavior

### Rollback-Journal Mode

In rollback mode, SQLite implements isolation by **locking the database file and preventing any reads** by other database connections while each write transaction is underway.

- Readers can be active at the beginning of a write, before any content is flushed to disk and while all changes are still held in the writer's private memory space.
- But **before any changes are made to the database file on disk, all readers must be (temporarily) expelled** in order to give the writer exclusive access to the database file.
- Readers are prohibited from seeing incomplete transactions by virtue of being locked out of the database while the transaction is being written to disk.
- Only after the transaction is completely written and synced to disk and committed are the readers allowed back into the database.

— Source: https://sqlite.org/isolation.html, "Isolation And Concurrency"

#### The lock escalation sequence for rollback-mode writes:

1. **SHARED** — acquired for reading; many simultaneous readers allowed.
2. **RESERVED** — signals intent to write; one writer at a time; other readers can continue.
3. Rollback journal is created; original pages written to journal.
4. **PENDING** — prevents new readers from connecting; existing readers allowed to finish.
5. **EXCLUSIVE** — writer writes changes to the database file; no other access allowed.
6. Journal is deleted (COMMIT occurs); EXCLUSIVE and PENDING locks released.

— Source: https://www.sqlite.org/lockingv3.html, §5.0 "Writing to a database file"

This means that in rollback mode, **writers block readers** during the actual disk write phase, and readers can potentially block a writer from obtaining its EXCLUSIVE lock. The PENDING lock mechanism exists specifically to prevent **writer starvation** when many readers are continuously connected.

— Source: https://www.sqlite.org/lockingv3.html, §5.1 "Writer starvation"

### WAL Mode

WAL mode permits **simultaneous readers and writers**. It can do this because changes do not overwrite the original database file, but rather go into the separate WAL file.

- Readers continue to read the old, original, unaltered content from the original database file at the same time that the writer is appending to the WAL.
- WAL mode exhibits **snapshot isolation**: when a read transaction starts, that reader continues to see an unchanging "snapshot" of the database as it existed at the moment the read transaction started. Any write transactions that commit while the read transaction is active are invisible to the read transaction.
- Each reader remembers an "end mark" — the location of the last valid commit record in the WAL at the moment its transaction began.
- When a reader needs a page, it first checks the WAL to see if that page appears there (prior to its end mark); if not, it reads from the original database file.
- Writers merely append new content to the end of the WAL file. Because writers do nothing that would interfere with the actions of readers, writers and readers can run at the same time.
- **However, since there is only one WAL file, there can only be one writer at a time.**

— Source: https://www.sqlite.org/wal.html, §2.2 "Concurrency"

#### Checkpointing and reader interaction

A checkpoint operation takes content from the WAL file and transfers it back into the original database file. A checkpoint **can run concurrently with readers**, however the checkpoint must stop when it reaches a page in the WAL that is past the end mark of any current reader — otherwise it might overwrite part of the database file that the reader is actively using. The checkpoint remembers (in the wal-index) how far it got and will resume on the next invocation. Thus a **long-running read transaction can prevent a checkpointer from making progress**.

— Source: https://www.sqlite.org/wal.html, §2.2 "Concurrency"

#### Important caveat: readers are not entirely immune to blocking

The second advantage of WAL-mode is that writers do not block readers and readers do not block writers. This is **mostly true**. But there are some obscure cases where a query against a WAL-mode database can return SQLITE_BUSY:

- If another connection has the database open in **exclusive locking mode**.
- When the last connection is closing and holds an exclusive lock briefly for cleanup.
- If the last connection crashed, the first new connection runs recovery under an exclusive lock; a third connection attempting to query during recovery gets SQLITE_BUSY.

— Source: https://www.sqlite.org/wal.html, §9 "Sometimes Queries Return SQLITE_BUSY In WAL Mode"

---

## 3. Crash Recovery Guarantees

### 3.1 Rollback-Journal Mode

#### Recovery mechanism

If a crash or power failure occurs during a write transaction, a **hot rollback journal** is left on disk. The first process to subsequently access the database detects the hot journal and performs automatic recovery:

1. Obtains a SHARED lock, then checks for a hot journal.
2. A journal is "hot" if: it exists, its size is greater than 512 bytes, its header is non-zero and well-formed, its super-journal exists (or the super-journal name is empty), and there is **no RESERVED lock** on the database file.
3. Acquires a PENDING then EXCLUSIVE lock on the database.
4. Reads the journal file and **rolls back the changes** — original page content is written back to the database file, and the database is truncated to its original size if it grew.
5. Flushes the rolled-back changes to persistent storage.
6. Deletes (or truncates/zeros) the journal file.
7. Drops EXCLUSIVE and PENDING, retains SHARED.

— Source: https://www.sqlite.org/lockingv3.html, §4.1 "Dealing with hot journals"
— Source: https://www.sqlite.org/atomiccommit.html, §4 "Rollback"

#### The commit instant

The COMMIT occurs at the moment the rollback journal is **deleted** (or truncated, or its header zeroed). If a power failure or system crash occurs **prior** to this point, recovery makes it appear as if **no changes were ever made**. If a crash occurs **after** the journal is deleted, it appears as if **all changes have been written to disk**. Thus, SQLite gives the appearance of having made no changes or the complete set of changes depending on whether or not the rollback journal file exists.

— Source: https://www.sqlite.org/atomiccommit.html, §3.11 "Deleting The Rollback Journal"

#### Durability nuance

The deletion of the journal file commits the transaction. But a power failure at the exact moment of deletion creates ambiguity. On most filesystems, file deletion appears atomic from the point of view of a user process — the file either exists (transaction rolls back) or does not (transaction is committed).

— Source: https://www.sqlite.org/atomiccommit.html, §3.11

### 3.2 WAL Mode

#### Recovery mechanism

In WAL mode, recovery is different because there is no rollback journal. Instead:

- Recovery is the process of **rebuilding the WAL-index** so that it is synchronized with the WAL file.
- Recovery is run by the **first thread to connect** to a WAL-mode database.
- Recovery works by doing a **single pass over the WAL, from beginning to end**. The checksums are verified on each frame. The scan stops at the end of the file or at the **first invalid checksum**.
- The `mxFrame` field is set to the index of the last valid commit frame. A "commit frame" is a frame that has a non-zero value in bytes 4-7 of the frame header.
- The `nBackfill` value is initialized to zero, since recovery has no way of knowing how many frames were previously copied back into the database.
- During recovery, **exclusive locks** are held on WAL_WRITE_LOCK, WAL_CKPT_LOCK, WAL_RECOVER_LOCK, and WAL_READ_LOCK(1) through WAL_READ_LOCK(4) — preventing any other thread from writing or reading transactions in the WAL until recovery is complete.

— Source: https://www.sqlite.org/walformat.html, §3 "Recovery"

#### What happens on crash

If the last connection to a database crashed, the first new connection to open will start the recovery process. An exclusive lock is held during recovery. A third connection trying to query during recovery gets SQLITE_BUSY.

— Source: https://www.sqlite.org/wal.html, §9

#### The WAL file and shared-memory files

The WAL file is part of the persistent state of the database. If a database file is separated from its WAL file, previously committed transactions might be lost or the database might become corrupted. The -shm (shared memory) file does **not** contain any database content and is **not required** to recover the database following a crash. For that reason, the first client to connect to a quiescent database will normally truncate the shm file if it exists. The shm file is **never fsync()-ed** to disk.

— Source: https://www.sqlite.org/walformat.html

#### Backwards compatibility guard

The database file format version numbers (bytes 18 and 19) are increased from 1 to 2 in WAL mode. Older versions of SQLite (pre-3.7.0) will refuse to open a WAL-mode database with an error like "file is encrypted or is not a database." This prevents older versions from attempting (and failing) to recover a WAL-mode database.

— Source: https://www.sqlite.org/wal.html, §10 "Backwards Compatibility"

### 3.3 The Role of PRAGMA synchronous

The synchronous pragma significantly affects crash recovery guarantees. Here is the official matrix:

| synchronous | Rollback Mode | WAL Mode |
|---|---|---|
| EXTRA (3) | ACID | ACID |
| FULL (2) | Atomic, Consistent, Isolated; **maybe not durable** | **ACID** |
| NORMAL (1) | **Maybe not consistent** (corruption possible on older filesystems) | Consistent, but **maybe not durable** |
| OFF (0) | Not consistent | Not consistent |

— Source: https://www.sqlite.org/pragma.html#pragma_synchronous

**Key documented facts:**

- **FULL is the default.** FULL is ACID in WAL mode and is atomic, consistent, and isolated with a rollback journal. FULL might also be durable using a rollback journal, depending on the underlying filesystem. **FULL is not necessarily durable across a power loss in rollback mode**, so if durability is desired in rollback mode, it is best to set synchronous to EXTRA.

- In WAL mode with synchronous=FULL, an additional sync operation of the WAL file happens after **each transaction commit**, helping ensure that transactions are durable across a power loss.

- In WAL mode with synchronous=NORMAL, the WAL file is synced before each checkpoint, the database file is synced after each completed checkpoint, and the WAL file header is synced when a WAL file begins to be reused — but **no sync operations occur during most transactions**. WAL mode is always **consistent** with synchronous=NORMAL, but WAL mode does **lose durability**: a transaction committed in WAL mode with synchronous=NORMAL might roll back following a power loss or system crash.

- **Transactions are durable across application crashes regardless of the synchronous setting or journal mode.** The commit record has been written to the filesystem; fsync() was simply not called, so an OS crash or power loss before the record reaches stable storage means the transaction will be rolled back on next open.

— Source: https://www.sqlite.org/pragma.html#pragma_synchronous
— Source: https://www.sqlite.org/wal.html, §2.3 "Performance Considerations"

---

## 4. Summary: Side-by-Side Comparison

| Aspect | Rollback-Journal Mode | WAL Mode |
|---|---|---|
| **Where changes go** | Directly into the database file | Appended to separate WAL file |
| **Original data** | Copied to rollback journal | Preserved in database file |
| **COMMIT moment** | When journal is deleted | When commit record is appended to WAL |
| **Readers during writes** | Blocked (must be expelled before writes hit disk) | Continue concurrently (snapshot isolation) |
| **Writers during reads** | Must wait for all readers to finish | Can proceed concurrently with readers |
| **Concurrent writers** | One at a time (via locks) | One at a time (single WAL file) |
| **Crash recovery** | Hot journal detection → rollback original pages | WAL-index rebuild via checksum-verified pass over WAL |
| **Consistency after crash (synchronous=FULL)** | Yes (atomic, consistent, isolated) | Yes (full ACID) |
| **Durability after crash (synchronous=FULL)** | Maybe not (depends on filesystem; use EXTRA) | Yes (extra WAL sync per commit) |
| **WAL-mode specific risk** | N/A | WAL-reset bug (3.7.0–3.51.2, fixed in 3.51.3), very rare |
| **Network filesystem** | Supported (with caveats) | **Not supported** (requires shared memory) |
| **Extra files** | `-journal` (transient) | `-wal` and `-shm` (quasi-persistent) |
| **Checkpointing** | Not applicable | Required; automatic at 1000 pages by default |

---

## 5. The WAL-Reset Bug (Documented Risk)

On 2026-03-03, SQLite developer Dan found and fixed a bug that could, in rare cases, lead to database corruption. The bug is present in all versions from 3.7.0 through 3.51.2, fixed in 3.51.3. It only affects databases in WAL mode when there are two or more connections attempting to write or checkpoint at the same instant. The SQLite developers were unable to reproduce the bug organically and had to add special testing logic to trigger it. Based on telemetry, the occurrence rate in the wild appears to be less than or equal to the expected occurrence rate of SSD malfunctions and/or cosmic-ray hits.

— Source: https://www.sqlite.org/wal.html, §11 "The WAL-Reset Bug"

---

## 6. Documented Facts vs. Inference

All statements above are **directly sourced** from the official SQLite documentation pages listed at the top. The following are **inferences or clarifications** that extend or contextualize the documented facts:

### Documented Facts (directly quoted or closely paraphrased from official pages):
- The mechanical description of how rollback journal and WAL commit work (§1)
- The lock escalation sequence in rollback mode (§2)
- Snapshot isolation and concurrent reader/writer behavior in WAL mode (§2)
- Hot journal detection and recovery procedure (§3.1)
- WAL recovery via checksum-verified pass (§3.2)
- The synchronous pragma matrix and its ACID implications (§3.3)
- The WAL-reset bug (§5)
- That WAL does not work over network filesystems (§2)

### Inferences / Summary Constructions:
- The side-by-side comparison table (§4) is a **synthesis** of documented facts from multiple pages; the structure is the author's.
- The characterization of "mostly true" regarding WAL's non-blocking guarantee is the official documentation's own hedging.
- The statement that rollback-mode FULL is "maybe not durable" is an explicit statement from the official documentation, not an inference.
