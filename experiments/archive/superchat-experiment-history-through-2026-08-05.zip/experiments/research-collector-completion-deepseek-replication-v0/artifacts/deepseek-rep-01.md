# Rollback-Journal vs. WAL Modes in SQLite: Reader/Writer Behavior and Crash Recovery

## Source Documents (Official SQLite Documentation)

All facts below are drawn from the following official SQLite pages:

1. **Write-Ahead Logging** — https://www.sqlite.org/wal.html (last updated 2026-04-13)
2. **File Locking And Concurrency In SQLite Version 3** — https://www.sqlite.org/lockingv3.html (last updated 2025-05-31)
3. **Atomic Commit In SQLite** — https://www.sqlite.org/atomiccommit.html (specifically covers rollback mode)
4. **Isolation In SQLite** — https://www.sqlite.org/isolation.html (last updated 2022-04-18)
5. **Temporary Files Used By SQLite** — https://www.sqlite.org/tempfiles.html (last updated 2025-06-12)

---

## 1. Mechanism Overview

### Rollback-Journal Mode (the default; `journal_mode=DELETE`, `TRUNCATE`, or `PERSIST`)

- The **original unchanged database content is copied into a separate rollback journal file** before any changes are written directly into the database file.
- The rollback journal is an ordinary disk file in the same directory as the database, with a `-journal` suffix.
- A COMMIT occurs when the rollback journal is **deleted** (or truncated, or its header zeroed, depending on the journal_mode variant).
- In the event of a crash or ROLLBACK, the original content from the rollback journal is **played back into the database file** to revert it to its original state.

*Source: https://www.sqlite.org/wal.html, Section 2 "How WAL Works"; https://www.sqlite.org/lockingv3.html, Section 4.0*

### WAL Mode (`journal_mode=WAL`)

- The approach is **inverted**: the original content is **preserved in the database file** and changes are **appended into a separate WAL file** (suffix `-wal`).
- A COMMIT occurs when a **special record indicating a commit is appended to the WAL** — without ever writing to the original database file.
- A third primitive operation, **checkpointing**, is introduced: moving WAL file transactions back into the database file.
- WAL mode also uses a **shared-memory file** (`-shm`) containing the wal-index for fast page lookup.
- WAL mode was introduced in SQLite version 3.7.0 (2010-07-21).

*Source: https://www.sqlite.org/wal.html, Sections 1, 2, and 2.1; https://www.sqlite.org/tempfiles.html, Sections 2.2 and 2.3*

---

## 2. Reader/Writer Behavior

### Rollback-Journal Mode: Writers Block Readers, Readers Block Writers

- SQLite uses a **five-state locking protocol**: UNLOCKED → SHARED → RESERVED → PENDING → EXCLUSIVE.
- **Readers** acquire a SHARED lock. Any number of processes can hold SHARED locks simultaneously.
- A **writer** first acquires a RESERVED lock (signaling intent to write; readers can still proceed). While holding RESERVED, the writer builds the rollback journal and accumulates changes in memory.
- Before writing changes to the database file, the writer must obtain a PENDING lock, then an EXCLUSIVE lock. 
  - A **PENDING lock** allows existing SHARED locks to continue but **prevents new SHARED locks** from being established. This prevents writer starvation.
  - An **EXCLUSIVE lock** blocks all other access. 
- **All readers must be expelled** before the writer can obtain the EXCLUSIVE lock and flush changes to the database file.
- Once the EXCLUSIVE lock is held, **no other processes can access the database** until the transaction commits and the EXCLUSIVE lock is released.
- **Result**: In rollback mode, writers block readers and readers block writers during the actual disk-write phase of a transaction.

*Source: https://www.sqlite.org/lockingv3.html, Sections 3.0, 5.0, and 5.1; https://www.sqlite.org/isolation.html, "Isolation And Concurrency"*

### WAL Mode: Readers and Writers Can Run Concurrently

- **Writers** merely **append new content to the end of the WAL file**. They do nothing that interferes with readers.
- **Readers** continue to read the **old, original, unaltered content** from the original database file. When a reader needs a page, it first checks the WAL (via the wal-index in shared memory) to see if the page appears there prior to its "end mark" — the last valid commit record at the time the read transaction began. If not, it reads from the database file.
- Because writers append to the WAL and readers read from the database file (supplemented by the WAL), **writers do not block readers and readers do not block writers**.
- **Only one writer at a time** is permitted, since there is only one WAL file.
- A **checkpoint** (moving WAL content into the database file) can run concurrently with readers, but must stop when it reaches a WAL page past the end mark of any current reader. A long-running read transaction can prevent a checkpoint from completing.
- **Snapshot isolation**: each reader sees an unchanging snapshot of the database as it existed at the moment the read transaction started. Committed writes from other connections that occur during the read transaction remain invisible to the reader.

*Source: https://www.sqlite.org/wal.html, Sections 2.2 "Concurrency" and 2.3 "Performance Considerations"; https://www.sqlite.org/isolation.html, "Isolation And Concurrency"*

### Edge Cases in WAL Mode

- Despite the general rule, queries in WAL mode can **sometimes return SQLITE_BUSY**:
  - If another connection has the database open in exclusive locking mode.
  - When the last connection is closing and holds an exclusive lock briefly during WAL and shared-memory cleanup.
  - During recovery: if the last connection crashed, the first new connection holds an exclusive lock during recovery; a third connection attempting to query will get SQLITE_BUSY.

*Source: https://www.sqlite.org/wal.html, Section 9 "Sometimes Queries Return SQLITE_BUSY In WAL Mode"*

---

## 3. Crash Recovery Guarantees

### Rollback-Journal Mode: Hot Journal Rollback

- **Crash during a write transaction**: The rollback journal file is left on disk. This is called a **"hot journal"**.
- A journal is "hot" if: it exists, its size is greater than 512 bytes, its header is non-zero and well-formed, its super-journal exists (or the super-journal name is empty), and there is **no RESERVED lock** on the database file.
- **Recovery is automatic on next access**: the first process to open the database after a crash checks for a hot journal. If one is found, the process:
  1. Acquires an EXCLUSIVE lock.
  2. Reads the original page content from the rollback journal and writes it back into the database file.
  3. Truncates the database back to its original size (if the incomplete transaction caused it to grow).
  4. Flushes changes to disk.
  5. Deletes (or truncates/zeros) the journal file.
- After recovery, the database is in the state it was in **before the aborted transaction began** — it is as if the incomplete transaction never happened.
- **The COMMIT atomicity guarantee**: The COMMIT is the instant the rollback journal is deleted. Before deletion, a crash causes rollback. After deletion, changes persist.

*Source: https://www.sqlite.org/atomiccommit.html, Sections 4.1–4.6; https://www.sqlite.org/lockingv3.html, Sections 4.0–4.1*

### WAL Mode: Roll-Forward Recovery from the WAL

- In WAL mode, the **WAL file is a roll-forward journal** that records transactions committed but not yet applied to the main database.
- **Crash recovery**: If the last connection to a database crashed, the first new connection to open the database starts a **recovery process**. An exclusive lock is held during recovery. The shared-memory wal-index is **recreated from scratch** based on the contents of the WAL file.
- All transactions that were **successfully committed to the WAL** (i.e., their commit records were appended and synced) survive the crash. The WAL file contains the record of committed transactions; these are recovered.
- Transactions that were **in-flight** at the time of the crash (no commit record in the WAL) are simply not seen — they are effectively rolled back because the WAL contains no commit record for them.
- After a clean shutdown (last connection closes normally), that connection does one last checkpoint and then **deletes the WAL and shared-memory files**.
- If the last connection does not shut down cleanly, the WAL file **remains on disk** and is automatically cleaned up (recovered) the next time the database is opened.

*Source: https://www.sqlite.org/wal.html, Section 4 "The WAL File"; https://www.sqlite.org/tempfiles.html, Sections 2.2 and 2.3; https://www.sqlite.org/walformat.html summary*

### Durability and Synchronous Setting Differences

- **Rollback mode**: Requires multiple fsync() operations — the rollback journal must be flushed to disk before writing to the database, and the database changes must be flushed before deleting the journal. This is the source of the mode's write performance cost.
- **WAL mode**: Writers sync the WAL on every transaction commit only if `PRAGMA synchronous=FULL`. If `PRAGMA synchronous=NORMAL`, the WAL sync is omitted on commit; the checkpoint is the only operation that issues an fsync(). Transactions are no longer durable after a power failure in this configuration, but write performance is improved.

*Source: https://www.sqlite.org/wal.html, Sections 2.3 "Performance Considerations"*

---

## 4. Multi-File Transaction Atomicity

### Rollback Mode

- For transactions involving multiple ATTACHed databases, a **super-journal** file is created. The super-journal contains the names of all individual database rollback journals.
- The multi-database COMMIT occurs when the super-journal is deleted. This ensures atomicity across all databases: either all commit or all roll back.

*Source: https://www.sqlite.org/atomiccommit.html, Section 5; https://www.sqlite.org/lockingv3.html, Section 5.0*

### WAL Mode

- Transactions involving multiple ATTACHed databases are **atomic for each individual database, but are not atomic across all databases as a set**. In a crash during a multi-file WAL transaction, some databases might roll back while others roll forward.

*Source: https://www.sqlite.org/wal.html, Section 1 (disadvantage #2); https://www.sqlite.org/tempfiles.html, Section 2.4*

---

## 5. Summary Comparison Table

| Aspect | Rollback-Journal (DELETE/TRUNCATE/PERSIST) | WAL Mode |
|---|---|---|
| **Mechanism** | Original pages copied to journal; changes written directly to DB | Original DB preserved; changes appended to WAL file |
| **COMMIT moment** | Rollback journal deleted/truncated/zeroed | Special commit record appended to WAL |
| **Readers vs. Writers** | Mutually exclusive during disk write; writers expel readers | Concurrent; readers see snapshot, writers append to WAL |
| **Isolation level** | Serializable (via write serialization) | Snapshot isolation |
| **Crash recovery** | Hot journal detected → original pages replayed into DB → journal deleted → DB restored to pre-transaction state | WAL file replayed forward; committed transactions survive; in-flight transactions lost (no commit record) |
| **Multi-file atomicity** | Yes (via super-journal) | Per-database only; not across ATTACHed databases |
| **Auxiliary files** | `-journal` (and optionally super-journal `-mjXXXXXXXX`) | `-wal` and `-shm` |
| **Persistence** | Non-persistent (except WAL mode itself and PERSIST journal_mode) | WAL mode is persistent across connections |
| **Write performance** | Slower (pages written twice: once to journal, once to DB; multiple fsyncs) | Faster (single sequential write to WAL; fewer fsyncs) |
| **Introduced** | Original (SQLite version 3.0.0, 2004) | Version 3.7.0 (2010-07-21) |

---

## 6. Distinguishing Documented Facts from Inference

### Documented Facts (explicitly stated in official documentation)
- Rollback mode: rollback journal is created, original pages copied, changes written to DB, journal deleted at commit. (atomiccommit.html, lockingv3.html)
- WAL mode: changes appended to WAL, commit record appended, checkpoint moves data to DB. (wal.html)
- In rollback mode, readers are expelled before writer can obtain EXCLUSIVE lock and write to DB. (lockingv3.html §5.0, isolation.html)
- In WAL mode, readers and writers can proceed concurrently. (wal.html §2.2)
- Hot journal recovery: next opener detects hot journal, replays original pages, deletes journal. (atomiccommit.html §4, lockingv3.html §4.1)
- WAL recovery: first connection after crash recreates wal-index from WAL and recovers. (tempfiles.html §2.3, wal.html §4)
- Multi-file transactions are not atomic across databases in WAL mode. (wal.html §1, tempfiles.html §2.4)

### Inferences (logically derived but not stated verbatim in docs)
- That WAL mode's roll-forward recovery is the "inverse" of rollback mode's roll-backward recovery is an inference drawn from the documented mechanisms; the documentation describes each separately.
- The relative simplicity of the WAL recovery path (no need to detect "hot" state via lock inspection; just replay the WAL) is an inference from comparing the two documented procedures.
- Performance trade-offs between the two modes are documented (wal.html §2.3), but specific quantitative claims about "most scenarios" are the SQLite team's generalization, not a benchmark guarantee for every workload.

---

*Artifact compiled from official SQLite documentation at sqlite.org. All source URLs retained above.*
