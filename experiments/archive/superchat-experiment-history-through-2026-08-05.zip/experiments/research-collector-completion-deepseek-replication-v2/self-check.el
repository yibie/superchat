;;; self-check.el --- Research Collector Completion Replication checks -*- lexical-binding: t; -*-

(require 'superchat-research-collector-completion-deepseek-replication-v2-run)
(require 'superchat-research-collector-completion-deepseek-replication-v2-evidence)

(unless
    (and (= 4 (length
               (superchat-research-collector-deepseek-replication-v2--assignments)))
         (let ((questions
                (mapcar
                 (lambda (assignment) (plist-get assignment :question))
                 (superchat-research-collector-deepseek-replication-v2--assignments))))
           (cl-every (lambda (question) (equal (car questions) question))
                     (cdr questions)))
         (eq 'none superchat-llm-reasoning)
         (= 30 llm-request-plz-connect-timeout)
         (equal
          "Using official SQLite documentation, explain how rollback-journal and WAL modes differ in reader/writer behavior and crash recovery guarantees."
          (plist-get
           (car (superchat-research-collector-deepseek-replication-v2--assignments))
           :question))
         (string-match-p
          (regexp-quote "deepseek-rep-v2-01")
          (superchat-research-collector-deepseek-replication-v2--task
           (car (superchat-research-collector-deepseek-replication-v2--assignments))))
         (equal "collector"
                (superchat-research-collector-deepseek-replication-v2--normalize-role
                 'collector))
         (equal "collector"
                (superchat-research-collector-deepseek-replication-v2--normalize-role
                 "collector"))
         (superchat-research-collector-deepseek-replication-v2--same-tool-surface-p
          ["agent_reach_search" "agent_reach_read" "workspace_read"
           "workspace_publish" "workspace_info" "team_task" "team_message"])
         (not
          (superchat-research-collector-deepseek-replication-v2--same-tool-surface-p
           ["agent_reach_search" "agent_reach_read" "workspace_read"
            "workspace_publish" "workspace_info" "team_task"]))
         (= 2
            (length
             (superchat-research-collector-deepseek-replication-v2--source-urls
              "A https://example.org/a B https://example.org/b")))
         (equal
          "material_read_contract_not_completed"
          (superchat-research-collector-deepseek-replication-v2--interpret
           t t 1 1 0 0 0 "artifact_absent" 0)))
  (error "Research Collector Completion Replication self-check failed"))

(provide 'superchat-research-collector-completion-deepseek-replication-v2-self-check)

;;; self-check.el ends here
