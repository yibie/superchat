# DeepSeek Collector Completion Replication v2 — Independent Evidence Check

## Verdict

The preregistered Replication Gate is **blocked**: `3/4` samples passed, while
the Manifest requires `4/4`. All four model-facing snapshots and the execution
record observed `llm-request-plz-connect-timeout = 30`.

No curl 28 timeout occurred in v2. The blocked sample instead ended with an
explicit curl 35 TLS handshake error, so the 30-second setting did not produce
a stable 4/4 transport surface.

## Samples

| Sample | Research | Publish | Terminal | Artifact | Gate |
| --- | --- | --- | --- | --- | --- |
| `deepseek-rep-v2-01` | 0 searches / 0 reads | 0/0 | failed: curl 35 TLS error | absent | blocked |
| `deepseek-rep-v2-02` | 2 searches / 5 reads | 1/1 | completed | deliverable | pass |
| `deepseek-rep-v2-03` | 2 searches / 5 reads | 1/1 | completed | deliverable | pass |
| `deepseek-rep-v2-04` | 1 search / 5 reads | 1/1 | completed | deliverable | pass |

All four Prior Gates passed. Model `deepseek-v4-pro`, reasoning `none`, the
same prompt/question semantics, exact seven-tool surface, and 30-second connect
timeout were observed. Tool identities and scopes were valid, no unexpected
tool was requested, and no `tool.failed` event occurred.

## Failure provenance

`deepseek-rep-v2-01` completed its initial model request and the first local
tool round (`team_task`, `workspace_info`, and `team_message`). The next curl
process started at `21:29:43.578`; Tape recorded
`[API error: curl error code 35: SSL connect error. The SSL handshaking failed.]`
at `21:29:59.447`. The next sample started a fresh curl process at
`21:29:59.504` and subsequently completed, so the observed TLS failure was
transient rather than a persistent credential or endpoint configuration error.

Because transport failed before research began, Artifact absence is censored
by the failed producer Run. It is not a clean
`model_did_not_select_workspace_publish` observation.

## Cross-replication comparison

| Replication | Connect timeout | Passed | Explicit transport failures | Gate |
| --- | ---: | ---: | ---: | --- |
| v0 | 10 s | 2/4 | 2: curl 28, curl 56 | blocked |
| v1 | 10 s | 3/4 | 1: curl 28 | blocked |
| v2 | 30 s | 3/4 | 1: curl 35 | blocked |

Increasing the connect timeout removed curl 28 from this four-sample batch but
did not close the Replication Gate. The samples are too small and non-random to
claim that 30 seconds is broadly superior. Across all 12 Runs, every blocked
sample has an explicit transport error; no clean application-compliance failure
has been observed.

## Boundary

- v2 used four new execution identities and imported no prior Run or Artifact.
- Zero retries, continuations, recoveries, substitutions, or downstream stages
  occurred.
- The failed fact was preserved and not repaired or reclassified.
- Outcome quality, effectiveness, Pattern, and Learning remain unevaluated or
  prohibited.
- Actual transport was `llm.el 0.31.0`; the package declares `0.31.1`.
- The SQLite Tape snapshot passed `PRAGMA integrity_check`.
