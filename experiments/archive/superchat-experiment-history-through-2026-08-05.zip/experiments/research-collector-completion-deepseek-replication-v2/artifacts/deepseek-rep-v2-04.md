# Rollback-Journal vs. WAL Modes in SQLite: Reader/Writer Behavior and Crash Recovery

## Source Documents

All information below is drawn from the official SQLite documentation at sqlite.org:

1. **Write-Ahead Logging** — https://www.sqlite.org/wal.html (last updated 2026-04-13)
2. **Isolation In SQLite** — https://www.sqlite.org/isolation.html (last updated 2022-04-18)
3. **Atomic Commit In SQLite** — https://www.sqlite.org/atomiccommit.html (last updated 2026-08-02)
4. **Temporary Files Used By SQLite** — https://www.sqlite.org/tempfiles.html (last updated 2025-06-12)
5. **File Locking And Concurrency In SQLite Version 3** — https://sqlite.org/lockingv3.html (last updated 2025-05-31)

---

## 1. Fundamental Mechanism — How Each Mode Works

### Rollback-Journal Mode (the default)

> "The traditional rollback journal works by writing a copy of the original unchanged database content into a separate rollback journal file and then writing changes directly into the database file." — wal.html §2

In rollback mode (controlled by `journal_mode=DELETE`, `PERSIST`, or `TRUNCATE`), the commit protocol proceeds as follows (documented in atomiccommit.html §3):

1. A SHARED lock is acquired to read the database.
2. A RESERVED lock is acquired, signaling intent to write. Other readers may still hold SHARED locks.
3. A rollback journal file is created, and original page content for pages about to be modified is written into it.
4. The rollback journal is flushed (fsync'd) to nonvolatile storage.
5. An EXCLUSIVE lock is obtained (via a PENDING lock to prevent writer starvation). During this step, all readers are expelled.
6. Changes are written directly into the database file.
7. Database changes are flushed to disk.
8. The rollback journal file is deleted (or truncated / header-zeroed). **This is the instant of commit.**
9. The EXCLUSIVE lock is released.

> "In rollback mode, SQLite implements isolation by locking the database file and preventing any reads by other database connections while each write transaction is underway." — isolation.html

> "Hence, readers are prohibited from seeing incomplete transactions by virtue of being locked out of the database while the transaction is being written to disk." — isolation.html

### WAL Mode (Write-Ahead Logging)

> "The WAL approach inverts this. The original content is preserved in the database file and the changes are appended into a separate WAL file. A COMMIT occurs when a special record indicating a commit is appended to the WAL." — wal.html §2

In WAL mode (enabled via `PRAGMA journal_mode=WAL`):

- Changes are appended to the WAL file; the original database file is not overwritten during writes.
- Commit is recorded by appending a commit record to the WAL, without touching the original database file.
- A checkpoint operation later transfers WAL content back into the original database file.
- Multiple transactions can be appended to a single WAL file.

> "Another way to think about the difference between rollback and write-ahead log is that in the rollback-journal approach, there are two primitive operations, reading and writing, whereas with a write-ahead log there are now three primitive operations: reading, writing, and checkpointing." — wal.html §2.1

---

## 2. Reader/Writer Behavior

### Rollback-Journal Mode: Readers Block Writers, Writers Block Readers

**From isolation.html:**

> "In rollback mode, SQLite implements isolation by locking the database file and preventing any reads by other database connections while each write transaction is underway. Readers can be active at the beginning of a write, before any content is flushed to disk and while all changes are still held in the writer's private memory space. But before any changes are made to the database file on disk, all readers must be (temporarily) expelled in order to give the writer exclusive access to the database file."

Key behavioral points:

- Multiple readers can coexist (SHARED locks).
- A single writer can hold a RESERVED lock while readers continue.
- When the writer escalates to PENDING, new readers are blocked; existing readers finish.
- When the writer escalates to EXCLUSIVE, all readers are expelled and the writer has sole access.
- Readers never see uncommitted changes — they are locked out until commit completes.

**From lockingv3.html §5.1:**

The PENDING lock mechanism prevents *writer starvation*: if readers continuously come and go, a writer could never get an EXCLUSIVE lock. The PENDING lock blocks *new* SHARED locks while letting existing readers finish, ensuring the writer eventually gains exclusive access.

### WAL Mode: Readers and Writers Are Concurrent

**From wal.html §2.2:**

> "Writers merely append new content to the end of the WAL file. Because writers do nothing that would interfere with the actions of readers, writers and readers can run at the same time. However, since there is only one WAL file, there can only be one writer at a time."

**From isolation.html:**

> "WAL mode permits simultaneous readers and writers. It can do this because changes do not overwrite the original database file, but rather go into the separate write-ahead log file. That means that readers can continue to read the old, original, unaltered content from the original database file at the same time that the writer is appending to the write-ahead log."

#### Snapshot Isolation in WAL Mode

**From isolation.html:**

> "In WAL mode, SQLite exhibits 'snapshot isolation'. When a read transaction starts, that reader continues to see an unchanging 'snapshot' of the database file as it existed at the moment in time when the read transaction started. Any write transactions that commit while the read transaction is active are still invisible to the read transaction, because the reader is seeing a snapshot of database file from a prior moment in time."

**From wal.html §2.2 — the "end mark" mechanism:**

> "When a read operation begins on a WAL-mode database, it first remembers the location of the last valid commit record in the WAL. Call this point the 'end mark'. … But for any particular reader, the end mark is unchanged for the duration of the transaction, thus ensuring that a single read transaction only sees the database content as it existed at a single point in time."

> "When a reader needs a page of content, it first checks the WAL to see if that page appears there, and if so it pulls in the last copy of the page that occurs in the WAL prior to the reader's end mark. If no copy of the page exists in the WAL prior to the reader's end mark, then the page is read from the original database file."

- The **wal-index** (shared-memory data structure) helps readers locate pages in the WAL efficiently.
- All processes must be on the same host (shared memory requirement); WAL does not work over network filesystems.

#### SQLITE_BUSY_SNAPSHOT on Read-to-Write Escalation

**From isolation.html:**

If a reader (connection X) starts a read transaction, then another connection Y commits a write, and X then tries to write, X gets `SQLITE_BUSY_SNAPSHOT`. This is because X's snapshot is no longer the latest version. X must release its snapshot and begin a new transaction. Use `BEGIN IMMEDIATE` to avoid this.

#### Checkpoint and Reader Interaction

**From wal.html §2.2:**

> "A checkpoint operation takes content from the WAL file and transfers it back into the original database file. A checkpoint can run concurrently with readers, however the checkpoint must stop when it reaches a page in the WAL that is past the end mark of any current reader."

Thus, long-running read transactions can prevent a checkpoint from completing, causing the WAL file to grow.

#### Edge Cases Where WAL Readers Get SQLITE_BUSY

**From wal.html §9:**

- If another connection has EXCLUSIVE locking mode.
- When the last connection closes and briefly holds an exclusive lock for cleanup.
- During crash recovery when the first new connection holds an exclusive lock.

---

## 3. Crash Recovery Guarantees

### Rollback-Journal Mode Crash Recovery

**From atomiccommit.html §4 (Rollback):**

Recovery is based on the "hot journal" concept:

> "A hot journal is a rollback journal that needs to be played back in order to restore the database to a sane state. A hot journal only exists when an earlier process was in the middle of committing a transaction when it crashed or lost power."

**Criteria for a hot journal** (atomiccommit.html §4.2):

1. The rollback journal exists.
2. The rollback journal is not empty.
3. No RESERVED lock on the main database file.
4. The journal header is well-formed and not zeroed.
5. The journal does not name a super-journal that is missing.

**Recovery algorithm** (lockingv3.html §4.1):

1. Obtain a SHARED lock.
2. Detect the hot journal.
3. Acquire PENDING then EXCLUSIVE lock.
4. Read the journal and write original page content back into the database file.
5. Flush changes to disk.
6. Delete (or truncate/zero-header) the journal.
7. Drop EXCLUSIVE/PENDING locks, retain SHARED.

**Key guarantee:** The flush of the rollback journal to disk *before* any database changes (step 3.7 of the commit protocol) is the critical safety measure. It ensures that if power is lost during database writes, a complete journal exists on disk to undo the partial changes.

**Commit atomicity:** The commit occurs at the moment the rollback journal is deleted.

> "If a power failure or system crash occurs prior to this point, then recovery processes … make it appear as if no changes were ever made to the database file. If a power failure or system crash occurs after the rollback journal is deleted, then it appears as if all changes have been written to disk." — atomiccommit.html §3.11

**From tempfiles.html §2.1 (journal_mode variants affecting crash safety):**

- `DELETE` (default): journal deleted at commit; full crash recovery.
- `PERSIST`: journal header zeroed instead of deleted; same crash safety but avoids file deletion cost.
- `TRUNCATE`: journal truncated to zero length; same crash safety.
- `MEMORY`: journal in memory only; **no crash recovery possible** — database likely corrupt after power loss.
- `OFF`: no journal at all; **no crash recovery** — database likely corrupt after power loss.

### WAL Mode Crash Recovery

**From wal.html:**

WAL mode crash recovery works differently because the WAL file *contains the committed changes* rather than the original pages:

> "If the last connection to a database crashed, then the first new connection to open the database will start a recovery process. An exclusive lock is held during recovery." — wal.html §9

**From tempfiles.html §2.2 and §2.3:**

> "If the last connection does not shutdown cleanly, the WAL file will remain in the filesystem and will be automatically cleaned up the next time the database is opened."

> "During WAL file recovery, the shared memory file is recreated from scratch based on the contents of the WAL file being recovered."

**Single-database atomicity across power loss:**

WAL mode preserves atomic commit for individual database files across a power loss. The WAL file, which contains committed transactions, persists. On reopening, recovery replays or continues from the WAL.

**Multi-database transactions (critical difference from rollback mode):**

**From tempfiles.html §2.4:**

> "This means that SQLite transactions are not atomic across multiple database files on a power-loss when the database files have synchronous turned off or when they are using journal modes of OFF, MEMORY, or WAL. … For WAL mode, individual database files are updated atomically across a power-loss, but in the case of a multi-file transactions, some files might rollback while others roll forward after power is restored."

This is a documented limitation: rollback-journal mode uses a super-journal file to coordinate atomicity across multiple attached databases. WAL mode does not use super-journals, so multi-database atomicity across crash is not guaranteed.

**Backwards compatibility:**

From wal.html §10: the database file format version numbers (bytes 18–19) are increased from 1 to 2 in WAL mode, so pre-3.7.0 versions of SQLite will refuse to open a WAL-mode database. Use `PRAGMA journal_mode=DELETE` to convert back.

**Checkpoint and durability:**

From wal.html §2.3: with `PRAGMA synchronous=FULL`, writers sync the WAL on every commit. With `synchronous=NORMAL`, the WAL sync is omitted and only the checkpoint issues an fsync. This means transactions are not durable after power loss with `synchronous=NORMAL` — they may roll back.

---

## 4. Summary Comparison Table

| Aspect | Rollback-Journal | WAL |
|---|---|---|
| **Where changes go** | Directly into the database file | Appended to a separate WAL file |
| **Commit moment** | When rollback journal is deleted | When a commit record is appended to the WAL |
| **Readers during writes** | Blocked (expelled before EXCLUSIVE lock) | Concurrent — readers see a snapshot |
| **Writers during reads** | Possible at start (RESERVED lock); then readers expelled | Concurrent — writer appends to WAL |
| **Concurrent writers** | One at a time | One at a time |
| **Isolation model** | Serialized via locking | Snapshot isolation |
| **Crash recovery mechanism** | Hot journal playback (undo partial DB changes) | WAL file replay (recover committed transactions from WAL) |
| **Multi-database atomicity across crash** | Yes (via super-journal) | No (each database is individually atomic, but not as a group) |
| **Network filesystem** | Works (with caveats about locking) | Does not work (requires shared memory) |
| **Primary performance characteristic** | Two writes per changed page (journal + DB); random I/O | One write per changed page (WAL append); sequential I/O; checkpoint overhead |
| **WAL file growth** | N/A | Grows until checkpoint; default auto-checkpoint at 1000 pages |

---

## 5. Distinguishing Documented Facts from Inference

### Documented Facts (directly stated in official documentation)

- Rollback-journal writes original page content to a journal, then changes to the database; WAL appends changes to a log, preserving the original database (wal.html §2).
- In rollback mode, readers are expelled before writers obtain an EXCLUSIVE lock (isolation.html).
- WAL mode permits simultaneous readers and writers (wal.html §2.2, isolation.html).
- WAL readers use an "end mark" for snapshot isolation (wal.html §2.2).
- The commit in rollback mode occurs when the journal is deleted (atomiccommit.html §3.11).
- The commit in WAL mode occurs when a commit record is appended to the WAL (wal.html §2).
- Crash recovery in rollback mode: hot journal is detected and played back to undo partial changes (atomiccommit.html §4, lockingv3.html §4.1).
- Crash recovery in WAL mode: first new connection performs recovery with an exclusive lock (wal.html §9, tempfiles.html §2.2).
- Multi-database transactions are NOT atomic across crash in WAL mode (tempfiles.html §2.4).
- WAL requires shared memory and does not work over network filesystems (wal.html §1, §2.2).

### Reasonable Inferences (not explicitly stated, but logically follow from documented facts)

- Because WAL writes are sequential appends, WAL write performance is generally better than rollback-journal mode, which requires both journal writes and database writes — this is documented as "WAL is significantly faster in most scenarios" (wal.html §1).
- A long-running WAL reader can delay checkpoint completion, potentially causing WAL file growth — documented through the mechanism described in wal.html §2.2 and §6.
- Rollback-journal mode provides stronger multi-file consistency guarantees than WAL mode — follows from the documented lack of super-journals in WAL (tempfiles.html §2.4).
- The `MEMORY` and `OFF` journal modes sacrifice crash recovery for performance — explicitly stated in tempfiles.html §2.1.

---

*Artifact compiled from official SQLite documentation at sqlite.org. All claims are traceable to the source URLs listed at the top.*
