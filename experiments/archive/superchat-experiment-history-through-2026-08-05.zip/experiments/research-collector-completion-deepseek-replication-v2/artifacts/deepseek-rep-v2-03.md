# Rollback-Journal vs. WAL Mode in SQLite: Reader/Writer Behavior and Crash Recovery

## Source Documents (Official SQLite Documentation)

| Page | URL |
|------|-----|
| Write-Ahead Logging | https://www.sqlite.org/wal.html |
| Isolation In SQLite | https://sqlite.org/isolation.html |
| Atomic Commit In SQLite | https://www.sqlite.org/atomiccommit.html |
| WAL-mode File Format | https://www.sqlite.org/walformat.html |

---

## 1. Fundamental Mechanism

### Rollback-Journal Mode (default; DELETE, PERSIST, TRUNCATE)

- **How it works:** Before modifying the database, the original unchanged pages are copied into a separate rollback-journal file. Then changes are written *directly into the database file*.
- **COMMIT:** Occurs when the rollback journal is *deleted* (or its header zeroed/truncated, depending on the journal_mode variant).
- **ROLLBACK / crash recovery:** The original content stored in the rollback journal is *played back* into the database file, reverting it to its pre-transaction state.

### WAL Mode (since 3.7.0, 2010-07-21)

- **How it works:** The original content is *preserved* in the database file and changes are *appended* into a separate Write-Ahead Log (WAL) file. The database file is not overwritten during a write transaction.
- **COMMIT:** Occurs when a special record indicating a commit is appended to the WAL.
- **Checkpointing:** Eventually, transactions in the WAL are transferred back into the database file in an operation called "checkpoint." There are three primitive operations in WAL mode: reading, writing, and checkpointing — versus only reading and writing in rollback mode.

---

## 2. Reader/Writer Behavior

### Rollback-Journal Mode

**Documented facts (from https://sqlite.org/isolation.html):**

- SQLite implements isolation by *locking the database file and preventing any reads by other database connections while each write transaction is underway*.
- "Readers can be active at the beginning of a write, before any content is flushed to disk and while all changes are still held in the writer's private memory space. But before any changes are made to the database file on disk, all readers must be (temporarily) expelled in order to give the writer exclusive access to the database file."
- "Readers are prohibited from seeing incomplete transactions by virtue of being locked out of the database while the transaction is being written to disk. Only after the transaction is completely written and synced to disk and committed are the readers allowed back into the database."
- During a write, the writer acquires a reserved lock, then a pending lock (blocks new readers but lets existing readers finish), and finally an exclusive lock (no readers at all) to write to the database file.

**Summary:** Reading and writing are *mutually exclusive*. A writer blocks all readers once it begins writing to disk. Multiple readers can coexist, but a writer must wait for all readers to finish, and readers must wait for a writer to complete.

### WAL Mode

**Documented facts (from https://www.sqlite.org/wal.html and https://sqlite.org/isolation.html):**

- "WAL provides more concurrency as readers do not block writers and a writer does not block readers. Reading and writing can proceed concurrently."
- "The WAL approach inverts this. The original content is preserved in the database file and the changes are appended into a separate WAL file. ... a COMMIT can happen without ever writing to the original database, which allows readers to continue operating from the original unaltered database while changes are simultaneously being committed into the WAL."
- "Writers merely append new content to the end of the WAL file. Because writers do nothing that would interfere with the actions of readers, writers and readers can run at the same time. However, since there is only one WAL file, there can only be one writer at a time."
- WAL mode exhibits **snapshot isolation**: "When a read transaction starts, that reader continues to see an unchanging 'snapshot' of the database file as it existed at the moment in time when the read transaction started. Any write transactions that commit while the read transaction is active are still invisible to the read transaction."
- Each reader remembers an **"end mark"** — the last valid commit record in the WAL at the time its transaction began. The end mark is unchanged for the duration of the transaction.
- When a reader needs a page, it first checks the WAL for copies of that page prior to its end mark. If none, it reads from the database file.
- A reader that started as read-only cannot escalate to a writer: if it tries, it receives **SQLITE_BUSY_SNAPSHOT** because its snapshot is no longer the latest version.
- A checkpoint can run concurrently with readers but must stop at pages past any reader's end mark to avoid overwriting pages the reader is using.

**Summary:** Readers and writers operate concurrently. Readers see a consistent snapshot from their transaction start. Only one writer at a time. A checkpoint can proceed alongside readers but a long-running reader can prevent checkpoint completion.

---

## 3. Crash Recovery Guarantees

### Rollback-Journal Mode

**Documented facts (from https://www.sqlite.org/atomiccommit.html):**

- **Commit sequence:** (1) Original pages written to rollback journal → (2) Rollback journal flushed to disk → (3) Database changes written to disk and flushed → (4) Rollback journal deleted.
- "If a power failure or system crash occurs prior to this point [deletion], then recovery processes ... make it appear as if no changes were ever made to the database file. If a power failure or system crash occurs after the rollback journal is deleted, then it appears as if all changes have been written to disk."
- **Hot journal recovery:** The first process to access the database after a crash notices the rollback journal file. If it is a "hot journal" (well-formed, non-empty, no reserved lock on the database), the process obtains an exclusive lock and *plays back* the original pages from the rollback journal into the database file, restoring it to the pre-transaction state. The journal is then deleted.
- The rollback journal header records the original database size; SQLite uses this to truncate the database if the incomplete transaction caused it to grow.
- A two-phase flush protects against partially-written journals: the journal's page content is flushed before the header's page count is updated. If the page count in the header is zero, the journal is treated as empty even if other data was written.
- **Failure mode:** "If either the original database file or the hot journal have been moved or renamed, then the hot journal will not be seen and the database will not be rolled back." This would leave the database in a potentially inconsistent state.
- The journal_mode variants (DELETE, PERSIST, TRUNCATE) differ only in how the journal file is invalidated at commit — the atomic guarantee is the same.

**Summary:** Guarantees that after any crash, the database reverts to the last committed state (all-or-nothing). Recovery is automatic on next open. The rollback journal file must remain alongside the database file with the original naming.

### WAL Mode

**Documented facts (from https://www.sqlite.org/wal.html and https://www.sqlite.org/walformat.html):**

- **Commit sequence:** Changes appended to the WAL with checksums. COMMIT is a special frame in the WAL. No database file modification needed for commit.
- **Recovery mechanism:** "Recovery is run by the first thread to connect to a WAL-mode database. Recovery restores the WAL-index so that it accurately describes the WAL file."
- Recovery does a single pass over the WAL from beginning to end, verifying checksums on each frame. "The scan stops at the end of the file or at the first invalid checksum."
- mxFrame is set to the index of the last valid commit frame. A commit frame has a non-zero "size of database" value in bytes 4-7 of the frame header. Frames after an invalid checksum are discarded.
- "Since the recovery procedure has no way of knowing how many frames of the WAL might have previously been copied back into the database, it initializes the nBackfill value to zero." This means after recovery, the WAL is treated as not yet checkpointed, and committed transactions in the WAL will be replayed into the database during future checkpoints. No committed data is lost.
- During recovery, exclusive locks are held on WAL_WRITE_LOCK, WAL_CKPT_LOCK, WAL_RECOVER_LOCK, and WAL_READ_LOCK(1-4), "which prevents any other thread from writing the database and from reading any transactions that are held in the WAL, until the recovery is complete."
- **WAL and SHM file lifecycle:** "If the last client using the database shuts down cleanly by calling sqlite3_close(), then a checkpoint is run automatically in order to transfer all information from the wal file over into the main database, and both the shm file and the wal file are unlinked." If the last client crashes, the WAL and SHM files persist and recovery runs on next open.
- **SHM file is disposable:** "The shm file does not contain any database content and is not required to recover the database following a crash."
- **Backwards compatibility safeguard:** The database file format version numbers (bytes 18 and 19) are increased from 1 to 2 in WAL mode. Older SQLite versions (pre-3.7.0) will refuse to open the database with "file is encrypted or is not a database," preventing them from corrupting it during recovery.
- **Persistence:** WAL mode is persistent across connection close/reopen (unlike other journal_mode settings).
- **Synchronous setting interaction:** With PRAGMA synchronous=FULL, the WAL is synced on every transaction commit. With synchronous=NORMAL, the WAL sync is omitted during commit — durability is then provided by the checkpoint sync operations. If the application runs checkpoints in a separate thread with synchronous=NORMAL, "transactions are no longer durable and might rollback following a power failure or hard reset."

**Summary:** Guarantees that after a crash, all committed transactions survive (they are in the WAL), and uncommitted/incomplete transactions are discarded (via checksum verification stopping at the first invalid frame). Recovery is automatic on the first connection to the database after a crash. The WAL file itself is the recovery mechanism — it's a roll-forward journal. The SHM file is not needed for recovery.

---

## 4. Side-by-Side Comparison

| Aspect | Rollback-Journal | WAL Mode |
|--------|-----------------|----------|
| **Disk files** | Database + `-journal` file (per transaction) | Database + `-wal` + `-shm` (persistent while connections exist) |
| **Write mechanism** | Original pages copied to journal; changes written directly to DB | Original DB preserved; changes appended to WAL |
| **Commit** | Journal file deletion (or header zero/truncate) | Special commit frame appended to WAL |
| **Readers vs. writers** | Mutually exclusive: writer blocks all readers | Concurrent: readers and writers do not block each other |
| **Multiple writers** | One at a time | One at a time (only one WAL_WRITE_LOCK) |
| **Isolation model** | Serializable via lock serialization | Snapshot isolation |
| **Reader visibility** | Readers see committed state at transaction start | Readers see a fixed snapshot (end-mark), even if later writes commit |
| **Crash recovery** | Hot journal playback: restore original pages to DB | WAL scan: verify checksums, discard incomplete frames; committed transactions survive |
| **Recovery trigger** | First open after crash detects hot journal | First connection to database after crash runs recovery |
| **Key risk** | Journal and DB must not be separated/renamed | WAL and DB must be kept together; SHM is disposable |
| **Network filesystem** | Works (file locks only) | Does NOT work (requires shared memory) |
| **Multi-DB transaction atomicity** | Atomic across ATTACHed databases (via super-journal) | Each DB individually atomic, but NOT atomic across ATTACHed databases as a set |
| **Performance profile** | Two writes per changed page (journal + DB); more fsync() calls | One sequential write per changed page to WAL; fewer fsync() calls; checkpoint overhead |

---

## 5. Distinguishing Documented Facts from Inferences

### Documented facts (directly stated in official pages):
- Rollback journal stores original pages, WAL stores changes. (wal.html, atomiccommit.html)
- Rollback mode: writers block readers and vice versa. (isolation.html)
- WAL mode: readers and writers are concurrent. (wal.html, isolation.html)
- WAL provides snapshot isolation. (isolation.html)
- Hot journal detection and playback is the recovery mechanism for rollback mode. (atomiccommit.html)
- WAL recovery scans checksums on first connect, discards incomplete frames. (walformat.html, wal.html)
- WAL mode is persistent across reopens. (wal.html)
- WAL does not work over network filesystems. (wal.html)
- SHM file is not needed for recovery. (walformat.html)

### Reasonable inferences (supported by documented facts but not verbatim):
- Rollback-journal mode provides stronger "serializable" isolation because writes are serialized through the exclusive lock. The documentation explicitly says SQLite implements "serializable" isolation in rollback mode by serializing writes. (isolation.html)
- WAL mode trades slightly weaker isolation (snapshot rather than strictly serializable) for dramatically better concurrency. The isolation page documents snapshot isolation explicitly.
- WAL recovery is more robust against partial writes because checksums let it identify exactly where valid data ends, whereas rollback-journal recovery relies on the journal file being fully flushed before database modification begins. Both methods are documented and the two-phase flush for journals is described in atomiccommit.html.
