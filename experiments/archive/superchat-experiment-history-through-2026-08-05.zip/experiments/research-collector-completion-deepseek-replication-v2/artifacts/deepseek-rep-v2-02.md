# Rollback-Journal vs. WAL Mode: Reader/Writer Behavior and Crash Recovery

## Source Documents

All information below is drawn from official SQLite documentation:

1. **[Write-Ahead Logging](https://www.sqlite.org/wal.html)** — WAL overview, concurrency, checkpointing, crash recovery, backward compatibility. (Last updated 2026-04-13)
2. **[Atomic Commit In SQLite](https://www.sqlite.org/atomiccommit.html)** — Rollback-journal atomic commit protocol, hot-journal recovery after crash. (Last updated 2026-08-02)
3. **[Isolation In SQLite](https://www.sqlite.org/isolation.html)** — Isolation and concurrency control in rollback vs. WAL mode. (Last updated 2022-04-18)
4. **[WAL-mode File Format](https://www.sqlite.org/walformat.html)** — Low-level WAL-index, locking matrix, and recovery procedure. (Last updated 2025-05-10)
5. **[SQLite Is Transactional](https://www.sqlite.org/transactional.html)** — ACID guarantees statement. (Last updated 2026-08-02)

---

## Part 1: How Each Mode Works — The Fundamental Difference

### Rollback-Journal Mode (DELETE / PERSIST / TRUNCATE)

The rollback journal is the default method by which SQLite implements atomic commit and rollback (since the beginning; WAL was introduced in version 3.7.0, 2010-07-21).

**Mechanism ([Atomic Commit](https://www.sqlite.org/atomiccommit.html), [WAL Overview](https://www.sqlite.org/wal.html)):**

1. The **original, unchanged database content** is copied into a separate rollback journal file *before* any changes are written to the main database file.
2. Changes are then written **directly into the main database file**.
3. The transaction **COMMIT is the moment the rollback journal is deleted** (or truncated, or its header zeroed — depending on journal_mode variant).
4. If a ROLLBACK is requested, the original content from the rollback journal is "played back" into the database file to restore it to its pre-transaction state.

In short: "The traditional rollback journal works by writing a copy of the original unchanged database content into a separate rollback journal file and then writing changes directly into the database file." — [wal.html §2](https://www.sqlite.org/wal.html)

### WAL Mode (Write-Ahead Log)

**Mechanism ([WAL](https://www.sqlite.org/wal.html), [Isolation](https://www.sqlite.org/isolation.html)):**

1. The **original content is preserved unchanged in the main database file**.
2. All changes are **appended to a separate WAL file** ("X-wal").
3. A COMMIT occurs when a special commit record is appended to the WAL — **without ever writing to the main database file**.
4. Eventually, WAL content is transferred back into the main database via an operation called **checkpointing**.

In short: "The WAL approach inverts this. The original content is preserved in the database file and the changes are appended into a separate WAL file. A COMMIT occurs when a special record indicating a commit is appended to the WAL. Thus a COMMIT can happen without ever writing to the original database." — [wal.html §2](https://www.sqlite.org/wal.html)

---

## Part 2: Reader/Writer Concurrency Behavior

### Rollback-Journal Mode: Readers and Writers Block Each Other

**Documented facts from [Isolation](https://www.sqlite.org/isolation.html) and [Atomic Commit](https://www.sqlite.org/atomiccommit.html):**

- "In rollback mode, SQLite implements isolation by locking the database file and preventing any reads by other database connections while each write transaction is underway."
- Readers can be active at the beginning of a write, while all changes are still held in the writer's private memory space. But **before any changes are made to the database file on disk, all readers must be (temporarily) expelled** to give the writer exclusive access.
- "Hence, readers are prohibited from seeing incomplete transactions by virtue of being locked out of the database while the transaction is being written to disk."
- Only after the transaction is completely written, synced to disk, and committed are readers allowed back.
- **Writers also block each other**: "SQLite implements serializable transactions by actually serializing the writes. There can only be a single writer at a time."
- The locking sequence for a write transaction is: read lock → reserved lock → (flush journal) → pending lock → exclusive lock → (write database) → delete journal → release lock. During the exclusive-lock phase, no readers can access the database.

**Summary for rollback-journal mode:**
- Readers do not block readers (shared locks coexist).
- Writers block readers once they escalate to exclusive lock.
- Readers block writers from obtaining the exclusive lock until all readers finish.
- There is no concurrent reading and writing.

### WAL Mode: Readers and Writers Run Concurrently

**Documented facts from [WAL](https://www.sqlite.org/wal.html) and [Isolation](https://www.sqlite.org/isolation.html):**

- "WAL provides more concurrency as readers do not block writers and a writer does not block readers. Reading and writing can proceed concurrently."
- "WAL mode permits simultaneous readers and writers. It can do this because changes do not overwrite the original database file, but rather go into the separate write-ahead log file. That means that readers can continue to read the old, original, unaltered content from the original database file at the same time that the writer is appending to the write-ahead log."
- **Writers merely append new content to the end of the WAL file.** Because writers do nothing that would interfere with readers, writers and readers can run at the same time.
- **However, there can still be only one writer at a time** — "since there is only one WAL file."
- WAL mode exhibits **snapshot isolation**: "When a read transaction starts, that reader continues to see an unchanging 'snapshot' of the database file as it existed at the moment in time when the read transaction started. Any write transactions that commit while the read transaction is active are still invisible to the read transaction."
- **Snapshot mechanism**: "When a read operation begins on a WAL-mode database, it first remembers the location of the last valid commit record in the WAL. Call this point the 'end mark'... for any particular reader, the end mark is unchanged for the duration of the transaction."
- **Page lookup**: "When a reader needs a page of content, it first checks the WAL to see if that page appears there, and if so it pulls in the last copy of the page that occurs in the WAL prior to the reader's end mark. If no copy of the page exists in the WAL prior to the reader's end mark, then the page is read from the original database file."
- **Checkpointing interacts with readers**: "A checkpoint can run concurrently with readers, however the checkpoint must stop when it reaches a page in the WAL that is past the end mark of any current reader. The checkpoint has to stop at that point because otherwise it might overwrite part of the database file that the reader is actively using."
- There are **three checkpoint subtypes** (PASSIVE, FULL, RESTART). The default PASSIVE checkpoint "does as much work as it can without interfering with other database connections, and which might not run to completion if there are concurrent readers or writers."

**Summary for WAL mode:**
- Readers do not block readers.
- Readers do not block writers.
- Writers do not block readers.
- Still only one writer at a time.
- Checkpointing may be blocked by long-running readers, causing WAL file growth.

### Documented Edge Cases Where SQLITE_BUSY Can Occur in WAL Mode

From [wal.html §9](https://www.sqlite.org/wal.html#sometimes_queries_return_sqlite_busy_in_wal_mode):

- If another connection has the database in **exclusive locking mode**, all queries return SQLITE_BUSY.
- When the **last connection closes**, it acquires an exclusive lock briefly for WAL cleanup; a concurrent open+query may get SQLITE_BUSY.
- If the last connection **crashed**, the first new connection runs recovery holding an exclusive lock; a third connection trying to query during recovery may get SQLITE_BUSY.

---

## Part 3: Crash Recovery Guarantees

### Rollback-Journal Mode: Hot-Journal Rollback

**Documented facts from [Atomic Commit](https://www.sqlite.org/atomiccommit.html):**

- The key guarantee: **if a crash occurs before the rollback journal is deleted, the transaction is rolled back (as if it never happened); if the crash occurs after deletion, the transaction is committed (all changes persist).** "If a power failure or system crash occurs prior to this point [journal deletion], then recovery processes to be described later make it appear as if no changes were ever made to the database file. If a power failure or system crash occurs after the rollback journal is deleted, then it appears as if all changes have been written to disk."
- This works because: "Deleting a file is not really an atomic operation, but it appears to be from the point of view of a user process. A process is always able to ask the operating system 'does this file exist?' and the process will get back a yes or no answer."
- On recovery after crash, if a rollback journal file exists, SQLite checks whether it is a **"hot journal"** — a journal that needs to be played back to restore the database. Conditions for a hot journal ([Atomic Commit §4.2](https://www.sqlite.org/atomiccommit.html#_hot_rollback_journals)):
  - The rollback journal exists.
  - It is not empty.
  - There is no reserved lock on the main database file.
  - The journal header is well-formed (not zeroed out).
  - No super-journal is referenced, or the referenced super-journal exists.
- **Recovery procedure**: obtain exclusive lock → read original page content from rollback journal → write it back into the database → truncate database to original size if it grew → flush to disk → delete the hot journal → release lock. "Since all of this recovery activity happens completely automatically and transparently, it appears to the program using SQLite as if the aborted transaction had never begun."
- **Critical prerequisite**: The rollback journal must be **flushed to nonvolatile storage before any changes are written to the database file**. "The reason for the flush operation in step 3.7 is to make absolutely sure that all of the rollback journal is safely on nonvolatile storage prior to making any changes to the database file itself."
- **Journal file variants** (DELETE, PERSIST, TRUNCATE) all provide the same recovery semantics. DELETE removes the file at commit; PERSIST zeroes the header; TRUNCATE truncates to zero length. **OFF** and **MEMORY** journal modes **disable crash recovery** — "a crash or power loss in the middle of a transaction that uses the OFF journal mode... the database file will likely go corrupt."

### WAL Mode: Roll-Forward Recovery

**Documented facts from [WAL](https://www.sqlite.org/wal.html), [WAL Format](https://www.sqlite.org/walformat.html), and [Temporary Files](https://www.sqlite.org/tempfiles.html):**

- WAL mode achieves atomic commit through a **different mechanism** than rollback journals. "SQLite still supports atomic commit when write-ahead logging is enabled, but it accomplishes atomic commit by a different mechanism from the one described in this article." — [Atomic Commit §1](https://www.sqlite.org/atomiccommit.html)
- **The WAL file is a roll-forward journal**: it records transactions that have been committed but not yet applied to the main database.
- **Recovery procedure** ([WAL Format §3](https://www.sqlite.org/walformat.html#recovery)): Recovery is run by the first thread to connect to a WAL-mode database after a crash. It works by doing a **single pass over the WAL from beginning to end**, verifying checksums on each frame. The scan stops at the end of the file or at the first invalid checksum. The mxFrame field is set to the index of the last valid commit frame. **nBackfill is initialized to zero**, meaning the recovery procedure has no way of knowing how many frames were previously checkpointed — it conservatively assumes none have been.
- During global shared-memory WAL-index recovery, **exclusive locks are held on all WAL locks except WAL_READ_LOCK(0)**. This prevents any other thread from writing or reading until recovery completes.
- **Commit frames**: frames with a non-zero "size of database" value in the frame header. Only valid commit frames survive recovery; partial/incomplete frames (those with bad checksums or without a commit marker) are discarded. The WAL file is effectively truncated at the last valid commit frame by setting mxFrame.
- **The main database file is NOT rolled back** to a prior state in WAL recovery — instead, committed transactions in the WAL are available for reading (and future checkpointing), while uncommitted/corrupt frames are discarded. This is the key asymmetry: rollback-journal recovery *undoes* the incomplete transaction; WAL recovery *keeps* committed transactions in the WAL.
- **Checkpointing after recovery**: eventually, all committed WAL content is transferred to the main database via checkpoint. Until then, readers access the latest committed state by consulting the WAL.
- **Multi-file transactions**: "Transactions that involve changes against multiple ATTACHed databases are atomic for each individual database, but are not atomic across all databases as a set" in WAL mode. Rollback-journal mode uses a super-journal to achieve cross-database atomicity.
- **WAL persistence**: The WAL file "is part of the persistent state of the database and should be kept with the database if the database is copied or moved. If a database file is separated from its WAL file, then transactions that were previously committed to the database might be lost, or the database file might become corrupted." — [wal.html §4](https://www.sqlite.org/wal.html#the_wal_file)
- **Backward compatibility**: To prevent older SQLite versions (pre-3.7.0) from attempting (and failing) to recover a WAL-mode database, the database file format version numbers (bytes 18 and 19) are increased from 1 to 2 in WAL mode. Older versions will report "file is encrypted or is not a database." — [wal.html §10](https://www.sqlite.org/wal.html#backwards_compatibility)
- **SQLITE_CHECKPOINT_TRUNCATE**: A special checkpoint mode that ensures the checkpoint runs to completion but may block readers.

### Global ACID Guarantee

From [transactional.html](https://www.sqlite.org/transactional.html):

> "All changes within a single transaction in SQLite either occur completely or not at all, even if the act of writing the change out to the disk is interrupted by a program crash, an operating system crash, or a power failure."

This applies to both rollback-journal and WAL modes — though each achieves it through a different mechanism (undo via rollback journal vs. roll-forward via WAL).

---

## Part 4: Key Differences — Summary Table

| Aspect | Rollback-Journal (DELETE) | WAL Mode |
|---|---|---|
| **Direction** | Original content → journal; changes → database (undo log) | Original content → stays in database; changes → WAL (redo log) |
| **Commit moment** | Rollback journal is deleted / truncated / zeroed | Special commit record appended to WAL |
| **Readers vs. Writers** | Mutually exclusive; readers expelled before writer writes to disk | Concurrent; readers read from DB or WAL snapshot |
| **Isolation level** | Serializable (via write serialization) | Snapshot isolation |
| **Max concurrent writers** | 1 | 1 |
| **Crash recovery mechanism** | Play back original pages from hot journal → undo incomplete transaction | Scan WAL for last valid commit frame → keep committed transactions; discard corrupt frames |
| **Recovery outcome** | Database restored to pre-transaction state (transaction fully undone) | Committed WAL transactions survive; uncommitted frames discarded; nBackfill reset to 0 |
| **What triggers recovery** | Presence of a non-empty, well-formed rollback journal with no reserved lock | First connection after a crash; always runs to rebuild WAL-index |
| **Extra files on disk** | Rollback journal ("-journal") — transient, deleted at commit | WAL file ("-wal") — quasi-persistent; WAL-index ("-shm") — shared memory |
| **Multi-database atomicity** | Yes, via super-journal | Atomic per individual database, not across ATTACHed databases |
| **Network filesystem** | Works | Does NOT work (requires shared memory via shm file, all processes must be on same host) |
| **Write performance** | Writes each page twice (once to journal, once to database) | Writes each page once (append to WAL), sequential I/O |
| **fsync() calls** | Multiple (journal flush + database flush) | Fewer (WAL sync on commit with FULL synchronous; checkpoint syncs) |
| **Persistence of mode** | Not persistent across reopens (reverts to DELETE) | Persistent; database stays in WAL mode until explicitly changed |

---

## Part 5: Distinguishing Documented Facts from Inferences

### Facts (directly stated in the official documentation):

- Rollback journal writes original content to a journal, then writes changes to the database; COMMIT = journal deletion. ([atomiccommit.html](https://www.sqlite.org/atomiccommit.html), [wal.html §2](https://www.sqlite.org/wal.html))
- WAL preserves original content in the database, appends changes to WAL; COMMIT = appending a commit record. ([wal.html §2](https://www.sqlite.org/wal.html))
- In rollback mode, readers are locked out during the write-to-disk phase. ([isolation.html](https://www.sqlite.org/isolation.html))
- In WAL mode, readers and writers run concurrently. ([wal.html §2.2](https://www.sqlite.org/wal.html), [isolation.html](https://www.sqlite.org/isolation.html))
- WAL recovery scans the WAL end-to-end, stopping at the first invalid checksum, sets mxFrame to the last valid commit frame, and sets nBackfill to 0. ([walformat.html §3](https://www.sqlite.org/walformat.html))
- Rollback-journal recovery reads original pages from the hot journal and writes them back into the database, then deletes the journal. ([atomiccommit.html §4](https://www.sqlite.org/atomiccommit.html))
- Both modes maintain ACID atomicity across program crash, OS crash, and power failure. ([transactional.html](https://www.sqlite.org/transactional.html))
- WAL is persistent across reopens; rollback-journal modes (except WAL) are not. ([wal.html §3.3](https://www.sqlite.org/wal.html))

### Inferences (reasonable conclusions drawn from documented facts, but not stated verbatim):

- Because WAL recovery sets nBackfill to 0, a crash may cause already-checkpointed pages to be re-read from the WAL (unnecessary but harmless), since the WAL still contains those committed frames.
- The fact that WAL mode cannot provide cross-database atomicity (while rollback-journal can, via super-journals) is because the WAL commit mechanism (appending to individual WAL files) has no cross-file coordination equivalent to the super-journal.
- WAL mode's requirement that all processes reside on the same host (due to shared memory for the WAL-index) is an architectural tradeoff: the WAL-index enables fast page lookup across processes but binds those processes to a single machine.
- The checkpoint starvation scenario (long-running readers preventing checkpoint completion → unbounded WAL growth) is a direct consequence of the design choice to allow checkpoints to run concurrently with readers while not overwriting pages readers depend on.
