;;; self-check.el --- Research Collector DeepSeek canary checks -*- lexical-binding: t; -*-

(require 'superchat-research-collector-completion-deepseek-canary-v0-run)

(unless
    (and
     (superchat-research-collector-deepseek-v0--same-tool-surface-p
      ["agent_reach_search" "agent_reach_read"
       "workspace_read" "workspace_publish" "workspace_info"
       "team_task" "team_message"])
     (superchat-research-collector-deepseek-v0--same-tool-surface-p
      ["team_message" "workspace_publish" "agent_reach_read"
       "workspace_info" "team_task" "agent_reach_search"
       "workspace_read"])
     (not
      (superchat-research-collector-deepseek-v0--same-tool-surface-p
       ["agent_reach_search" "agent_reach_read" "workspace_read"
        "workspace_publish" "workspace_info" "team_task"]))
     (equal "collector"
            (superchat-research-collector-deepseek-v0--normalize-name
             'collector))
     (= 2
        (length
         (superchat-research-collector-deepseek-v0--source-urls
          "A https://sqlite.org/wal.html B https://sqlite.org/lockingv3.html")))
     (equal
      "official_read_contract_not_completed"
      (superchat-research-collector-deepseek-v0--interpret
       '(:agent_reach_search_completed 1
         :agent_reach_read_completed 1
         :workspace_publish_requested 0
         :workspace_publish_completed 0
         :artifact_classification "artifact_absent"
         :official_source_url_count 0))))
  (error "Research Collector DeepSeek completion canary self-check failed"))

(provide 'superchat-research-collector-completion-deepseek-canary-v0-self-check)

;;; self-check.el ends here
