# Rollback-Journal vs. WAL Mode in SQLite: Reader/Writer Behavior and Crash-Recovery Guarantees

## Source Documents

All information below is drawn from these official SQLite documentation pages:

1. **Write-Ahead Logging** — https://www.sqlite.org/wal.html (last updated 2026-04-13)
2. **Isolation In SQLite** — https://www.sqlite.org/isolation.html (last updated 2022-04-18)
3. **Atomic Commit In SQLite** — https://www.sqlite.org/atomiccommit.html (applies only to rollback mode)
4. **WAL-mode File Format** — https://www.sqlite.org/walformat.html (last updated 2025-05-10)

---

## 1. Fundamental Architectural Difference

### Rollback-Journal Mode (default: DELETE)

- **Mechanism:** Before modifying the database file, SQLite writes a copy of the *original, unchanged* page content into a separate rollback-journal file. Changes are then written *directly into the database file*. The transaction **commits** at the moment the rollback journal is **deleted** (or truncated, or its header zeroed). [wal.html §2, atomiccommit.html §3.11]
- **Data flow:** original pages → journal file; new content → database file.

### WAL Mode

- **Mechanism:** The original content is *preserved* in the database file. Changes are *appended* into a separate Write-Ahead Log ("-wal") file. A **COMMIT** occurs when a special commit record is appended to the WAL. Changes are later transferred from the WAL back into the database file via an operation called **checkpointing**. [wal.html §2]
- **Data flow:** original pages stay in database file; new content → WAL file; later, WAL → database file via checkpoint.

---

## 2. Reader/Writer Concurrency Behavior

### Rollback-Journal Mode

**Writers block readers; readers block writers.** [isolation.html]

- SQLite implements isolation by locking the database file. During a write transaction, after obtaining an exclusive lock, **all other readers are expelled** before any changes are written to disk. Readers are locked out until the write transaction is fully committed and the exclusive lock is released. [isolation.html]
- Readers can coexist with each other (shared locks), but only one writer can hold the reserved/exclusive lock at a time. [atomiccommit.html §3.2–§3.8]
- This means reads and writes are **serialized** — they cannot proceed concurrently.
- **Fact, not inference:** "In rollback mode, SQLite implements isolation by locking the database file and preventing any reads by other database connections while each write transaction is underway." [isolation.html]

### WAL Mode

**Writers do not block readers; readers do not block writers.** [wal.html §1, §2.2]

- Because changes are written to the separate WAL file rather than the main database file, readers can continue to read the old, unaltered content from the database file while the writer appends to the WAL. [wal.html §2.2, isolation.html]
- **Only one writer at a time** — there is a single WAL file and writers serialize on `WAL_WRITE_LOCK`. [wal.html §2.2, walformat.html §2.3.1]
- **Snapshot Isolation:** Each reader sees an unchanging "snapshot" of the database as it existed at the moment the read transaction started. Committed changes from writers that commit *after* the read transaction began are invisible to that reader. [isolation.html, wal.html §2.2]
- **End-mark mechanism:** When a reader starts, it records the location of the last valid commit record in the WAL (the "end mark"). This end mark is fixed for the duration of the transaction. When a reader needs a page, it first checks the WAL for that page (up to its end mark); if not found there, it reads from the database file. [wal.html §2.2]
- **Checkpoint vs. readers:** A checkpoint can run concurrently with readers but must stop before overwriting any page that a current reader still depends on. Long-running readers can therefore prevent checkpoints from completing. [wal.html §2.2]
- **WAL reset:** When all WAL content has been checkpointed into the database and no readers hold `WAL_READ_LOCK(N)` for N>0, the next writer rewinds the WAL to the beginning. This prevents unlimited WAL growth. [wal.html §2.2]
- **Caveat (documented):** There are obscure cases where WAL-mode queries can return `SQLITE_BUSY` — e.g., during recovery or during last-connection cleanup. [wal.html §9]
- **Escalation failure:** If a reader tries to upgrade to a writer after another connection has committed changes, it will receive `SQLITE_BUSY_SNAPSHOT` because its snapshot is no longer the latest version. [isolation.html]
- **Fact, not inference:** "WAL provides more concurrency as readers do not block writers and a writer does not block readers. Reading and writing can proceed concurrently." [wal.html §1]

---

## 3. Crash-Recovery Guarantees

### Rollback-Journal Mode

**Recovery mechanism: hot-journal rollback.**

- If a crash or power loss occurs mid-transaction, the rollback-journal file remains on disk. On the next database open, SQLite detects this "hot journal" and uses it to **restore** the database to its state before the incomplete transaction began. [atomiccommit.html §4]
- **Key invariant:** The rollback journal is flushed to nonvolatile storage *before* any changes are written to the database file. This ensures the journal is always intact for recovery. [atomiccommit.html §3.7, §4.1]
- The commit atomicity depends on file existence: if the journal file exists after a crash, the transaction is rolled back; if it does not exist (was deleted), the transaction committed. File deletion is treated as atomic from a user-process perspective. [atomiccommit.html §3.11]
- **Two-phase journal flush:** First, page content is flushed. Then the journal header (containing the page count) is modified and flushed separately. This prevents a partially-written journal from being mistaken for a complete one. [atomiccommit.html §3.7, §6.2]
- **Hot journal criteria:** A rollback journal is "hot" if it (1) exists, (2) is non-empty, (3) no reserved lock exists on the database, (4) the header is well-formed/not zeroed, and (5) no super-journal is referenced (or if referenced, the super-journal exists). [atomiccommit.html §4.2]
- Recovery obtains an exclusive lock, replays original pages from the journal into the database, truncates the database to its original size if needed, then deletes the journal. [atomiccommit.html §4.3–§4.5]
- **Guarantee:** Either all changes from the transaction appear (journal absent) or none appear (journal replayed). This is the atomic commit property. [atomiccommit.html §1]
- **Fact, not inference:** "SQLite gives the appearance of having made no changes to the database file or having made the complete set of changes to the database file depending on whether or not the rollback journal file exists." [atomiccommit.html §3.11]

### WAL Mode

**Recovery mechanism: WAL reconstruction via checksum scan.**

- Recovery in WAL mode rebuilds the WAL-index (the shared-memory structure that helps locate frames in the WAL) so it is synchronized with the WAL file. [walformat.html §3]
- **Recovery is triggered** when the first connection opens a WAL-mode database after a crash. During recovery, an exclusive lock is held, so any third connection attempting to query during recovery will get `SQLITE_BUSY`. [wal.html §9]
- **Recovery procedure:** SQLite performs a single pass over the WAL file from beginning to end, verifying checksums on each frame. The scan stops at the end of the file or at the first invalid checksum. `mxFrame` is set to the index of the last valid commit frame. [walformat.html §3]
- Since recovery cannot know how many WAL frames were previously checkpointed into the database, `nBackfill` is initialized to zero. [walformat.html §3]
- **During recovery**, exclusive locks are held on `WAL_WRITE_LOCK`, `WAL_CKPT_LOCK`, `WAL_RECOVER_LOCK`, and `WAL_READ_LOCK(1)` through `WAL_READ_LOCK(4)`. This prevents any other thread from writing to the database or reading from the WAL until recovery completes. [walformat.html §3]
- **The shm file is not required for recovery** — it contains no database content and is not needed to recover the database after a crash. [walformat.html §1.3]
- **Clean shutdown:** If the last client calls `sqlite3_close()` cleanly, a checkpoint transfers all WAL content to the database and deletes both the WAL and SHM files. If the last client crashes, the WAL and SHM files may persist on disk until the next connection opens the database and runs recovery. [walformat.html §1.4]
- **Critical safety rule:** A database file separated from its WAL file may lose committed transactions or become corrupted. The only safe way to remove a WAL file is to open the database and then immediately close it cleanly. [wal.html §4]
- **Guarantee:** Only frames up to the last valid commit frame (with valid checksums) are considered committed. Any partially-written commit records at the tail of the WAL (with invalid checksums) are discarded during recovery.
- **Fact, not inference:** "Recovery works by doing a single pass over the WAL, from beginning to end. The checksums are verified on each frame of the WAL as it is read. The scan stops at the end of the file or at the first invalid checksum." [walformat.html §3]

---

## 4. Side-by-Side Comparison

| Aspect | Rollback-Journal | WAL |
|---|---|---|
| **Readers/writers** | Mutually exclusive (serialized) | Concurrent (snapshot isolation) |
| **Writer count** | One at a time | One at a time |
| **Commit mechanism** | Delete/truncate journal file | Append commit record to WAL |
| **Recovery trigger** | Hot journal present on next open | First connection rebuilds WAL-index |
| **Recovery method** | Replay original pages from journal into database | Scan WAL, verify checksums, set mxFrame |
| **Recovery concurrency** | Exclusive lock blocks all access during recovery | Exclusive lock blocks other connections during recovery |
| **Atomicity guarantee** | Journal exists → rollback; journal absent → committed | Valid checksum chain → committed; invalid tail → discarded |
| **Extra files** | `-journal` (transient) | `-wal` + `-shm` (persist across connections) |
| **fsync() requirement** | Journal flush + database flush (2 fsyncs minimum) | WAL sync on commit (if synchronous=FULL); checkpoint requires fsync |
| **Write I/O** | Content written twice (journal + database) | Content written once (WAL), then checkpoint copies to database |
| **Long-running readers** | Block writers from committing | Prevent checkpoint from completing (WAL grows) |
| **Network filesystem** | Works | Does NOT work (requires shared memory) |
| **Default mode** | Yes (journal_mode=DELETE) | No (opt-in via PRAGMA journal_mode=WAL) |

---

## 5. Summary of Guarantees

**Both modes guarantee atomic commit:** after a crash, the database is either in the state before a transaction began or after it fully completed — never in between.

**Rollback-journal** achieves this by writing old page content to a journal *before* modifying the database, and using the journal's existence/absence as the commit indicator. Recovery replays the journal to undo partial changes.

**WAL** achieves this by writing new content to a separate log *before* it reaches the database, using a checksum-verified commit record as the commit indicator. Recovery scans the WAL to determine the last valid commit point and ignores any incomplete tail.

The key trade-off is concurrency versus complexity: WAL enables concurrent reads and writes but introduces checkpointing, shared memory requirements, and potential WAL file growth management.

---

*Artifact compiled from official SQLite documentation at sqlite.org. All claims above are directly sourced from the referenced pages. Distinctions between documented facts and inferences are noted inline.*