# DeepSeek Collector Completion Canary v0 — Evidence Check

## Verdict

`pass` for the preregistered single-Run Collector completion gate.

This proves only that this `deepseek-v4-pro` Run, with
`superchat-llm-reasoning = none`, closed the frozen application contract. It
does not prove repeatability, comparative model effectiveness, research
quality, Pattern discovery, or Learning.

## Independent checks

- Prompt snapshot: one snapshot; target model `deepseek-v4-pro`; reasoning
  mode `none`; exact seven-tool surface present.
- Execution: trace `valid`; durable terminal `proved/completed`; zero invalid
  tool identities, invalid scope identities, unexpected tools, or failed
  tools.
- Research activity: one search and four page reads requested and completed.
- Publication: exactly one `workspace_publish` request and completion.
- Artifact: exactly one readable `collector` Artifact; delivery decision
  `deliver`; producer Run matches the completed Collector Run.
- Artifact bytes: exported SHA-256
  `89fa437fe7b4d15db89eb592286b0e00f919e22d8a1b72bdfad211ee24ca4108`,
  equal to the recorded revision and evidence-bundle content hash.
- References: four distinct official `sqlite.org` URLs retained.
- Tape snapshot: SQLite `PRAGMA integrity_check` returned `ok`; the Run has
  one `run.started`, one `response.completed`, one `run.completed`, one
  `workspace.artifact.added`, and matching requested/started/completed events
  for all nine tool calls.
- Experiment controls: zero continuation, retry, recovery, downstream stage,
  or historical evidence import.

## Remaining evidence limits

- Outcome evaluation is deliberately `not-evaluated`; Artifact existence and
  source retention are not a quality judgment.
- A single Run cannot establish stability or an effect relative to the prior
  Qwen calibration.
- The prompt snapshot's `provider` field is populated from `llm-name` and
  therefore contains `deepseek-v4-pro`, not the adapter class name. The
  content-addressed runner reconstructs the actual `llm-deepseek` constructor,
  but a future multi-provider cohort may need an explicit adapter-class field.
- The executed environment contains `llm.el` 0.31.0 while the current package
  header declares a 0.31.1 minimum. This Canary verifies the tested path, not
  package-version conformance.

