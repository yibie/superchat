# DeepSeek Collector Completion Replication v1 — Independent Evidence Check

## Verdict

The preregistered Replication Gate is **blocked**: `3/4` samples passed, while
the Manifest requires `4/4`. Repeatability is therefore `not-demonstrated`.

The blocked sample is transport-censored, not a clean application-compliance
failure. It completed the required research activity and `workspace_publish`
before an explicit API timeout caused the producer Run to fail.

## Samples

| Sample | Research | Publish | Terminal | Artifact | Gate |
| --- | --- | --- | --- | --- | --- |
| `deepseek-rep-v1-01` | 2 searches / 4 reads | 1/1 | failed: `Operation timeout` | present, rejected | blocked |
| `deepseek-rep-v1-02` | 2 searches / 5 reads | 1/1 | completed | deliverable | pass |
| `deepseek-rep-v1-03` | 2 searches / 5 reads | 1/1 | completed | deliverable | pass |
| `deepseek-rep-v1-04` | 2 searches / 6 reads | 1/1 | completed | deliverable | pass |

All four Prior Gates passed: model `deepseek-v4-pro`, reasoning `none`, the
same system-prompt hash, the same question hash, and the same exact seven-tool
surface were observed. All tool identities and scopes were valid, no
unexpected tool was requested, and no `tool.failed` event occurred.

## Failure provenance

`deepseek-rep-v1-01` completed two searches, four reads, and one publication.
The following model request produced `[API error: Operation timeout.]`, giving
the producer Run a proved `failed` terminal. Artifact Delivery therefore
correctly rejected the otherwise intact file. Its SHA-256
`950679f8520d63a8460aca37a932112b9221d0ababaffd588a9b3ac33e6ed730`
matches the recorded Artifact revision.

The current evidence has no provider request identifier or network trace. It
cannot distinguish a DeepSeek service timeout from a local proxy, network, or
`plz`/curl timeout.

## v0 comparison

| Replication | Passed | Explicit transport failures | Gate |
| --- | ---: | ---: | --- |
| v0 | 2/4 | 2 | blocked |
| v1 | 3/4 | 1 | blocked |

Across the two independent frozen replications, all three blocked samples have
explicit transport errors. The repeated `Operation timeout` in both v0 and v1
shows that transport instability remains observable. The small, non-random
sample does not estimate a failure rate, model quality, or broad stability.

## Boundary

- v1 used four new execution identities and imported no v0 Run or Artifact.
- Zero retries, continuations, recoveries, substitutions, or downstream stages
  occurred.
- The failed fact is preserved and was not repaired or reclassified.
- Outcome quality, effectiveness, Pattern, and Learning remain unevaluated or
  prohibited.
- The SQLite Tape snapshot passed `PRAGMA integrity_check`.
