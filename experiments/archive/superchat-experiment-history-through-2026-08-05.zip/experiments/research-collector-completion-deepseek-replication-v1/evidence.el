;;; evidence.el --- Research Collector Completion Replication evidence -*- lexical-binding: t; -*-

;;; Commentary:

;; Read-only consumer of the four frozen Runtime histories.  It does not change
;; Tape, Closure, Workspace, or any Run fact.

;;; Code:

(require 'superchat-research-collector-completion-deepseek-replication-v1-run)

(defconst superchat-research-collector-deepseek-replication-v1--report-json-path
  (expand-file-name "replication-report.json"
                    superchat-research-collector-deepseek-replication-v1--directory))

(defconst superchat-research-collector-deepseek-replication-v1--report-md-path
  (expand-file-name "replication-report.md"
                    superchat-research-collector-deepseek-replication-v1--directory))

(defconst superchat-research-collector-deepseek-replication-v1--gap-path
  (expand-file-name "evidence-gap-report.md"
                    superchat-research-collector-deepseek-replication-v1--directory))

(defun superchat-research-collector-deepseek-replication-v1--normalize-role (role)
  "Return ROLE as a stable string."
  (if (symbolp role) (symbol-name role) role))

(defun superchat-research-collector-deepseek-replication-v1--same-tool-surface-p (tools)
  "Return non-nil when TOOLS exactly names the frozen surface."
  (and (= (length tools)
          (length superchat-research-collector-deepseek-replication-v1--allowed-tools))
       (null
        (cl-set-exclusive-or
         (append tools nil)
         superchat-research-collector-deepseek-replication-v1--allowed-tools
         :test #'equal))))

(defun superchat-research-collector-deepseek-replication-v1--event-tool-name (event)
  "Return normalized tool name from EVENT."
  (let ((payload (plist-get event :payload)))
    (or (plist-get payload :tool-name)
        (plist-get payload :tool_name))))

(defun superchat-research-collector-deepseek-replication-v1--artifact-view (artifact)
  "Return delivery and content evidence for ARTIFACT."
  (let* ((view (superchat-research-workflow--artifact-view artifact))
         (content
          (and (eq 'deliver (plist-get view :delivery-decision))
               (plist-get view :available)
               (condition-case nil
                   (superchat-workspace-read
                    (plist-get artifact :artifact-id)
                    (plist-get artifact :workspace-id)
                    (plist-get artifact :revision))
                 (error nil)))))
    (append
     view
     (list :run-id (plist-get artifact :run-id)
           :content-sha256
           (and content
                (superchat-research-collector-deepseek-replication-v1--sha256-string
                 content))
           :content content))))

(defun superchat-research-collector-deepseek-replication-v1--source-urls (content)
  "Return distinct HTTP(S) URLs found in CONTENT."
  (let ((start 0) urls)
    (while (and content
                (string-match
                 "https?://[^][(){}<> \t\n\"']+" content start))
      (push (match-string 0 content) urls)
      (setq start (match-end 0)))
    (delete-dups (nreverse urls))))

(defun superchat-research-collector-deepseek-replication-v1--tool-count
    (events type name)
  "Count EVENTS with TYPE and tool NAME."
  (cl-count-if
   (lambda (event)
     (and (equal type (plist-get event :type))
          (equal name
                 (superchat-research-collector-deepseek-replication-v1--event-tool-name
                  event))))
   events))

(defun superchat-research-collector-deepseek-replication-v1--interpret
    (prior-pass execution-pass search-completed read-completed
                publish-requested publish-completed tool-failed
                artifact-classification official-source-url-count)
  "Return the frozen interpretation of one sample's evidence."
  (cond
   ((not prior-pass) "prior_evidence_incomplete")
   ((not execution-pass) "execution_evidence_invalid")
   ((zerop search-completed) "search_not_completed")
   ((< read-completed 2) "material_read_contract_not_completed")
   ((zerop publish-requested) "model_did_not_select_workspace_publish")
   ((or (not (= 1 publish-requested))
        (not (= 1 publish-completed))
        (not (zerop tool-failed)))
    "workspace_publish_denied_or_failed")
   ((not (equal "artifact_closure_pass" artifact-classification))
    "artifact_present_provenance_invalid")
   ((< official-source-url-count 2) "source_references_not_retained")
   (t "real_research_collector_contract_closed")))

(defun superchat-research-collector-deepseek-replication-v1--sample
    (assignment launch snapshot)
  "Return closed evidence for one ASSIGNMENT, LAUNCH, and SNAPSHOT."
  (let* ((assignment-id (plist-get assignment :assignment_id))
         (actor-id (plist-get launch :actor_id))
         (run-id (plist-get launch :run_id))
         (workspace-id (plist-get launch :workspace_id))
         (question (plist-get assignment :question))
         (events (superchat-tape-replay-events actor-id))
         (run-events
          (cl-remove-if-not
           (lambda (event) (equal run-id (plist-get event :run-id)))
           events))
         (tool-events
          (cl-remove-if-not
           (lambda (event)
             (string-prefix-p "tool." (or (plist-get event :type) "")))
           run-events))
         (publish-requested
          (cl-count-if
           (lambda (event)
             (and (equal "tool.requested" (plist-get event :type))
                  (equal "workspace_publish"
                         (superchat-research-collector-deepseek-replication-v1--event-tool-name
                          event))))
           tool-events))
         (publish-completed
          (cl-count-if
           (lambda (event)
             (and (equal "tool.completed" (plist-get event :type))
                  (equal "workspace_publish"
                         (superchat-research-collector-deepseek-replication-v1--event-tool-name
                          event))))
           tool-events))
         (search-requested
          (superchat-research-collector-deepseek-replication-v1--tool-count
           tool-events "tool.requested" "agent_reach_search"))
         (search-completed
          (superchat-research-collector-deepseek-replication-v1--tool-count
           tool-events "tool.completed" "agent_reach_search"))
         (read-requested
          (superchat-research-collector-deepseek-replication-v1--tool-count
           tool-events "tool.requested" "agent_reach_read"))
         (read-completed
          (superchat-research-collector-deepseek-replication-v1--tool-count
           tool-events "tool.completed" "agent_reach_read"))
         (tool-failed
          (cl-count "tool.failed" tool-events
                    :key (lambda (event) (plist-get event :type))
                    :test #'equal))
         (invalid-tool-identity
          (cl-count-if-not
           (lambda (event)
             (and (equal actor-id (plist-get event :actor-id))
                  (stringp (plist-get event :turn-id))
                  (not (string-empty-p (plist-get event :turn-id)))))
           tool-events))
         (invalid-scope-identity
          (cl-count-if-not
           (lambda (event)
             (and (equal actor-id (plist-get event :actor-id))
                  (equal workspace-id (plist-get event :workspace-id))
                  (equal workspace-id (plist-get event :correlation-id))
                  (null (plist-get event :parent-run-id))))
           run-events))
         (unexpected-tools
          (cl-count-if
           (lambda (event)
             (and (equal "tool.requested" (plist-get event :type))
                  (not (member
                        (superchat-research-collector-deepseek-replication-v1--event-tool-name
                         event)
                        superchat-research-collector-deepseek-replication-v1--allowed-tools))))
           tool-events))
         (well
          (superchat-closure-judge
           (list :kind 'trace-well-formed :run-id run-id) events))
         (terminal
          (superchat-closure-judge
           (list :kind 'durable-run-terminal :run-id run-id) events))
         (artifacts
          (mapcar
           #'superchat-research-collector-deepseek-replication-v1--artifact-view
           (cl-remove-if-not
            (lambda (artifact) (equal run-id (plist-get artifact :run-id)))
            (superchat-workspace-artifacts workspace-id t))))
         (deliverable
          (cl-remove-if-not
           (lambda (artifact)
             (and (eq 'deliver (plist-get artifact :delivery-decision))
                  (plist-get artifact :available)
                  (equal
                   "collector"
                   (superchat-research-collector-deepseek-replication-v1--normalize-role
                    (plist-get artifact :role)))))
           artifacts))
         (artifact-classification
          (cond ((null artifacts) "artifact_absent")
                ((and (= 1 (length artifacts))
                      (= 1 (length deliverable)))
                 "artifact_closure_pass")
                (t "artifact_present_provenance_invalid")))
         (source-urls
          (and (= 1 (length deliverable))
               (cl-remove-if-not
                (lambda (url)
                  (string-match-p
                   "\\`https?://\\(?:www\\.\\)?sqlite\\.org/" url))
                (superchat-research-collector-deepseek-replication-v1--source-urls
                 (plist-get (car deliverable) :content)))))
         (official-source-url-count (length source-urls))
         (prior-pass
          (and snapshot
               (equal assignment-id (plist-get snapshot :assignment_id))
               (equal actor-id (plist-get snapshot :actor_id))
               (equal "deepseek-v4-pro" (plist-get snapshot :target_model))
               (string-match-p "deepseek"
                               (or (plist-get snapshot :provider) ""))
               (equal "none" (plist-get snapshot :reasoning_mode))
               (string-match-p (regexp-quote assignment-id)
                               (or (plist-get snapshot :model_prompt) ""))
               (string-match-p (regexp-quote question)
                               (or (plist-get snapshot :model_prompt) ""))
               (superchat-research-collector-deepseek-replication-v1--same-tool-surface-p
                (plist-get snapshot :prepared_tool_names))))
         (execution-pass
          (and (equal 'valid (plist-get well :verdict))
               (equal 'proved (plist-get terminal :verdict))
               (equal 'completed
                      (plist-get (plist-get terminal :judgment)
                                 :terminal-kind))
               (zerop invalid-tool-identity)
               (zerop invalid-scope-identity)
               (zerop unexpected-tools)
               (zerop tool-failed)))
         (research-pass
          (and (>= search-completed 1)
               (>= read-completed 2)))
         (publish-pass
          (and (= 1 publish-requested)
               (= 1 publish-completed)))
         (artifact-pass
          (and (equal "artifact_closure_pass" artifact-classification)
               (= 1 (length artifacts))
               (= 1 (length deliverable))))
         (references-pass (>= official-source-url-count 2))
         (pass (and prior-pass execution-pass research-pass publish-pass
                    artifact-pass references-pass))
         (interpretation
          (superchat-research-collector-deepseek-replication-v1--interpret
           prior-pass execution-pass search-completed read-completed
           publish-requested publish-completed tool-failed
           artifact-classification official-source-url-count)))
    (when (= 1 (length deliverable))
      (let ((directory
             (expand-file-name
              "artifacts/"
              superchat-research-collector-deepseek-replication-v1--directory)))
        (make-directory directory t)
        (with-temp-file (expand-file-name
                         (concat assignment-id ".md") directory)
          (insert (plist-get (car deliverable) :content)))))
    (list
     :assignment_id assignment-id
     :source_task_id (plist-get assignment :source_task_id)
     :family (plist-get assignment :family)
     :actor_id actor-id
     :run_id run-id
     :turn_id (plist-get launch :turn_id)
     :workspace_id workspace-id
     :correlation_id (plist-get launch :correlation_id)
     :parent_run_id nil
     :gates
     (vconcat
      (list (list :name "prior" :verdict (if prior-pass "pass" "blocked"))
            (list :name "execution" :verdict
                  (if execution-pass "pass" "blocked"))
            (list :name "research-activity" :verdict
                  (if research-pass "pass" "blocked"))
            (list :name "publish" :verdict
                  (if publish-pass "pass" "blocked"))
            (list :name "artifact" :verdict
                  (if artifact-pass "pass" "blocked"))
            (list :name "source-references" :verdict
                  (if references-pass "pass" "blocked"))))
     :sample_gate (if pass "pass" "blocked")
     :interpretation interpretation
     :trace_verdict (symbol-name (plist-get well :verdict))
     :terminal_verdict (symbol-name (plist-get terminal :verdict))
     :terminal_kind
     (symbol-name
      (plist-get (plist-get terminal :judgment) :terminal-kind))
     :run_event_count (length run-events)
     :tool_event_count (length tool-events)
     :tool_events_invalid_identity invalid-tool-identity
     :scope_events_invalid_identity invalid-scope-identity
     :unexpected_tool_request_count unexpected-tools
     :agent_reach_search_requested search-requested
     :agent_reach_search_completed search-completed
     :agent_reach_read_requested read-requested
     :agent_reach_read_completed read-completed
     :workspace_publish_requested publish-requested
     :workspace_publish_completed publish-completed
     :tool_failed_count tool-failed
     :artifact_classification artifact-classification
     :artifact_count (length artifacts)
     :deliverable_count (length deliverable)
     :question_sha256
     (superchat-research-collector-deepseek-replication-v1--sha256-string question)
     :official_source_url_count official-source-url-count
     :artifacts
     (vconcat
      (mapcar
       (lambda (artifact)
         (list :artifact_id (plist-get artifact :artifact-id)
               :run_id (plist-get artifact :run-id)
               :workspace_id (plist-get artifact :workspace-id)
               :revision (plist-get artifact :revision)
               :uri (plist-get artifact :uri)
               :role
               (superchat-research-collector-deepseek-replication-v1--normalize-role
                (plist-get artifact :role))
               :delivery_decision
               (symbol-name (plist-get artifact :delivery-decision))
               :available
               (if (plist-get artifact :available) t json-false)
               :content_sha256 (plist-get artifact :content-sha256)
               :content_length (length (or (plist-get artifact :content) ""))
               :source_url_count
               (length
                (superchat-research-collector-deepseek-replication-v1--source-urls
                 (plist-get artifact :content)))))
       artifacts)))))

(defun superchat-research-collector-deepseek-replication-v1-generate-evidence ()
  "Generate the frozen 4/4 Replication report from durable facts."
  (interactive)
  (unless (equal "settled"
                 (plist-get superchat-research-collector-deepseek-replication-v1--state
                            :status))
    (error "Research Collector Completion Replication has not settled"))
  (let* ((assignments
          (superchat-research-collector-deepseek-replication-v1--assignments))
         (samples
          (mapcar
           (lambda (assignment)
             (let* ((assignment-id (plist-get assignment :assignment_id))
                    (launch
                     (cl-find assignment-id
                              superchat-research-collector-deepseek-replication-v1--launches
                              :key (lambda (item)
                                     (plist-get item :assignment_id))
                              :test #'equal))
                    (snapshot
                     (cl-find assignment-id
                              superchat-research-collector-deepseek-replication-v1--snapshots
                              :key (lambda (item)
                                     (plist-get item :assignment_id))
                              :test #'equal)))
               (superchat-research-collector-deepseek-replication-v1--sample
                assignment launch snapshot)))
           assignments))
         (pass-count
          (cl-count "pass" samples
                    :key (lambda (sample) (plist-get sample :sample_gate))
                    :test #'equal))
         (pass (and (= 4 (length samples)) (= 4 pass-count)))
         (report
          (list
           :experiment_id "research-collector-completion-deepseek-replication-v1"
           :generated_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
           :manifest_sha256
           (superchat-research-collector-deepseek-replication-v1--sha256-file
            superchat-research-collector-deepseek-replication-v1--manifest-path)
           :required_sample_count 4
           :observed_sample_count (length samples)
           :sample_pass_count pass-count
           :all_samples_required t
           :replication_gate (if pass "pass" "blocked")
           :repeatability_status
           (if pass "observed-4-of-4" "not-demonstrated")
           :samples (vconcat samples)
           :continuation_count 0
           :retry_count 0
           :recovery_count 0
           :downstream_stages_started json-false
           :outcome_evaluation "not-evaluated"
           :effectiveness_claim "not_evaluated"
           :learning_claim "prohibited")))
    (superchat-research-collector-deepseek-replication-v1--write-json
     superchat-research-collector-deepseek-replication-v1--report-json-path report)
    (with-temp-file superchat-research-collector-deepseek-replication-v1--report-md-path
      (insert "# DeepSeek Collector Completion Replication v1\n\n")
      (insert (format "Replication Gate: **%s**\n\n"
                      (if pass "pass" "blocked")))
      (insert (format "Required/observed/passed: `4/%d/%d`.\n\n"
                      (length samples) pass-count))
      (dolist (sample samples)
        (insert
         (format "- `%s`: %s — `%s`\n"
                 (plist-get sample :assignment_id)
                 (plist-get sample :sample_gate)
                 (plist-get sample :interpretation))))
      (insert
       "\nNo continuation, retry, recovery, Outcome, effectiveness, Pattern, or Learning claim is authorized.\n"))
    (with-temp-file superchat-research-collector-deepseek-replication-v1--gap-path
      (insert "# DeepSeek Collector Completion Replication v1 — Evidence Gaps\n\n")
      (if pass
          (insert
           "No required Prior, Execution, Research Activity, Publish, Artifact, or Source Reference Gate is missing in the four frozen samples.\n\n")
        (dolist (sample samples)
          (unless (equal "pass" (plist-get sample :sample_gate))
            (insert
             (format "- `%s`: `%s`\n"
                     (plist-get sample :assignment_id)
                     (plist-get sample :interpretation))))))
      (insert
       "This report does not evaluate research quality, broad stability, effectiveness, Pattern, or Learning.\n"))
    report))

(provide 'superchat-research-collector-completion-deepseek-replication-v1-evidence)

;;; evidence.el ends here
