# Rollback Journal vs. WAL Mode in SQLite: Reader/Writer Behavior and Crash Recovery Guarantees

## Source Documents

All information in this artifact is drawn from official SQLite documentation pages:

1. **Write-Ahead Logging** — https://www.sqlite.org/wal.html (updated 2026-04-13)
2. **Isolation In SQLite** — https://www.sqlite.org/isolation.html (updated 2022-04-18)
3. **Atomic Commit In SQLite** — https://www.sqlite.org/atomiccommit.html (applies to rollback mode)
4. **File Locking And Concurrency In SQLite Version 3** — https://www.sqlite.org/lockingv3.html (applies to rollback mode; updated 2025-05-31)
5. **WAL-mode File Format** — https://www.sqlite.org/walformat.html (updated 2025-05-10)

Each section below distinguishes **documented facts** from **inferences** the documentation explicitly draws, and from any remaining points that are only implied.

---

## 1. Fundamental Architectural Difference

### Rollback Journal (default, pre-3.7.0)

**Documented fact:** The rollback journal works by writing a copy of the original unchanged database content into a separate rollback journal file, then writing changes directly into the database file. In the event of a crash or ROLLBACK, the original content contained in the rollback journal is played back into the database file to revert it to its original state. The COMMIT occurs when the rollback journal is deleted.

**Documented fact:** Two primitive operations exist: reading and writing.

**Documented fact:** The rollback journal is named by appending "-journal" to the database filename. It is created in the same directory as the database.

**Documented fact:** Rollback mode corresponds to the DELETE, PERSIST, or TRUNCATE options of the journal_mode pragma. DELETE (where the rollback journal is deleted from disk at the conclusion of each transaction) is the current default behavior.

### WAL Mode (since version 3.7.0, 2010-07-21)

**Documented fact:** The WAL approach inverts the rollback model. Original content is preserved in the database file and changes are appended into a separate WAL file. A COMMIT occurs when a special record indicating a commit is appended to the WAL. Thus a COMMIT can happen without ever writing to the original database.

**Documented fact:** Three primitive operations exist: reading, writing, and checkpointing.

**Documented fact:** The WAL file is named by appending "-wal" to the database filename. A separate "-shm" (shared memory / wal-index) file is also maintained. The WAL file is a roll-forward journal that records transactions committed but not yet applied to the main database.

**Documented fact:** In WAL mode, the database file format version numbers (bytes 18 and 19 in the database header) are increased from 1 to 2. This prevents older versions of SQLite (<3.7.0) from attempting recovery on a WAL-mode database.

**Inference drawn by SQLite docs:** Another way to think about the difference is that rollback journal has two primitive operations (reading, writing) whereas WAL has three (reading, writing, checkpointing).

---

## 2. Reader/Writer Concurrency Behavior

### Rollback Journal Mode

**Documented fact:** In rollback mode, SQLite implements isolation by locking the database file and preventing any reads by other database connections while each write transaction is underway. Readers can be active at the beginning of a write, before any content is flushed to disk and while all changes are still held in the writer's private memory space. But before any changes are made to the database file on disk, all readers must be (temporarily) expelled in order to give the writer exclusive access.

**Documented fact:** The locking states for rollback mode are: UNLOCKED → SHARED → RESERVED → PENDING → EXCLUSIVE. Multiple readers can hold SHARED locks concurrently. A single RESERVED lock can coexist with multiple SHARED locks, allowing one writer to prepare while readers continue. PENDING blocks new SHARED locks but allows existing readers to finish. EXCLUSIVE is required for actual writes to the database file.

**Key documented fact — readers blocked during write:** Only after the transaction is completely written and synced to disk and committed are the readers allowed back into the database. Hence readers never get a chance to see partially written changes.

**Documented fact:** Writer starvation (where a constant stream of readers prevents any writer from ever obtaining an EXCLUSIVE lock) is addressed by the PENDING lock mechanism — it allows existing readers to continue but prevents new readers from connecting.

**Documented fact:** The EXCLUSIVE lock that the writer obtains to write to the database must be held until all changes are committed. That means no other processes can access the database from the time the memory cache first spills to disk until the transaction commits.

**Inference drawn by SQLite docs:** Readers are prohibited from seeing incomplete transactions by virtue of being locked out of the database while the transaction is being written to disk.

### WAL Mode

**Documented fact (central claim):** WAL mode permits simultaneous readers and writers. It can do this because changes do not overwrite the original database file, but rather go into the separate write-ahead log file. Readers can continue to read the old, original, unaltered content from the original database file at the same time that the writer is appending to the write-ahead log.

**Documented fact:** In WAL mode, SQLite exhibits "snapshot isolation." When a read transaction starts, that reader continues to see an unchanging "snapshot" of the database file as it existed at the moment in time when the read transaction started. Any write transactions that commit while the read transaction is active are still invisible to the read transaction.

**Documented fact:** There can only be one writer at a time (since there is only one WAL file), but writers do not block readers and readers do not block a writer.

**Documented fact about locking simplification:** In WAL mode, only SQLITE_LOCK_SHARED and SQLITE_LOCK_EXCLUSIVE are factors from the legacy locking states. The other states (RESERVED, PENDING) are used only in rollback mode. All connections hold SQLITE_LOCK_SHARED continuously while attached to a WAL-mode database — even when not within a transaction. This differs from rollback mode where SHARED is released at the end of each transaction.

**Documented fact about WAL-specific locks:** WAL mode uses an additional set of locks via shared memory (xShmLock): WAL_WRITE_LOCK, WAL_CKPT_LOCK, WAL_RECOVER_LOCK, and WAL_READ_LOCK(0) through WAL_READ_LOCK(4). Only WAL_READ_LOCK(N) can be held shared; all others are exclusive-only.

**Documented qualifier — SQLITE_BUSY still possible:** "The second advantage of WAL-mode is that writers do not block readers and readers do not block writers. This is mostly true. But there are some obscure cases where a query against a WAL-mode database can return SQLITE_BUSY." These cases include: (a) another connection has the database open in exclusive locking mode, (b) the last connection is closing and holds an exclusive lock briefly for cleanup, and (c) the first new connection after a crash holds an exclusive lock during recovery.

**Documented fact:** WAL requires all processes to be on the same host computer; it does not work over a network filesystem. This is because the wal-index uses shared memory.

**Inference drawn by SQLite docs:** WAL provides snapshot isolation, meaning a reader sees a consistent view from the moment its transaction began, regardless of concurrent writes.

---

## 3. Checkpointing (WAL-Specific)

**Documented fact:** Checkpointing is the operation of moving WAL file transactions back into the original database. It is the third primitive operation unique to WAL mode.

**Documented fact:** By default, SQLite automatically checkpoints when the WAL file reaches a threshold of 1000 pages (about 4 MB), or when the last database connection closes. This default can be changed via wal_autocheckpoint pragma or SQLITE_DEFAULT_WAL_AUTOCHECKPOINT compile-time option.

**Documented fact:** A checkpoint can run concurrently with readers, but must stop when it reaches a page in the WAL past the end mark of any current reader. This prevents overwriting database content a reader is actively using. The checkpoint remembers how far it got (in the wal-index's nBackfill field) and resumes from there on the next invocation.

**Documented fact:** A long-running read transaction can prevent a checkpointer from making progress (checkpoint starvation), which can cause the WAL file to grow without bound.

**Documented fact:** Three checkpoint subtypes exist via sqlite3_wal_checkpoint_v2(): PASSIVE (default, non-blocking), FULL, and RESTART (try harder to complete).

**Documented fact:** Checkpointing requires sync operations to avoid database corruption following a power loss. The WAL must be synced to persistent storage prior to moving content into the database, and the database must be synced prior to resetting the WAL.

**Documented fact:** When PRAGMA synchronous is set to NORMAL, the checkpoint is the only operation that issues an I/O barrier or sync operation. Writers sync the WAL on every commit if synchronous is FULL, but omit the sync if synchronous is NORMAL (sacrificing durability for speed).

---

## 4. Crash Recovery Guarantees

### Rollback Journal Mode

**Documented fact:** The rollback journal is flushed to nonvolatile storage **before** any changes are made to the database file. This is a critical ordering guarantee.

**Documented fact:** The rollback journal contains the original content of every database page about to be modified, plus the original database file size in its header.

**Documented fact (two-flush protocol):** The rollback journal is flushed to disk twice during commit: first to write page content, then a second time to write the page count in the header (after all content is safely on disk). The header is kept in a separate sector from page data so it can be overwritten without risking damage to a data page if power is lost.

**Documented fact — the commit instant:** After database changes are safely on mass storage, the rollback journal file is deleted. This is the instant where the transaction commits. If a power failure or system crash occurs prior to this point, recovery makes it appear as if no changes were ever made. If a crash occurs after the rollback journal is deleted, then it appears as if all changes have been written.

**Documented fact — hot journal detection:** The first time any SQLite process accesses the database file after a crash, it notices a rollback journal file is present and checks whether it is a "hot journal." A hot journal is one that needs to be played back to restore the database to a sane state. A hot journal exists only when an earlier process was in the middle of committing a transaction when it crashed or lost power. Criteria for a hot journal: it exists, its size > 512 bytes, its header is non-zero and well-formed, its super-journal (if named) exists, and there is no RESERVED lock on the database file.

**Documented fact — recovery steps:**
1. Obtain an EXCLUSIVE lock on the database (to prevent concurrent recovery attempts).
2. Read original page content from the rollback journal and write it back into the database file.
3. Use the original database size from the journal header to truncate the database if the incomplete transaction caused it to grow.
4. Flush recovered content to disk.
5. Delete (or truncate/zero) the hot journal.
6. Reduce EXCLUSIVE lock back to SHARED.

**Documented fact:** If a crash or power failure occurs and a hot journal is left on disk, it is essential that the original database file and the hot journal remain on disk with their original names. If either is moved or renamed, the hot journal will not be found and recovery will not occur. SQLite tries to prevent filesystem namespace corruption by opening and syncing the directory containing the rollback journal, but this cannot prevent all cases (e.g., files moved to /lost+found by unrelated processes).

**Documented fact:** The developers test rollback-journal crash recovery extensively using a modified VFS that simulates incomplete sector writes, garbage-filled pages, and out-of-order writes at varying points. Each test reopens the database after the simulated crash and verifies that the transaction either occurred completely or not at all and that the database is in a completely consistent state.

**Inference drawn by SQLite docs:** Because the rollback journal must be safely on disk before any database changes are written, the recovery guarantee is: if the journal exists after a crash, the database can be fully restored to its pre-transaction state; if the journal is deleted (or zeroed/truncated), the transaction committed completely.

### WAL Mode

**Documented fact:** In WAL mode, crash recovery is fundamentally different from rollback mode. The WAL file is a roll-forward journal — it records committed transactions that may not yet have been applied to the main database.

**Documented fact — recovery triggered:** Recovery is run by the first thread to connect to a WAL-mode database after a crash. Recovery rebuilds the WAL-index so that it accurately describes the WAL file. If no WAL file is present, there is nothing to recover, but the recovery process still runs to initialize the WAL-index.

**Documented fact — recovery mechanism:** Recovery works by doing a single pass over the WAL, from beginning to end. Checksums are verified on each frame. The scan stops at the end of the file or at the first invalid checksum. The mxFrame field is set to the index of the last valid commit frame in the WAL. A "commit frame" is a frame with a non-zero value in bytes 4 through 7 of the frame header.

**Documented fact:** Since the recovery procedure has no way of knowing how many frames of the WAL might have previously been copied back into the database (checkpointed), it initializes the nBackfill value to zero. This means that after recovery, all valid committed transactions in the WAL are available to readers, even if some had been checkpointed before the crash.

**Documented fact — exclusive lock during recovery:** During recovery of the global shared WAL-index, exclusive locks are held on WAL_WRITE_LOCK, WAL_CKPT_LOCK, WAL_RECOVER_LOCK, and WAL_READ_LOCK(1) through WAL_READ_LOCK(4). This prevents any other thread from writing the database and from reading any transactions held in the WAL until recovery is complete. If a third connection tries to query while recovery is running, it gets SQLITE_BUSY.

**Documented fact — shm file is disposable:** The shm file does not contain any database content and is not required to recover the database following a crash. The first client to connect to a quiescent database will normally truncate the shm file if it exists. The shm file is never fsync()-ed to disk.

**Documented fact — WAL file is part of persistent state:** The WAL file is part of the persistent state of the database and should be kept with the database if the database is copied or moved. If a database file is separated from its WAL file, transactions previously committed might be lost, or the database file might become corrupted.

**Documented fact — clean shutdown:** If the last client shuts down cleanly via sqlite3_close(), a checkpoint is run automatically to transfer all WAL content into the database, and both the shm and wal files are unlinked. After clean shutdown, only the main database file exists — as if it were a rollback-mode database.

**Inference drawn by SQLite docs:** In WAL mode, crash recovery is about reconstructing the WAL-index from the WAL file (which persists). Valid committed frames in the WAL survive a crash because they were already appended and synced to the WAL file. The recovery guarantee is: all committed transactions whose frames have valid checksums in the WAL file are preserved; the database is in a consistent state reflecting all such transactions. Uncommitted or partially-written frames (invalid checksums) are discarded at the scan boundary.

---

## 5. Summary Comparison Table

| Aspect | Rollback Journal | WAL Mode |
|---|---|---|
| **Write mechanism** | Original pages saved to journal; changes written directly to DB | DB preserved; changes appended to WAL |
| **Commit instant** | When rollback journal is deleted | When commit record is appended to WAL |
| **Readers during writes** | Blocked — all readers expelled before DB writes begin | Concurrent — readers see old snapshot from DB file |
| **Writer during reads** | Must wait for readers to finish (PENDING lock) | Writer appends to WAL without blocking readers |
| **Isolation level** | Serializable (via write serialization) | Snapshot isolation |
| **Crash recovery approach** | Rollback: replay journal to undo partial changes | Roll-forward: WAL contains committed transactions; rebuild WAL-index |
| **Recovery trigger** | Hot journal detected on next open | First connection after crash rebuilds WAL-index |
| **Key recovery invariant** | Journal flushed to disk before DB changes → always recoverable | Committed WAL frames with valid checksums survive; uncommitted frames discarded at checksum boundary |
| **Locking during recovery** | EXCLUSIVE lock on database file | EXCLUSIVE on WAL_RECOVER_LOCK and all other WAL locks |
| **Extra files** | One "-journal" file (transient, deleted on commit) | "-wal" file (persistent) + "-shm" file (disposable, rebuilt on recovery) |
| **Network filesystem** | Works (with caveats) | Does not work (requires shared memory) |
| **Persistence of mode** | Not persistent (resets to DELETE on reopen) | Persistent (survives close/reopen) |

---

## 6. Distinguishing Documented Facts from Inference

**Directly documented** (verbatim or near-verbatim from source pages):
- The rollback journal mechanism: original pages saved, changes written to DB, commit = journal deletion, crash recovery = replay journal.
- The WAL mechanism: changes appended to WAL, commit = commit record in WAL, checkpoint moves WAL content to DB.
- The locking state machine for rollback mode (UNLOCKED → SHARED → RESERVED → PENDING → EXCLUSIVE).
- That WAL readers and writers are concurrent (with the SQLITE_BUSY caveat).
- Snapshot isolation in WAL mode.
- Recovery procedures for both modes as described in sections 4.1–4.5 of this artifact.
- The two-flush rollback journal protocol and its safety rationale.
- WAL recovery: single pass, checksum verification, nBackfill reset to zero.

**Explicit inferences drawn by the SQLite documentation itself:**
- "Readers never get a chance to see partially written changes" (rollback mode).
- "Thus a COMMIT can happen without ever writing to the original database" (WAL mode).
- The comparison that rollback has two primitive operations vs. WAL's three.
- WAL provides "snapshot isolation."

**Observations synthesized in this artifact (not verbatim from a single source):**
- The table in Section 5 comparing aspects side-by-side draws from multiple pages.
- The characterization of the WAL recovery guarantee as "committed frames with valid checksums survive; uncommitted frames are discarded at the checksum boundary" synthesizes the WAL and WAL-format pages' descriptions.

---

## 7. Additional Notable Details

**Persistence of WAL mode** (documented fact): Unlike other journal modes, WAL mode is persistent. If a process sets WAL mode, closes, and reopens the database, it comes back in WAL mode. This is in contrast to, e.g., TRUNCATE mode, which resets to DELETE on reopen.

**WAL-Reset Bug** (documented fact, from the WAL page): A bug present in SQLite versions 3.7.0 through 3.51.2 could, in rare cases with multiple concurrent connections, lead to database corruption during checkpoint/WAL-reset interactions. Fixed in 3.51.3 (2026-03-13). The developers were unable to reproduce it organically and had to add special testing logic.

**Durability trade-off** (documented fact): With PRAGMA synchronous=NORMAL in WAL mode, writers do not sync the WAL on commit; only checkpoints issue sync operations. This means transactions are not durable and might roll back following a power failure — an explicit trade-off for speed.

**Exclusive locking mode** (documented fact): If locking_mode=EXCLUSIVE is set before the first WAL-mode access, the shared-memory wal-index is never created. This allows WAL mode on VFSes that lack shared-memory primitives, as long as only one process accesses the database.
