# Rollback-Journal vs. WAL Mode in SQLite: Reader/Writer Behavior and Crash Recovery Guarantees

**Source documents** (official SQLite documentation, all on www.sqlite.org):

- **Write-Ahead Logging**: https://www.sqlite.org/wal.html
- **Isolation In SQLite**: https://www.sqlite.org/isolation.html
- **Atomic Commit In SQLite**: https://www.sqlite.org/atomiccommit.html
- **PRAGMA Statements (synchronous)**: https://www.sqlite.org/pragma.html (PRAGMA synchronous section)

---

## 1. How Each Mode Works (Documented Mechanism)

### Rollback-Journal Mode (DELETE, TRUNCATE, PERSIST — default mode)

The traditional rollback journal works by writing a copy of the **original unchanged database content** into a separate rollback journal file and then writing changes **directly into the database file**. In the event of a crash or ROLLBACK, the original content contained in the rollback journal is played back into the database file to revert the database file to its original state. **The COMMIT occurs when the rollback journal is deleted.**

*(Source: wal.html, "How WAL Works")*

The atomic commit document describes the 12-step commit process in detail:

1. Acquire a shared lock
2. Read information from the database
3. Obtain a reserved lock (signals intent to write; readers may continue)
4. Create a rollback journal file containing original pages
5. Change database pages in user-space memory (other connections still see old pages)
6. **Flush the rollback journal to mass storage** (critical for crash survival)
7. Obtain a pending lock then escalate to an exclusive lock (readers are expelled)
8. Write changes to the database file
9. **Flush database changes to mass storage**
10. **Delete the rollback journal** — this is the instant of COMMIT
11. Release the exclusive lock

*(Source: atomiccommit.html, sections 3.1–3.12)*

### WAL Mode (PRAGMA journal_mode=WAL)

The WAL approach inverts this. **The original content is preserved in the database file and the changes are appended into a separate WAL file.** A COMMIT occurs when a special record indicating a commit is appended to the WAL. Thus a COMMIT can happen without ever writing to the original database, which allows readers to continue operating from the original unaltered database while changes are simultaneously being committed into the WAL. Multiple transactions can be appended to the end of a single WAL file.

Eventually, transactions in the WAL file must be moved back into the original database. This operation is called a **"checkpoint."**

*(Source: wal.html, "How WAL Works")*

---

## 2. Reader/Writer Behavior (Concurrency)

This is the single most important operational difference between the two modes.

### Rollback-Mode: Writers Block Readers, Readers Block Writers

> "In rollback mode, SQLite implements isolation by locking the database file and preventing any reads by other database connections while each write transaction is underway. Readers can be active at the beginning of a write, before any content is flushed to disk and while all changes are still held in the writer's private memory space. But before any changes are made to the database file on disk, all readers must be (temporarily) expelled in order to give the writer exclusive access to the database file."

*(Source: isolation.html, "Isolation And Concurrency")*

Key consequences:
- Only after the transaction is completely written, synced to disk, and committed are readers allowed back.
- Readers never see partially written changes.
- There can be multiple concurrent readers (shared locks), but only one writer.
- When a writer needs to commit, it must expel all existing readers via the pending → exclusive lock escalation.

### WAL-Mode: Readers and Writers Run Concurrently

> "WAL mode permits simultaneous readers and writers. It can do this because changes do not overwrite the original database file, but rather go into the separate write-ahead log file. That means that readers can continue to read the old, original, unaltered content from the original database file at the same time that the writer is appending to the write-ahead log."

> "In WAL mode, SQLite exhibits 'snapshot isolation'. When a read transaction starts, that reader continues to see an unchanging 'snapshot' of the database file as it existed at the moment in time when the read transaction started. Any write transactions that commit while the read transaction is active are still invisible to the read transaction, because the reader is seeing a snapshot of database file from a prior moment in time."

*(Source: isolation.html, "Isolation And Concurrency")*

Key consequences:
- Writers do not block readers. Readers do not block writers. Reading and writing can proceed concurrently.
- Each reader has its own "end mark" in the WAL, ensuring it sees a consistent snapshot.
- There can still be only one writer at a time (there is only one WAL file).
- A checkpoint can run concurrently with readers but must stop at pages past the end mark of any current reader. A long-running read transaction can prevent a checkpoint from completing.

**Caveat about SQLITE_BUSY in WAL mode** (explicitly documented):
> "The second advantage of WAL-mode is that writers do not block readers and readers do not block writers. This is mostly true. But there are some obscure cases where a query against a WAL-mode database can return SQLITE_BUSY, so applications should be prepared for that happenstance."

Cases include: another connection has exclusive locking mode; the last connection is closing and holds an exclusive lock for cleanup; or a new connection attempts to query while another connection is running crash recovery.

*(Source: wal.html, "Sometimes Queries Return SQLITE_BUSY In WAL Mode")*

---

## 3. Crash Recovery Guarantees

### Rollback-Journal Mode: Recovery by Playing Back the Journal

After a crash or power loss during a transaction, the rollback journal file is left on disk. The next process to open the database detects the presence of the abandoned rollback journal (called a **"hot journal"**) and uses it to restore the database to its state prior to the start of the incomplete transaction.

> "A hot journal is a rollback journal that needs to be played back in order to restore the database to a sane state. A hot journal only exists when an earlier process was in the middle of committing a transaction when it crashed or lost power."

A rollback journal is "hot" if all of the following are true:
- The rollback journal exists.
- The rollback journal is not an empty file.
- There is no reserved lock on the main database file.
- The header of the rollback journal is well-formed and in particular has not been zeroed out.
- The rollback journal does not contain the name of a super-journal file, or if it does, that super-journal file exists.

*(Source: atomiccommit.html, "Hot Rollback Journals")*

Recovery steps:
1. Obtain an exclusive lock on the database file.
2. Read original page content from the rollback journal and write it back into the database file.
3. If the database grew during the aborted transaction, truncate it back to original size using the size recorded in the journal header.
4. Delete the hot journal (or truncate/zero the header).
5. Reduce exclusive lock to shared lock. The database is now as if the aborted transaction never started.

*(Source: atomiccommit.html, sections 4.1–4.6)*

**Critical prerequisite for recovery**: the rollback journal must be complete and intact on disk when power is restored. This is why step 6 (flushing the rollback journal to mass storage) in the commit process is essential. The flush happens **before** any changes are written to the database file itself.

*(Source: atomiccommit.html, "When Something Goes Wrong...")*

**What breaks recovery** (documented):
- If the hot journal files are moved, deleted, or renamed after a crash or power failure, automatic recovery will not work and the database may go corrupt.
- If a power failure causes filesystem corruption such that recently changed filenames are forgotten and the file is moved into "/lost+found", the hot journal will not be found and recovery will not occur.
- Copying a database file without also copying its journal.

*(Source: atomiccommit.html, "Things That Can Go Wrong"; howtocorrupt.html)*

### WAL Mode: Recovery by Reading the WAL File

When the last connection to a database crashed, the first new connection to open the database will start a recovery process. An exclusive lock is held during recovery.

*(Source: wal.html, "Sometimes Queries Return SQLITE_BUSY In WAL Mode")*

> "The database file format is unchanged for WAL mode. However, the WAL file and the wal-index are new concepts and so older versions of SQLite will not know how to recover a crashed SQLite database that was operating in WAL mode when the crash occurred. To prevent older versions of SQLite (prior to version 3.7.0, 2010-07-22) from trying to recover a WAL-mode database (and making matters worse) the database file format version numbers (bytes 18 and 19 in the database header) are increased from 1 to 2 in WAL mode."

*(Source: wal.html, "Backwards Compatibility")*

The WAL file exists for as long as any database connection has the database open. Usually, the WAL file is deleted automatically when the last connection closes. However, if the last process exits without cleanly shutting down, the WAL file might be retained. **The WAL file is part of the persistent state of the database and should be kept with the database if the database is copied or moved. If a database file is separated from its WAL file, then transactions that were previously committed to the database might be lost, or the database file might become corrupted.**

*(Source: wal.html, "The WAL File")*

---

## 4. Durability and Synchronous Settings (Documented Table)

The PRAGMA synchronous documentation provides this explicit comparison table:

| Synchronous Setting | Rollback Mode | WAL Mode |
|---------------------|---------------|----------|
| EXTRA | ACID | ACID |
| FULL | ACID (but "not necessarily durable across a power loss in rollback mode, depending on the underlying filesystem") | ACID |
| NORMAL | "Maybe not consistent" | "Maybe not durable" |
| OFF | "Not consistent" | "Not consistent" |

*(Source: pragma.html, PRAGMA synchronous section)*

Key documented elaborations:

- **WAL mode with synchronous=NORMAL**: The WAL file is synchronized before each checkpoint, the database file is synchronized after each completed checkpoint, and the WAL file header is synchronized when a WAL file begins to be reused after a checkpoint, but **no sync operations occur during most transactions**. "WAL mode is always consistent with synchronous=NORMAL, but WAL mode does lose durability. A transaction committed in WAL mode with synchronous=NORMAL might roll back following a power loss or system crash."

- **WAL mode with synchronous=FULL**: An additional sync operation of the WAL file happens after each transaction commit. This extra WAL sync helps ensure that transactions are durable across a power loss.

- **Rollback mode with synchronous=FULL**: "FULL might also be durable using a rollback journal, depending on the underlying filesystem. FULL is not necessarily durable across a power loss in rollback mode, so if durability is desired, it is best to set the synchronous mode to EXTRA."

*(Source: pragma.html, PRAGMA synchronous section)*

---

## 5. Distinguishing Documented Facts from Inference

### Documented Facts (verbatim or near-verbatim from sources)

1. In rollback mode, COMMIT occurs when the rollback journal is deleted. (wal.html)
2. In WAL mode, COMMIT occurs when a special record is appended to the WAL. (wal.html)
3. In rollback mode, readers must be expelled before a writer can write to disk. (isolation.html)
4. In WAL mode, readers and writers can proceed concurrently because changes go to a separate WAL file. (isolation.html, wal.html)
5. WAL mode provides snapshot isolation: each reader sees the database as it existed when its read transaction started. (isolation.html)
6. A hot rollback journal is detected on next open, and its original pages are played back into the database to restore the pre-transaction state. (atomiccommit.html)
7. In WAL mode, the first new connection after a crash starts a recovery process holding an exclusive lock. (wal.html)
8. The synchronous pragma table explicitly states the ACID/durability properties for each combination of mode and setting. (pragma.html)
9. WAL mode is persistent across connections; changing to WAL once keeps the database in WAL mode until explicitly changed back. (wal.html)
10. WAL mode raises the database file format version numbers from 1 to 2 to prevent older SQLite versions from attempting recovery. (wal.html)
11. WAL mode uses fewer fsync() operations than rollback mode and is less vulnerable to broken fsync(). (wal.html)
12. All processes using a WAL-mode database must be on the same host computer; WAL does not work over a network filesystem. (wal.html)

### Reasonable Inferences (not stated verbatim, derived from documented facts)

- Because WAL mode only appends to the WAL and does not overwrite the original database during writes, the risk of the main database file being in an inconsistent state after a crash is lower than in rollback mode. *(Inference from: WAL preserves original content in the database file; rollback writes changes directly into the database file.)*
- WAL mode recovery is effectively a forward-recovery (committed transactions in the WAL that haven't been checkpointed are preserved), while rollback-mode recovery is a backward-recovery (uncommitted changes are undone from the journal). *(Inference from the documented mechanisms.)*
- Checkpoint starvation (due to long-running readers) in WAL mode could prevent the WAL from being reset, causing it to grow without bound and degrading read performance. *(Inference from the documented checkpoint mechanism.)*
- The rollback-mode two-flush pattern (flush journal, then flush database) is why rollback-mode writes are roughly "twice" the I/O of WAL-mode writes. *(Inference from the atomic commit step descriptions and the WAL performance discussion.)*

---

## 6. Summary Comparison Table

| Aspect | Rollback-Journal (DELETE/TRUNCATE/PERSIST) | WAL Mode |
|--------|---------------------------------------------|----------|
| **Write mechanism** | Original pages saved to journal; changes written directly to DB file | Original DB preserved; changes appended to WAL file |
| **COMMIT signal** | Rollback journal is deleted | Special commit record appended to WAL |
| **Reader/Writer concurrency** | Writers block readers; readers block writers | Readers and writers run concurrently (snapshot isolation) |
| **Isolation level** | Serializable (via write serialization) | Snapshot isolation |
| **Crash recovery** | Hot journal detected → original pages played back into DB (rollback) | Recovery process on first open; committed WAL entries preserved |
| **Recovery direction** | Backward (undo incomplete transaction) | Forward (preserve committed transactions not yet checkpointed) |
| **Extra operation** | None | Checkpointing (automatic at 1000-page WAL threshold) |
| **fsync() frequency** | More frequent (journal flush + DB flush per commit) | Fewer (WAL sync at commit if synchronous=FULL; otherwise only at checkpoint) |
| **Durability with synchronous=FULL** | ACID (but durability may depend on filesystem) | ACID (extra WAL sync per commit) |
| **Durability with synchronous=NORMAL** | "Maybe not consistent" | "Maybe not durable" (consistent but may lose last transactions on power loss) |
| **File artifacts** | `-journal` file (transient) | `-wal` file and `-shm` wal-index file (quasi-persistent) |
| **Mode persistence** | Not persistent (reverts to DELETE on reopen) | Persistent (survives close/reopen) |
| **Network filesystem** | Works | Does not work (requires shared memory) |
| **DB file format version** | 1 | 2 |

*(All table entries are sourced from the four official documentation pages cited above.)*
