# Rollback-Journal vs. WAL Modes in SQLite: Reader/Writer Behavior and Crash Recovery

## Source Documents (Official SQLite Documentation)

All information below is drawn from the following official SQLite pages:

1. **Write-Ahead Logging** — https://www.sqlite.org/wal.html
2. **Isolation In SQLite** — https://www.sqlite.org/isolation.html
3. **Atomic Commit In SQLite** — https://www.sqlite.org/atomiccommit.html
4. **WAL-mode File Format** — https://www.sqlite.org/walformat.html
5. **Database File Format** — https://www.sqlite.org/fileformat.html
6. **Temporary Files Used By SQLite** — https://www.sqlite.org/tempfiles.html

---

## 1. Mechanistic Difference: How Each Mode Works

### Rollback-Journal Mode (the default, DELETE/TRUNCATE/PERSIST)

**Documented fact** (wal.html §1, atomiccommit.html §3): Before modifying any database pages, SQLite writes the *original* unchanged content of those pages into a separate rollback journal file. Changes are then written directly into the main database file. The COMMIT occurs when the rollback journal is *deleted* (or its header zeroed, or the file truncated, depending on the journal_mode variant — DELETE, PERSIST, TRUNCATE). In the event of a crash or ROLLBACK, the original content from the rollback journal is played back into the database file to revert it to its original state.

**Documented fact** (atomiccommit.html, fileformat.html §1.1): The rollback journal is called a "hot journal" when it contains information necessary for recovering the database. A hot journal is identified at the next database open by the presence of the journal file. The database then obtains an exclusive lock, plays back the original pages from the journal into the database, and deletes the journal.

### WAL Mode (Write-Ahead Logging)

**Documented fact** (wal.html §2): The WAL approach inverts the rollback journal. The original content is *preserved* in the database file and changes are *appended* into a separate WAL file. A COMMIT occurs when a special commit record is appended to the WAL — without ever writing to the original database file. Multiple transactions can be appended to the end of a single WAL file.

**Documented fact** (wal.html §2.1): Eventually, transactions in the WAL must be transferred back into the main database. This operation is called "checkpointing." In the rollback-journal approach there are two primitive operations: reading and writing. With WAL there are three: reading, writing, and checkpointing.

---

## 2. Reader/Writer Behavior

### Rollback-Journal Mode

**Documented fact** (isolation.html): "In rollback mode, SQLite implements isolation by locking the database file and preventing any reads by other database connections while each write transaction is underway." Readers can be active at the beginning of a write, before content is flushed to disk and while changes are held in the writer's private memory. But before any changes are made to the database file on disk, **all readers must be temporarily expelled** to give the writer exclusive access. Only after the transaction is completely written, synced to disk, and committed are readers allowed back.

**Documented fact** (atomiccommit.html §3): The write sequence involves: shared lock → reserved lock → create rollback journal → flush journal → pending lock → exclusive lock → write database → flush database → delete journal → release lock. Readers are blocked during the exclusive-lock phase.

**Inference from documented behavior**: Writers block readers; readers block writers. Concurrency is limited — reads and writes are serialized at the exclusive-lock boundary.

### WAL Mode

**Documented fact** (wal.html §1, advantages): "WAL provides more concurrency as readers do not block writers and a writer does not block readers. Reading and writing can proceed concurrently."

**Documented fact** (wal.html §2.2 — Concurrency): When a read operation begins, it remembers the location of the last valid commit record in the WAL (the "end mark"). This end mark is unchanged for the duration of the transaction, ensuring the reader sees the database as it existed at a single point in time. When a reader needs a page, it first checks the WAL for that page prior to its end mark; if not found there, it reads from the original database file. A wal-index data structure in shared memory helps readers locate pages in the WAL quickly.

**Documented fact** (wal.html §2.2): Writers merely append new content to the end of the WAL file. Because writers do nothing that would interfere with readers, writers and readers can run concurrently. However, there can only be **one writer at a time** (only one WAL file).

**Documented fact** (isolation.html): "In WAL mode, SQLite exhibits 'snapshot isolation.' When a read transaction starts, that reader continues to see an unchanging 'snapshot' of the database file as it existed at the moment when the read transaction started. Any write transactions that commit while the read transaction is active are still invisible to the read transaction."

**Documented fact** (isolation.html): If a reader holding a snapshot tries to escalate to a writer (e.g., a read transaction followed by UPDATE), it fails with **SQLITE_BUSY_SNAPSHOT** because the snapshot is no longer the latest version. The reader must release its snapshot and start a new transaction. The solution is **BEGIN IMMEDIATE**, which starts a write transaction from the beginning and blocks other writers.

**Documented fact** (wal.html §9): There are obscure cases where a WAL-mode query can return SQLITE_BUSY: when another connection holds exclusive locking mode; during the cleanup of WAL and shared-memory files on the last connection close; and during crash recovery when an exclusive lock is held.

**Documented fact** (wal.html §2.2): A checkpoint can run concurrently with readers, but must stop when it reaches a page past the end mark of any current reader, to avoid overwriting content the reader is actively using. A long-running read transaction can prevent a checkpoint from completing.

---

## 3. Crash Recovery Guarantees

### Rollback-Journal Mode

**Documented fact** (atomiccommit.html §4, fileformat.html §1.1): If a crash or power loss occurs mid-transaction, the rollback journal remains on disk. When any SQLite process next opens the database, it detects the journal file. If the journal meets the "hot journal" criteria (exists, non-empty, no reserved lock on the main database, well-formed header not zeroed, super-journal is present if referenced), recovery proceeds:

1. Obtain an exclusive lock on the database.
2. Read the original page content from the rollback journal and write it back into the database file.
3. Truncate the database back to its original size if the aborted transaction caused growth.
4. Delete (or invalidate) the hot journal.
5. Release the exclusive lock.

**Documented fact** (atomiccommit.html §3.11): The deletion of the rollback journal *is* the commit point. If power fails before deletion, the transaction rolls back. If power fails after deletion, the transaction is committed. The existence of the journal file is the binary signal: present = rollback, absent = committed.

**Documented fact** (atomiccommit.html §1): "SQLite has the important property that transactions appear to be atomic even if the transaction is interrupted by an operating system crash or power failure."

**Documented fact** (tempfiles.html §2.1): Without a rollback journal, "if a crash or power loss occurred in the middle of a transaction the entire database would likely go corrupt." The OFF and MEMORY journal modes disable crash recovery and risk corruption.

### WAL Mode

**Documented fact** (walformat.html §3, wal.html §10): When a WAL-mode database is opened after a crash, the first connection runs **recovery**. Recovery rebuilds the WAL-index so that it is synchronized with the WAL file.

**Documented fact** (walformat.html §3): Recovery works by doing a single pass over the WAL file from beginning to end. Checksums are verified on each frame. The scan stops at the end of the file or at the first invalid checksum. The mxFrame field is set to the index of the last valid commit frame. A "commit frame" has a non-zero database-size value in bytes 4–7 of the frame header. Since recovery cannot know how many frames were previously checkpointed, nBackfill is initialized to zero.

**Documented fact** (walformat.html §3): During recovery of the global shared-memory WAL-index, exclusive locks are held on WAL_WRITE_LOCK, WAL_CKPT_LOCK, WAL_RECOVER_LOCK, and WAL_READ_LOCK(1) through WAL_READ_LOCK(4). All WAL-index locks except WAL_READ_LOCK(0) are held exclusively. This prevents any other thread from writing the database or reading from the WAL until recovery completes.

**Documented fact** (wal.html §2.3): Writers sync the WAL on every transaction commit if PRAGMA synchronous is set to FULL, but omit this sync if synchronous is NORMAL. With synchronous=NORMAL, transactions are not durable across a power loss — they may roll back. The checkpoint is the only operation that issues an I/O barrier/sync when synchronous=NORMAL.

**Documented fact** (wal.html §10, fileformat.html §1.3.3): To prevent older SQLite versions (pre-3.7.0) from attempting to recover a WAL-mode database and making matters worse, the database file format version numbers (bytes 18 and 19) are increased from 1 to 2 in WAL mode. Older versions will report "file is encrypted or is not a database."

**Documented fact** (walformat.html §1.3): The -shm (wal-index) file does not contain any database content and is not required to recover the database following a crash. The first client to connect to a quiescent database will normally truncate the shm file if it exists. The shm file is never fsync()-ed to disk.

**Documented fact** (wal.html §2.1, §2.3): By default, SQLite automatically checkpoints when the WAL file reaches 1000 pages, or when the last database connection closes. The WAL file is not truncated after a checkpoint (unless journal_size_limit is set); SQLite reuses the file by overwriting from the beginning. The WAL file can grow without bound if automatic checkpointing is disabled, if checkpoint starvation occurs (always an active reader), or during very large write transactions.

**Documented fact** (tempfiles.html §2.4): For multi-file transactions, WAL mode does **not** provide atomicity across all attached databases: "individual database files are updated atomically across a power-loss, but in the case of a multi-file transactions, some files might rollback while others roll forward after power is restored." (This contrasts with rollback-journal mode, which uses a super-journal to ensure cross-database atomicity.)

**Documented fact** (wal.html §4): "If a database file is separated from its WAL file, then transactions that were previously committed to the database might be lost, or the database file might become corrupted. The only safe way to remove a WAL file is to open the database file using one of the sqlite3_open() interfaces then immediately close the database using sqlite3_close()."

**Documented fact** (wal.html §11): A bug discovered 2026-03-03 ("WAL-reset bug") affected all SQLite versions from 3.7.0 through 3.51.2. Under rare concurrent checkpoint-and-write scenarios, a data race could cause a checkpoint to skip frames, leading to database corruption. Fixed in version 3.51.3.

---

## 4. Summary Comparison Table

| Aspect | Rollback-Journal (DELETE) | WAL |
|---|---|---|
| **Mechanism** | Original pages copied to journal; changes written to main DB; commit = delete journal | Original DB preserved; changes appended to WAL; commit = append commit record to WAL |
| **Reader/Writer** | Writers block all readers; readers block writers (serialized at exclusive lock) | Readers and writers run concurrently; readers see a snapshot; writers append only |
| **Isolation Level** | Serializable (via serialized writes) | Snapshot Isolation |
| **Concurrency** | One writer OR multiple readers, never both | One writer AND multiple readers simultaneously |
| **Crash Recovery Signal** | Presence/absence of rollback journal file | WAL file: replay from last valid commit frame; checksums verified |
| **Atomicity** | Across all attached databases (via super-journal) | Per individual database only; multi-file transactions may split on power loss |
| **Durability (synchronous=FULL)** | Yes — journal and database are synced | Yes — WAL synced on each commit + checkpoint syncing |
| **Durability (synchronous=NORMAL)** | Reduced — fewer syncs | Reduced — WAL not synced on commit; only checkpoint syncs |
| **Performance** | Two writes per changed page (journal + database); random I/O | One write per change (WAL append); sequential I/O; faster in most scenarios |
| **On-Disk Files** | Main DB + rollback journal (-journal) | Main DB + WAL (-wal) + wal-index (-shm) |
| **Persistence of mode** | Not persistent across reopens | Persistent across reopens |
| **Network filesystem** | Works | Does NOT work (requires shared memory) |
| **Backwards compat** | Version numbers = 1 | Version numbers = 2; pre-3.7.0 cannot open |

---

## 5. Inference vs. Documented Fact — Key Distinctions

- **"Rollback journal mode provides stronger crash guarantees than WAL"** — this is **inference**, not stated in the documentation. The documentation states both modes provide atomic commit across power loss for individual databases. WAL actually has an additional integrity mechanism (frame checksums) that rollback journals lack. However, rollback-journal mode does provide cross-database atomicity via super-journals, which WAL does not.

- **"WAL is always faster"** — the documentation explicitly states this is **not always true**: WAL may be 1–2% slower for read-mostly workloads (wal.html §1, disadvantage #5), and checkpoint operations involve syncs and seeking that make them slower than write transactions.

- **"Readers never block in WAL mode"** — the documentation says this is "mostly true" but documents specific SQLITE_BUSY scenarios (wal.html §9).

- **"The WAL-index file (-shm) is needed for crash recovery"** — this is **false** per walformat.html §1.3: the shm file "does not contain any database content and is not required to recover the database following a crash."
