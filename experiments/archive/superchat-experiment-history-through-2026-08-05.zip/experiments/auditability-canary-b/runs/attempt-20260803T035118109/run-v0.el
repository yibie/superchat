;;; run.el --- Throwaway Auditability Canary B -*- lexical-binding: t; -*-

;; Question: can one frozen baseline/intervention pair close all five
;; Auditability gates without interpreting their outcome difference as an
;; intervention effect?  This experiment uses two scratch SQLite databases
;; and a deterministic model adapter.  It does not test learning.
;; Run once with:
;;   emacs -Q --batch -L . -l experiments/auditability-canary-b/run.el

(require 'cl-lib)
(require 'json)
(require 'seq)
(require 'subr-x)
(require 'superchat-workflow)
(require 'superchat-subagent)
(require 'superchat-workspace)
(require 'superchat-tools)

(defconst canary-b--directory
  (file-name-directory (or load-file-name buffer-file-name)))
(defconst canary-b--root (expand-file-name "../.." canary-b--directory))
(defconst canary-b--manifest-path
  (expand-file-name "manifest.json" canary-b--directory))

(defvar canary-b--manifest nil)
(defvar canary-b--condition-id nil)
(defvar canary-b--prompt-snapshots nil)
(defvar canary-b--model-calls nil)

(defun canary-b--sha256-string (value)
  "Return a prefixed SHA-256 for string VALUE."
  (concat "sha256:"
          (secure-hash 'sha256 (encode-coding-string value 'utf-8))))

(defun canary-b--file-content (path)
  "Return PATH bytes as a unibyte string."
  (with-temp-buffer
    (set-buffer-multibyte nil)
    (insert-file-contents-literally path)
    (buffer-string)))

(defun canary-b--file-sha256 (path)
  "Return a prefixed SHA-256 for PATH."
  (concat "sha256:"
          (secure-hash 'sha256 (canary-b--file-content path))))

(defun canary-b--plist-p (value)
  "Return non-nil when VALUE is a non-empty keyword plist."
  (and value
       (listp value)
       (let ((rest value)
             (valid t))
         (while (and rest valid)
           (setq valid (and (keywordp (car rest)) (cdr rest))
                 rest (cddr rest)))
         (and valid (null rest)))))

(defun canary-b--json-value (value)
  "Make sequence shape explicit before encoding VALUE as JSON."
  (cond
   ((canary-b--plist-p value)
    (let (result)
      (while value
        (setq result
              (nconc result
                     (list (pop value)
                           (canary-b--json-value (pop value))))))
      result))
   ((listp value)
    (vconcat (mapcar #'canary-b--json-value value)))
   ((vectorp value)
    (vconcat (mapcar #'canary-b--json-value (append value nil))))
   (t value)))

(defun canary-b--write-json (path value)
  "Write VALUE as readable JSON to PATH."
  (let ((json-encoding-pretty-print t))
    (with-temp-file path
      (insert (json-encode (canary-b--json-value value)) "\n"))))

(defun canary-b--manifest-read ()
  "Read the frozen Canary B manifest."
  (json-parse-string
   (canary-b--file-content canary-b--manifest-path)
   :object-type 'plist :array-type 'list
   :null-object nil :false-object :false))

(defun canary-b--source-checks ()
  "Verify source snapshots declared by the frozen manifest."
  (mapcar
   (lambda (snapshot)
     (let* ((relative (plist-get snapshot :path))
            (path (expand-file-name relative canary-b--root))
            (expected (plist-get snapshot :sha256))
            (actual (and (file-readable-p path)
                         (canary-b--file-sha256 path))))
       (unless (equal expected actual)
         (error "Frozen source mismatch for %s: expected %s, got %s"
                relative expected actual))
       (list :path relative :sha256 actual :status "observed")))
   (plist-get canary-b--manifest :source_snapshots)))

(defun canary-b--condition (condition-id)
  "Return the frozen manifest condition named CONDITION-ID."
  (or (cl-find condition-id (plist-get canary-b--manifest :conditions)
               :key (lambda (item) (plist-get item :condition_id))
               :test #'equal)
      (error "Unknown Canary B condition: %s" condition-id)))

(defun canary-b--role (prompt)
  "Return the Research role encoded in PROMPT."
  (cond ((string-match-p "\\[research/collector\\]" prompt) "collector")
        ((string-match-p "\\[research/analyst\\]" prompt) "analyst")
        ((string-match-p "\\[research/reviewer\\]" prompt) "reviewer")
        (t (error "Unknown Research stage"))))

(defun canary-b--tool-names (tools)
  "Return names from Canary tool descriptor plists TOOLS."
  (mapcar (lambda (tool) (plist-get tool :name)) tools))

(defun canary-b--prepare-query (turn)
  "Capture TURN and apply only the frozen model-facing intervention."
  (let* ((workflow-prompt (superchat-turn-prompt turn))
         (system-prompt (superchat-turn-system-prompt turn))
         (role (canary-b--role workflow-prompt))
         (condition (canary-b--condition canary-b--condition-id))
         (intervention (plist-get condition :intervention))
         (instruction (plist-get intervention :instruction))
         (applied (and instruction (equal role "reviewer")))
         (model-prompt
          (if applied
              (concat workflow-prompt "\n" instruction)
            workflow-prompt))
         (offered (plist-get (plist-get canary-b--manifest :prior)
                             :offered_tools)))
    (push (list :condition_id canary-b--condition-id
                :role role
                :workflow_prompt workflow-prompt
                :workflow_prompt_sha256
                (canary-b--sha256-string workflow-prompt)
                :model_prompt model-prompt
                :model_prompt_sha256
                (canary-b--sha256-string model-prompt)
                :system_prompt system-prompt
                :system_prompt_sha256
                (canary-b--sha256-string system-prompt)
                :intervention_applied (and applied t)
                :intervention_sha256
                (and applied (canary-b--sha256-string instruction))
                :run_id nil
                :target_model nil
                :observed_system_prompt_sha256 nil
                :prepared_tool_names nil)
          canary-b--prompt-snapshots)
    (list :prompt model-prompt
          :system-prompt system-prompt
          :target-model
          (plist-get (plist-get canary-b--manifest :prior) :model_id)
          :tools (canary-b--tool-names offered))))

(defun canary-b--prepare-tools (_context _prompt _requested-tools)
  "Expose the frozen Canary B tool surface."
  (copy-tree
   (plist-get (plist-get canary-b--manifest :prior) :offered_tools)))

(defun canary-b--call-tool (role name function args context)
  "Call NAME for ROLE through Authority and retain observable arguments."
  (let ((result (superchat-tool-execute
                 name function args :context context)))
    (push (list :role role
                :run_id (plist-get context :run-id)
                :tool_name name
                :arguments args
                :result_sha256
                (canary-b--sha256-string (format "%s" result)))
          canary-b--model-calls)
    result))

(defun canary-b--scripted-model
    (prompt _callback _stream-callback
            &optional target-model _context-files _tools system-prompt _preset)
  "Execute one deterministic Research stage for model-facing PROMPT."
  (let* ((role (canary-b--role prompt))
         (context
          (plist-put (copy-sequence superchat--tool-execution-context)
                     :approval-function (lambda (_request) t)))
         (workspace-id (plist-get context :workspace-id))
         (prior (superchat-workspace-artifacts workspace-id))
         consumed)
    (dolist (artifact prior)
      (let ((artifact-id (plist-get artifact :artifact-id))
            (revision (plist-get artifact :revision)))
        (canary-b--call-tool
         role "workspace_read" #'superchat-tool-workspace-read
         (list artifact-id revision) context)
        (push (format "%s@%s" artifact-id revision) consumed)))
    (setq consumed (nreverse consumed))
    (let ((content
           (if (equal role "reviewer")
               (format
                (concat "[canary-b/reviewer]\n"
                        "central_conclusion=The comparison evidence is reconstructable.\n"
                        "evidence_refs=%s\n"
                        "citations=%s\n"
                        "contradiction_handling=No material conflict is present in the scripted evidence; effectiveness remains unevaluated.\n")
                (string-join consumed ",")
                (string-join
                 (mapcar (lambda (item) (concat "artifact:" item)) consumed)
                 ","))
             (format "[canary-b/%s]\nquery=%s\nconsumed=%s\n"
                     role (plist-get canary-b--manifest :task_input)
                     (string-join consumed ",")))))
      (canary-b--call-tool
       role "workspace_publish" #'superchat-tool-workspace-publish
       (list content role) context))
    (let ((snapshot
           (cl-find role canary-b--prompt-snapshots
                    :key (lambda (item) (plist-get item :role))
                    :test #'equal)))
      (setf (plist-get snapshot :run_id) (plist-get context :run-id)
            (plist-get snapshot :target_model) target-model
            (plist-get snapshot :observed_system_prompt_sha256)
            (canary-b--sha256-string system-prompt)
            (plist-get snapshot :prepared_tool_names)
            (canary-b--tool-names superchat--llm-prepared-tools)))
    (funcall superchat--llm-runtime-observer
             'terminal
             (list :status 'completed
                   :response (format "%s complete" role)))))

(defun canary-b--events (session-id)
  "Replay SESSION-ID from the real Tape."
  (superchat-tape-replay-events session-id))

(defun canary-b--event-reference (event)
  "Return a bounded reference to EVENT without copying Tape payload."
  (list :event_id (plist-get event :event-id)
        :type (plist-get event :type)
        :session_id (plist-get event :session-id)
        :run_id (plist-get event :run-id)
        :recorded_at (plist-get event :recorded-at)))

(defun canary-b--effect-scope-p (event artifact-id)
  "Return non-nil when EVENT declares ARTIFACT-ID as effect scope."
  (let ((effects (plist-get (plist-get event :payload) :effects)))
    (or
     (and (listp effects)
          (listp (car effects))
          (seq-some
           (lambda (effect)
             (equal artifact-id (plist-get effect :scope)))
           effects))
     ;; This bounded decoder consumes the observed singleton replay shape; it
     ;; does not promote that transport shape into Runtime semantics.
     (let* ((flat (and (listp effects) (plist-get effects :effect)))
            (scope-tail (and (listp flat) (member "scope" flat))))
       (equal artifact-id (cadr scope-tail))))))

(defun canary-b--read-event (events run-id artifact-id)
  "Find the explicit workspace_read request for ARTIFACT-ID in RUN-ID."
  (cl-find-if
   (lambda (event)
     (let ((payload (plist-get event :payload)))
       (and (equal "tool.requested" (plist-get event :type))
            (equal run-id (plist-get event :run-id))
            (equal "workspace_read" (plist-get payload :tool-name))
            (canary-b--effect-scope-p event artifact-id))))
   events))

(defun canary-b--closure-summary (session-id run-id)
  "Return Closure evidence for RUN-ID in SESSION-ID."
  (let* ((trace (canary-b--events session-id))
         (well (superchat-closure-judge
                (list :kind 'trace-well-formed :run-id run-id) trace))
         (terminal (superchat-closure-judge
                    (list :kind 'durable-run-terminal :run-id run-id) trace)))
    (list :session_id session-id
          :run_id run-id
          :trace_verdict (symbol-name (plist-get well :verdict))
          :terminal_verdict (symbol-name (plist-get terminal :verdict))
          :terminal_kind
          (when-let* ((judgment (plist-get terminal :judgment))
                      (kind (plist-get judgment :terminal-kind)))
            (symbol-name kind))
          :witness_event_ids
          (plist-get (plist-get terminal :witness) :event-ids))))

(defun canary-b--reference-roles (prompt)
  "Return ordered Artifact roles from model-facing PROMPT."
  (unless (string-match
           "Prior Artifact references: \\(\\[[^\n]*\\]\\)" prompt)
    (error "No JSON Artifact reference array in Prompt"))
  (mapcar
   (lambda (reference) (plist-get reference :role))
   (json-parse-string (match-string 1 prompt)
                      :object-type 'plist :array-type 'list)))

(defun canary-b--canonical-prompt (prompt)
  "Return PROMPT with execution identities reduced to Artifact roles.
This is derived comparison fingerprint interpreter reference-role-v0."
  (unless (string-match
           "Prior Artifact references: \\(\\[[^\n]*\\]\\)" prompt)
    (error "Cannot canonicalize Prompt without Artifact reference array"))
  (concat (substring prompt 0 (match-beginning 1))
          (json-encode (vconcat (canary-b--reference-roles prompt)))
          (substring prompt (match-end 1))))

(defun canary-b--gate (name verdict evidence)
  "Return one evidence gate named NAME."
  (list :name name :verdict verdict :evidence evidence))

(defun canary-b--evaluate-outcome
    (reviewer-content reviewer-artifact reviewer-reads)
  "Blindly evaluate REVIEWER-CONTENT using the frozen Research rubric."
  (let* ((evidence-score
          (if (and reviewer-content
                   (string-match-p "^central_conclusion=" reviewer-content)
                   (= 2 (length reviewer-reads)))
              2 0))
         (citation-score
          (if (and reviewer-content
                   (string-match-p "^citations=artifact:" reviewer-content)
                   (cl-every
                    (lambda (read)
                      (string-match-p
                       (regexp-quote (plist-get read :artifact_id))
                       reviewer-content))
                    reviewer-reads))
              2 0))
         (contradiction-score
          (if (and reviewer-content
                   (string-match-p "^contradiction_handling="
                                   reviewer-content))
              2 0))
         (scores (list evidence-score citation-score contradiction-score))
         (label (cond ((cl-every (lambda (score) (= score 2)) scores)
                       "accept")
                      ((cl-some (lambda (score) (= score 0)) scores)
                       "reject")
                      (t "revise"))))
    (list
     :evaluation_target
     (and reviewer-artifact
          (list :artifact_id (plist-get reviewer-artifact :artifact-id)
                :revision (plist-get reviewer-artifact :revision)))
     :criteria
     (list
      (list :id "evidence_completeness" :score evidence-score
            :evidence (mapcar (lambda (read) (plist-get read :event))
                              reviewer-reads))
      (list :id "citation_quality" :score citation-score
            :evidence (mapcar (lambda (read)
                                (plist-get read :artifact_id))
                              reviewer-reads))
      (list :id "contradiction_handling" :score contradiction-score
            :evidence "reviewer_artifact"))
     :primary_outcome
     (list :id "reviewer_acceptance" :label label)
     :missing_data []
     :abstentions [])))

(defun canary-b--run-condition (condition-id output-directory source-checks)
  "Run one frozen CONDITION-ID and write its evidence below OUTPUT-DIRECTORY."
  (let* ((condition-directory
          (expand-file-name condition-id output-directory))
         (runtime-directory
          (expand-file-name "runtime" condition-directory))
         (database (expand-file-name "superchat.db" runtime-directory))
         (canary-b--condition-id condition-id)
         (canary-b--prompt-snapshots nil)
         (canary-b--model-calls nil)
         (superchat-data-directory runtime-directory)
         (superchat-db--connection nil)
         (superchat-db--path nil)
         (superchat-runtime--runs (make-hash-table :test #'equal))
         (superchat-workspace--registry nil)
         (superchat-workspace--artifact-counter 0)
         (superchat--subagent-running nil)
         (superchat-subagent-timeout nil)
         (superchat-closure-terminal-guard-enabled t)
         instance-id view steps sessions all-events closure-evidence
         artifacts explicit-reads reviewer-artifact reviewer-content
         reviewer-reads outcome gates)
    (make-directory runtime-directory t)
    (let ((default-directory canary-b--root))
      (superchat-db-open database)
      (unwind-protect
          (cl-letf (((symbol-function 'superchat--execute-llm-query)
                     #'canary-b--prepare-query)
                    ((symbol-function 'superchat--subagent-prepare-tools)
                     #'canary-b--prepare-tools)
                    ((symbol-function 'superchat--subagent-refresh-panel)
                     #'ignore)
                    ((symbol-function 'superchat--update-status) #'ignore)
                    ((symbol-function 'superchat--llm-generate-answer)
                     #'canary-b--scripted-model))
            (setq instance-id
                  (superchat-research-workflow
                   (plist-get canary-b--manifest :task_input))))
        (superchat-db-close)))
    (setq view (superchat-research-workflow-view instance-id)
          steps (plist-get view :steps)
          sessions (cons instance-id
                         (mapcar (lambda (step) (plist-get step :actor-id))
                                 steps))
          all-events (apply #'append (mapcar #'canary-b--events sessions))
          closure-evidence
          (mapcar
           (lambda (step)
             (canary-b--closure-summary (plist-get step :actor-id)
                                        (plist-get step :run-id)))
           steps)
          artifacts
          (apply
           #'append
           (mapcar
            (lambda (step)
              (mapcar
               (lambda (artifact)
                 (append (copy-sequence artifact)
                         (list :producer-run-id (plist-get step :run-id)
                               :producer-actor-id
                               (plist-get step :actor-id))))
               (plist-get step :artifacts)))
            steps))
          canary-b--prompt-snapshots
          (nreverse canary-b--prompt-snapshots)
          canary-b--model-calls (nreverse canary-b--model-calls))
    (dolist (call canary-b--model-calls)
      (when (equal "workspace_read" (plist-get call :tool_name))
        (let* ((artifact-id (car (plist-get call :arguments)))
               (event (canary-b--read-event
                       all-events (plist-get call :run_id) artifact-id)))
          (when event
            (push (list :consumer_run_id (plist-get call :run_id)
                        :consumer_role (plist-get call :role)
                        :artifact_id artifact-id
                        :event (canary-b--event-reference event))
                  explicit-reads)))))
    (setq explicit-reads (nreverse explicit-reads)
          reviewer-artifact
          (cl-find "reviewer" artifacts
                   :key (lambda (artifact) (plist-get artifact :role))
                   :test #'equal)
          reviewer-content
          (and reviewer-artifact
               (superchat-workspace-read
                (plist-get reviewer-artifact :artifact-id)
                (plist-get reviewer-artifact :workspace-id)
                (plist-get reviewer-artifact :revision)))
          reviewer-reads
          (cl-remove-if-not
           (lambda (read) (equal "reviewer"
                                 (plist-get read :consumer_role)))
           explicit-reads)
          outcome
          (append
           (list :outcome_record_id
                 (format "%s-%s-outcome"
                         (file-name-nondirectory
                          (directory-file-name output-directory))
                         condition-id)
                 :experiment_id
                 (plist-get canary-b--manifest :experiment_id)
                 :condition_id condition-id
                 :research_instance_id instance-id
                 :rubric_id
                 (plist-get (plist-get canary-b--manifest :outcome)
                            :rubric_id)
                 :rubric_sha256
                 (plist-get (plist-get canary-b--manifest :outcome)
                            :rubric_sha256)
                 :evaluator_id
                 (plist-get (plist-get canary-b--manifest :outcome)
                            :evaluator_id)
                 :evaluator_version
                 (plist-get (plist-get canary-b--manifest :outcome)
                            :evaluator_version)
                 :blinding "assignment-hidden-from-evaluator"
                 :evaluated_at
                 (format-time-string "%Y-%m-%dT%H:%M:%S.%3NZ" nil t))
           (canary-b--evaluate-outcome
            reviewer-content reviewer-artifact reviewer-reads)))
    (let* ((expected-roles
            '(("collector") ("analyst" "collector")
              ("reviewer" "collector" "analyst")))
           (prior-pass
            (and (= 3 (length canary-b--prompt-snapshots))
                 (cl-every
                  (lambda (expected)
                    (let* ((role (car expected))
                           (snapshot
                            (cl-find role canary-b--prompt-snapshots
                                     :key (lambda (item)
                                            (plist-get item :role))
                                     :test #'equal)))
                      (and snapshot
                           (equal (cdr expected)
                                  (canary-b--reference-roles
                                   (plist-get snapshot :model_prompt)))
                           (equal
                            (plist-get snapshot :system_prompt_sha256)
                            (plist-get
                             snapshot :observed_system_prompt_sha256))
                           (equal
                            (plist-get snapshot :target_model)
                            (plist-get
                             (plist-get canary-b--manifest :prior)
                             :model_id))
                           (equal
                            (plist-get snapshot :prepared_tool_names)
                            (canary-b--tool-names
                             (plist-get
                              (plist-get canary-b--manifest :prior)
                              :offered_tools))))))
                  expected-roles)))
           (execution-pass
            (and (= 3 (length closure-evidence))
                 (cl-every
                  (lambda (item)
                    (and (equal "valid" (plist-get item :trace_verdict))
                         (equal "proved"
                                (plist-get item :terminal_verdict))
                         (equal "completed"
                                (plist-get item :terminal_kind))))
                  closure-evidence)
                 (not (cl-find "tool.failed" all-events
                               :key (lambda (event)
                                      (plist-get event :type))
                               :test #'equal))))
           (artifact-pass
            (and (= 3 (length artifacts))
                 (= 3 (length explicit-reads))
                 (cl-every
                  (lambda (artifact)
                    (and (stringp (plist-get artifact :producer-run-id))
                         (eq 'deliver
                             (plist-get artifact :delivery-decision))
                         (plist-get artifact :available)))
                  artifacts)))
           (outcome-pass
            (and (equal
                  (plist-get outcome :rubric_sha256)
                  (canary-b--file-sha256
                   (expand-file-name
                    (plist-get (plist-get canary-b--manifest :outcome)
                               :rubric_path)
                    canary-b--root)))
                 (equal 3 (length (plist-get outcome :criteria)))
                 (member (plist-get
                          (plist-get outcome :primary_outcome) :label)
                         '("accept" "revise" "reject")))))
      (setq gates
            (list
             (canary-b--gate
              "prior" (if prior-pass "pass" "blocked")
              (list :source_snapshots source-checks
                    :prompt_snapshots canary-b--prompt-snapshots))
             (canary-b--gate
              "execution" (if execution-pass "pass" "blocked")
              closure-evidence)
             (canary-b--gate
              "artifact" (if artifact-pass "pass" "blocked")
              (list :artifacts (length artifacts)
                    :explicit_consumers (length explicit-reads)))
             (canary-b--gate
              "outcome" (if outcome-pass "pass" "blocked")
              (list :outcome_record_id
                    (plist-get outcome :outcome_record_id)
                    :primary_outcome
                    (plist-get outcome :primary_outcome))))))
    (let* ((evidence-path
            (expand-file-name "evidence-bundle.json" condition-directory))
           (outcome-path
            (expand-file-name "outcome-record.json" condition-directory))
           (identity
            (list :condition_id condition-id
                  :research_instance_id instance-id
                  :runtime_database database
                  :run_ids (mapcar (lambda (step) (plist-get step :run-id))
                                   steps)
                  :actor_ids
                  (mapcar (lambda (step) (plist-get step :actor-id)) steps))))
      (canary-b--write-json
       evidence-path
       (list :identity identity
             :prompt_fingerprint_interpreter "reference-role-v0"
             :prompt_snapshots canary-b--prompt-snapshots
             :observable_model_tool_calls canary-b--model-calls
             :tape_sessions
             (mapcar
              (lambda (session-id)
                (let ((events (canary-b--events session-id)))
                  (list :session_id session-id
                        :event_count (length events)
                        :events
                        (mapcar #'canary-b--event-reference events))))
              sessions)
             :closure closure-evidence
             :artifacts
             (mapcar
              (lambda (artifact)
                (list :artifact_id (plist-get artifact :artifact-id)
                      :uri (plist-get artifact :uri)
                      :revision (plist-get artifact :revision)
                      :role (plist-get artifact :role)
                      :producer_run_id
                      (plist-get artifact :producer-run-id)
                      :producer_actor_id
                      (plist-get artifact :producer-actor-id)
                      :delivery_decision
                      (symbol-name
                       (plist-get artifact :delivery-decision))
                      :available (and (plist-get artifact :available) t)))
              artifacts)
             :explicit_consumers explicit-reads
             :gates gates))
      (canary-b--write-json outcome-path outcome)
      (list :condition_id condition-id
            :identity identity
            :prompt_snapshots canary-b--prompt-snapshots
            :gates gates
            :outcome outcome
            :evidence_bundle evidence-path
            :outcome_record outcome-path))))

(defun canary-b--condition-gate-pass-p (result gate-name)
  "Return non-nil when RESULT's GATE-NAME verdict is pass."
  (equal "pass"
         (plist-get
          (cl-find gate-name (plist-get result :gates)
                   :key (lambda (gate) (plist-get gate :name))
                   :test #'equal)
          :verdict)))

(defun canary-b--snapshot (result role)
  "Return ROLE's Prompt snapshot from condition RESULT."
  (cl-find role (plist-get result :prompt_snapshots)
           :key (lambda (snapshot) (plist-get snapshot :role))
           :test #'equal))

(defun canary-b--comparison-closure (baseline intervention)
  "Purely judge frozen BASELINE and INTERVENTION evidence."
  (let* ((roles '("collector" "analyst" "reviewer"))
         (condition-gates-pass
          (cl-every
           (lambda (gate-name)
             (and (canary-b--condition-gate-pass-p baseline gate-name)
                  (canary-b--condition-gate-pass-p intervention gate-name)))
           '("prior" "execution" "artifact" "outcome")))
         (base-prompts-equal
          (cl-every
           (lambda (role)
             (equal
              (canary-b--canonical-prompt
               (plist-get (canary-b--snapshot baseline role)
                          :workflow_prompt))
              (canary-b--canonical-prompt
               (plist-get (canary-b--snapshot intervention role)
                          :workflow_prompt))))
           roles))
         (baseline-clean
          (not (cl-some
                (lambda (snapshot)
                  (plist-get snapshot :intervention_applied))
                (plist-get baseline :prompt_snapshots))))
         (intervention-only-reviewer
          (equal '("reviewer")
                 (mapcar
                  (lambda (snapshot) (plist-get snapshot :role))
                  (cl-remove-if-not
                   (lambda (snapshot)
                     (plist-get snapshot :intervention_applied))
                   (plist-get intervention :prompt_snapshots)))))
         (instruction
          (plist-get
           (plist-get (canary-b--condition "intervention") :intervention)
           :instruction))
         (instruction-hash
          (plist-get
           (plist-get (canary-b--condition "intervention") :intervention)
           :instruction_sha256))
         (instruction-matches
          (and (equal instruction-hash
                      (canary-b--sha256-string instruction))
               (equal instruction-hash
                      (plist-get
                       (canary-b--snapshot intervention "reviewer")
                       :intervention_sha256))))
         (outcome-protocol-equal
          (and
           (equal (plist-get (plist-get baseline :outcome) :rubric_sha256)
                  (plist-get (plist-get intervention :outcome)
                             :rubric_sha256))
           (equal (plist-get (plist-get baseline :outcome) :evaluator_id)
                  (plist-get (plist-get intervention :outcome)
                             :evaluator_id))
           (equal (plist-get (plist-get baseline :outcome)
                             :evaluator_version)
                  (plist-get (plist-get intervention :outcome)
                             :evaluator_version))))
         (passed
          (and condition-gates-pass base-prompts-equal baseline-clean
               intervention-only-reviewer instruction-matches
               outcome-protocol-equal)))
    (list
     :verdict (if passed "pass" "blocked")
     :claim_scope "comparison-infrastructure-only"
     :effectiveness_claim "not_evaluated"
     :learning_claim "prohibited"
     :evidence
     (list
      :condition_gates_pass (and condition-gates-pass t)
      :semantic_prior_equivalence (and base-prompts-equal t)
      :prompt_fingerprint_interpreter "reference-role-v0"
      :baseline_intervention_absent (and baseline-clean t)
      :intervention_only_reviewer (and intervention-only-reviewer t)
      :intervention_instruction_sha256 instruction-hash
      :intervention_instruction_matches (and instruction-matches t)
      :outcome_protocol_equal (and outcome-protocol-equal t)
      :observed_primary_outcomes
      (list
       :baseline
       (plist-get (plist-get (plist-get baseline :outcome)
                             :primary_outcome) :label)
       :intervention
       (plist-get (plist-get (plist-get intervention :outcome)
                             :primary_outcome) :label))))))

(defun canary-b--write-gap-report (path identity gates gaps)
  "Write Canary B GATES and GAPS to PATH."
  (with-temp-file path
    (insert "# Auditability Canary B — Evidence Gap Report\n\n")
    (insert (format "- Experiment: `%s`\n"
                    (plist-get identity :experiment_id)))
    (insert (format "- Manifest: `%s`\n"
                    (plist-get identity :manifest_sha256)))
    (insert (format "- Attempt: `%s`\n\n"
                    (plist-get identity :attempt_id)))
    (insert "## Gate verdicts\n\n| Gate | Verdict |\n|---|---|\n")
    (dolist (gate gates)
      (insert (format "| %s | `%s` |\n"
                      (plist-get gate :name)
                      (plist-get gate :verdict))))
    (insert "\n## Evidence gaps\n\n")
    (if gaps
        (dolist (gap gaps)
          (insert (format "- `%s`: %s\n"
                          (plist-get gap :gate)
                          (plist-get gap :impact))))
      (insert "None.\n"))
    (insert "\n## Decision\n\n")
    (if (cl-every (lambda (gate)
                    (equal "pass" (plist-get gate :verdict)))
                  gates)
        (insert
         "Comparison infrastructure is valid for this frozen pair. "
         "Effectiveness was not evaluated, and no learning claim is permitted.\n")
      (insert
       "Comparison Closure is blocked or invalid. No causal or learning "
       "claim is permitted.\n"))))

(defun canary-b--main ()
  "Run the frozen paired Canary B and persist all external evidence."
  (setq canary-b--manifest (canary-b--manifest-read))
  (unless (equal "frozen" (plist-get canary-b--manifest :status))
    (error "Canary B manifest is not frozen"))
  (let* ((source-checks (canary-b--source-checks))
         (attempt-id
          (format "attempt-%s"
                  (format-time-string "%Y%m%dT%H%M%S%3N" nil t)))
         (output-directory
          (expand-file-name (concat "runs/" attempt-id) canary-b--directory))
         (manifest-sha256 (canary-b--file-sha256 canary-b--manifest-path))
         (baseline
          (canary-b--run-condition
           "baseline" output-directory source-checks))
         (intervention
          (canary-b--run-condition
           "intervention" output-directory source-checks))
         (comparison
          (canary-b--comparison-closure baseline intervention))
         (gate-names '("prior" "execution" "artifact" "outcome"))
         (gates
          (append
           (mapcar
            (lambda (name)
              (canary-b--gate
               name
               (if (and (canary-b--condition-gate-pass-p baseline name)
                        (canary-b--condition-gate-pass-p intervention name))
                   "pass" "blocked")
               (list :baseline
                     (canary-b--condition-gate-pass-p baseline name)
                     :intervention
                     (canary-b--condition-gate-pass-p intervention name))))
            gate-names)
           (list (canary-b--gate
                  "comparison" (plist-get comparison :verdict)
                  (plist-get comparison :evidence)))))
         (gaps
          (mapcar
           (lambda (gate)
             (list :gate (plist-get gate :name)
                   :impact "cannot_claim_comparison_infrastructure_valid"))
           (cl-remove-if
            (lambda (gate) (equal "pass" (plist-get gate :verdict)))
            gates)))
         (identity
          (list :experiment_id
                (plist-get canary-b--manifest :experiment_id)
                :attempt_id attempt-id
                :manifest_sha256 manifest-sha256
                :output_directory output-directory))
         (record
          (list :identity identity
                :conditions
                (list
                 (list :condition_id "baseline"
                       :identity (plist-get baseline :identity)
                       :evidence_bundle (plist-get baseline :evidence_bundle)
                       :outcome_record (plist-get baseline :outcome_record))
                 (list :condition_id "intervention"
                       :identity (plist-get intervention :identity)
                       :evidence_bundle
                       (plist-get intervention :evidence_bundle)
                       :outcome_record
                       (plist-get intervention :outcome_record)))
                :comparison_closure comparison
                :gates gates
                :gaps gaps)))
    (canary-b--write-json
     (expand-file-name "comparison-record.json" output-directory) record)
    (canary-b--write-gap-report
     (expand-file-name "evidence-gap-report.md" output-directory)
     identity gates gaps)
    (copy-file canary-b--manifest-path
               (expand-file-name "manifest-v0.json" output-directory))
    (copy-file (or load-file-name buffer-file-name)
               (expand-file-name "run-v0.el" output-directory))
    (princ "\n=== Auditability Canary B ===\n")
    (pp record)
    (if (cl-every (lambda (gate)
                    (equal "pass" (plist-get gate :verdict)))
                  gates)
        (princ (format "\nCANARY_B_PASS output=%s\n" output-directory))
      (error "CANARY_B_BLOCKED output=%s" output-directory))))

(canary-b--main)

;;; run.el ends here
