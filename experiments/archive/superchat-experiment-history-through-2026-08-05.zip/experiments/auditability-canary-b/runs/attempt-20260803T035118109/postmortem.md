# Canary B v0 post-run audit

The original v0 outputs in this directory are preserved unchanged. A manual
audit found two experiment-harness defects; no Runtime defect was required to
explain the blocked comparison.

1. `reference-role-v0` removed Artifact identities but retained the Team and
   Actor IDs that the frozen manifest already classified as expected execution
   variance. It therefore reported `semantic_prior_equivalence=false` for two
   otherwise equivalent Workflow prompts.
2. The projected Reviewer role was a symbol while the harness searched for a
   string. The Outcome target became missing, yet the v0 Outcome gate failed to
   require either a target link or an explicit missing-data record.

Consequently, v0's Outcome `pass` must be treated as `invalid`; Comparison
remains `blocked`. Manifest v1 fixes only the experiment decoder, canonical
fingerprint, and gate requirement. Tape, Closure, Authority, Workflow, and
Workspace semantics remain unchanged.
