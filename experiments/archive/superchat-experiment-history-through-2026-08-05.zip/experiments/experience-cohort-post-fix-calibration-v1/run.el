;;; run.el --- Post-fix Calibration runner -*- lexical-binding: t; -*-

;;; Commentary:

;; Dedicated experiment runner.  It reuses the frozen Cohort v0 Research and
;; Agent Reach surfaces, but writes every new fact under a new experiment and
;; Runtime data directory.  Old Cohort Runs are never resumed or imported.

;;; Code:

(require 'cl-lib)
(require 'json)
(require 'subr-x)

(load "/Users/chenyibin/Documents/emacs/package/superchat/experiments/experience-cohort-v0/run-batch.el"
      nil nil t)

(defconst superchat-post-fix-calibration-v1--directory
  "/Users/chenyibin/Documents/emacs/package/superchat/experiments/experience-cohort-post-fix-calibration-v1/")

(defconst superchat-post-fix-calibration-v1--root
  "/Users/chenyibin/.agent-reach/superchat/experience-cohort-post-fix-calibration-v1/")

(defconst superchat-post-fix-calibration-v1--manifest-path
  (expand-file-name "manifest.json" superchat-post-fix-calibration-v1--directory))

(defconst superchat-post-fix-calibration-v1--assignments-path
  (expand-file-name "assignments.json" superchat-post-fix-calibration-v1--directory))

(defconst superchat-post-fix-calibration-v1--launch-record-path
  (expand-file-name "launch-record.json" superchat-post-fix-calibration-v1--directory))

(defconst superchat-post-fix-calibration-v1--prompt-record-path
  (expand-file-name "prompt-snapshots.json" superchat-post-fix-calibration-v1--directory))

(defconst superchat-post-fix-calibration-v1--deliverable-guard-path
  (expand-file-name "deliverable-guard-v1.txt"
                    superchat-post-fix-calibration-v1--directory))

(defvar superchat-post-fix-calibration-v1--launches nil)
(defvar superchat-post-fix-calibration-v1--prompt-snapshots nil)

(setq superchat-data-directory
      (expand-file-name "runtime/" superchat-post-fix-calibration-v1--root)
      superchat-llm-backend
      (make-llm-ollama :chat-model "qwen3.6:latest")
      superchat-llm-model nil
      superchat-response-timeout 7200
      superchat-subagent-timeout 21600)

(defun superchat-post-fix-calibration-v1--read-json (path)
  "Read PATH as a plist-backed JSON object."
  (with-temp-buffer
    (insert-file-contents path)
    (json-parse-buffer :object-type 'plist :array-type 'list
                       :null-object nil :false-object json-false)))

(defun superchat-post-fix-calibration-v1--write-json (path value)
  "Write VALUE as JSON to PATH."
  (make-directory (file-name-directory path) t)
  (with-temp-file path
    (insert (json-encode value))
    (insert "\n")))

(defun superchat-post-fix-calibration-v1--read-file (path)
  "Return PATH contents without interpretation."
  (with-temp-buffer
    (insert-file-contents path)
    (buffer-string)))

(defun superchat-post-fix-calibration-v1--sha256-file (path)
  "Return protocol-prefixed SHA-256 for PATH."
  (with-temp-buffer
    (set-buffer-multibyte nil)
    (insert-file-contents-literally path)
    (concat "sha256:" (secure-hash 'sha256 (current-buffer)))))

(defun superchat-post-fix-calibration-v1--sha256-string (value)
  "Return protocol-prefixed SHA-256 for VALUE."
  (concat "sha256:" (secure-hash 'sha256 (or value ""))))

(defun superchat-post-fix-calibration-v1--harden-stage-prompt (prompt)
  "Append the frozen deliverable guard to Research stage PROMPT."
  (concat prompt "\n\n"
          (string-trim-right
           (superchat-post-fix-calibration-v1--read-file
            superchat-post-fix-calibration-v1--deliverable-guard-path))))

(defun superchat-post-fix-calibration-v1--manifest ()
  "Return the frozen Post-fix Calibration Manifest."
  (superchat-post-fix-calibration-v1--read-json
   superchat-post-fix-calibration-v1--manifest-path))

(defun superchat-post-fix-calibration-v1--assignments ()
  "Return the four frozen Calibration assignments."
  (plist-get
   (superchat-post-fix-calibration-v1--read-json
    superchat-post-fix-calibration-v1--assignments-path)
   :assignments))

(defun superchat-post-fix-calibration-v1--verify-inputs ()
  "Fail unless every frozen experiment input still matches its hash."
  (let ((manifest (superchat-post-fix-calibration-v1--manifest)))
    (unless (equal "calibration-authorized" (plist-get manifest :status))
      (error "Post-fix Calibration is not authorized"))
    (unless (= 4 (length (superchat-post-fix-calibration-v1--assignments)))
      (error "Post-fix Calibration requires exactly four assignments"))
    (when (cl-find-if
           (lambda (assignment)
             (not (equal "calibration" (plist-get assignment :split))))
           (superchat-post-fix-calibration-v1--assignments))
      (error "Non-calibration assignment reached the runner"))
    (dolist (input (plist-get manifest :frozen_inputs))
      (let* ((path (expand-file-name
                    (plist-get input :path)
                    "/Users/chenyibin/Documents/emacs/package/superchat/"))
             (actual (and (file-readable-p path)
                          (superchat-post-fix-calibration-v1--sha256-file path))))
        (unless (equal actual (plist-get input :sha256))
          (error "Frozen input changed or missing: %s" path))))
    manifest))

(defun superchat-post-fix-calibration-v1--role (prompt)
  "Return the Research role encoded in PROMPT."
  (when (string-match "\\[research/\\(collector\\|analyst\\|reviewer\\)\\]"
                      (or prompt ""))
    (match-string 1 prompt)))

(defun superchat-post-fix-calibration-v1--assignment-id (prompt)
  "Return the frozen assignment identity encoded in PROMPT."
  (when (string-match "assignment \\([^;\n]+\\);" (or prompt ""))
    (match-string 1 prompt)))

(defun superchat-post-fix-calibration-v1--tool-names (tools)
  "Normalize model-facing TOOLS to ordered names."
  (mapcar (lambda (tool)
            (cond ((stringp tool) tool)
                  ((symbolp tool) (symbol-name tool))
                  ((listp tool) (plist-get tool :name))
                  (t (format "%s" tool))))
          tools))

(defun superchat-post-fix-calibration-v1--write-prompts ()
  "Persist observed model-facing prompt snapshots."
  (superchat-post-fix-calibration-v1--write-json
   superchat-post-fix-calibration-v1--prompt-record-path
   (list :experiment_id "experience-cohort-post-fix-calibration-v1"
         :snapshot_count
         (length superchat-post-fix-calibration-v1--prompt-snapshots)
         :snapshots
         (vconcat (reverse superchat-post-fix-calibration-v1--prompt-snapshots)))))

(defun superchat-post-fix-calibration-v1--capture-query (original turn &rest args)
  "Call ORIGINAL with TURN and ARGS, retaining the actual model-facing query."
  (let* ((result (apply original turn args))
         (prompt (plist-get result :prompt))
         (role (superchat-post-fix-calibration-v1--role prompt))
         (assignment-id
          (superchat-post-fix-calibration-v1--assignment-id prompt)))
    (when (and role assignment-id)
      (let ((snapshot
             (list :assignment_id assignment-id
                   :role role
                   :actor_id (and (boundp 'superchat--session-id)
                                  superchat--session-id)
                   :captured_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
                   :model_prompt prompt
                   :model_prompt_sha256
                   (superchat-post-fix-calibration-v1--sha256-string prompt)
                   :system_prompt (plist-get result :system-prompt)
                   :system_prompt_sha256
                   (superchat-post-fix-calibration-v1--sha256-string
                    (plist-get result :system-prompt))
                   :target_model
                   (or (plist-get result :target-model) "qwen3.6:latest")
                   :prepared_tool_names
                   (vconcat
                    (superchat-post-fix-calibration-v1--tool-names
                     (plist-get result :tools))))))
        (setq superchat-post-fix-calibration-v1--prompt-snapshots
              (cons snapshot
                    (cl-remove-if
                     (lambda (old)
                       (and (equal assignment-id
                                   (plist-get old :assignment_id))
                            (equal role (plist-get old :role))))
                     superchat-post-fix-calibration-v1--prompt-snapshots)))
        (superchat-post-fix-calibration-v1--write-prompts)))
    result))

(defun superchat-post-fix-calibration-v1--load-records ()
  "Restore experiment-only launch and prompt records after daemon restart."
  (when (file-readable-p superchat-post-fix-calibration-v1--launch-record-path)
    (setq superchat-post-fix-calibration-v1--launches
          (reverse
           (plist-get
            (superchat-post-fix-calibration-v1--read-json
             superchat-post-fix-calibration-v1--launch-record-path)
            :launches))))
  (when (file-readable-p superchat-post-fix-calibration-v1--prompt-record-path)
    (setq superchat-post-fix-calibration-v1--prompt-snapshots
          (reverse
           (plist-get
            (superchat-post-fix-calibration-v1--read-json
             superchat-post-fix-calibration-v1--prompt-record-path)
            :snapshots)))))

(defun superchat-post-fix-calibration-v1--write-launches ()
  "Persist all new Post-fix Calibration launch identities."
  (superchat-post-fix-calibration-v1--write-json
   superchat-post-fix-calibration-v1--launch-record-path
   (list :experiment_id "experience-cohort-post-fix-calibration-v1"
         :manifest_sha256
         (superchat-post-fix-calibration-v1--sha256-file
          superchat-post-fix-calibration-v1--manifest-path)
         :status "runs-started"
         :launch_count (length superchat-post-fix-calibration-v1--launches)
         :launches
         (vconcat (reverse superchat-post-fix-calibration-v1--launches))
         :historical_runs_imported json-false
         :held_out_used json-false
         :effectiveness_claim "not_evaluated"
         :learning_claim "prohibited")))

(defun superchat-post-fix-calibration-v1--assignment (run-index)
  "Return frozen assignment RUN-INDEX."
  (or (cl-find run-index
               (superchat-post-fix-calibration-v1--assignments)
               :key (lambda (assignment) (plist-get assignment :run_index)))
      (error "Unknown Post-fix Calibration index: %s" run-index)))

(defun superchat-post-fix-calibration-v1--launch (run-index)
  "Return persisted launch RUN-INDEX, or nil."
  (cl-find run-index superchat-post-fix-calibration-v1--launches
           :key (lambda (launch) (plist-get launch :run_index))))

(defun superchat-post-fix-calibration-v1--settled-p (launch)
  "Return non-nil when LAUNCH cannot advance without a new decision."
  (let* ((view (superchat-research-workflow-view
                (plist-get launch :instance_id)))
         (steps (plist-get view :steps)))
    (or (eq 'completed (plist-get view :status))
        (cl-some (lambda (step)
                   (memq (plist-get step :resume-decision)
                         '(manual-review stop)))
                 steps))))

(defun superchat-post-fix-calibration-v1-start (run-index)
  "Start one new frozen Calibration RUN-INDEX."
  (interactive "nCalibration index (1-4): ")
  (superchat-post-fix-calibration-v1--verify-inputs)
  (when (superchat-post-fix-calibration-v1--launch run-index)
    (error "Calibration index already started: %s" run-index))
  (when-let* ((previous (car superchat-post-fix-calibration-v1--launches)))
    (unless (superchat-post-fix-calibration-v1--settled-p previous)
      (error "Previous Calibration index is still running: %s"
             (plist-get previous :run_index))))
  (let* ((assignment (superchat-post-fix-calibration-v1--assignment run-index))
         (default-directory superchat-post-fix-calibration-v1--root)
         (superchat--active-authority-policy "default")
         (instance-id
          (superchat-research-workflow
           (superchat-experience-cohort-v0--batch-query assignment)))
         (view (superchat-research-workflow-view instance-id))
         (collector (car (plist-get view :steps)))
         (launch
          (list :run_index run-index
                :assignment_id (plist-get assignment :assignment_id)
                :family (plist-get assignment :family)
                :instance_id instance-id
                :actor_id (plist-get collector :actor-id)
                :run_id (plist-get collector :run-id)
                :started_at (format-time-string "%Y-%m-%dT%H:%M:%S%z"))))
    (push launch superchat-post-fix-calibration-v1--launches)
    (superchat-post-fix-calibration-v1--write-launches)
    launch))

(defun superchat-post-fix-calibration-v1-status ()
  "Return current Workflow views for all launched Calibration tasks."
  (interactive)
  (mapcar
   (lambda (launch)
     (list :run_index (plist-get launch :run_index)
           :assignment_id (plist-get launch :assignment_id)
           :view
           (superchat-research-workflow-view
            (plist-get launch :instance_id))))
   (reverse superchat-post-fix-calibration-v1--launches)))

(make-directory superchat-post-fix-calibration-v1--root t)
(superchat-post-fix-calibration-v1--verify-inputs)
(superchat-post-fix-calibration-v1--load-records)
(unless (advice-member-p
         #'superchat-post-fix-calibration-v1--harden-stage-prompt
         'superchat-research-workflow--stage-prompt)
  (advice-add 'superchat-research-workflow--stage-prompt :filter-return
              #'superchat-post-fix-calibration-v1--harden-stage-prompt))
(unless (advice-member-p #'superchat-post-fix-calibration-v1--capture-query
                         'superchat--execute-llm-query)
  (advice-add 'superchat--execute-llm-query :around
              #'superchat-post-fix-calibration-v1--capture-query))

(provide 'superchat-post-fix-calibration-v1-run)

;;; run.el ends here
