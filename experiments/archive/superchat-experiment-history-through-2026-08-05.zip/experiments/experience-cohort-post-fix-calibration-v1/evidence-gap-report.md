# Post-fix Calibration v1 — Evidence Gap Report

Generated after all four preregistered first attempts settled on 2026-08-03.

## Verdict

`calibration_gate = blocked` (`0/4`). Discovery remains unauthorized and
held-out remains sealed. No effectiveness, Pattern, or Learning claim is made.

## Frozen application change reached the model

The only preregistered application change was
`research-deliverable-guard-v1`, appended to every final model-facing Research
stage prompt. All four observed prompt snapshots contained the exact guard
once. Their target model, system-prompt hash, and ordered tool surface matched
the frozen Prior.

This establishes intervention delivery, not intervention effectiveness.
Comparison Closure was not part of this Calibration.

## What remained valid

- Four new Workflow, Session, Turn, Run, Actor, and Workspace identity sets
  were created; parent Calibration Runs and Artifacts were not imported.
- Four Collector stages executed. All four traces were `valid`, all four
  durable terminal judgments were `proved/completed`, and all four Tool
  identity judgments passed.
- The Collectors produced 72 Tool lifecycle events for 24 Tool requests. No
  Tool event had invalid Run, Turn, or Actor identity, and no `tool.failed`
  event occurred.
- Outcome Closure passed for all four tasks through the preregistered
  missing-final-Artifact rule. All four primary outcomes are `reject`.

## Why the 4/4 Gate failed

| Assignment | Last executed stage | Artifact result | Workflow result |
|---|---|---|---|
| `cal-systems-01` | Collector | `artifact_absent` | `manual-review` |
| `cal-security-01` | Collector | `artifact_absent` | `manual-review` |
| `cal-science-01` | Collector | `artifact_absent` | `manual-review` |
| `cal-standards-01` | Collector | `artifact_absent` | `manual-review` |

No Collector requested `workspace_publish`. Because the Workflow correctly
required a deliverable Artifact before `advance`, no Analyst or Reviewer stage
started. Prior and Execution Closure are blocked only at the complete-sample
level: the eight downstream prompt/trace sets do not exist. The four executed
Collector Prior snapshots and execution traces are valid.

Observed Tool requests were:

- `cal-systems-01`: one search, three reads, two `team_task` calls.
- `cal-security-01`: one `workspace_info`, two searches, three reads.
- `cal-science-01`: one `workspace_info`, four searches, five reads.
- `cal-standards-01`: one `workspace_info`, one search.

The current failure classification is application contract compliance:
`run.completed` with `artifact_absent`. It is not Runtime identity failure and
not `artifact_present_provenance_invalid`.

## Interpretation boundary

The four attempts show that this prompt-only guard did not produce a complete
Calibration sample in the observed executions. They do not establish a causal
effect estimate, general guard ineffectiveness, or any Learning conclusion.
The v0 and v1 evidence sets remain separate historical facts.

Option B, a bounded missing-Artifact recovery policy, was not activated. Any
such policy changes Research Workflow application orchestration and requires a
new preregistered experiment identity; it must not be applied retroactively to
these Runs.

## Integrity

- All 14 frozen input hashes matched after execution.
- All generated JSON records parsed and passed the v1 evidence assertions.
- Stopped Runtime SQLite `PRAGMA integrity_check` returned `ok`: 116 Tape rows
  across 8 Sessions.
- Canonical ERT: 575 tests, 560 expected passes, 15 skipped, 0 unexpected.
- `git diff --check` passed.
- The dedicated `superchat-post-fix-calibration-v1` daemon was stopped after
  the final evidence snapshot; the shared Ollama service was not stopped.
