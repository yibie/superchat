# DeepSeek Transport Canary — llm.el 0.31.1

- Strict gate: **pass**
- Transport successes: **4/4**
- Scope: direct non-streaming `llm-chat-async`; no Runtime, tools, retries, Artifacts, or quality scoring.
- Claim boundary: a pass validates only this four-request transport sample.

| Attempt | Status | Latency ms | Failure class | Error |
|---|---:|---:|---|---|
| transport-01 | success | 1749 | — | — |
| transport-02 | success | 1738 | — | — |
| transport-03 | success | 1837 | — | — |
| transport-04 | success | 1698 | — | — |
