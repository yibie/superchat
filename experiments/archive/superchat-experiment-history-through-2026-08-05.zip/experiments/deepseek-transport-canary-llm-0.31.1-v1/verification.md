# Verification

- Replication configuration matches v0 for provider, model, prompt, reasoning, tools, retries, timeouts, and llm package identity.
- v0 and v1 Runner SHA-256: `1d2bdf23996ab787a94b1364546a7408fd199a36d4aea99aca981ed7d1afc746`.
- Loaded `llm.el`: 0.31.1 from `/Users/chenyibin/.config/nova-emacs/elpa/llm-0.31.1/llm.elc`.
- Installed `llm.el` source SHA-256: `fe169df78471fad559ddea32009f6e00dee53b570b980a58c5d3ed68a45e0dd6`.
- Live replication: 4/4 success, 0 transport errors, strict gate `pass`.
- Latencies: 1749, 1738, 1837, and 1698 ms.
- Independent record check passed; no response plaintext was persisted.

Across v0 and v1, the observed result is 8/8 successful minimal transport
requests.  This does not prove that intermittent TLS failures are eliminated
and makes no Agent, effectiveness, or learning claim.

The already-running GUI Emacs process still has llm 0.31.0 loaded.  These
results come from fresh batch processes that loaded 0.31.1.
