;;; self-check.el --- Collector completion Calibration checks -*- lexical-binding: t; -*-

(require 'superchat-collector-completion-contract-calibration-v0-run)
(require 'superchat-collector-completion-contract-calibration-v0-evidence)

(unless
    (and (= 4 (length
               (superchat-collector-contract-calibration-v0--assignments)))
         (equal
          "Collector completion calibration payload 01: alpha supplied content."
          (plist-get
           (car (superchat-collector-contract-calibration-v0--assignments))
           :payload))
         (string-match-p
          (regexp-quote "collector-cal-01")
          (superchat-collector-contract-calibration-v0--task
           (car (superchat-collector-contract-calibration-v0--assignments))))
         (equal "collector"
                (superchat-collector-contract-calibration-v0--normalize-role
                 'collector))
         (equal "collector"
                (superchat-collector-contract-calibration-v0--normalize-role
                 "collector"))
         (superchat-collector-contract-calibration-v0--same-tool-surface-p
          ["workspace_publish" "workspace_info"])
         (not
          (superchat-collector-contract-calibration-v0--same-tool-surface-p
           ["workspace_publish" "workspace_info" "agent_reach_search"])))
  (error "Collector completion Calibration self-check failed"))

(provide 'superchat-collector-completion-contract-calibration-v0-self-check)

;;; self-check.el ends here
