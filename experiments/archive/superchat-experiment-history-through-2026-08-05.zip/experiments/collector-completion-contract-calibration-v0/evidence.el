;;; evidence.el --- Collector completion Calibration evidence -*- lexical-binding: t; -*-

;;; Commentary:

;; Read-only consumer of the four frozen Runtime histories.  It does not change
;; Tape, Closure, Workspace, or any Run fact.

;;; Code:

(require 'superchat-collector-completion-contract-calibration-v0-run)

(defconst superchat-collector-contract-calibration-v0--report-json-path
  (expand-file-name "calibration-report.json"
                    superchat-collector-contract-calibration-v0--directory))

(defconst superchat-collector-contract-calibration-v0--report-md-path
  (expand-file-name "calibration-report.md"
                    superchat-collector-contract-calibration-v0--directory))

(defconst superchat-collector-contract-calibration-v0--gap-path
  (expand-file-name "evidence-gap-report.md"
                    superchat-collector-contract-calibration-v0--directory))

(defun superchat-collector-contract-calibration-v0--normalize-role (role)
  "Return ROLE as a stable string."
  (if (symbolp role) (symbol-name role) role))

(defun superchat-collector-contract-calibration-v0--same-tool-surface-p (tools)
  "Return non-nil when TOOLS exactly names the frozen surface."
  (and (= (length tools)
          (length superchat-collector-contract-calibration-v0--allowed-tools))
       (null
        (cl-set-exclusive-or
         (append tools nil)
         superchat-collector-contract-calibration-v0--allowed-tools
         :test #'equal))))

(defun superchat-collector-contract-calibration-v0--event-tool-name (event)
  "Return normalized tool name from EVENT."
  (let ((payload (plist-get event :payload)))
    (or (plist-get payload :tool-name)
        (plist-get payload :tool_name))))

(defun superchat-collector-contract-calibration-v0--artifact-view (artifact)
  "Return delivery and content evidence for ARTIFACT."
  (let* ((view (superchat-research-workflow--artifact-view artifact))
         (content
          (and (eq 'deliver (plist-get view :delivery-decision))
               (plist-get view :available)
               (condition-case nil
                   (superchat-workspace-read
                    (plist-get artifact :artifact-id)
                    (plist-get artifact :workspace-id)
                    (plist-get artifact :revision))
                 (error nil)))))
    (append
     view
     (list :run-id (plist-get artifact :run-id)
           :content-sha256
           (and content
                (superchat-collector-contract-calibration-v0--sha256-string
                 content))
           :content content))))

(defun superchat-collector-contract-calibration-v0--interpret
    (prior-pass execution-pass publish-requested publish-completed
                tool-failed artifact-classification payload-matches)
  "Return the frozen interpretation of one sample's evidence."
  (cond
   ((not prior-pass) "prior_evidence_incomplete")
   ((not execution-pass) "execution_evidence_invalid")
   ((zerop publish-requested) "model_did_not_select_workspace_publish")
   ((or (not (= 1 publish-requested))
        (not (= 1 publish-completed))
        (not (zerop tool-failed)))
    "workspace_publish_denied_or_failed")
   ((not (equal "artifact_closure_pass" artifact-classification))
    "artifact_present_provenance_invalid")
   ((not payload-matches) "published_payload_mismatch")
   (t "minimal_collector_contract_closed")))

(defun superchat-collector-contract-calibration-v0--sample
    (assignment launch snapshot)
  "Return closed evidence for one ASSIGNMENT, LAUNCH, and SNAPSHOT."
  (let* ((assignment-id (plist-get assignment :assignment_id))
         (actor-id (plist-get launch :actor_id))
         (run-id (plist-get launch :run_id))
         (workspace-id (plist-get launch :workspace_id))
         (payload (plist-get assignment :payload))
         (events (superchat-tape-replay-events actor-id))
         (run-events
          (cl-remove-if-not
           (lambda (event) (equal run-id (plist-get event :run-id)))
           events))
         (tool-events
          (cl-remove-if-not
           (lambda (event)
             (string-prefix-p "tool." (or (plist-get event :type) "")))
           run-events))
         (publish-requested
          (cl-count-if
           (lambda (event)
             (and (equal "tool.requested" (plist-get event :type))
                  (equal "workspace_publish"
                         (superchat-collector-contract-calibration-v0--event-tool-name
                          event))))
           tool-events))
         (publish-completed
          (cl-count-if
           (lambda (event)
             (and (equal "tool.completed" (plist-get event :type))
                  (equal "workspace_publish"
                         (superchat-collector-contract-calibration-v0--event-tool-name
                          event))))
           tool-events))
         (tool-failed
          (cl-count "tool.failed" tool-events
                    :key (lambda (event) (plist-get event :type))
                    :test #'equal))
         (invalid-tool-identity
          (cl-count-if-not
           (lambda (event)
             (and (equal actor-id (plist-get event :actor-id))
                  (stringp (plist-get event :turn-id))
                  (not (string-empty-p (plist-get event :turn-id)))))
           tool-events))
         (invalid-scope-identity
          (cl-count-if-not
           (lambda (event)
             (and (equal actor-id (plist-get event :actor-id))
                  (equal workspace-id (plist-get event :workspace-id))
                  (equal workspace-id (plist-get event :correlation-id))
                  (null (plist-get event :parent-run-id))))
           run-events))
         (unexpected-tools
          (cl-count-if
           (lambda (event)
             (and (equal "tool.requested" (plist-get event :type))
                  (not (member
                        (superchat-collector-contract-calibration-v0--event-tool-name
                         event)
                        superchat-collector-contract-calibration-v0--allowed-tools))))
           tool-events))
         (well
          (superchat-closure-judge
           (list :kind 'trace-well-formed :run-id run-id) events))
         (terminal
          (superchat-closure-judge
           (list :kind 'durable-run-terminal :run-id run-id) events))
         (artifacts
          (mapcar
           #'superchat-collector-contract-calibration-v0--artifact-view
           (cl-remove-if-not
            (lambda (artifact) (equal run-id (plist-get artifact :run-id)))
            (superchat-workspace-artifacts workspace-id t))))
         (deliverable
          (cl-remove-if-not
           (lambda (artifact)
             (and (eq 'deliver (plist-get artifact :delivery-decision))
                  (plist-get artifact :available)
                  (equal
                   "collector"
                   (superchat-collector-contract-calibration-v0--normalize-role
                    (plist-get artifact :role)))))
           artifacts))
         (artifact-classification
          (cond ((null artifacts) "artifact_absent")
                ((and (= 1 (length artifacts))
                      (= 1 (length deliverable)))
                 "artifact_closure_pass")
                (t "artifact_present_provenance_invalid")))
         (payload-matches
          (and (= 1 (length deliverable))
               (equal payload (plist-get (car deliverable) :content))))
         (prior-pass
          (and snapshot
               (equal assignment-id (plist-get snapshot :assignment_id))
               (equal actor-id (plist-get snapshot :actor_id))
               (equal "qwen3.6:latest" (plist-get snapshot :target_model))
               (string-match-p (regexp-quote assignment-id)
                               (or (plist-get snapshot :model_prompt) ""))
               (string-match-p (regexp-quote payload)
                               (or (plist-get snapshot :model_prompt) ""))
               (superchat-collector-contract-calibration-v0--same-tool-surface-p
                (plist-get snapshot :prepared_tool_names))))
         (execution-pass
          (and (equal 'valid (plist-get well :verdict))
               (equal 'proved (plist-get terminal :verdict))
               (equal 'completed
                      (plist-get (plist-get terminal :judgment)
                                 :terminal-kind))
               (zerop invalid-tool-identity)
               (zerop invalid-scope-identity)
               (zerop unexpected-tools)))
         (publish-pass
          (and (= 1 publish-requested)
               (= 1 publish-completed)
               (zerop tool-failed)))
         (artifact-pass
          (and (equal "artifact_closure_pass" artifact-classification)
               (= 1 (length artifacts))
               (= 1 (length deliverable))
               payload-matches))
         (pass (and prior-pass execution-pass publish-pass artifact-pass))
         (interpretation
          (superchat-collector-contract-calibration-v0--interpret
           prior-pass execution-pass publish-requested publish-completed
           tool-failed artifact-classification payload-matches)))
    (list
     :assignment_id assignment-id
     :actor_id actor-id
     :run_id run-id
     :turn_id (plist-get launch :turn_id)
     :workspace_id workspace-id
     :correlation_id (plist-get launch :correlation_id)
     :parent_run_id nil
     :gates
     (vconcat
      (list (list :name "prior" :verdict (if prior-pass "pass" "blocked"))
            (list :name "execution" :verdict
                  (if execution-pass "pass" "blocked"))
            (list :name "publish" :verdict
                  (if publish-pass "pass" "blocked"))
            (list :name "artifact" :verdict
                  (if artifact-pass "pass" "blocked"))))
     :sample_gate (if pass "pass" "blocked")
     :interpretation interpretation
     :trace_verdict (symbol-name (plist-get well :verdict))
     :terminal_verdict (symbol-name (plist-get terminal :verdict))
     :terminal_kind
     (symbol-name
      (plist-get (plist-get terminal :judgment) :terminal-kind))
     :run_event_count (length run-events)
     :tool_event_count (length tool-events)
     :tool_events_invalid_identity invalid-tool-identity
     :scope_events_invalid_identity invalid-scope-identity
     :unexpected_tool_request_count unexpected-tools
     :workspace_publish_requested publish-requested
     :workspace_publish_completed publish-completed
     :tool_failed_count tool-failed
     :artifact_classification artifact-classification
     :artifact_count (length artifacts)
     :deliverable_count (length deliverable)
     :expected_payload_sha256
     (superchat-collector-contract-calibration-v0--sha256-string payload)
     :payload_matches (if payload-matches t json-false)
     :artifacts
     (vconcat
      (mapcar
       (lambda (artifact)
         (list :artifact_id (plist-get artifact :artifact-id)
               :run_id (plist-get artifact :run-id)
               :workspace_id (plist-get artifact :workspace-id)
               :revision (plist-get artifact :revision)
               :uri (plist-get artifact :uri)
               :role
               (superchat-collector-contract-calibration-v0--normalize-role
                (plist-get artifact :role))
               :delivery_decision
               (symbol-name (plist-get artifact :delivery-decision))
               :available
               (if (plist-get artifact :available) t json-false)
               :content_sha256 (plist-get artifact :content-sha256)))
       artifacts)))))

(defun superchat-collector-contract-calibration-v0-generate-evidence ()
  "Generate the frozen 4/4 Calibration report from durable facts."
  (interactive)
  (unless (equal "settled"
                 (plist-get superchat-collector-contract-calibration-v0--state
                            :status))
    (error "Collector completion Calibration has not settled"))
  (let* ((assignments
          (superchat-collector-contract-calibration-v0--assignments))
         (samples
          (mapcar
           (lambda (assignment)
             (let* ((assignment-id (plist-get assignment :assignment_id))
                    (launch
                     (cl-find assignment-id
                              superchat-collector-contract-calibration-v0--launches
                              :key (lambda (item)
                                     (plist-get item :assignment_id))
                              :test #'equal))
                    (snapshot
                     (cl-find assignment-id
                              superchat-collector-contract-calibration-v0--snapshots
                              :key (lambda (item)
                                     (plist-get item :assignment_id))
                              :test #'equal)))
               (superchat-collector-contract-calibration-v0--sample
                assignment launch snapshot)))
           assignments))
         (pass-count
          (cl-count "pass" samples
                    :key (lambda (sample) (plist-get sample :sample_gate))
                    :test #'equal))
         (pass (and (= 4 (length samples)) (= 4 pass-count)))
         (report
          (list
           :experiment_id "collector-completion-contract-calibration-v0"
           :generated_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
           :manifest_sha256
           (superchat-collector-contract-calibration-v0--sha256-file
            superchat-collector-contract-calibration-v0--manifest-path)
           :required_sample_count 4
           :observed_sample_count (length samples)
           :sample_pass_count pass-count
           :all_samples_required t
           :calibration_gate (if pass "pass" "blocked")
           :repeatability_status
           (if pass "observed-4-of-4" "not-demonstrated")
           :samples (vconcat samples)
           :continuation_count 0
           :retry_count 0
           :downstream_stages_started json-false
           :effectiveness_claim "not_evaluated"
           :learning_claim "prohibited")))
    (superchat-collector-contract-calibration-v0--write-json
     superchat-collector-contract-calibration-v0--report-json-path report)
    (with-temp-file superchat-collector-contract-calibration-v0--report-md-path
      (insert "# Collector Completion Contract Calibration v0\n\n")
      (insert (format "Calibration Gate: **%s**\n\n"
                      (if pass "pass" "blocked")))
      (insert (format "Required/observed/passed: `4/%d/%d`.\n\n"
                      (length samples) pass-count))
      (dolist (sample samples)
        (insert
         (format "- `%s`: %s — `%s`\n"
                 (plist-get sample :assignment_id)
                 (plist-get sample :sample_gate)
                 (plist-get sample :interpretation))))
      (insert
       "\nNo continuation, retry, outcome, effectiveness, Pattern, or Learning claim is authorized.\n"))
    (with-temp-file superchat-collector-contract-calibration-v0--gap-path
      (insert "# Collector Completion Contract Calibration v0 — Evidence Gaps\n\n")
      (if pass
          (insert
           "No required Prior, Execution, Publish, or Artifact Gate is missing in the four frozen samples.\n\n")
        (dolist (sample samples)
          (unless (equal "pass" (plist-get sample :sample_gate))
            (insert
             (format "- `%s`: `%s`\n"
                     (plist-get sample :assignment_id)
                     (plist-get sample :interpretation))))))
      (insert
       "This report does not evaluate research quality, broad stability, effectiveness, Pattern, or Learning.\n"))
    report))

(provide 'superchat-collector-completion-contract-calibration-v0-evidence)

;;; evidence.el ends here
