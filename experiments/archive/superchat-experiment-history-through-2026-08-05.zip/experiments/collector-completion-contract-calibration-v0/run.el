;;; run.el --- Four-Run Collector completion Calibration -*- lexical-binding: t; -*-

;;; Commentary:

;; Experiment-only sequential launcher.  Each assignment gets a new Actor, Run,
;; Workspace, and correlation identity.  No continuation or retry is possible.

;;; Code:

(require 'cl-lib)
(require 'json)
(require 'subr-x)
(require 'superchat)
(require 'superchat-subagent)
(require 'superchat-closure)
(require 'superchat-workflow)
(require 'llm-ollama)

(defconst superchat-collector-contract-calibration-v0--directory
  "/Users/chenyibin/Documents/emacs/package/superchat/experiments/collector-completion-contract-calibration-v0/")

(defconst superchat-collector-contract-calibration-v0--root
  "/Users/chenyibin/.agent-reach/superchat/collector-completion-contract-calibration-v0/")

(defconst superchat-collector-contract-calibration-v0--manifest-path
  (expand-file-name "manifest.json"
                    superchat-collector-contract-calibration-v0--directory))

(defconst superchat-collector-contract-calibration-v0--assignments-path
  (expand-file-name "assignments.json"
                    superchat-collector-contract-calibration-v0--directory))

(defconst superchat-collector-contract-calibration-v0--task-template-path
  (expand-file-name "task-template.txt"
                    superchat-collector-contract-calibration-v0--directory))

(defconst superchat-collector-contract-calibration-v0--execution-path
  (expand-file-name "execution-record.json"
                    superchat-collector-contract-calibration-v0--directory))

(defconst superchat-collector-contract-calibration-v0--prompt-path
  (expand-file-name "prompt-snapshots.json"
                    superchat-collector-contract-calibration-v0--directory))

(defconst superchat-collector-contract-calibration-v0--allowed-tools
  '("workspace_info" "workspace_publish"))

(defvar superchat-collector-contract-calibration-v0--state nil)
(defvar superchat-collector-contract-calibration-v0--launches nil)
(defvar superchat-collector-contract-calibration-v0--remaining nil)
(defvar superchat-collector-contract-calibration-v0--snapshots nil)
(defvar superchat-collector-contract-calibration-v0--launching-assignment-id nil)

(setq superchat-data-directory
      (expand-file-name "runtime/"
                        superchat-collector-contract-calibration-v0--root)
      superchat-llm-backend
      (make-llm-ollama :chat-model "qwen3.6:latest")
      superchat-llm-model nil
      superchat-response-timeout 600
      superchat-subagent-timeout 1800)

(defun superchat-collector-contract-calibration-v0--read-file (path)
  "Return PATH contents without trailing whitespace."
  (with-temp-buffer
    (insert-file-contents path)
    (string-trim-right (buffer-string))))

(defun superchat-collector-contract-calibration-v0--read-json (path)
  "Read PATH as a plist-backed JSON object."
  (with-temp-buffer
    (insert-file-contents path)
    (json-parse-buffer :object-type 'plist :array-type 'list
                       :null-object nil :false-object json-false)))

(defun superchat-collector-contract-calibration-v0--write-json (path value)
  "Write VALUE as JSON to PATH."
  (with-temp-file path
    (insert (json-encode value))
    (insert "\n")))

(defun superchat-collector-contract-calibration-v0--sha256-file (path)
  "Return protocol-prefixed SHA-256 for PATH."
  (with-temp-buffer
    (set-buffer-multibyte nil)
    (insert-file-contents-literally path)
    (concat "sha256:" (secure-hash 'sha256 (current-buffer)))))

(defun superchat-collector-contract-calibration-v0--sha256-string (value)
  "Return protocol-prefixed SHA-256 for VALUE."
  (concat "sha256:" (secure-hash 'sha256 (or value ""))))

(defun superchat-collector-contract-calibration-v0--manifest ()
  "Return the frozen Calibration Manifest."
  (superchat-collector-contract-calibration-v0--read-json
   superchat-collector-contract-calibration-v0--manifest-path))

(defun superchat-collector-contract-calibration-v0--assignments ()
  "Return the four frozen Calibration assignments."
  (plist-get
   (superchat-collector-contract-calibration-v0--read-json
    superchat-collector-contract-calibration-v0--assignments-path)
   :assignments))

(defun superchat-collector-contract-calibration-v0--verify-inputs ()
  "Fail unless the frozen four-Run inputs remain unchanged."
  (let* ((manifest (superchat-collector-contract-calibration-v0--manifest))
         (assignments (superchat-collector-contract-calibration-v0--assignments))
         (ids (mapcar (lambda (item) (plist-get item :assignment_id))
                      assignments)))
    (unless (equal "calibration-authorized" (plist-get manifest :status))
      (error "Collector completion Calibration is not authorized"))
    (unless (and (= 4 (length assignments))
                 (= 4 (length (delete-dups (copy-sequence ids))))
                 (cl-every
                  (lambda (item)
                    (and (equal "calibration" (plist-get item :split))
                         (stringp (plist-get item :payload))
                         (not (string-empty-p (plist-get item :payload)))))
                  assignments))
      (error "Collector completion Calibration assignments are invalid"))
    (unless (equal superchat-collector-contract-calibration-v0--allowed-tools
                   (plist-get manifest :model_tool_surface))
      (error "Collector completion Calibration tool surface changed"))
    (dolist (input (plist-get manifest :frozen_inputs))
      (let* ((path (expand-file-name
                    (plist-get input :path)
                    "/Users/chenyibin/Documents/emacs/package/superchat/"))
             (actual (and (file-readable-p path)
                          (superchat-collector-contract-calibration-v0--sha256-file
                           path))))
        (unless (equal actual (plist-get input :sha256))
          (error "Frozen input changed or missing: %s" path))))
    manifest))

(defun superchat-collector-contract-calibration-v0--preset ()
  "Return the frozen minimal Collector preset."
  (superchat--subagent-make-preset
   "researcher" "researcher"
   "Minimal Collector durable publication Calibration"
   'agent "research"
   superchat-collector-contract-calibration-v0--allowed-tools
   (concat
    "You are the Collector in a completion-contract Calibration. The complete "
    "Artifact content is supplied in the task. Publish exactly that content "
    "once through workspace_publish with role collector. workspace_info is "
    "optional. Do not narrate a future action or finish before publication "
    "succeeds.")))

(defun superchat-collector-contract-calibration-v0--permission (tool-name _args)
  "Allow only the frozen model-facing TOOL-NAME surface."
  (if (member tool-name superchat-collector-contract-calibration-v0--allowed-tools)
      'allow
    'deny))

(defun superchat-collector-contract-calibration-v0--configure-surface ()
  "Install the experiment-only preset and Authority permission hook."
  (setcdr (assoc "researcher" superchat--subagent-builtin-presets)
          #'superchat-collector-contract-calibration-v0--preset)
  (setq superchat-agent-permission-functions
        '(superchat-collector-contract-calibration-v0--permission)))

(defun superchat-collector-contract-calibration-v0--task (assignment)
  "Return the model-facing task for ASSIGNMENT."
  (concat
   (format
    (superchat-collector-contract-calibration-v0--read-file
     superchat-collector-contract-calibration-v0--task-template-path)
    (plist-get assignment :assignment_id))
   "\n\n<artifact_payload>\n"
   (plist-get assignment :payload)
   "\n</artifact_payload>"))

(defun superchat-collector-contract-calibration-v0--tool-names (tools)
  "Normalize model-facing TOOLS to ordered names."
  (mapcar (lambda (tool)
            (cond ((stringp tool) tool)
                  ((symbolp tool) (symbol-name tool))
                  ((listp tool) (plist-get tool :name))
                  (t (format "%s" tool))))
          tools))

(defun superchat-collector-contract-calibration-v0--capture-query
    (original turn &rest args)
  "Call ORIGINAL with TURN and ARGS, retaining actor-bound Prior evidence."
  (let* ((assignment-id
          superchat-collector-contract-calibration-v0--launching-assignment-id)
         (actor-id (and (boundp 'superchat--session-id)
                        superchat--session-id))
         (result (apply original turn args))
         (prompt (plist-get result :prompt)))
    (when assignment-id
      (when (cl-find assignment-id
                     superchat-collector-contract-calibration-v0--snapshots
                     :key (lambda (item) (plist-get item :assignment_id))
                     :test #'equal)
        (error "Duplicate model-facing snapshot for %s" assignment-id))
      (push
       (list :assignment_id assignment-id
             :actor_id actor-id
             :captured_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
             :model_prompt prompt
             :model_prompt_sha256
             (superchat-collector-contract-calibration-v0--sha256-string prompt)
             :system_prompt (plist-get result :system-prompt)
             :system_prompt_sha256
             (superchat-collector-contract-calibration-v0--sha256-string
              (plist-get result :system-prompt))
             :target_model
             (or (plist-get result :target-model) "qwen3.6:latest")
             :prepared_tool_names
             (vconcat
              (superchat-collector-contract-calibration-v0--tool-names
               (plist-get result :tools))))
       superchat-collector-contract-calibration-v0--snapshots)
      (superchat-collector-contract-calibration-v0--write-json
       superchat-collector-contract-calibration-v0--prompt-path
       (list :experiment_id "collector-completion-contract-calibration-v0"
             :snapshot_count
             (length superchat-collector-contract-calibration-v0--snapshots)
             :snapshots
             (vconcat
              (reverse
               superchat-collector-contract-calibration-v0--snapshots)))))
    result))

(defun superchat-collector-contract-calibration-v0--write-execution ()
  "Persist the current Calibration execution record."
  (superchat-collector-contract-calibration-v0--write-json
   superchat-collector-contract-calibration-v0--execution-path
   (append
    superchat-collector-contract-calibration-v0--state
    (list :launch_count
          (length superchat-collector-contract-calibration-v0--launches)
          :launches
          (vconcat
           (reverse superchat-collector-contract-calibration-v0--launches))))))

(defun superchat-collector-contract-calibration-v0--update-launch
    (assignment-id report)
  "Record REPORT completion for ASSIGNMENT-ID."
  (setq superchat-collector-contract-calibration-v0--launches
        (mapcar
         (lambda (launch)
           (if (equal assignment-id (plist-get launch :assignment_id))
               (append
                launch
                (list :completed_at
                      (format-time-string "%Y-%m-%dT%H:%M:%S%z")
                      :response_length (length (or report ""))
                      :response_sha256
                      (superchat-collector-contract-calibration-v0--sha256-string
                       report)))
             launch))
         superchat-collector-contract-calibration-v0--launches)))

(defun superchat-collector-contract-calibration-v0--finished
    (assignment-id report)
  "Record ASSIGNMENT-ID REPORT and start the next frozen assignment."
  (superchat-collector-contract-calibration-v0--update-launch
   assignment-id report)
  (superchat-collector-contract-calibration-v0--write-execution)
  (superchat-collector-contract-calibration-v0--launch-next))

(defun superchat-collector-contract-calibration-v0--launch-assignment
    (assignment)
  "Launch one independent Collector ASSIGNMENT."
  (let* ((assignment-id (plist-get assignment :assignment_id))
         (scope-id
          (format "collector-contract-%s-%s-%06d"
                  assignment-id (format-time-string "%Y%m%d-%H%M%S")
                  (random 1000000)))
         (root superchat-collector-contract-calibration-v0--root)
         (superchat--team-id scope-id)
         (superchat--team-actor "lead")
         (superchat--workspace-binding (list :id scope-id :root root))
         (superchat--tool-execution-context
          (list :session-id scope-id
                :team-id scope-id
                :correlation-id scope-id
                :attendance 'attended
                :authority-policy "default"
                :workspace-id scope-id
                :workspace-root root))
         (superchat-collector-contract-calibration-v0--launching-assignment-id
          assignment-id)
         (actor-id
          (superchat--subagent-run-async
           'researcher
           (superchat-collector-contract-calibration-v0--task assignment)
           nil
           (lambda (report)
             (superchat-collector-contract-calibration-v0--finished
              assignment-id report))))
         (entry (superchat--subagent-entry actor-id))
         (run-id (plist-get entry :run-id))
         (runtime (superchat-runtime-status run-id)))
    (push
     (list :assignment_id assignment-id
           :actor_id actor-id
           :run_id run-id
           :turn_id (plist-get runtime :turn-id)
           :parent_run_id nil
           :workspace_id scope-id
           :correlation_id scope-id
           :payload_sha256
           (superchat-collector-contract-calibration-v0--sha256-string
            (plist-get assignment :payload))
           :started_at (format-time-string "%Y-%m-%dT%H:%M:%S%z"))
     superchat-collector-contract-calibration-v0--launches)
    (superchat-collector-contract-calibration-v0--write-execution)
    run-id))

(defun superchat-collector-contract-calibration-v0--launch-next ()
  "Launch the next frozen assignment or settle after all four."
  (if-let* ((assignment
             (pop superchat-collector-contract-calibration-v0--remaining)))
      (superchat-collector-contract-calibration-v0--launch-assignment assignment)
    (setq superchat-collector-contract-calibration-v0--state
          (plist-put superchat-collector-contract-calibration-v0--state
                     :status "settled"))
    (setq superchat-collector-contract-calibration-v0--state
          (plist-put superchat-collector-contract-calibration-v0--state
                     :settled_at
                     (format-time-string "%Y-%m-%dT%H:%M:%S%z")))
    (superchat-collector-contract-calibration-v0--write-execution)))

;;;###autoload
(defun superchat-collector-contract-calibration-v0-start ()
  "Start four frozen sequential Collector Runs exactly once."
  (interactive)
  (when superchat-collector-contract-calibration-v0--state
    (error "Collector completion Calibration already started"))
  (when (file-exists-p
         (expand-file-name "superchat.db" superchat-data-directory))
    (error "Collector completion Calibration Runtime database already exists"))
  (superchat-collector-contract-calibration-v0--verify-inputs)
  (setq superchat-collector-contract-calibration-v0--remaining
        (copy-tree
         (superchat-collector-contract-calibration-v0--assignments)))
  (setq superchat-collector-contract-calibration-v0--state
        (list :experiment_id "collector-completion-contract-calibration-v0"
              :manifest_sha256
              (superchat-collector-contract-calibration-v0--sha256-file
               superchat-collector-contract-calibration-v0--manifest-path)
              :status "running"
              :started_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
              :planned_run_count 4
              :execution_mode "sequential"
              :continuation_count 0
              :retry_count 0
              :historical_runs_imported json-false
              :downstream_stages_started json-false
              :effectiveness_claim "not_evaluated"
              :learning_claim "prohibited"))
  (superchat-collector-contract-calibration-v0--write-execution)
  (superchat-collector-contract-calibration-v0--launch-next))

(defun superchat-collector-contract-calibration-v0-status ()
  "Return current Calibration state and live Runtime statuses."
  (interactive)
  (list
   :state superchat-collector-contract-calibration-v0--state
   :launches (vconcat
              (reverse superchat-collector-contract-calibration-v0--launches))
   :runtime
   (vconcat
    (mapcar
     (lambda (launch)
       (superchat-runtime-status (plist-get launch :run_id)))
     (reverse superchat-collector-contract-calibration-v0--launches)))))

(make-directory superchat-collector-contract-calibration-v0--root t)
(superchat-collector-contract-calibration-v0--configure-surface)
(unless (advice-member-p
         #'superchat-collector-contract-calibration-v0--capture-query
         'superchat--execute-llm-query)
  (advice-add 'superchat--execute-llm-query :around
              #'superchat-collector-contract-calibration-v0--capture-query))

(provide 'superchat-collector-completion-contract-calibration-v0-run)

;;; run.el ends here
