;;; self-check.el --- Research Collector Completion Calibration checks -*- lexical-binding: t; -*-

(require 'superchat-research-collector-completion-calibration-v1-run)
(require 'superchat-research-collector-completion-calibration-v1-evidence)

(unless
    (and (= 4 (length
               (superchat-research-collector-calibration-v1--assignments)))
         (equal
          "Using official SQLite documentation, explain how rollback-journal and WAL modes differ in reader/writer behavior and crash recovery guarantees."
          (plist-get
           (car (superchat-research-collector-calibration-v1--assignments))
           :question))
         (string-match-p
          (regexp-quote "research-cal-01")
          (superchat-research-collector-calibration-v1--task
           (car (superchat-research-collector-calibration-v1--assignments))))
         (equal "collector"
                (superchat-research-collector-calibration-v1--normalize-role
                 'collector))
         (equal "collector"
                (superchat-research-collector-calibration-v1--normalize-role
                 "collector"))
         (superchat-research-collector-calibration-v1--same-tool-surface-p
          ["agent_reach_search" "agent_reach_read" "workspace_read"
           "workspace_publish" "workspace_info" "team_task" "team_message"])
         (not
          (superchat-research-collector-calibration-v1--same-tool-surface-p
           ["agent_reach_search" "agent_reach_read" "workspace_read"
            "workspace_publish" "workspace_info" "team_task"]))
         (= 2
            (length
             (superchat-research-collector-calibration-v1--source-urls
              "A https://example.org/a B https://example.org/b")))
         (equal
          "material_read_contract_not_completed"
          (superchat-research-collector-calibration-v1--interpret
           t t 1 1 0 0 0 "artifact_absent" 0)))
  (error "Research Collector Completion Calibration self-check failed"))

(provide 'superchat-research-collector-completion-calibration-v1-self-check)

;;; self-check.el ends here
