# Research Collector Completion Calibration v1 — Evidence Gaps

- `research-cal-01`: `model_did_not_select_workspace_publish`
- `research-cal-02`: `model_did_not_select_workspace_publish`
- `research-cal-03`: `model_did_not_select_workspace_publish`
- `research-cal-04`: `search_not_completed`
This report does not evaluate research quality, broad stability, effectiveness, Pattern, or Learning.

## Post-stop verification

- All four Runs reached durable `run.completed`; the v0 transport-finalization gap did not recur on these tested paths.
- Prior and Execution Closure passed for all four samples; invalid identity events and failed tool events were both `0`.
- `research-cal-01` through `research-cal-03` completed the frozen search/read minimum but never selected `workspace_publish`.
- `research-cal-04` selected no research or publish tool.
- Artifact events: `0`; Artifact classification: `artifact_absent` for all four samples.
- SQLite integrity: `ok`; Tape rows: `97`.
- Runtime snapshot SHA-256: `714d0ffae7b4eca091064a157607ea8dd32e3b42c846eeaa4e086b2aef3d26ea`.
- Calibration JSON SHA-256: `8288bf7a3007e5923ae1bc18d5542d5767184e262b89ea7d5e37a01b2b7f8745`.
- Execution record SHA-256: `a5661f93a1cd22f71eef106dfe4861552546991168515b37a22b9620a4d32c52`.
- Prompt snapshots SHA-256: `fb60d4b1e29d3d40a78e7a2dad8572873dae18acfa62bc8fac68bed1aeea7f35`.

The current blocker is repeatable Application completion compliance, not Runtime identity propagation, Artifact provenance, or transport finalization. Discovery remains blocked.
