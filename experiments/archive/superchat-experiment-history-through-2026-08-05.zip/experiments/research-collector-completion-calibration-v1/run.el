;;; run.el --- Four-Run Research Collector Completion Calibration -*- lexical-binding: t; -*-

;;; Commentary:

;; Experiment-only sequential launcher.  Each assignment gets a new Actor, Run,
;; Workspace, and correlation identity.  No continuation or retry is possible.

;;; Code:

(require 'cl-lib)
(require 'json)
(require 'subr-x)
(require 'superchat)
(require 'superchat-subagent)
(require 'superchat-closure)
(require 'superchat-workflow)
(require 'llm-ollama)

(defconst superchat-research-collector-calibration-v1--directory
  "/Users/chenyibin/Documents/emacs/package/superchat/experiments/research-collector-completion-calibration-v1/")

(defconst superchat-research-collector-calibration-v1--root
  "/private/tmp/superchat-research-collector-completion-calibration-v1/")

(defconst superchat-research-collector-calibration-v1--manifest-path
  (expand-file-name "manifest.json"
                    superchat-research-collector-calibration-v1--directory))

(defconst superchat-research-collector-calibration-v1--assignments-path
  (expand-file-name "assignments.json"
                    superchat-research-collector-calibration-v1--directory))

(defconst superchat-research-collector-calibration-v1--task-template-path
  (expand-file-name "task-template.txt"
                    superchat-research-collector-calibration-v1--directory))

(defconst superchat-research-collector-calibration-v1--execution-path
  (expand-file-name "execution-record.json"
                    superchat-research-collector-calibration-v1--directory))

(defconst superchat-research-collector-calibration-v1--prompt-path
  (expand-file-name "prompt-snapshots.json"
                    superchat-research-collector-calibration-v1--directory))

(defconst superchat-research-collector-calibration-v1--allowed-tools
  '("agent_reach_search" "agent_reach_read"
    "workspace_read" "workspace_publish" "workspace_info"
    "team_task" "team_message"))

(defvar superchat-research-collector-calibration-v1--state nil)
(defvar superchat-research-collector-calibration-v1--launches nil)
(defvar superchat-research-collector-calibration-v1--remaining nil)
(defvar superchat-research-collector-calibration-v1--snapshots nil)
(defvar superchat-research-collector-calibration-v1--launching-assignment-id nil)

(setq superchat-data-directory
      (expand-file-name "runtime/"
                        superchat-research-collector-calibration-v1--root)
      superchat-llm-backend
      (make-llm-ollama :chat-model "qwen3.6:latest")
      superchat-llm-model nil
      superchat-response-timeout 900
      superchat-subagent-timeout 1800)

(defun superchat-research-collector-calibration-v1--read-file (path)
  "Return PATH contents without trailing whitespace."
  (with-temp-buffer
    (insert-file-contents path)
    (string-trim-right (buffer-string))))

(defun superchat-research-collector-calibration-v1--read-json (path)
  "Read PATH as a plist-backed JSON object."
  (with-temp-buffer
    (insert-file-contents path)
    (json-parse-buffer :object-type 'plist :array-type 'list
                       :null-object nil :false-object json-false)))

(defun superchat-research-collector-calibration-v1--write-json (path value)
  "Write VALUE as JSON to PATH."
  (with-temp-file path
    (insert (json-encode value))
    (insert "\n")))

(defun superchat-research-collector-calibration-v1--sha256-file (path)
  "Return protocol-prefixed SHA-256 for PATH."
  (with-temp-buffer
    (set-buffer-multibyte nil)
    (insert-file-contents-literally path)
    (concat "sha256:" (secure-hash 'sha256 (current-buffer)))))

(defun superchat-research-collector-calibration-v1--sha256-string (value)
  "Return protocol-prefixed SHA-256 for VALUE."
  (concat "sha256:" (secure-hash 'sha256 (or value ""))))

(defun superchat-research-collector-calibration-v1--manifest ()
  "Return the frozen Calibration Manifest."
  (superchat-research-collector-calibration-v1--read-json
   superchat-research-collector-calibration-v1--manifest-path))

(defun superchat-research-collector-calibration-v1--assignments ()
  "Return the four frozen Calibration assignments."
  (plist-get
   (superchat-research-collector-calibration-v1--read-json
    superchat-research-collector-calibration-v1--assignments-path)
   :assignments))

(defun superchat-research-collector-calibration-v1--verify-inputs ()
  "Fail unless the frozen four-Run inputs remain unchanged."
  (let* ((manifest (superchat-research-collector-calibration-v1--manifest))
         (assignments (superchat-research-collector-calibration-v1--assignments))
         (ids (mapcar (lambda (item) (plist-get item :assignment_id))
                      assignments)))
    (unless (equal "calibration-authorized" (plist-get manifest :status))
      (error "Research Collector Completion Calibration is not authorized"))
    (unless (and (= 4 (length assignments))
                 (= 4 (length (delete-dups (copy-sequence ids))))
                 (cl-every
                 (lambda (item)
                    (and (equal "calibration" (plist-get item :split))
                         (stringp (plist-get item :family))
                         (not (string-empty-p (plist-get item :family)))
                         (stringp (plist-get item :question))
                         (not (string-empty-p (plist-get item :question)))))
                  assignments))
      (error "Research Collector Completion Calibration assignments are invalid"))
    (unless (equal superchat-research-collector-calibration-v1--allowed-tools
                   (plist-get manifest :model_tool_surface))
      (error "Research Collector Completion Calibration tool surface changed"))
    (dolist (input (plist-get manifest :frozen_inputs))
      (let* ((path (expand-file-name
                    (plist-get input :path)
                    "/Users/chenyibin/Documents/emacs/package/superchat/"))
             (actual (and (file-readable-p path)
                          (superchat-research-collector-calibration-v1--sha256-file
                           path))))
        (unless (equal actual (plist-get input :sha256))
          (error "Frozen input changed or missing: %s" path))))
    manifest))

(defun superchat-research-collector-calibration-v1--bounded-process
    (program args max-characters)
  "Run PROGRAM with ARGS and return at most MAX-CHARACTERS."
  (with-temp-buffer
    (let ((status (apply #'call-process
                         "/opt/homebrew/bin/gtimeout" nil t nil
                         "90s" program args)))
      (unless (and (integerp status) (zerop status))
        (error "%s failed with status %s: %s"
               program status (string-trim (buffer-string))))
      (let ((text (buffer-string)))
        (if (> (length text) max-characters)
            (concat (substring text 0 max-characters)
                    "\n[Result truncated by frozen tool limit]")
          text)))))

(defun superchat-research-collector-calibration-v1-search
    (query &optional num-results)
  "Search the public web for QUERY through Agent Reach Exa."
  (unless (and (stringp query) (not (string-empty-p (string-trim query))))
    (error "Search query must be non-empty"))
  (let* ((count (max 1 (min 8 (truncate (or num-results 5)))))
         (call (format "exa.web_search_exa(query: %s, numResults: %d)"
                       (json-encode-string query) count)))
    (superchat-research-collector-calibration-v1--bounded-process
     "/Users/chenyibin/.bun/bin/mcporter" (list "call" call) 30000)))

(defun superchat-research-collector-calibration-v1-read (url)
  "Read public HTTP(S) URL through Agent Reach Jina Reader."
  (unless (and (stringp url) (string-match-p "\\`https?://" url))
    (error "Reader URL must use HTTP or HTTPS"))
  (superchat-research-collector-calibration-v1--bounded-process
   "/opt/local/bin/curl"
   (list "--silent" "--show-error" "--location" "--max-time" "80"
         (concat "https://r.jina.ai/" url))
   40000))

(defun superchat-research-collector-calibration-v1--external-read-effects
    (args)
  "Return frozen external-read effects for ARGS."
  (list (list :effect 'external-read :resource 'web :scope (car args))
        (list :effect 'process-exec :resource 'agent-reach
              :scope "frozen-read-only-adapter")))

(defun superchat-research-collector-calibration-v1--register-tools ()
  "Register the frozen Agent Reach tools."
  (superchat-register-tool
   "agent_reach_search"
   :function #'superchat-research-collector-calibration-v1-search
   :description
   "Search the public web through Agent Reach Exa. Prefer official or primary sources and retain URLs."
   :args (list (list :name "query" :type 'string
                     :description "Precise web search query.")
               (list :name "num-results" :type 'number :optional t
                     :description "Number of results, from 1 to 8."))
   :effects #'superchat-research-collector-calibration-v1--external-read-effects)
  (superchat-register-tool
   "agent_reach_read"
   :function #'superchat-research-collector-calibration-v1-read
   :description
   "Read one public HTTP(S) page through Agent Reach Jina Reader and return bounded Markdown."
   :args (list (list :name "url" :type 'string
                     :description "Public HTTP(S) URL to read."))
   :effects #'superchat-research-collector-calibration-v1--external-read-effects))

(defun superchat-research-collector-calibration-v1--preset ()
  "Return the frozen real Research Collector preset."
  (superchat--subagent-make-preset
   "researcher" "researcher"
   "Real Research Collector completion Calibration"
   'agent "research"
   superchat-research-collector-calibration-v1--allowed-tools
   (concat
    "You are the Collector in a four-sample completion Calibration. Complete "
    "each research task in its current Run: use agent_reach_search, inspect "
    "at least two distinct material sources with agent_reach_read, distinguish "
    "evidence from inference, retain source URLs, then publish exactly one "
    "complete durable Artifact with workspace_publish using role collector. "
    "Do not narrate a future action or finish before publication succeeds.")))

(defun superchat-research-collector-calibration-v1--permission (tool-name _args)
  "Allow only the frozen model-facing TOOL-NAME surface."
  (if (member tool-name superchat-research-collector-calibration-v1--allowed-tools)
      'allow
    'deny))

(defun superchat-research-collector-calibration-v1--configure-surface ()
  "Install the experiment-only preset and Authority permission hook."
  (superchat-research-collector-calibration-v1--register-tools)
  (setcdr (assoc "researcher" superchat--subagent-builtin-presets)
          #'superchat-research-collector-calibration-v1--preset)
  (setq superchat-agent-permission-functions
        '(superchat-research-collector-calibration-v1--permission)))

(defun superchat-research-collector-calibration-v1--task (assignment)
  "Return the model-facing task for ASSIGNMENT."
  (format
   (superchat-research-collector-calibration-v1--read-file
    superchat-research-collector-calibration-v1--task-template-path)
   (plist-get assignment :assignment_id)
   (plist-get assignment :family)
   (plist-get assignment :question)))

(defun superchat-research-collector-calibration-v1--tool-names (tools)
  "Normalize model-facing TOOLS to ordered names."
  (mapcar (lambda (tool)
            (cond ((stringp tool) tool)
                  ((symbolp tool) (symbol-name tool))
                  ((listp tool) (plist-get tool :name))
                  (t (format "%s" tool))))
          tools))

(defun superchat-research-collector-calibration-v1--capture-query
    (original turn &rest args)
  "Call ORIGINAL with TURN and ARGS, retaining actor-bound Prior evidence."
  (let* ((assignment-id
          superchat-research-collector-calibration-v1--launching-assignment-id)
         (actor-id (and (boundp 'superchat--session-id)
                        superchat--session-id))
         (result (apply original turn args))
         (prompt (plist-get result :prompt)))
    (when assignment-id
      (when (cl-find assignment-id
                     superchat-research-collector-calibration-v1--snapshots
                     :key (lambda (item) (plist-get item :assignment_id))
                     :test #'equal)
        (error "Duplicate model-facing snapshot for %s" assignment-id))
      (push
       (list :assignment_id assignment-id
             :actor_id actor-id
             :captured_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
             :model_prompt prompt
             :model_prompt_sha256
             (superchat-research-collector-calibration-v1--sha256-string prompt)
             :system_prompt (plist-get result :system-prompt)
             :system_prompt_sha256
             (superchat-research-collector-calibration-v1--sha256-string
              (plist-get result :system-prompt))
             :target_model
             (or (plist-get result :target-model) "qwen3.6:latest")
             :prepared_tool_names
             (vconcat
              (superchat-research-collector-calibration-v1--tool-names
               (plist-get result :tools))))
       superchat-research-collector-calibration-v1--snapshots)
      (superchat-research-collector-calibration-v1--write-json
       superchat-research-collector-calibration-v1--prompt-path
       (list :experiment_id "research-collector-completion-calibration-v1"
             :snapshot_count
             (length superchat-research-collector-calibration-v1--snapshots)
             :snapshots
             (vconcat
              (reverse
               superchat-research-collector-calibration-v1--snapshots)))))
    result))

(defun superchat-research-collector-calibration-v1--write-execution ()
  "Persist the current Calibration execution record."
  (superchat-research-collector-calibration-v1--write-json
   superchat-research-collector-calibration-v1--execution-path
   (append
    superchat-research-collector-calibration-v1--state
    (list :launch_count
          (length superchat-research-collector-calibration-v1--launches)
          :launches
          (vconcat
           (reverse superchat-research-collector-calibration-v1--launches))))))

(defun superchat-research-collector-calibration-v1--update-launch
    (assignment-id report)
  "Record REPORT completion for ASSIGNMENT-ID."
  (setq superchat-research-collector-calibration-v1--launches
        (mapcar
         (lambda (launch)
           (if (equal assignment-id (plist-get launch :assignment_id))
               (append
                launch
                (list :completed_at
                      (format-time-string "%Y-%m-%dT%H:%M:%S%z")
                      :response_length (length (or report ""))
                      :response_sha256
                      (superchat-research-collector-calibration-v1--sha256-string
                       report)))
             launch))
         superchat-research-collector-calibration-v1--launches)))

(defun superchat-research-collector-calibration-v1--finished
    (assignment-id report)
  "Record ASSIGNMENT-ID REPORT and start the next frozen assignment."
  (superchat-research-collector-calibration-v1--update-launch
   assignment-id report)
  (superchat-research-collector-calibration-v1--write-execution)
  (superchat-research-collector-calibration-v1--launch-next))

(defun superchat-research-collector-calibration-v1--launch-assignment
    (assignment)
  "Launch one independent Collector ASSIGNMENT."
  (let* ((assignment-id (plist-get assignment :assignment_id))
         (scope-id
          (format "collector-contract-%s-%s-%06d"
                  assignment-id (format-time-string "%Y%m%d-%H%M%S")
                  (random 1000000)))
         (root superchat-research-collector-calibration-v1--root)
         (superchat--team-id scope-id)
         (superchat--team-actor "lead")
         (superchat--workspace-binding (list :id scope-id :root root))
         (superchat--tool-execution-context
          (list :session-id scope-id
                :team-id scope-id
                :correlation-id scope-id
                :attendance 'attended
                :authority-policy "default"
                :workspace-id scope-id
                :workspace-root root))
         (superchat-research-collector-calibration-v1--launching-assignment-id
          assignment-id)
         (actor-id
          (superchat--subagent-run-async
           'researcher
           (superchat-research-collector-calibration-v1--task assignment)
           nil
           (lambda (report)
             (superchat-research-collector-calibration-v1--finished
              assignment-id report))))
         (entry (superchat--subagent-entry actor-id))
         (run-id (plist-get entry :run-id))
         (runtime (superchat-runtime-status run-id)))
    (push
     (list :assignment_id assignment-id
           :actor_id actor-id
           :run_id run-id
           :turn_id (plist-get runtime :turn-id)
           :parent_run_id nil
           :workspace_id scope-id
           :correlation_id scope-id
           :source_task_id (plist-get assignment :source_task_id)
           :family (plist-get assignment :family)
           :question_sha256
           (superchat-research-collector-calibration-v1--sha256-string
            (plist-get assignment :question))
           :started_at (format-time-string "%Y-%m-%dT%H:%M:%S%z"))
     superchat-research-collector-calibration-v1--launches)
    (superchat-research-collector-calibration-v1--write-execution)
    run-id))

(defun superchat-research-collector-calibration-v1--launch-next ()
  "Launch the next frozen assignment or settle after all four."
  (if-let* ((assignment
             (pop superchat-research-collector-calibration-v1--remaining)))
      (superchat-research-collector-calibration-v1--launch-assignment assignment)
    (setq superchat-research-collector-calibration-v1--state
          (plist-put superchat-research-collector-calibration-v1--state
                     :status "settled"))
    (setq superchat-research-collector-calibration-v1--state
          (plist-put superchat-research-collector-calibration-v1--state
                     :settled_at
                     (format-time-string "%Y-%m-%dT%H:%M:%S%z")))
    (superchat-research-collector-calibration-v1--write-execution)))

;;;###autoload
(defun superchat-research-collector-calibration-v1-start ()
  "Start four frozen sequential Collector Runs exactly once."
  (interactive)
  (when superchat-research-collector-calibration-v1--state
    (error "Research Collector Completion Calibration already started"))
  (when (file-exists-p
         (expand-file-name "superchat.db" superchat-data-directory))
    (error "Research Collector Completion Calibration Runtime database already exists"))
  (superchat-research-collector-calibration-v1--verify-inputs)
  (setq superchat-research-collector-calibration-v1--remaining
        (copy-tree
         (superchat-research-collector-calibration-v1--assignments)))
  (setq superchat-research-collector-calibration-v1--state
        (list :experiment_id "research-collector-completion-calibration-v1"
              :manifest_sha256
              (superchat-research-collector-calibration-v1--sha256-file
               superchat-research-collector-calibration-v1--manifest-path)
              :status "running"
              :started_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
              :planned_run_count 4
              :execution_mode "sequential"
              :continuation_count 0
              :retry_count 0
              :recovery_count 0
              :historical_runs_imported json-false
              :downstream_stages_started json-false
              :outcome_evaluation "not-evaluated"
              :effectiveness_claim "not_evaluated"
              :learning_claim "prohibited"))
  (superchat-research-collector-calibration-v1--write-execution)
  (superchat-research-collector-calibration-v1--launch-next))

(defun superchat-research-collector-calibration-v1-status ()
  "Return current Calibration state and live Runtime statuses."
  (interactive)
  (list
   :state superchat-research-collector-calibration-v1--state
   :launches (vconcat
              (reverse superchat-research-collector-calibration-v1--launches))
   :runtime
   (vconcat
    (mapcar
     (lambda (launch)
       (superchat-runtime-status (plist-get launch :run_id)))
     (reverse superchat-research-collector-calibration-v1--launches)))))

(make-directory superchat-research-collector-calibration-v1--root t)
(superchat-research-collector-calibration-v1--configure-surface)
(unless (advice-member-p
         #'superchat-research-collector-calibration-v1--capture-query
         'superchat--execute-llm-query)
  (advice-add 'superchat--execute-llm-query :around
              #'superchat-research-collector-calibration-v1--capture-query))

(provide 'superchat-research-collector-completion-calibration-v1-run)

;;; run.el ends here
