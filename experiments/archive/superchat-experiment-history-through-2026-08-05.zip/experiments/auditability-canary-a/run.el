;;; run.el --- Throwaway Auditability Canary A -*- lexical-binding: t; -*-

;; Question: can one deterministic Research Workflow run close Prior,
;; Execution, Artifact, and Outcome evidence without changing Runtime?
;; This is experimental code.  It uses a scratch SQLite database and a
;; scripted model adapter; it does not measure research quality or learning.
;; Run once with:
;;   emacs -Q --batch -L . -l experiments/auditability-canary-a/run.el

(require 'cl-lib)
(require 'json)
(require 'seq)
(require 'subr-x)
(require 'superchat-workflow)
(require 'superchat-subagent)
(require 'superchat-workspace)
(require 'superchat-tools)

(defconst canary--directory
  (file-name-directory (or load-file-name buffer-file-name)))
(defconst canary--root (expand-file-name "../.." canary--directory))
(defconst canary--manifest-path
  (expand-file-name "manifest.json" canary--directory))

(defvar canary--manifest nil)
(defvar canary--prompt-snapshots nil)
(defvar canary--prepared-tool-requests nil)
(defvar canary--model-calls nil)

(defun canary--sha256-string (value)
  "Return a prefixed SHA-256 for string VALUE."
  (concat "sha256:"
          (secure-hash 'sha256 (encode-coding-string value 'utf-8))))

(defun canary--file-content (path)
  "Return PATH bytes as a unibyte string."
  (with-temp-buffer
    (set-buffer-multibyte nil)
    (insert-file-contents-literally path)
    (buffer-string)))

(defun canary--file-sha256 (path)
  "Return a prefixed SHA-256 for PATH."
  (concat "sha256:" (secure-hash 'sha256 (canary--file-content path))))

(defun canary--plist-p (value)
  "Return non-nil when VALUE is a non-empty keyword plist."
  (and value
       (listp value)
       (let ((rest value)
             (valid t))
         (while (and rest valid)
           (setq valid (and (keywordp (car rest)) (cdr rest))
                 rest (cddr rest)))
         (and valid (null rest)))))

(defun canary--json-value (value)
  "Make sequence shape explicit before encoding VALUE as JSON."
  (cond
   ((canary--plist-p value)
    (let (result)
      (while value
        (setq result
              (nconc result
                     (list (pop value)
                           (canary--json-value (pop value))))))
      result))
   ((listp value)
    (vconcat (mapcar #'canary--json-value value)))
   ((vectorp value)
    (vconcat (mapcar #'canary--json-value (append value nil))))
   (t value)))

(defun canary--write-json (path value)
  "Write VALUE as readable JSON to PATH."
  (let ((json-encoding-pretty-print t))
    (with-temp-file path
      (insert (json-encode (canary--json-value value)) "\n"))))

(defun canary--manifest-read ()
  "Read the frozen Canary manifest."
  (json-parse-string
   (canary--file-content canary--manifest-path)
   :object-type 'plist :array-type 'list
   :null-object nil :false-object :false))

(defun canary--source-checks ()
  "Verify all source snapshots in the frozen manifest."
  (mapcar
   (lambda (snapshot)
     (let* ((relative (plist-get snapshot :path))
            (path (expand-file-name relative canary--root))
            (expected (plist-get snapshot :sha256))
            (actual (and (file-readable-p path)
                         (canary--file-sha256 path))))
       (unless (equal expected actual)
         (error "Frozen source mismatch for %s: expected %s, got %s"
                relative expected actual))
       (list :path relative :sha256 actual :status "observed")))
   (plist-get canary--manifest :source_snapshots)))

(defun canary--role (prompt)
  "Return the Research role encoded in PROMPT."
  (cond ((string-match-p "\\[research/collector\\]" prompt) "collector")
        ((string-match-p "\\[research/analyst\\]" prompt) "analyst")
        ((string-match-p "\\[research/reviewer\\]" prompt) "reviewer")
        (t (error "Unknown Research stage"))))

(defun canary--tool-names (tools)
  "Return names from Canary tool descriptor plists TOOLS."
  (mapcar (lambda (tool) (plist-get tool :name)) tools))

(defun canary--prepare-query (turn)
  "Capture the exact prepared TURN and return the scripted request."
  (let* ((prompt (superchat-turn-prompt turn))
         (system-prompt (superchat-turn-system-prompt turn))
         (role (canary--role prompt))
         (offered (plist-get (plist-get canary--manifest :prior)
                             :offered_tools)))
    (push (list :role role
                :prompt prompt
                :prompt_sha256 (canary--sha256-string prompt)
                :system_prompt system-prompt
                :system_prompt_sha256
                (canary--sha256-string system-prompt)
                :profile_requested_tools (superchat-turn-tools turn)
                :adapter_offered_tools (canary--tool-names offered)
                :run_id nil
                :target_model nil
                :context_files nil
                :observed_system_prompt_sha256 nil
                :prepared_tool_names nil)
          canary--prompt-snapshots)
    (list :prompt prompt
          :system-prompt system-prompt
          :target-model
          (plist-get (plist-get canary--manifest :prior) :model_id)
          :tools (canary--tool-names offered))))

(defun canary--prepare-tools (_context _prompt requested-tools)
  "Expose the frozen tool surface and record REQUESTED-TOOLS."
  (push requested-tools canary--prepared-tool-requests)
  (copy-tree
   (plist-get (plist-get canary--manifest :prior) :offered_tools)))

(defun canary--call-tool (role name function args context)
  "Call NAME for ROLE through Authority and record observable arguments."
  (let ((result (superchat-tool-execute
                 name function args :context context)))
    (push (list :role role
                :run_id (plist-get context :run-id)
                :tool_name name
                :arguments args
                :result_sha256
                (canary--sha256-string (format "%s" result)))
          canary--model-calls)
    result))

(defun canary--scripted-model
    (prompt _callback _stream-callback
            &optional target-model context-files _tools system-prompt _preset)
  "Execute one deterministic Research stage for PROMPT."
  (let* ((role (canary--role prompt))
         (context
          (plist-put (copy-sequence superchat--tool-execution-context)
                     :approval-function (lambda (_request) t)))
         (workspace-id (plist-get context :workspace-id))
         (prior (superchat-workspace-artifacts workspace-id))
         consumed)
    (dolist (artifact prior)
      (let ((artifact-id (plist-get artifact :artifact-id))
            (revision (plist-get artifact :revision)))
        (canary--call-tool
         role "workspace_read" #'superchat-tool-workspace-read
         (list artifact-id revision) context)
        (push (format "%s@%s" artifact-id revision) consumed)))
    (let ((content
           (format "[canary/%s]\nquery=%s\nconsumed=%s\n"
                   role (plist-get canary--manifest :task_input)
                   (string-join (nreverse consumed) ","))))
      (canary--call-tool
       role "workspace_publish" #'superchat-tool-workspace-publish
       (list content role) context))
    (let ((snapshot
           (cl-find role canary--prompt-snapshots
                    :key (lambda (item) (plist-get item :role))
                    :test #'equal)))
      (setf (plist-get snapshot :run_id) (plist-get context :run-id)
            (plist-get snapshot :target_model) target-model
            (plist-get snapshot :context_files) context-files
            (plist-get snapshot :observed_system_prompt_sha256)
            (canary--sha256-string system-prompt)
            (plist-get snapshot :prepared_tool_names)
            (canary--tool-names superchat--llm-prepared-tools)))
    (funcall superchat--llm-runtime-observer
             'terminal
             (list :status 'completed
                   :response (format "%s complete" role)))))

(defun canary--events (session-id)
  "Replay SESSION-ID from the real Tape."
  (superchat-tape-replay-events session-id))

(defun canary--run-events (sessions run-id)
  "Return events for RUN-ID across SESSIONS."
  (apply #'append
         (mapcar
          (lambda (session-id)
            (cl-remove-if-not
             (lambda (event) (equal run-id (plist-get event :run-id)))
             (canary--events session-id)))
          sessions)))

(defun canary--event-reference (event)
  "Return a bounded reference to EVENT without duplicating Tape payload."
  (list :event_id (plist-get event :event-id)
        :type (plist-get event :type)
        :session_id (plist-get event :session-id)
        :run_id (plist-get event :run-id)
        :recorded_at (plist-get event :recorded-at)))

(defun canary--effect-scope-p (event artifact-id)
  "Return non-nil when EVENT declares ARTIFACT-ID as an effect scope."
  (let ((effects (plist-get (plist-get event :payload) :effects)))
    (or
     (and (listp effects)
          (listp (car effects))
          (seq-some
           (lambda (effect)
             (equal artifact-id (plist-get effect :scope)))
           effects))
     ;; Tape v0 JSON replay flattens a singleton effect plist into the value
     ;; under :effect.  Decode that observed shape without inventing fields.
     (let* ((flat (and (listp effects) (plist-get effects :effect)))
            (scope-tail (and (listp flat) (member "scope" flat))))
       (equal artifact-id (cadr scope-tail))))))

(defun canary--effect-shape (event)
  "Return the observed replay shape of EVENT effects."
  (let ((effects (plist-get (plist-get event :payload) :effects)))
    (if (and (listp effects) (listp (car effects)))
        "effect-list"
      "singleton-flattened")))

(defun canary--read-event (events run-id artifact-id)
  "Find the explicit workspace_read request for ARTIFACT-ID in RUN-ID."
  (cl-find-if
   (lambda (event)
     (let ((payload (plist-get event :payload)))
       (and (equal "tool.requested" (plist-get event :type))
            (equal run-id (plist-get event :run-id))
            (equal "workspace_read" (plist-get payload :tool-name))
            (canary--effect-scope-p event artifact-id))))
   events))

(defun canary--closure-summary (session-id run-id)
  "Return Closure evidence for RUN-ID in SESSION-ID."
  (let* ((trace (canary--events session-id))
         (well (superchat-closure-judge
                (list :kind 'trace-well-formed :run-id run-id) trace))
         (terminal (superchat-closure-judge
                    (list :kind 'durable-run-terminal :run-id run-id) trace)))
    (list :session_id session-id
          :run_id run-id
          :trace_verdict (symbol-name (plist-get well :verdict))
          :terminal_verdict (symbol-name (plist-get terminal :verdict))
          :terminal_kind
          (when-let* ((judgment (plist-get terminal :judgment))
                      (kind (plist-get judgment :terminal-kind)))
            (symbol-name kind))
          :witness_event_ids
          (plist-get (plist-get terminal :witness) :event-ids))))

(defun canary--criterion (id passed evidence)
  "Return one structural outcome criterion."
  (list :id id
        :status (if passed "pass" "fail")
        :evidence evidence))

(defun canary--gate (name verdict evidence &optional gaps)
  "Return one evidence gate result."
  (list :name name :verdict verdict :evidence evidence
        :gaps (or gaps [])))

(defun canary--write-gap-report (path identity gates gaps)
  "Write Canary gate verdicts and GAPS to PATH."
  (with-temp-file path
    (insert "# Auditability Canary A — Evidence Gap Report\n\n")
    (insert (format "- Experiment: `%s`\n"
                    (plist-get identity :experiment_id)))
    (insert (format "- Manifest: `%s`\n"
                    (plist-get identity :manifest_sha256)))
    (insert (format "- Research instance: `%s`\n"
                    (plist-get identity :research_instance_id)))
    (insert (format "- Runtime database: `%s`\n\n"
                    (plist-get identity :runtime_database)))
    (insert "## Gate verdicts\n\n")
    (insert "| Gate | Verdict |\n|---|---|\n")
    (dolist (gate gates)
      (insert (format "| %s | `%s` |\n"
                      (plist-get gate :name)
                      (plist-get gate :verdict))))
    (insert "\n## Evidence gaps\n\n")
    (if (null gaps)
        (insert "None.\n")
      (dolist (gap gaps)
        (insert (format
                 "### %s\n\n- Status: `%s`\n- Expected source: `%s`\n- Affected gate: `%s`\n- Impact: `%s`\n- Workaround: `%s`\n- Runtime change needed: `%s`\n\n"
                 (plist-get gap :evidence)
                 (plist-get gap :status)
                 (plist-get gap :expected_source)
                 (plist-get gap :affected_gate)
                 (plist-get gap :impact)
                 (plist-get gap :workaround)
                 (plist-get gap :runtime_change_needed)))))
    (insert "## Decision\n\n")
    (if (cl-every
         (lambda (gate) (equal "pass" (plist-get gate :verdict)))
         (seq-take gates 4))
        (insert "Canary A closes Prior, Execution, Artifact, and Outcome. "
                "Comparison remains blocked by design; no learning or "
                "causal claim is permitted.\n")
      (insert "Canary A is not audit-ready. At least one of Prior, "
              "Execution, Artifact, or Outcome remains blocked or invalid; "
              "no learning or causal claim is permitted.\n"))))

(defun canary--main ()
  "Run Canary A once and persist its external evidence objects."
  (setq canary--manifest (canary--manifest-read))
  (unless (equal "frozen" (plist-get canary--manifest :status))
    (error "Canary manifest is not frozen"))
  (let* ((source-checks (canary--source-checks))
         (attempt-id (format "attempt-%s"
                             (format-time-string "%Y%m%dT%H%M%S%3N" nil t)))
         (output-directory
          (expand-file-name (concat "runs/" attempt-id) canary--directory))
         (runtime-directory (expand-file-name "runtime" output-directory))
         (database (expand-file-name "superchat.db" runtime-directory))
         (manifest-sha256 (canary--file-sha256 canary--manifest-path))
         (superchat-data-directory runtime-directory)
         (superchat-db--connection nil)
         (superchat-db--path nil)
         (superchat-runtime--runs (make-hash-table :test #'equal))
         (superchat-workspace--registry nil)
         (superchat-workspace--artifact-counter 0)
         (superchat--subagent-running nil)
         (superchat-subagent-timeout nil)
         (superchat-closure-terminal-guard-enabled t)
         instance-id view steps sessions all-events closure-evidence
         artifacts explicit-reads criteria outcome-passed gates gaps identity
         canary-passed)
    (make-directory runtime-directory t)
    (let ((default-directory canary--root))
      (superchat-db-open database)
      (unwind-protect
          (cl-letf (((symbol-function 'superchat--execute-llm-query)
                     #'canary--prepare-query)
                    ((symbol-function 'superchat--subagent-prepare-tools)
                     #'canary--prepare-tools)
                    ((symbol-function 'superchat--subagent-refresh-panel)
                     #'ignore)
                    ((symbol-function 'superchat--update-status) #'ignore)
                    ((symbol-function 'superchat--llm-generate-answer)
                     #'canary--scripted-model))
            (setq instance-id
                  (superchat-research-workflow
                   (plist-get canary--manifest :task_input))))
        (superchat-db-close)))
    (setq view (superchat-research-workflow-view instance-id)
          steps (plist-get view :steps)
          sessions (cons instance-id
                         (mapcar (lambda (step) (plist-get step :actor-id))
                                 steps))
          all-events (apply #'append (mapcar #'canary--events sessions))
          closure-evidence
          (mapcar
           (lambda (step)
             (canary--closure-summary (plist-get step :actor-id)
                                      (plist-get step :run-id)))
           steps)
          artifacts
          (apply
           #'append
           (mapcar
            (lambda (step)
              (mapcar
               (lambda (artifact)
                 (append (copy-sequence artifact)
                         (list :producer-run-id (plist-get step :run-id)
                               :producer-actor-id
                               (plist-get step :actor-id))))
               (plist-get step :artifacts)))
            steps))
          canary--prompt-snapshots (nreverse canary--prompt-snapshots)
          canary--prepared-tool-requests
          (nreverse canary--prepared-tool-requests)
          canary--model-calls (nreverse canary--model-calls))
    (dolist (call canary--model-calls)
      (when (equal "workspace_read" (plist-get call :tool_name))
        (let* ((artifact-id (car (plist-get call :arguments)))
               (event (canary--read-event
                       all-events (plist-get call :run_id) artifact-id)))
          (when event
            (push (list :consumer_run_id (plist-get call :run_id)
                        :artifact_id artifact-id
                        :effect_shape (canary--effect-shape event)
                        :event (canary--event-reference event))
                  explicit-reads)))))
    (setq explicit-reads (nreverse explicit-reads)
          criteria
          (list
           (canary--criterion
            "workflow-completed"
            (eq 'completed (plist-get view :status))
            (list :research_instance_id instance-id))
           (canary--criterion
            "three-deliverable-artifacts"
            (and (= 3 (length artifacts))
                 (cl-every
                  (lambda (artifact)
                    (and (eq 'deliver
                             (plist-get artifact :delivery-decision))
                         (plist-get artifact :available)))
                  artifacts))
            (mapcar (lambda (artifact)
                      (list :artifact_id (plist-get artifact :artifact-id)
                            :revision (plist-get artifact :revision)
                            :producer_run_id
                            (plist-get artifact :producer-run-id)))
                    artifacts))
           (canary--criterion
            "explicit-cross-run-consumption"
            (= 3 (length explicit-reads))
            explicit-reads)
           (canary--criterion
            "durable-terminal-closure"
            (cl-every
             (lambda (item)
               (and (equal "valid" (plist-get item :trace_verdict))
                    (equal "proved" (plist-get item :terminal_verdict))
                    (equal "completed" (plist-get item :terminal_kind))))
             closure-evidence)
            closure-evidence))
          outcome-passed
          (cl-every (lambda (item)
                      (equal "pass" (plist-get item :status)))
                    criteria))
    (let* ((prior-pass
            (and (= 3 (length canary--prompt-snapshots))
                 (= 3 (length closure-evidence))
                 (cl-every
                  (lambda (snapshot)
                    (and (equal (plist-get snapshot :system_prompt_sha256)
                                (plist-get snapshot
                                           :observed_system_prompt_sha256))
                         (equal (plist-get snapshot :target_model)
                                (plist-get
                                 (plist-get canary--manifest :prior)
                                 :model_id))
                         (equal (plist-get snapshot :prepared_tool_names)
                                (canary--tool-names
                                 (plist-get
                                  (plist-get canary--manifest :prior)
                                  :offered_tools)))))
                  canary--prompt-snapshots)))
           (execution-pass
            (and (= 3 (length closure-evidence))
                 (cl-every
                  (lambda (item)
                    (and (equal "valid" (plist-get item :trace_verdict))
                         (equal "proved" (plist-get item :terminal_verdict))
                         (equal "completed" (plist-get item :terminal_kind))))
                  closure-evidence)
                 (not (cl-find "tool.failed" all-events
                               :key (lambda (event)
                                      (plist-get event :type))
                               :test #'equal))))
           (artifact-pass
            (and (= 3 (length artifacts))
                 (= 3 (length explicit-reads))
                 (cl-every (lambda (artifact)
                             (and (stringp
                                   (plist-get artifact :producer-run-id))
                                  (eq 'deliver
                                      (plist-get artifact
                                                 :delivery-decision))
                                  (plist-get artifact :available)))
                           artifacts))))
      (setq gaps
            (list
             (list :evidence "baseline_intervention_pair"
                   :status "missing"
                   :expected_source "experiment_manifest"
                   :affected_gate "comparison"
                   :impact "cannot_make_causal_or_learning_claim"
                   :workaround "execute pre-registered Canary B"
                   :runtime_change_needed "no"))
            gates
            (list
             (canary--gate "prior" (if prior-pass "pass" "blocked")
                           (list :source_snapshots source-checks
                                 :prompt_count
                                 (length canary--prompt-snapshots)))
             (canary--gate "execution"
                           (if execution-pass "pass" "blocked")
                           closure-evidence)
             (canary--gate "artifact"
                           (if artifact-pass "pass" "blocked")
                           (list :artifact_count (length artifacts)
                                 :explicit_read_count
                                 (length explicit-reads)))
             (canary--gate "outcome"
                           (if outcome-passed "pass" "blocked") criteria)
             (canary--gate "comparison" "blocked" [] gaps)))
      (setq canary-passed
            (and prior-pass execution-pass artifact-pass outcome-passed)))
    (setq identity
          (list :experiment_id (plist-get canary--manifest :experiment_id)
                :attempt_id attempt-id
                :manifest_sha256 manifest-sha256
                :research_instance_id instance-id
                :runtime_database database
                :run_ids (mapcar (lambda (step) (plist-get step :run-id))
                                 steps)
                :actor_ids (mapcar (lambda (step) (plist-get step :actor-id))
                                   steps)))
    (canary--write-json
     (expand-file-name "evidence-bundle.json" output-directory)
     (list :identity identity
           :source_snapshots source-checks
           :prompt_snapshots canary--prompt-snapshots
           :prepared_tool_requests canary--prepared-tool-requests
           :observable_model_tool_calls canary--model-calls
           :tape_sessions
           (mapcar
            (lambda (session-id)
              (let ((events (canary--events session-id)))
                (list :session_id session-id
                      :event_count (length events)
                      :events (mapcar #'canary--event-reference events))))
            sessions)
           :closure closure-evidence
           :artifacts
           (mapcar
            (lambda (artifact)
              (list :artifact_id (plist-get artifact :artifact-id)
                    :uri (plist-get artifact :uri)
                    :revision (plist-get artifact :revision)
                    :producer_run_id
                    (plist-get artifact :producer-run-id)
                    :producer_actor_id
                    (plist-get artifact :producer-actor-id)
                    :delivery_decision
                    (symbol-name (plist-get artifact :delivery-decision))
                    :available (and (plist-get artifact :available) t)))
            artifacts)
           :explicit_consumers explicit-reads
           :gates gates))
    (canary--write-json
     (expand-file-name "outcome-record.json" output-directory)
     (list :outcome_record_id (concat attempt-id "-outcome")
           :experiment_id (plist-get canary--manifest :experiment_id)
           :research_instance_id instance-id
           :rubric_id
           (plist-get (plist-get canary--manifest :outcome) :rubric_id)
           :rubric_sha256
           (canary--sha256-string
            (json-encode
             (plist-get (plist-get canary--manifest :outcome) :criteria)))
           :evaluator_id
           (plist-get (plist-get canary--manifest :outcome) :evaluator_id)
           :evaluated_at (format-time-string "%Y-%m-%dT%H:%M:%S.%3NZ" nil t)
           :status (if outcome-passed "pass" "fail")
           :criteria criteria
           :missing_data []
           :abstentions []))
    (canary--write-gap-report
     (expand-file-name "evidence-gap-report.md" output-directory)
     identity gates gaps)
    (princ "\n=== Auditability Canary A ===\n")
    (pp (list :output-directory output-directory
              :identity identity
              :gates gates
              :gaps gaps))
    (if canary-passed
        (princ (format "\nCANARY_A_PASS output=%s\n" output-directory))
      (error "CANARY_A_BLOCKED output=%s" output-directory))))

(canary--main)

;;; run.el ends here
