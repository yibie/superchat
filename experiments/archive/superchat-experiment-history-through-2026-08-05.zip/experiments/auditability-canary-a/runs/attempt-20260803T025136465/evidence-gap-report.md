# Auditability Canary A v0 — Invalid Attempt

- Experiment: `auditability-canary-a-20260803-v0`
- Manifest snapshot: `manifest-v0.json`
- Runner snapshot: `run-v0.el`
- Research instance: `research-20260803-105136-467831-d58b`
- Runtime database: `runtime/superchat.db`
- Attempt result: `invalid`

The Research Workflow itself completed. The experiment runner aborted before
persisting its Evidence Bundle and Outcome Record, so the attempt is not
audit-ready.

## Post-mortem gate verdicts

| Gate | Verdict | Evidence |
|---|---|---|
| Prior | `blocked` | Source snapshots match, but exact prompt snapshots remained only in runner memory and were lost on abort. |
| Execution | `pass` | All three child traces are `valid`; all terminal judgments are `proved/completed`; Tape has 64 events and no `tool.failed`. |
| Artifact | `invalid` | Three producer Artifacts are available and revision-matched, but the declared explicit-consumer extractor could not decode replayed singleton `effects`. |
| Outcome | `blocked` | The frozen evaluator ran in memory, but no Outcome Record was persisted before abort. |
| Comparison | `blocked` | Canary A intentionally has no baseline/intervention pair. |

## Durable observations

| Role | Run | Artifact | Revision | Closure |
|---|---|---|---|---|
| collector | `run-20260803-105136-476031-a4d3` | `artifact-b437c1a8-1` | `dd427cc275c49cc7e31bd1f7e83b540f3e7148edc2c313576d5e8be5de998b0e` | `valid / proved-completed` |
| analyst | `run-20260803-105136-484601-7f9a` | `artifact-b437c1a8-2` | `950b2d87d5a8f39baf94d9b5fb057391741d8e8eeb1ca4b3383eecfc2a5e411b` | `valid / proved-completed` |
| reviewer | `run-20260803-105136-504174-2a19` | `artifact-b437c1a8-3` | `b373f5ac863a01b948495e490cbfe03678b14b4f4952bc3a3d731be2e9aba28f` | `valid / proved-completed` |

Tape contains three completed `workspace_read` executions:

- `evt_e0cc5f0c956a0a4d41f05b31cc` — Analyst read Collector Artifact.
- `evt_cb1c295d289fe380868e1ea077` — Reviewer read Analyst Artifact.
- `evt_8a0c042da11d8caed4a997da6b` — Reviewer read Collector Artifact.

## Evidence gaps

### report-before-assert

- Status: `invalid`
- Expected source: `experiment_runner`
- Affected gates: `prior`, `artifact`, `outcome`
- Impact: in-memory prompt, consumer, and evaluator evidence was lost when the runner asserted before writing reports.
- Workaround: persist gate state and reports before returning a failing exit status.
- Runtime change needed: `no`

### singleton-authority-effects-shape

- Status: `invalid`
- Expected source: `Tape / Authority`
- Affected gate: `artifact`
- Impact: a one-element effect list does not replay as a list of effect plists. For example, an explicit read replays as:

  ```elisp
  (:effects
   (:effect
    ("local-read" "resource" "workspace" "scope"
     "artifact-b437c1a8-1")))
  ```

  The Artifact ID remains present, but a consumer expecting the original
  `((:effect ... :resource ... :scope ...))` shape cannot reconstruct it
  without cardinality-aware normalization.
- Workaround: the v1 experiment reader may normalize both observed shapes and must report which one was used.
- Runtime change needed: `unknown`; one Canary is insufficient to expand Runtime, and the experiment layer has a bounded decoder.

### baseline-intervention-pair

- Status: `missing`
- Expected source: `experiment_manifest`
- Affected gate: `comparison`
- Impact: no causal or learning claim is permitted.
- Workaround: execute a separately frozen Canary B after Canary A closes.
- Runtime change needed: `no`

## Decision

This v0 attempt is retained as an invalid primary source. Do not reinterpret it
as a passing Canary. A new manifest revision is required before changing the
runner and executing again.
