# Auditability Canary A — Evidence Gap Report

- Experiment: `auditability-canary-a-20260803-v2`
- Manifest: `sha256:905fca8428a23724eb9a92f68f3d442e4d21915a5ef0b68b933daefdfd57777a`
- Research instance: `research-20260803-105922-794884-df03`
- Runtime database: `/Users/chenyibin/Documents/emacs/package/superchat/experiments/auditability-canary-a/runs/attempt-20260803T025922786/runtime/superchat.db`

## Gate verdicts

| Gate | Verdict |
|---|---|
| prior | `pass` |
| execution | `pass` |
| artifact | `pass` |
| outcome | `pass` |
| comparison | `blocked` |

## Evidence gaps

### baseline_intervention_pair

- Status: `missing`
- Expected source: `experiment_manifest`
- Affected gate: `comparison`
- Impact: `cannot_make_causal_or_learning_claim`
- Workaround: `execute pre-registered Canary B`
- Runtime change needed: `no`

## Non-blocking evidence observations

### singleton-authority-effects-shape

All three explicit `workspace_read` requests replayed their one-element
Authority effect list as `singleton-flattened`, not as a list of effect
plists. The Artifact IDs remained directly recoverable, so Canary v2's
bounded decoder closed Artifact evidence without inference.

This is not a request to change Runtime after one Canary. A second consumer
should first establish whether the cardinality-sensitive representation is a
repeated interoperability problem.

### research-prior-reference-json-shape

The exact Analyst and Reviewer Prompt snapshots show that Research Workflow's
`Prior Artifact references` uses the same ambiguous list-of-plists JSON
encoding. One reference becomes an object whose first key owns the flattened
plist; two references produce duplicate object keys.

Prior Closure still passes because the exact Prompt and source version were
captured. This observation concerns model-facing Workflow correctness, not
evidence completeness, and is not repaired inside this Canary.

## Decision

Canary A closes Prior, Execution, Artifact, and Outcome. Comparison remains blocked by design; no learning or causal claim is permitted.
