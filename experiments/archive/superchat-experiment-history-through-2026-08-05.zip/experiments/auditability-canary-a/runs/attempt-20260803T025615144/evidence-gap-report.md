# Auditability Canary A — Evidence Gap Report

- Experiment: `auditability-canary-a-20260803-v1`
- Manifest: `sha256:3f00bca84f7e45b5aaa1639c58c542e7c4cf90c27943b14c5ff67497d07c8a80`
- Research instance: `research-20260803-105615-146543-f123`
- Runtime database: `/Users/chenyibin/Documents/emacs/package/superchat/experiments/auditability-canary-a/runs/attempt-20260803T025615144/runtime/superchat.db`

## Gate verdicts

| Gate | Verdict |
|---|---|
| prior | `blocked` |
| execution | `pass` |
| artifact | `pass` |
| outcome | `pass` |
| comparison | `blocked` |

## Evidence gaps

### baseline_intervention_pair

- Status: `missing`
- Expected source: `experiment_manifest`
- Affected gate: `comparison`
- Impact: `cannot_make_causal_or_learning_claim`
- Workaround: `execute pre-registered Canary B`
- Runtime change needed: `no`

## Decision

Canary A closes Prior, Execution, Artifact, and Outcome only. Comparison remains blocked by design; no learning or causal claim is permitted.
