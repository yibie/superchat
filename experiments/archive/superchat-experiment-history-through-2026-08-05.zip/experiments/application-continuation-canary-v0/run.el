;;; run.el --- Application Continuation Canary v0 -*- lexical-binding: t; -*-

;;; Commentary:

;; Experiment-only one-shot continuation policy.  It preserves a completed
;; primary Run, and launches at most one child Run only when Closure is valid
;; and the primary produced no Artifact.  Runtime semantics are unchanged.

;;; Code:

(require 'cl-lib)
(require 'json)
(require 'subr-x)

(load "/Users/chenyibin/Documents/emacs/package/superchat/experiments/experience-cohort-v0/run-batch.el"
      nil nil t)

(defconst superchat-continuation-canary-v0--directory
  "/Users/chenyibin/Documents/emacs/package/superchat/experiments/application-continuation-canary-v0/")

(defconst superchat-continuation-canary-v0--root
  "/Users/chenyibin/.agent-reach/superchat/application-continuation-canary-v0/")

(defconst superchat-continuation-canary-v0--manifest-path
  (expand-file-name "manifest.json"
                    superchat-continuation-canary-v0--directory))

(defconst superchat-continuation-canary-v0--primary-task-path
  (expand-file-name "primary-task.txt"
                    superchat-continuation-canary-v0--directory))

(defconst superchat-continuation-canary-v0--continuation-task-path
  (expand-file-name "continuation-task.txt"
                    superchat-continuation-canary-v0--directory))

(defconst superchat-continuation-canary-v0--state-path
  (expand-file-name "execution-record.json"
                    superchat-continuation-canary-v0--directory))

(defconst superchat-continuation-canary-v0--prompt-path
  (expand-file-name "prompt-snapshots.json"
                    superchat-continuation-canary-v0--directory))

(defvar superchat-continuation-canary-v0--state nil)
(defvar superchat-continuation-canary-v0--prompts nil)

(setq superchat-data-directory
      (expand-file-name "runtime/" superchat-continuation-canary-v0--root)
      superchat-llm-backend
      (make-llm-ollama :chat-model "qwen3.6:latest")
      superchat-llm-model nil
      superchat-response-timeout 7200
      superchat-subagent-timeout 21600)

(defun superchat-continuation-canary-v0--read-file (path)
  "Return PATH contents."
  (with-temp-buffer
    (insert-file-contents path)
    (buffer-string)))

(defun superchat-continuation-canary-v0--read-json (path)
  "Read PATH as plist-backed JSON."
  (with-temp-buffer
    (insert-file-contents path)
    (json-parse-buffer :object-type 'plist :array-type 'list
                       :null-object nil :false-object json-false)))

(defun superchat-continuation-canary-v0--write-json (path value)
  "Write VALUE as JSON to PATH."
  (make-directory (file-name-directory path) t)
  (with-temp-file path
    (insert (json-encode value))
    (insert "\n")))

(defun superchat-continuation-canary-v0--sha256-file (path)
  "Return protocol-prefixed SHA-256 for PATH."
  (with-temp-buffer
    (set-buffer-multibyte nil)
    (insert-file-contents-literally path)
    (concat "sha256:" (secure-hash 'sha256 (current-buffer)))))

(defun superchat-continuation-canary-v0--sha256-string (value)
  "Return protocol-prefixed SHA-256 for VALUE."
  (concat "sha256:" (secure-hash 'sha256 (or value ""))))

(defun superchat-continuation-canary-v0--manifest ()
  "Return the frozen Canary Manifest."
  (superchat-continuation-canary-v0--read-json
   superchat-continuation-canary-v0--manifest-path))

(defun superchat-continuation-canary-v0--verify-inputs ()
  "Fail unless every frozen Canary input still matches its hash."
  (let ((manifest (superchat-continuation-canary-v0--manifest)))
    (unless (equal "canary-authorized" (plist-get manifest :status))
      (error "Continuation Canary is not authorized"))
    (dolist (input (plist-get manifest :frozen_inputs))
      (let* ((path (expand-file-name
                    (plist-get input :path)
                    "/Users/chenyibin/Documents/emacs/package/superchat/"))
             (actual (and (file-readable-p path)
                          (superchat-continuation-canary-v0--sha256-file
                           path))))
        (unless (equal actual (plist-get input :sha256))
          (error "Frozen input changed or missing: %s" path))))
    manifest))

(defun superchat-continuation-canary-v0--attempt-kind (prompt)
  "Return the Canary attempt kind encoded in PROMPT."
  (when (string-match
         "\\[application-continuation-canary-v0/\\(primary\\|continuation\\)\\]"
         (or prompt ""))
    (match-string 1 prompt)))

(defun superchat-continuation-canary-v0--tool-names (tools)
  "Normalize model-facing TOOLS to ordered names."
  (mapcar (lambda (tool)
            (cond ((stringp tool) tool)
                  ((symbolp tool) (symbol-name tool))
                  ((listp tool) (plist-get tool :name))
                  (t (format "%s" tool))))
          tools))

(defun superchat-continuation-canary-v0--write-prompts ()
  "Persist observed model-facing prompt snapshots."
  (superchat-continuation-canary-v0--write-json
   superchat-continuation-canary-v0--prompt-path
   (list :experiment_id "application-continuation-canary-v0"
         :snapshot_count (length superchat-continuation-canary-v0--prompts)
         :snapshots
         (vconcat (reverse superchat-continuation-canary-v0--prompts)))))

(defun superchat-continuation-canary-v0--capture-query
    (original turn &rest args)
  "Call ORIGINAL with TURN and ARGS, retaining the model-facing query."
  (let* ((result (apply original turn args))
         (prompt (plist-get result :prompt))
         (kind (superchat-continuation-canary-v0--attempt-kind prompt)))
    (when kind
      (let ((snapshot
             (list :attempt kind
                   :actor_id (and (boundp 'superchat--session-id)
                                  superchat--session-id)
                   :captured_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
                   :model_prompt prompt
                   :model_prompt_sha256
                   (superchat-continuation-canary-v0--sha256-string prompt)
                   :system_prompt (plist-get result :system-prompt)
                   :system_prompt_sha256
                   (superchat-continuation-canary-v0--sha256-string
                    (plist-get result :system-prompt))
                   :target_model
                   (or (plist-get result :target-model) "qwen3.6:latest")
                   :prepared_tool_names
                   (vconcat
                    (superchat-continuation-canary-v0--tool-names
                     (plist-get result :tools))))))
        (setq superchat-continuation-canary-v0--prompts
              (cons snapshot
                    (cl-remove kind
                               superchat-continuation-canary-v0--prompts
                               :key (lambda (old) (plist-get old :attempt))
                               :test #'equal)))
        (superchat-continuation-canary-v0--write-prompts)))
    result))

(defun superchat-continuation-canary-v0--write-state ()
  "Persist current experiment-only execution state."
  (superchat-continuation-canary-v0--write-json
   superchat-continuation-canary-v0--state-path
   superchat-continuation-canary-v0--state))

(defun superchat-continuation-canary-v0--artifact-views (run-id)
  "Return projected Artifact delivery views produced by RUN-ID."
  (mapcar
   #'superchat-research-workflow--artifact-view
   (cl-remove-if-not
    (lambda (artifact) (equal run-id (plist-get artifact :run-id)))
    (superchat-workspace-artifacts
     (plist-get superchat-continuation-canary-v0--state :workspace_id) t))))

(defun superchat-continuation-canary-v0--attempt-summary (attempt)
  "Return Closure, identity, and Artifact evidence for ATTEMPT."
  (let* ((actor-id (plist-get attempt :actor_id))
         (run-id (plist-get attempt :run_id))
         (events (superchat-tape-replay-events actor-id))
         (well
          (superchat-closure-judge
           (list :kind 'trace-well-formed :run-id run-id) events))
         (terminal
          (superchat-closure-judge
           (list :kind 'durable-run-terminal :run-id run-id) events))
         (tool-events
          (cl-remove-if-not
           (lambda (event)
             (and (equal run-id (plist-get event :run-id))
                  (string-prefix-p "tool." (or (plist-get event :type) ""))))
           events))
         (invalid-identity
          (cl-count-if-not
           (lambda (event)
             (and (equal actor-id (plist-get event :actor-id))
                  (stringp (plist-get event :turn-id))
                  (not (string-empty-p (plist-get event :turn-id)))))
           tool-events))
         (artifacts (superchat-continuation-canary-v0--artifact-views run-id))
         (deliverable
          (cl-remove-if-not
           (lambda (artifact)
             (and (eq 'deliver (plist-get artifact :delivery-decision))
                  (plist-get artifact :available)
                  (equal "collector" (plist-get artifact :role))))
           artifacts))
         (classification
          (cond ((null artifacts) "artifact_absent")
                ((and (= 1 (length artifacts))
                      (= 1 (length deliverable)))
                 "artifact_closure_pass")
                (t "artifact_present_provenance_invalid"))))
    (list :attempt (plist-get attempt :attempt)
          :actor_id actor-id
          :run_id run-id
          :parent_run_id (plist-get attempt :parent_run_id)
          :trace_verdict (symbol-name (plist-get well :verdict))
          :terminal_verdict (symbol-name (plist-get terminal :verdict))
          :terminal_kind
          (when-let* ((judgment (plist-get terminal :judgment))
                      (kind (plist-get judgment :terminal-kind)))
            (symbol-name kind))
          :tool_event_count (length tool-events)
          :tool_events_invalid_identity invalid-identity
          :tool_failed_count
          (cl-count "tool.failed" tool-events
                    :key (lambda (event) (plist-get event :type))
                    :test #'equal)
          :artifact_classification classification
          :artifact_count (length artifacts)
          :deliverable_count (length deliverable)
          :artifacts
          (vconcat
           (mapcar
            (lambda (artifact)
              (list :artifact_id (plist-get artifact :artifact-id)
                    :revision (plist-get artifact :revision)
                    :uri (plist-get artifact :uri)
                    :role (plist-get artifact :role)
                    :delivery_decision
                    (symbol-name (plist-get artifact :delivery-decision))
                    :available
                    (if (plist-get artifact :available) t json-false)))
            artifacts))
          :event_count (length events)
          :parent_identity_on_all_run_events
          (if (plist-get attempt :parent_run_id)
              (if (cl-every
                   (lambda (event)
                     (or (not (equal run-id (plist-get event :run-id)))
                         (equal (plist-get attempt :parent_run_id)
                                (plist-get event :parent-run-id))))
                   events)
                  t json-false)
            nil))))

(defun superchat-continuation-canary-v0--eligible-p (summary)
  "Return non-nil when primary SUMMARY permits one continuation."
  (and (equal "valid" (plist-get summary :trace_verdict))
       (equal "proved" (plist-get summary :terminal_verdict))
       (equal "completed" (plist-get summary :terminal_kind))
       (equal "artifact_absent"
              (plist-get summary :artifact_classification))))

(defun superchat-continuation-canary-v0--launch-attempt
    (kind task context parent-run-id callback)
  "Launch KIND TASK with CONTEXT, optional PARENT-RUN-ID, and CALLBACK."
  (let* ((canary-id (plist-get superchat-continuation-canary-v0--state
                               :canary_id))
         (workspace-id (plist-get superchat-continuation-canary-v0--state
                                  :workspace_id))
         (root superchat-continuation-canary-v0--root)
         (superchat--team-id canary-id)
         (superchat--team-actor "lead")
         (superchat--workspace-binding (list :id workspace-id :root root))
         (superchat--tool-execution-context
          (list :session-id canary-id
                :run-id parent-run-id
                :team-id canary-id
                :correlation-id canary-id
                :attendance 'attended
                :authority-policy "default"
                :workspace-id workspace-id
                :workspace-root root))
         (actor-id
          (superchat--subagent-run-async
           'researcher task context callback))
         (entry (superchat--subagent-entry actor-id))
         (run-id (plist-get entry :run-id))
         (runtime (superchat-runtime-status run-id)))
    (list :attempt kind
          :actor_id actor-id
          :run_id run-id
          :turn_id (plist-get runtime :turn-id)
          :parent_run_id parent-run-id
          :started_at (format-time-string "%Y-%m-%dT%H:%M:%S%z"))))

(defun superchat-continuation-canary-v0--finalize ()
  "Write final evidence and report for the settled Canary."
  (let* ((primary
          (superchat-continuation-canary-v0--attempt-summary
           (plist-get superchat-continuation-canary-v0--state :primary)))
         (continuation-record
          (plist-get superchat-continuation-canary-v0--state :continuation))
         (continuation
          (and continuation-record
               (superchat-continuation-canary-v0--attempt-summary
                continuation-record)))
         (prompt-pass
          (and (= 2 (length superchat-continuation-canary-v0--prompts))
               (equal '("primary" "continuation")
                      (mapcar
                       (lambda (snapshot) (plist-get snapshot :attempt))
                       (reverse superchat-continuation-canary-v0--prompts)))))
         (primary-pass
          (superchat-continuation-canary-v0--eligible-p primary))
         (lineage-pass
          (and continuation
               (equal (plist-get primary :run_id)
                      (plist-get continuation :parent_run_id))
               (eq t (plist-get continuation
                                :parent_identity_on_all_run_events))))
         (continuation-pass
          (and continuation
               (equal "valid" (plist-get continuation :trace_verdict))
               (equal "proved" (plist-get continuation :terminal_verdict))
               (equal "completed" (plist-get continuation :terminal_kind))
               (zerop (plist-get continuation
                                 :tool_events_invalid_identity))
               (zerop (plist-get continuation :tool_failed_count))))
         (artifact-pass
          (and continuation
               (equal "artifact_closure_pass"
                      (plist-get continuation :artifact_classification))))
         (pass (and prompt-pass primary-pass lineage-pass
                    continuation-pass artifact-pass))
         (evidence
          (list :experiment_id "application-continuation-canary-v0"
                :generated_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
                :trigger_observed (if primary-pass t json-false)
                :continuation_count (if continuation 1 0)
                :gates
                (vconcat
                 (list (list :name "prior" :verdict
                             (if prompt-pass "pass" "blocked"))
                       (list :name "primary-trigger" :verdict
                             (if primary-pass "pass" "blocked"))
                       (list :name "lineage" :verdict
                             (if lineage-pass "pass" "blocked"))
                       (list :name "continuation-execution" :verdict
                             (if continuation-pass "pass" "blocked"))
                       (list :name "artifact" :verdict
                             (if artifact-pass "pass" "blocked"))))
                :canary_gate (if pass "pass" "blocked")
                :attempts (vconcat (delq nil (list primary continuation)))
                :downstream_stages_started json-false
                :outcome_evaluation "not-evaluated"
                :effectiveness_claim "not_evaluated"
                :learning_claim "prohibited"))
         (json-path
          (expand-file-name "evidence-bundle.json"
                            superchat-continuation-canary-v0--directory))
         (report-path
          (expand-file-name "canary-report.md"
                            superchat-continuation-canary-v0--directory)))
    (superchat-continuation-canary-v0--write-json json-path evidence)
    (with-temp-file report-path
      (insert "# Application Continuation Canary v0\n\n")
      (insert (format "Canary Gate: **%s**\n\n"
                      (plist-get evidence :canary_gate)))
      (insert (format "Trigger observed: `%s`; continuation count: `%d`.\n\n"
                      (if primary-pass "true" "false")
                      (if continuation 1 0)))
      (insert (format "Primary: `%s`; continuation: `%s`.\n\n"
                      (plist-get primary :artifact_classification)
                      (or (and continuation
                               (plist-get continuation
                                          :artifact_classification))
                          "not-launched")))
      (insert "No Analyst, Reviewer, Outcome, effectiveness, Pattern, or Learning claim is authorized.\n"))
    (setq superchat-continuation-canary-v0--state
          (plist-put superchat-continuation-canary-v0--state
                     :status "settled"))
    (setq superchat-continuation-canary-v0--state
          (plist-put superchat-continuation-canary-v0--state
                     :canary_gate (if pass "pass" "blocked")))
    (superchat-continuation-canary-v0--write-state)
    evidence))

(defun superchat-continuation-canary-v0--continuation-finished (report)
  "Record continuation REPORT and finalize the Canary."
  (let ((attempt (plist-get superchat-continuation-canary-v0--state
                            :continuation)))
    (setq attempt
          (append attempt
                  (list :response_length (length (or report ""))
                        :response_sha256
                        (superchat-continuation-canary-v0--sha256-string
                         report))))
    (setq superchat-continuation-canary-v0--state
          (plist-put superchat-continuation-canary-v0--state
                     :continuation attempt))
    (superchat-continuation-canary-v0--write-state)
    (superchat-continuation-canary-v0--finalize)))

(defun superchat-continuation-canary-v0--launch-continuation (report)
  "Launch the one permitted continuation using primary REPORT as context."
  (let* ((primary (plist-get superchat-continuation-canary-v0--state :primary))
         (task
          (string-trim-right
           (superchat-continuation-canary-v0--read-file
            superchat-continuation-canary-v0--continuation-task-path)))
         (context
          (format
           (concat "Parent Run: %s\nOriginal task:\n%s\n\n"
                   "Parent final response (incomplete):\n%s")
           (plist-get primary :run_id)
           (string-trim-right
            (superchat-continuation-canary-v0--read-file
             superchat-continuation-canary-v0--primary-task-path))
           report))
         (attempt
          (superchat-continuation-canary-v0--launch-attempt
           "continuation" task context (plist-get primary :run_id)
           #'superchat-continuation-canary-v0--continuation-finished)))
    (setq superchat-continuation-canary-v0--state
          (plist-put superchat-continuation-canary-v0--state
                     :continuation attempt))
    (setq superchat-continuation-canary-v0--state
          (plist-put superchat-continuation-canary-v0--state
                     :status "continuation-running"))
    (superchat-continuation-canary-v0--write-state)
    attempt))

(defun superchat-continuation-canary-v0--primary-finished (report)
  "Record primary REPORT and apply the frozen continuation trigger."
  (let* ((attempt (plist-get superchat-continuation-canary-v0--state :primary))
         (attempt
          (append attempt
                  (list :response_length (length (or report ""))
                        :response_sha256
                        (superchat-continuation-canary-v0--sha256-string
                         report))))
         (summary (superchat-continuation-canary-v0--attempt-summary attempt)))
    (setq superchat-continuation-canary-v0--state
          (plist-put superchat-continuation-canary-v0--state
                     :primary attempt))
    (setq superchat-continuation-canary-v0--state
          (plist-put superchat-continuation-canary-v0--state
                     :trigger_observed
                     (if (superchat-continuation-canary-v0--eligible-p summary)
                         t json-false)))
    (superchat-continuation-canary-v0--write-state)
    (if (superchat-continuation-canary-v0--eligible-p summary)
        (superchat-continuation-canary-v0--launch-continuation report)
      (superchat-continuation-canary-v0--finalize))))

(defun superchat-continuation-canary-v0-start ()
  "Start the one preregistered primary attempt exactly once."
  (interactive)
  (superchat-continuation-canary-v0--verify-inputs)
  (when superchat-continuation-canary-v0--state
    (error "Continuation Canary already started"))
  (let* ((canary-id
          (format "continuation-canary-%s-%04x"
                  (format-time-string "%Y%m%d-%H%M%S-%6N")
                  (random 65536)))
         (task
          (string-trim-right
           (superchat-continuation-canary-v0--read-file
            superchat-continuation-canary-v0--primary-task-path))))
    (superchat-workspace-bind
     canary-id superchat-continuation-canary-v0--root canary-id)
    (setq superchat-continuation-canary-v0--state
          (list :experiment_id "application-continuation-canary-v0"
                :manifest_sha256
                (superchat-continuation-canary-v0--sha256-file
                 superchat-continuation-canary-v0--manifest-path)
                :status "primary-running"
                :canary_id canary-id
                :workspace_id canary-id
                :started_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
                :continuation_limit 1
                :historical_runs_imported json-false
                :downstream_stages_started json-false
                :effectiveness_claim "not_evaluated"
                :learning_claim "prohibited"))
    (superchat-continuation-canary-v0--write-state)
    (let ((attempt
           (superchat-continuation-canary-v0--launch-attempt
            "primary" task nil nil
            #'superchat-continuation-canary-v0--primary-finished)))
      (setq superchat-continuation-canary-v0--state
            (plist-put superchat-continuation-canary-v0--state
                       :primary attempt))
      (superchat-continuation-canary-v0--write-state)
      attempt)))

(defun superchat-continuation-canary-v0-status ()
  "Return current Canary state and live Runtime statuses."
  (interactive)
  (list :state superchat-continuation-canary-v0--state
        :runtime
        (vconcat
         (delq nil
               (mapcar
                (lambda (key)
                  (when-let* ((attempt
                               (plist-get
                                superchat-continuation-canary-v0--state key))
                              (run-id (plist-get attempt :run_id)))
                    (superchat-runtime-status run-id)))
                '(:primary :continuation))))))

(make-directory superchat-continuation-canary-v0--root t)
(superchat-continuation-canary-v0--verify-inputs)
(unless (advice-member-p #'superchat-continuation-canary-v0--capture-query
                         'superchat--execute-llm-query)
  (advice-add 'superchat--execute-llm-query :around
              #'superchat-continuation-canary-v0--capture-query))

(provide 'superchat-continuation-canary-v0-run)

;;; run.el ends here
