# Application Continuation Canary v0 — Evidence Gap Report

## Verdict

`blocked`

The preregistered trigger fired and exactly one continuation Run was created.
The continuation preserved the parent identity and completed with a valid
Closure trace, but it did not publish an Artifact.  No downstream stage,
Outcome evaluation, effectiveness claim, Pattern observation, or Learning
claim was started.

## Gate results

| Gate | Verdict | Evidence |
| --- | --- | --- |
| Prior | blocked | Only one model-facing snapshot was retained because the continuation prompt contained both the continuation marker and the embedded primary marker. |
| Primary trigger | pass | The primary trace was valid, its durable terminal was proved as `completed`, and its Artifact classification was `artifact_absent`. |
| Lineage | pass | The continuation is a new Run whose `parent_run_id` is the primary Run. Runtime events use the same workspace and correlation identity. |
| Continuation execution | pass | The continuation trace was valid, its terminal was proved as `completed`, and all 12 tool lifecycle events had valid identity with no `tool.failed`. |
| Artifact | blocked | Neither Run called `workspace_publish`; both are `artifact_absent`. |

## Runs

- Primary: `run-20260804-100428-119358-d9e6`
- Continuation: `run-20260804-100449-139132-cdf1`
- Shared workspace/correlation: `continuation-canary-20260804-100428-105446-e05d`

The primary requested `workspace_info` and `agent_reach_search`, then ended with
a transitional response saying it would read the primary sources.  The
continuation requested `workspace_info`, `team_task`, `team_message`, and
`agent_reach_search`, then also ended with a transitional response saying it
would read the source pages.  It did not call `agent_reach_read` or
`workspace_publish`.

## Independent evidence checks

- Stopped SQLite snapshot integrity: `ok`
- Tape rows: `38`
- Snapshot SHA-256: `e5dd96af911cf76d04e85e145f3c0f314bd8faa56e3f82f25e04f26db30978c1`
- Original parent terminal facts were retained; no historical event was edited.
- Exactly one continuation was launched; no retry or task substitution occurred.

## Harness gaps exposed

1. `superchat-continuation-canary-v0--attempt-kind` uses the first marker in a
   prompt.  Because continuation context embeds the original primary task, the
   continuation prompt contains both markers and is misclassified as primary.
   The frozen self-check covered only a single marker.
2. The generated lineage Gate checks `parent_run_id`, but does not itself assert
   the manifest's same-workspace and same-correlation requirements.  The raw
   Runtime events satisfy both requirements in this run, so this is verifier
   coverage debt rather than a failed Runtime fact.

These gaps do not change the Artifact result and must not be repaired by
rewriting this Canary's evidence.

## Next gate

Do not resume Calibration or rerun this frozen Canary.  A successor Canary must
first harden the experiment-only prompt classifier and lineage assertions, then
preregister one bounded application-level continuation policy.  Runtime,
Closure, Authority, Workspace semantics, and the archived v0 facts remain
unchanged.
