;;; self-check.el --- Continuation Canary trigger check -*- lexical-binding: t; -*-

(require 'superchat-continuation-canary-v0-run)

(let ((eligible '(:trace_verdict "valid"
                  :terminal_verdict "proved"
                  :terminal_kind "completed"
                  :artifact_classification "artifact_absent")))
  (unless (and (superchat-continuation-canary-v0--eligible-p eligible)
               (not (superchat-continuation-canary-v0--eligible-p
                     (plist-put (copy-sequence eligible)
                                :artifact_classification
                                "artifact_closure_pass")))
               (equal "continuation"
                      (superchat-continuation-canary-v0--attempt-kind
                       "[application-continuation-canary-v0/continuation]")))
    (error "Continuation Canary self-check failed")))

(provide 'superchat-continuation-canary-v0-self-check)

;;; self-check.el ends here
