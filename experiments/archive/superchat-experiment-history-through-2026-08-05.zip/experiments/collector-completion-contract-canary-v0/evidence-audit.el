;;; evidence-audit.el --- Read-only correction for Canary v0 evidence -*- lexical-binding: t; -*-

;;; Commentary:

;; The frozen runner compared the projected Artifact role symbol `collector'
;; with the string "collector".  This read-only consumer preserves the original
;; Bundle and recomputes only the affected Artifact Gate from durable facts.

;;; Code:

(require 'superchat-collector-completion-contract-canary-v0-run)

(defconst superchat-collector-contract-canary-v0--correction-path
  (expand-file-name "evidence-correction-v1.json"
                    superchat-collector-contract-canary-v0--directory))

(defconst superchat-collector-contract-canary-v0--corrected-report-path
  (expand-file-name "canary-report-v1.md"
                    superchat-collector-contract-canary-v0--directory))

(defun superchat-collector-contract-canary-v0--normalize-role (role)
  "Return ROLE as a string without changing its domain meaning."
  (if (symbolp role) (symbol-name role) role))

(defun superchat-collector-contract-canary-v0--gate-verdict (evidence name)
  "Return NAME's verdict from EVIDENCE."
  (plist-get
   (cl-find name (plist-get evidence :gates)
            :key (lambda (gate) (plist-get gate :name))
            :test #'equal)
   :verdict))

(defun superchat-collector-contract-canary-v0-audit-evidence ()
  "Write a versioned Artifact Gate correction from immutable Runtime facts."
  (interactive)
  (unless (and (equal "collector"
                      (superchat-collector-contract-canary-v0--normalize-role
                       'collector))
               (equal "collector"
                      (superchat-collector-contract-canary-v0--normalize-role
                       "collector")))
    (error "Collector role normalization self-check failed"))
  (let* ((original
          (superchat-collector-contract-canary-v0--read-json
           superchat-collector-contract-canary-v0--evidence-path))
         (collector
          (plist-get superchat-collector-contract-canary-v0--state :collector))
         (run-id (plist-get collector :run_id))
         (workspace-id
          (plist-get superchat-collector-contract-canary-v0--state
                     :workspace_id))
         (raw-artifacts
          (cl-remove-if-not
           (lambda (artifact) (equal run-id (plist-get artifact :run-id)))
           (superchat-workspace-artifacts workspace-id t)))
         (artifact (car raw-artifacts))
         (view (and artifact
                    (superchat-collector-contract-canary-v0--artifact-view
                     artifact)))
         (role (and view (plist-get view :role)))
         (corrected-pass
          (and (= 1 (length raw-artifacts))
               (equal "collector"
                      (superchat-collector-contract-canary-v0--normalize-role
                       role))
               (equal run-id (plist-get view :run-id))
               (eq 'deliver (plist-get view :delivery-decision))
               (plist-get view :available)
               (eq t (plist-get view :payload-matches))
               (equal
                (plist-get view :content-sha256)
                (plist-get
                 (superchat-collector-contract-canary-v0--manifest)
                 :expected_payload_sha256))))
         (upstream-pass
          (cl-every
           (lambda (name)
             (equal "pass"
                    (superchat-collector-contract-canary-v0--gate-verdict
                     original name)))
           '("prior" "execution" "publish")))
         (pass (and upstream-pass corrected-pass))
         (correction
          (list
           :experiment_id "collector-completion-contract-canary-v0"
           :correction_id "collector-role-shape-v1"
           :generated_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
           :scope "experiment-evidence-decoder-only"
           :original_bundle_path
           "experiments/collector-completion-contract-canary-v0/evidence-bundle.json"
           :original_bundle_sha256
           (superchat-collector-contract-canary-v0--sha256-file
            superchat-collector-contract-canary-v0--evidence-path)
           :original_bundle_immutable t
           :runtime_events_rewritten json-false
           :workspace_facts_rewritten json-false
           :defect
           (list :field "artifact.role"
                 :observed_value (format "%s" role)
                 :observed_elisp_type (symbol-name (type-of role))
                 :decoder_expectation "string"
                 :normalization "symbol-name when symbol; identity when string")
           :gates
           (vconcat
            (list (list :name "prior" :verdict
                        (superchat-collector-contract-canary-v0--gate-verdict
                         original "prior"))
                  (list :name "execution" :verdict
                        (superchat-collector-contract-canary-v0--gate-verdict
                         original "execution"))
                  (list :name "publish" :verdict
                        (superchat-collector-contract-canary-v0--gate-verdict
                         original "publish"))
                  (list :name "artifact" :verdict
                        (if corrected-pass "pass" "blocked"))))
           :canary_gate (if pass "pass" "blocked")
           :interpretation
           (if pass
               "minimal_collector_contract_closed"
             "artifact_evidence_correction_failed")
           :artifact
           (list :artifact_id (plist-get view :artifact-id)
                 :run_id (plist-get view :run-id)
                 :workspace_id workspace-id
                 :revision (plist-get view :revision)
                 :uri (plist-get view :uri)
                 :role (format "%s" role)
                 :role_elisp_type (symbol-name (type-of role))
                 :delivery_decision
                 (symbol-name (plist-get view :delivery-decision))
                 :available (if (plist-get view :available) t json-false)
                 :content_sha256 (plist-get view :content-sha256)
                 :payload_matches
                 (if (eq t (plist-get view :payload-matches)) t json-false))
           :continuation_count 0
           :retry_count 0
           :stability_claim "not_evaluated"
           :effectiveness_claim "not_evaluated"
           :learning_claim "prohibited")))
    (superchat-collector-contract-canary-v0--write-json
     superchat-collector-contract-canary-v0--correction-path correction)
    (with-temp-file
        superchat-collector-contract-canary-v0--corrected-report-path
      (insert "# Collector Completion Contract Canary v0 — Corrected Evidence\n\n")
      (insert (format "Canary Gate: **%s**\n\n"
                      (if pass "pass" "blocked")))
      (insert
       "The original Bundle is preserved. Its Artifact Gate was blocked by an experiment-only symbol/string role comparison.\n\n")
      (insert
       (format
        "Durable facts: publish completed; Artifact `%s`; delivery `%s`; available `%s`; exact payload `%s`.\n\n"
        (plist-get view :artifact-id)
        (plist-get view :delivery-decision)
        (if (plist-get view :available) "true" "false")
        (if (eq t (plist-get view :payload-matches)) "true" "false")))
      (insert
       "This pass proves one minimum Collector contract can close. Stability, effectiveness, Pattern, and Learning remain unevaluated.\n"))
    correction))

(provide 'superchat-collector-completion-contract-canary-v0-evidence-audit)

;;; evidence-audit.el ends here
