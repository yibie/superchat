;;; run.el --- Minimal Collector completion contract Canary -*- lexical-binding: t; -*-

;;; Commentary:

;; Experiment-only runner.  It starts one Collector Run with supplied content,
;; two Workspace tools, and no continuation, retry, or downstream stage.

;;; Code:

(require 'cl-lib)
(require 'json)
(require 'subr-x)
(require 'superchat)
(require 'superchat-subagent)
(require 'superchat-closure)
(require 'superchat-workflow)
(require 'llm-ollama)

(defconst superchat-collector-contract-canary-v0--directory
  "/Users/chenyibin/Documents/emacs/package/superchat/experiments/collector-completion-contract-canary-v0/")

(defconst superchat-collector-contract-canary-v0--root
  "/Users/chenyibin/.agent-reach/superchat/collector-completion-contract-canary-v0/")

(defconst superchat-collector-contract-canary-v0--manifest-path
  (expand-file-name "manifest.json"
                    superchat-collector-contract-canary-v0--directory))

(defconst superchat-collector-contract-canary-v0--task-path
  (expand-file-name "task.txt"
                    superchat-collector-contract-canary-v0--directory))

(defconst superchat-collector-contract-canary-v0--payload-path
  (expand-file-name "payload.txt"
                    superchat-collector-contract-canary-v0--directory))

(defconst superchat-collector-contract-canary-v0--execution-path
  (expand-file-name "execution-record.json"
                    superchat-collector-contract-canary-v0--directory))

(defconst superchat-collector-contract-canary-v0--prompt-path
  (expand-file-name "prompt-snapshot.json"
                    superchat-collector-contract-canary-v0--directory))

(defconst superchat-collector-contract-canary-v0--evidence-path
  (expand-file-name "evidence-bundle.json"
                    superchat-collector-contract-canary-v0--directory))

(defconst superchat-collector-contract-canary-v0--report-path
  (expand-file-name "canary-report.md"
                    superchat-collector-contract-canary-v0--directory))

(defconst superchat-collector-contract-canary-v0--allowed-tools
  '("workspace_info" "workspace_publish"))

(defvar superchat-collector-contract-canary-v0--state nil)
(defvar superchat-collector-contract-canary-v0--snapshot nil)

(setq superchat-data-directory
      (expand-file-name "runtime/"
                        superchat-collector-contract-canary-v0--root)
      superchat-llm-backend
      (make-llm-ollama :chat-model "qwen3.6:latest")
      superchat-llm-model nil
      superchat-response-timeout 600
      superchat-subagent-timeout 1800)

(defun superchat-collector-contract-canary-v0--read-file (path)
  "Return PATH contents without trailing whitespace."
  (with-temp-buffer
    (insert-file-contents path)
    (string-trim-right (buffer-string))))

(defun superchat-collector-contract-canary-v0--read-json (path)
  "Read PATH as a plist-backed JSON object."
  (with-temp-buffer
    (insert-file-contents path)
    (json-parse-buffer :object-type 'plist :array-type 'list
                       :null-object nil :false-object json-false)))

(defun superchat-collector-contract-canary-v0--write-json (path value)
  "Write VALUE as JSON to PATH."
  (with-temp-file path
    (insert (json-encode value))
    (insert "\n")))

(defun superchat-collector-contract-canary-v0--sha256-file (path)
  "Return protocol-prefixed SHA-256 for PATH."
  (with-temp-buffer
    (set-buffer-multibyte nil)
    (insert-file-contents-literally path)
    (concat "sha256:" (secure-hash 'sha256 (current-buffer)))))

(defun superchat-collector-contract-canary-v0--sha256-string (value)
  "Return protocol-prefixed SHA-256 for VALUE."
  (concat "sha256:" (secure-hash 'sha256 (or value ""))))

(defun superchat-collector-contract-canary-v0--payload ()
  "Return the exact supplied Artifact payload."
  (superchat-collector-contract-canary-v0--read-file
   superchat-collector-contract-canary-v0--payload-path))

(defun superchat-collector-contract-canary-v0--task ()
  "Return the frozen model-facing Collector task."
  (concat
   (superchat-collector-contract-canary-v0--read-file
    superchat-collector-contract-canary-v0--task-path)
   "\n\n<artifact_payload>\n"
   (superchat-collector-contract-canary-v0--payload)
   "\n</artifact_payload>"))

(defun superchat-collector-contract-canary-v0--manifest ()
  "Return the frozen Canary Manifest."
  (superchat-collector-contract-canary-v0--read-json
   superchat-collector-contract-canary-v0--manifest-path))

(defun superchat-collector-contract-canary-v0--verify-inputs ()
  "Fail unless every frozen Canary input still matches its hash."
  (let ((manifest (superchat-collector-contract-canary-v0--manifest)))
    (unless (equal "canary-authorized" (plist-get manifest :status))
      (error "Collector completion Canary is not authorized"))
    (unless (equal superchat-collector-contract-canary-v0--allowed-tools
                   (plist-get manifest :model_tool_surface))
      (error "Collector completion Canary tool surface changed"))
    (unless (equal (plist-get manifest :expected_payload_sha256)
                   (superchat-collector-contract-canary-v0--sha256-string
                    (superchat-collector-contract-canary-v0--payload)))
      (error "Collector completion Canary payload transform changed"))
    (dolist (input (plist-get manifest :frozen_inputs))
      (let* ((path (expand-file-name
                    (plist-get input :path)
                    "/Users/chenyibin/Documents/emacs/package/superchat/"))
             (actual (and (file-readable-p path)
                          (superchat-collector-contract-canary-v0--sha256-file
                           path))))
        (unless (equal actual (plist-get input :sha256))
          (error "Frozen input changed or missing: %s" path))))
    manifest))

(defun superchat-collector-contract-canary-v0--preset ()
  "Return the frozen minimal Collector preset."
  (superchat--subagent-make-preset
   "researcher" "researcher"
   "Minimal Collector durable publication Canary"
   'agent "research"
   superchat-collector-contract-canary-v0--allowed-tools
   (concat
    "You are the Collector in a completion-contract Canary. The complete "
    "Artifact content is supplied in the task. Publish exactly that content "
    "once through workspace_publish with role collector. workspace_info is "
    "optional. Do not narrate a future action or finish before publication "
    "succeeds.")))

(defun superchat-collector-contract-canary-v0--permission (tool-name _args)
  "Allow only the frozen model-facing TOOL-NAME surface."
  (if (member tool-name superchat-collector-contract-canary-v0--allowed-tools)
      'allow
    'deny))

(defun superchat-collector-contract-canary-v0--configure-surface ()
  "Install the experiment-only preset and Authority permission hook."
  (setcdr (assoc "researcher" superchat--subagent-builtin-presets)
          #'superchat-collector-contract-canary-v0--preset)
  (setq superchat-agent-permission-functions
        '(superchat-collector-contract-canary-v0--permission)))

(defun superchat-collector-contract-canary-v0--tool-names (tools)
  "Normalize model-facing TOOLS to ordered names."
  (mapcar (lambda (tool)
            (cond ((stringp tool) tool)
                  ((symbolp tool) (symbol-name tool))
                  ((listp tool) (plist-get tool :name))
                  (t (format "%s" tool))))
          tools))

(defun superchat-collector-contract-canary-v0--capture-query
    (original turn &rest args)
  "Call ORIGINAL with TURN and ARGS, retaining this actor's actual query."
  (let* ((actor-id (and (boundp 'superchat--session-id)
                        superchat--session-id))
         (result (apply original turn args))
         (prompt (plist-get result :prompt)))
    (when (and actor-id
               (string-match-p
                (regexp-quote "[collector-completion-contract-canary-v0]")
                (or prompt "")))
      (when superchat-collector-contract-canary-v0--snapshot
        (error "Collector completion Canary observed more than one query"))
      (setq superchat-collector-contract-canary-v0--snapshot
            (list :attempt "collector"
                  :actor_id actor-id
                  :captured_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
                  :model_prompt prompt
                  :model_prompt_sha256
                  (superchat-collector-contract-canary-v0--sha256-string prompt)
                  :system_prompt (plist-get result :system-prompt)
                  :system_prompt_sha256
                  (superchat-collector-contract-canary-v0--sha256-string
                   (plist-get result :system-prompt))
                  :target_model
                  (or (plist-get result :target-model) "qwen3.6:latest")
                  :prepared_tool_names
                  (vconcat
                   (superchat-collector-contract-canary-v0--tool-names
                    (plist-get result :tools)))))
      (superchat-collector-contract-canary-v0--write-json
       superchat-collector-contract-canary-v0--prompt-path
       (list :experiment_id "collector-completion-contract-canary-v0"
             :snapshot_count 1
             :snapshot superchat-collector-contract-canary-v0--snapshot)))
    result))

(defun superchat-collector-contract-canary-v0--event-tool-name (event)
  "Return normalized tool name from EVENT."
  (let ((payload (plist-get event :payload)))
    (or (plist-get payload :tool-name)
        (plist-get payload :tool_name))))

(defun superchat-collector-contract-canary-v0--artifact-view (artifact)
  "Return delivery facts and content match for ARTIFACT."
  (let* ((view (superchat-research-workflow--artifact-view artifact))
         (content
          (and (eq 'deliver (plist-get view :delivery-decision))
               (plist-get view :available)
               (condition-case nil
                   (superchat-workspace-read
                    (plist-get artifact :artifact-id)
                    (plist-get artifact :workspace-id)
                    (plist-get artifact :revision))
                 (error nil)))))
    (append
     view
     (list :run-id (plist-get artifact :run-id)
           :content-sha256
           (and content
                (superchat-collector-contract-canary-v0--sha256-string
                 content))
           :payload-matches
           (if (equal content
                      (superchat-collector-contract-canary-v0--payload))
               t json-false)))))

(defun superchat-collector-contract-canary-v0--attempt-summary ()
  "Return Closure, tool, scope, and Artifact evidence for the Collector."
  (let* ((attempt
          (plist-get superchat-collector-contract-canary-v0--state :collector))
         (actor-id (plist-get attempt :actor_id))
         (run-id (plist-get attempt :run_id))
         (workspace-id
          (plist-get superchat-collector-contract-canary-v0--state
                     :workspace_id))
         (events (superchat-tape-replay-events actor-id))
         (run-events
          (cl-remove-if-not
           (lambda (event) (equal run-id (plist-get event :run-id)))
           events))
         (tool-events
          (cl-remove-if-not
           (lambda (event)
             (string-prefix-p "tool." (or (plist-get event :type) "")))
           run-events))
         (publish-requested
          (cl-count-if
           (lambda (event)
             (and (equal "tool.requested" (plist-get event :type))
                  (equal "workspace_publish"
                         (superchat-collector-contract-canary-v0--event-tool-name
                          event))))
           tool-events))
         (publish-completed
          (cl-count-if
           (lambda (event)
             (and (equal "tool.completed" (plist-get event :type))
                  (equal "workspace_publish"
                         (superchat-collector-contract-canary-v0--event-tool-name
                          event))))
           tool-events))
         (invalid-tool-identity
          (cl-count-if-not
           (lambda (event)
             (and (equal actor-id (plist-get event :actor-id))
                  (stringp (plist-get event :turn-id))
                  (not (string-empty-p (plist-get event :turn-id)))))
           tool-events))
         (invalid-scope-identity
          (cl-count-if-not
           (lambda (event)
             (and (equal actor-id (plist-get event :actor-id))
                  (equal workspace-id (plist-get event :workspace-id))
                  (equal workspace-id (plist-get event :correlation-id))
                  (null (plist-get event :parent-run-id))))
           run-events))
         (well
          (superchat-closure-judge
           (list :kind 'trace-well-formed :run-id run-id) events))
         (terminal
          (superchat-closure-judge
           (list :kind 'durable-run-terminal :run-id run-id) events))
         (artifacts
          (mapcar
           #'superchat-collector-contract-canary-v0--artifact-view
           (cl-remove-if-not
            (lambda (artifact) (equal run-id (plist-get artifact :run-id)))
            (superchat-workspace-artifacts workspace-id t))))
         (deliverable
          (cl-remove-if-not
           (lambda (artifact)
             (and (eq 'deliver (plist-get artifact :delivery-decision))
                  (plist-get artifact :available)
                  (equal "collector" (plist-get artifact :role))))
           artifacts))
         (classification
          (cond ((null artifacts) "artifact_absent")
                ((and (= 1 (length artifacts))
                      (= 1 (length deliverable)))
                 "artifact_closure_pass")
                (t "artifact_present_provenance_invalid"))))
    (list :attempt "collector"
          :actor_id actor-id
          :run_id run-id
          :turn_id (plist-get attempt :turn_id)
          :parent_run_id nil
          :trace_verdict (symbol-name (plist-get well :verdict))
          :terminal_verdict (symbol-name (plist-get terminal :verdict))
          :terminal_kind
          (when-let* ((judgment (plist-get terminal :judgment))
                      (kind (plist-get judgment :terminal-kind)))
            (symbol-name kind))
          :run_event_count (length run-events)
          :tool_event_count (length tool-events)
          :tool_events_invalid_identity invalid-tool-identity
          :scope_events_invalid_identity invalid-scope-identity
          :unexpected_tool_request_count
          (cl-count-if
           (lambda (event)
             (and (equal "tool.requested" (plist-get event :type))
                  (not (member
                        (superchat-collector-contract-canary-v0--event-tool-name
                         event)
                        superchat-collector-contract-canary-v0--allowed-tools))))
           tool-events)
          :workspace_publish_requested publish-requested
          :workspace_publish_completed publish-completed
          :tool_failed_count
          (cl-count "tool.failed" tool-events
                    :key (lambda (event) (plist-get event :type))
                    :test #'equal)
          :artifact_classification classification
          :artifact_count (length artifacts)
          :deliverable_count (length deliverable)
          :payload_matches
          (if (and (= 1 (length deliverable))
                   (eq t (plist-get (car deliverable) :payload-matches)))
              t json-false)
          :artifacts (vconcat artifacts))))

(defun superchat-collector-contract-canary-v0--same-tool-surface-p (tools)
  "Return non-nil when TOOLS exactly names the frozen surface."
  (and (= (length tools)
          (length superchat-collector-contract-canary-v0--allowed-tools))
       (null
        (cl-set-exclusive-or
         (append tools nil)
         superchat-collector-contract-canary-v0--allowed-tools
         :test #'equal))))

(defun superchat-collector-contract-canary-v0--interpret
    (prior-pass execution-pass summary artifact-pass)
  "Return the preregistered interpretation for the observed facts."
  (cond
   ((not prior-pass) "prior_evidence_incomplete")
   ((not execution-pass) "execution_evidence_invalid")
   ((zerop (plist-get summary :workspace_publish_requested))
    "model_did_not_select_workspace_publish")
   ((or (not (= 1 (plist-get summary :workspace_publish_requested)))
        (not (= 1 (plist-get summary :workspace_publish_completed)))
        (not (zerop (plist-get summary :tool_failed_count))))
    "workspace_publish_denied_or_failed")
   ((not (equal "artifact_closure_pass"
                (plist-get summary :artifact_classification)))
    "artifact_present_provenance_invalid")
   ((not (eq t (plist-get summary :payload_matches)))
    "published_payload_mismatch")
   ((not artifact-pass) "artifact_contract_invalid")
   (t "minimal_collector_contract_closed")))

(defun superchat-collector-contract-canary-v0--finalize ()
  "Write final evidence and report for the settled Canary."
  (let* ((summary (superchat-collector-contract-canary-v0--attempt-summary))
         (snapshot superchat-collector-contract-canary-v0--snapshot)
         (prior-pass
          (and snapshot
               (equal (plist-get summary :actor_id)
                      (plist-get snapshot :actor_id))
               (string-match-p
                (regexp-quote "[collector-completion-contract-canary-v0]")
                (or (plist-get snapshot :model_prompt) ""))
               (string-match-p
                (regexp-quote (superchat-collector-contract-canary-v0--payload))
                (or (plist-get snapshot :model_prompt) ""))
               (equal "qwen3.6:latest" (plist-get snapshot :target_model))
               (superchat-collector-contract-canary-v0--same-tool-surface-p
                (plist-get snapshot :prepared_tool_names))))
         (execution-pass
          (and (equal "valid" (plist-get summary :trace_verdict))
               (equal "proved" (plist-get summary :terminal_verdict))
               (equal "completed" (plist-get summary :terminal_kind))
               (zerop (plist-get summary :tool_events_invalid_identity))
               (zerop (plist-get summary :scope_events_invalid_identity))
               (zerop (plist-get summary :unexpected_tool_request_count))))
         (publish-pass
          (and (= 1 (plist-get summary :workspace_publish_requested))
               (= 1 (plist-get summary :workspace_publish_completed))
               (zerop (plist-get summary :tool_failed_count))))
         (artifact-pass
          (and (equal "artifact_closure_pass"
                      (plist-get summary :artifact_classification))
               (= 1 (plist-get summary :artifact_count))
               (= 1 (plist-get summary :deliverable_count))
               (eq t (plist-get summary :payload_matches))))
         (pass (and prior-pass execution-pass publish-pass artifact-pass))
         (interpretation
          (superchat-collector-contract-canary-v0--interpret
           prior-pass execution-pass summary artifact-pass))
         (evidence
          (list :experiment_id "collector-completion-contract-canary-v0"
                :generated_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
                :gates
                (vconcat
                 (list (list :name "prior" :verdict
                             (if prior-pass "pass" "blocked"))
                       (list :name "execution" :verdict
                             (if execution-pass "pass" "blocked"))
                       (list :name "publish" :verdict
                             (if publish-pass "pass" "blocked"))
                       (list :name "artifact" :verdict
                             (if artifact-pass "pass" "blocked"))))
                :canary_gate (if pass "pass" "blocked")
                :interpretation interpretation
                :collector summary
                :continuation_count 0
                :retry_count 0
                :downstream_stages_started json-false
                :stability_claim "not_evaluated"
                :effectiveness_claim "not_evaluated"
                :learning_claim "prohibited")))
    (setq superchat-collector-contract-canary-v0--state
          (plist-put superchat-collector-contract-canary-v0--state
                     :status "settled"))
    (setq superchat-collector-contract-canary-v0--state
          (plist-put superchat-collector-contract-canary-v0--state
                     :canary_gate (if pass "pass" "blocked")))
    (setq superchat-collector-contract-canary-v0--state
          (plist-put superchat-collector-contract-canary-v0--state
                     :interpretation interpretation))
    (superchat-collector-contract-canary-v0--write-json
     superchat-collector-contract-canary-v0--execution-path
     superchat-collector-contract-canary-v0--state)
    (superchat-collector-contract-canary-v0--write-json
     superchat-collector-contract-canary-v0--evidence-path evidence)
    (with-temp-file superchat-collector-contract-canary-v0--report-path
      (insert "# Collector Completion Contract Canary v0\n\n")
      (insert (format "Canary Gate: **%s**\n\n"
                      (if pass "pass" "blocked")))
      (insert (format "Interpretation: `%s`.\n\n" interpretation))
      (insert
       (format
        "workspace_publish requested/completed: `%d/%d`; Artifact: `%s`; payload match: `%s`.\n\n"
        (plist-get summary :workspace_publish_requested)
        (plist-get summary :workspace_publish_completed)
        (plist-get summary :artifact_classification)
        (if (eq t (plist-get summary :payload_matches)) "true" "false")))
      (insert
       "No continuation, retry, downstream stage, stability, effectiveness, Pattern, or Learning claim is authorized.\n"))
    evidence))

(defun superchat-collector-contract-canary-v0--finished (report)
  "Record REPORT and settle the single Collector Canary."
  (let ((collector
         (copy-sequence
          (plist-get superchat-collector-contract-canary-v0--state
                     :collector))))
    (setq collector
          (plist-put collector :response_length (length (or report ""))))
    (setq collector
          (plist-put collector :response_sha256
                     (superchat-collector-contract-canary-v0--sha256-string
                      report)))
    (setq superchat-collector-contract-canary-v0--state
          (plist-put superchat-collector-contract-canary-v0--state
                     :collector collector))
    (superchat-collector-contract-canary-v0--finalize)))

(defun superchat-collector-contract-canary-v0--launch (task)
  "Launch the single Collector TASK through the existing Subagent seam."
  (let* ((canary-id
          (format "collector-contract-canary-%s-%06d"
                  (format-time-string "%Y%m%d-%H%M%S")
                  (random 1000000)))
         (root superchat-collector-contract-canary-v0--root)
         (superchat--team-id canary-id)
         (superchat--team-actor "lead")
         (superchat--workspace-binding (list :id canary-id :root root))
         (superchat--tool-execution-context
          (list :session-id canary-id
                :team-id canary-id
                :correlation-id canary-id
                :attendance 'attended
                :authority-policy "default"
                :workspace-id canary-id
                :workspace-root root)))
    (setq superchat-collector-contract-canary-v0--state
          (list :experiment_id "collector-completion-contract-canary-v0"
                :manifest_sha256
                (superchat-collector-contract-canary-v0--sha256-file
                 superchat-collector-contract-canary-v0--manifest-path)
                :status "collector-running"
                :canary_id canary-id
                :workspace_id canary-id
                :started_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
                :continuation_count 0
                :retry_count 0
                :historical_runs_imported json-false
                :downstream_stages_started json-false
                :stability_claim "not_evaluated"
                :effectiveness_claim "not_evaluated"
                :learning_claim "prohibited"))
    (superchat-collector-contract-canary-v0--write-json
     superchat-collector-contract-canary-v0--execution-path
     superchat-collector-contract-canary-v0--state)
    (let* ((actor-id
            (superchat--subagent-run-async
             'researcher task nil
             #'superchat-collector-contract-canary-v0--finished))
           (entry (superchat--subagent-entry actor-id))
           (run-id (plist-get entry :run-id))
           (runtime (superchat-runtime-status run-id))
           (collector
            (list :attempt "collector"
                  :actor_id actor-id
                  :run_id run-id
                  :turn_id (plist-get runtime :turn-id)
                  :parent_run_id nil
                  :started_at (format-time-string "%Y-%m-%dT%H:%M:%S%z"))))
      (setq superchat-collector-contract-canary-v0--state
            (plist-put superchat-collector-contract-canary-v0--state
                       :collector collector))
      (superchat-collector-contract-canary-v0--write-json
       superchat-collector-contract-canary-v0--execution-path
       superchat-collector-contract-canary-v0--state)
      collector)))

;;;###autoload
(defun superchat-collector-contract-canary-v0-start ()
  "Start the frozen single-Run Collector completion Canary exactly once."
  (interactive)
  (when superchat-collector-contract-canary-v0--state
    (error "Collector completion Canary already started"))
  (when (file-exists-p
         (expand-file-name "superchat.db" superchat-data-directory))
    (error "Collector completion Canary Runtime database already exists"))
  (superchat-collector-contract-canary-v0--verify-inputs)
  (superchat-collector-contract-canary-v0--launch
   (superchat-collector-contract-canary-v0--task)))

(defun superchat-collector-contract-canary-v0-status ()
  "Return current Canary state and live Runtime status."
  (interactive)
  (let* ((collector
          (plist-get superchat-collector-contract-canary-v0--state :collector))
         (run-id (plist-get collector :run_id)))
    (list :state superchat-collector-contract-canary-v0--state
          :runtime (and run-id (superchat-runtime-status run-id)))))

(make-directory superchat-collector-contract-canary-v0--root t)
(superchat-collector-contract-canary-v0--configure-surface)
(unless (advice-member-p
         #'superchat-collector-contract-canary-v0--capture-query
         'superchat--execute-llm-query)
  (advice-add 'superchat--execute-llm-query :around
              #'superchat-collector-contract-canary-v0--capture-query))

(provide 'superchat-collector-completion-contract-canary-v0-run)

;;; run.el ends here
