# Collector Completion Contract Canary v0 — Evidence Report

## Final verdict

`pass`, after a bounded experiment-only evidence decoder correction.

The original `evidence-bundle.json` remains immutable and reports the Artifact
Gate as blocked.  Its own Artifact record nevertheless shows `deliver`,
`available=true`, the expected revision, and `payload-matches=true`.  The
disagreement came from comparing the projected role symbol `collector` with the
string `"collector"`.  `evidence-correction-v1.json` normalizes only that field
and recomputes the affected Gate from the same durable facts.

## Closed facts

- Prior, Execution, Publish, and corrected Artifact Gates pass.
- The model-facing tool surface was exactly `workspace_info` and
  `workspace_publish`.
- The only requested model tool was one `workspace_publish`; it completed.
- Run `run-20260804-113015-881628-9082` has a valid trace and proved durable
  `completed` terminal.
- Artifact `artifact-8c9c77c3-1` has role `collector`, delivery decision
  `deliver`, and remains readable.
- Artifact revision and exported content hash are both
  `9fa43f127b1e58720dcb77d781e01517893da1c87749c9b3f51e7f50c2adf147`,
  exactly matching the transformed frozen payload.
- Actor, workspace, and correlation identities match on every Run event; no
  parent Run exists.
- Continuation count, retry count, and downstream stage count are zero.

## Archived evidence

- Stopped SQLite integrity: `ok`
- Tape rows: `14`
- SQLite snapshot SHA-256:
  `6b59b751bfb786cca5645fe56ac557fdfda300fa30a494ffb4f99f79329a0ae6`
- Artifact export SHA-256:
  `9fa43f127b1e58720dcb77d781e01517893da1c87749c9b3f51e7f50c2adf147`
- Original Bundle SHA-256:
  `30783a8a7909f691f745ed20cc50d795992f2898f7fe33b409e48c0411bca752`
- Correction Bundle SHA-256:
  `e7f0ea28a4df37846d68dc044a704c2c97ac243c6213d52183c3f14ab4fb6e99`

## Boundary

This proves that one minimum Collector completion contract can close when the
content is supplied and the tool surface is reduced to Workspace publication.
It does not prove stability, research quality, effectiveness, Pattern, or
Learning.  The next authorized gate is four independent Collector Calibration
Runs with the same no-continuation/no-retry contract.
