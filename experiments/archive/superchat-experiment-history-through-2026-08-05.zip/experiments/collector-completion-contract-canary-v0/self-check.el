;;; self-check.el --- Collector contract Canary checks -*- lexical-binding: t; -*-

(require 'superchat-collector-completion-contract-canary-v0-run)

(unless
    (and
     (superchat-collector-contract-canary-v0--same-tool-surface-p
      ["workspace_info" "workspace_publish"])
     (superchat-collector-contract-canary-v0--same-tool-surface-p
      ["workspace_publish" "workspace_info"])
     (not
      (superchat-collector-contract-canary-v0--same-tool-surface-p
       ["workspace_info" "workspace_publish" "agent_reach_search"]))
     (equal
      "model_did_not_select_workspace_publish"
      (superchat-collector-contract-canary-v0--interpret
       t t '(:workspace_publish_requested 0) nil)))
  (error "Collector completion contract Canary self-check failed"))

(provide 'superchat-collector-completion-contract-canary-v0-self-check)

;;; self-check.el ends here
