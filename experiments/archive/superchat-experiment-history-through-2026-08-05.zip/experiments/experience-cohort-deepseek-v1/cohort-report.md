# DeepSeek Experience Cohort v1

Generated: `2026-08-05T10:17:25+0800`

Execution: **incomplete** (1/20 finalized)

Calibration Gate: **blocked** (1/4)

| Index | Split | Assignment | Evidence | Workflow Contract | Outcome |
|---:|---|---|---|---|---|
| 1 | calibration | cal-systems-01 | pass | satisfied | accept |
| 2 | calibration | cal-security-01 | not-started | - | - |
| 3 | calibration | cal-science-01 | not-started | - | - |
| 4 | calibration | cal-standards-01 | not-started | - | - |
| 5 | discovery | disc-systems-01 | not-started | - | - |
| 6 | discovery | disc-systems-02 | not-started | - | - |
| 7 | discovery | disc-systems-03 | not-started | - | - |
| 8 | discovery | disc-security-01 | not-started | - | - |
| 9 | discovery | disc-security-02 | not-started | - | - |
| 10 | discovery | disc-security-03 | not-started | - | - |
| 11 | discovery | disc-science-01 | not-started | - | - |
| 12 | discovery | disc-science-02 | not-started | - | - |
| 13 | discovery | disc-science-03 | not-started | - | - |
| 14 | discovery | disc-standards-01 | not-started | - | - |
| 15 | discovery | disc-standards-02 | not-started | - | - |
| 16 | discovery | disc-standards-03 | not-started | - | - |
| 17 | replicate | rep-disc-systems-01-01 | not-started | - | - |
| 18 | replicate | rep-disc-security-01-01 | not-started | - | - |
| 19 | replicate | rep-disc-science-01-01 | not-started | - | - |
| 20 | replicate | rep-disc-standards-01-01 | not-started | - | - |

Discovery is authorized only by a 4/4 Calibration pass. Replicates do not increase occurrence thresholds. Held-out remains sealed.
No effectiveness, Pattern, or learning claim is authorized.
