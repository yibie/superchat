# Post-fix Calibration v0 — Evidence Gap Report

Generated after all four preregistered first attempts settled on 2026-08-03.

## Verdict

`calibration_gate = blocked` (`0/4`). Discovery remains unauthorized and
held-out remains sealed. No effectiveness, Pattern, or learning claim is made.

## What the experiment proved

- Four new Workflow, Session, Turn, Run, and Actor identity sets were created
  under the isolated Post-fix Runtime; no historical Run or Artifact was
  imported.
- Five Research stages actually executed: four Collectors and one Analyst.
- All five executed stage traces were `valid`, all five durable terminal
  judgments were `proved/completed`, and no executed stage had `tool.failed`.
- Four tool-using stages produced 54 Tool lifecycle events. Every observed
  Tool event carried valid Run, Turn, and Actor identity; invalid identity
  count was zero.
- Outcome Closure passed for all four tasks by applying the preregistered
  missing-final-Artifact rule. All four primary outcomes are `reject`.

This validates the identity propagation fix on the observed Subagent tool
path. It does not establish complete sample generation.

## Why the 4/4 Gate failed

| Assignment | Last executed stage | Artifact result | Workflow result |
|---|---|---|---|
| `cal-systems-01` | Collector | `artifact_absent` | `manual-review` |
| `cal-security-01` | Analyst | `artifact_absent` | `manual-review` |
| `cal-science-01` | Collector | `artifact_absent` | `manual-review` |
| `cal-standards-01` | Collector | `artifact_absent` | `manual-review` |

Across the five executed stages, one produced a deliverable Artifact and four
did not. Because downstream stages were correctly blocked, no task produced
all three stage prompts, all three terminal traces, or a final Reviewer
Artifact. Prior, Execution, and Artifact Closure are therefore blocked at the
sample level even though every executed stage has valid Runtime closure.

Observed Tool requests distinguish the failure modes:

- `cal-systems-01` Collector searched, read two sources, inspected Workspace,
  then completed without `workspace_publish`.
- `cal-security-01` Collector searched, read four sources, and called
  `workspace_publish`; its Analyst later searched, read the prior Artifact,
  inspected Workspace, then completed without `workspace_publish`.
- `cal-science-01` Collector completed without requesting any Tool.
- `cal-standards-01` Collector used `team_task` and `workspace_info`, but did
  not search, read a source, or call `workspace_publish`.

The dominant observed gap is model compliance with the stage delivery
contract, not Runtime identity propagation.

## Frozen decoder limitation retained as evidence

The sole deliverable Artifact was produced by the `cal-security-01` Collector
Run but declared its Artifact role as `analyst`. Runtime provenance and
Delivery Closure still pass because the producer Run, revision, hash, and
Closure witness are valid. The frozen v0 evidence decoder does not separately
assert declared Artifact role equality.

This observation does not change the current `0/4` verdict: the same sample
already fails when its Analyst produces no Artifact. The decoder and generated
Evidence Bundles are not rewritten post hoc. Any future role-equality gate must
be preregistered in a new experiment rather than applied retroactively.

## Integrity

- Frozen input verification passed again after execution.
- Runtime SQLite `PRAGMA integrity_check` returned `ok`.
- Runtime snapshot at inspection: 109 Tape rows across 9 Sessions.
- Four unique preregistered Collector Run IDs and four unique Workflow
  instance IDs were retained.
- Comparison is `not-applicable`; Discovery and held-out were not executed.

