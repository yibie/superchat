# Post-fix Calibration v0

Generated: `2026-08-03T21:01:27+0800`

Calibration Gate: **blocked** (0/4)

| Index | Assignment | Evidence | Workflow Contract | Outcome |
|---:|---|---|---|---|
| 1 | cal-systems-01 | blocked | violated | reject |
| 2 | cal-security-01 | blocked | violated | reject |
| 3 | cal-science-01 | blocked | violated | reject |
| 4 | cal-standards-01 | blocked | violated | reject |

Comparison is not applicable. Discovery remains blocked unless 4/4 pass.
No effectiveness, Pattern, or learning claim is authorized.
