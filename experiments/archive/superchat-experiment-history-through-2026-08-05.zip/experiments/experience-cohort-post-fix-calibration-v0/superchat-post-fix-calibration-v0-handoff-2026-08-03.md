# Superchat Post-fix Calibration v0 — Handoff

Finalized and archived on 2026-08-03 after all four preregistered first
attempts settled.  The dedicated `superchat-post-fix-calibration-v0` Emacs
daemon was stopped; the shared Ollama service was left running.

## Experiment boundary

This is a new post-fix calibration cohort, not a continuation or repair of the
archived Experience Cohort v0 evidence.  It used new Workflow, Session, Turn,
Run, Actor, Workspace, and Artifact identities.  No historical Run or Artifact
was imported.

The sole question was whether the identity-repaired Runtime could produce four
complete and interpretable evidence samples.  The experiment did not evaluate
intervention effectiveness, discover Patterns, or authorize a Learning claim.
Discovery remained blocked and held-out tasks remained sealed.

## Final verdict

`calibration_gate = blocked` (`0/4`).

| Assignment | Last executed stage | Evidence | Workflow contract | Outcome |
|---|---|---|---|---|
| `cal-systems-01` | Collector | blocked | violated | reject |
| `cal-security-01` | Analyst | blocked | violated | reject |
| `cal-science-01` | Collector | blocked | violated | reject |
| `cal-standards-01` | Collector | blocked | violated | reject |

Five stages actually executed: four Collectors and one Analyst.  All five
stage traces were `valid`, all five terminal judgments were
`proved/completed`, and no executed stage emitted `tool.failed`.  The four
tool-using stages produced 54 Tool lifecycle events with zero invalid Run,
Turn, or Actor identities.  This validates the identity propagation fix on
the observed Subagent tool path.

The complete sample gate still failed.  Only one of five executed stages
published a deliverable Artifact; the other four were `artifact_absent`.
Downstream stages were correctly left at `manual-review`.  Outcome Closure
passed for all four assignments through the preregistered missing-target rule,
and all four outcome results are `reject`.  Outcome Closure is evidence
completeness, not outcome success.

## Preserved limitation

The sole deliverable Artifact was produced by the `cal-security-01` Collector
Run but declared Artifact role `analyst`.  Runtime Delivery Closure passed
because producer Run, revision, hash, and Closure witness were valid.  The
frozen v0 evidence decoder did not assert declared-role equality.  This was
documented after execution and was not retroactively added to the Gate.

Any future role-equality check must be preregistered in a new experiment.  Do
not rewrite these Evidence Bundles or reinterpret the archived `0/4` result.

## Files to inspect first

- `project/experiments/experience-cohort-post-fix-calibration-v0/manifest.json`
- `project/experiments/experience-cohort-post-fix-calibration-v0/calibration-report.md`
- `project/experiments/experience-cohort-post-fix-calibration-v0/calibration-report.json`
- `project/experiments/experience-cohort-post-fix-calibration-v0/evidence-gap-report.md`
- `project/experiments/experience-cohort-post-fix-calibration-v0/runs/`
- `runtime/superchat-snapshot.db`
- `runtime/artifacts/`

The archive also includes the frozen inputs, experiment runner/decoder,
identity propagation repair, its regression test, and the Runtime modules
needed to interpret Tape, Closure, Workflow, Workspace, and Delivery facts.

## Integrity and verification

- Manifest SHA-256:
  `bb4686599a4234a64a250a684511f25b88b0eab310c1f57f59fc3474b123fddd`.
- All 12 frozen input hashes matched after execution.
- Runtime SQLite `PRAGMA integrity_check` returned `ok` before packaging.
- Final Runtime snapshot: 109 Tape rows across 9 Sessions.
- All generated JSON files parsed successfully.
- `run.el` and `evidence.el` passed `check-parens`.
- Canonical ERT completed with zero unexpected failures.
- `git diff --check` passed.
- `SHA256SUMS` at archive root covers every packaged file except itself.

## Next decision

Do not launch Discovery from this evidence.  The next experiment must first
choose and preregister how the model-facing stage Artifact delivery contract
will be made testable: prompt/Agent behavior, Runtime completion enforcement,
or an experiment-only role validation rule.  Those choices change different
system boundaries and must not be applied post hoc to this cohort.

