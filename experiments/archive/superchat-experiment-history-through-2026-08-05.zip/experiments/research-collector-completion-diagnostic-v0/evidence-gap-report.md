# Research Collector Completion Diagnostic v0 — Evidence Gap Report

## Verdict

`blocked — experiment prior surface invalid`

The only Run is preserved. It requested `team_task`, Authority denied the
request, and the Run durably failed without search, read, publish, or Artifact
events. No retry, continuation, recovery, downstream stage, Outcome, Pattern,
or Learning operation was started.

## Root cause

The actual model-facing prompt instructed the Collector to use `team_task` and
`team_message`, while the frozen four-tool surface exposed only:

- `agent_reach_search`
- `agent_reach_read`
- `workspace_info`
- `workspace_publish`

The model therefore selected a tool named by its prompt but absent from its
prepared tool surface. Authority correctly denied that request. This is an
experiment Prior contradiction, not evidence that the Research Collector
cannot complete the research contract.

The Manifest also records `frozen_at` later than the Run's recorded start.
That timestamp error cannot be repaired after execution, so the generated
Prior Gate's `pass` is superseded by the versioned evidence correction and is
classified as `blocked`.

## Preserved facts

- Actor: `subagent-researcher-20260804-120902-398d`
- Run: `run-20260804-120902-094429-3758`
- Workspace/correlation: `research-collector-diagnostic-20260804-120902-260202`
- Terminal: `failed`, durably proved
- Tool request/failure: `team_task`, denied
- Artifact classification: `artifact_absent`
- Tape rows: `12`
- SQLite integrity: `ok`
- Runtime snapshot SHA-256: `212cd78d60959bb609b0f46249a6eb652433ebd1d88a2ea86ac8ca94510d920c`
- Original evidence SHA-256: `bcc71f993e40985dbe247c6bb84bbbc91b765d05a55410de2b8f2542fdd56240`
- Prompt snapshot SHA-256: `380c71e7472a80116501e88995a60fa6d3605c0538065435ed1bf083f3898b11`

## Successor requirement

A successor diagnostic must use the standard Research Subagent tool surface
that matches the built-in team instructions, record a valid pre-execution
freeze time, and keep the same one-Run/no-retry/no-continuation boundary. v0
must not be rewritten or counted as a Research completion sample.
