;;; self-check.el --- Research Collector diagnostic checks -*- lexical-binding: t; -*-

(require 'superchat-research-collector-completion-diagnostic-v0-run)

(unless
    (and
     (superchat-research-collector-diagnostic-v0--same-tool-surface-p
      ["agent_reach_search" "agent_reach_read"
       "workspace_info" "workspace_publish"])
     (superchat-research-collector-diagnostic-v0--same-tool-surface-p
      ["workspace_publish" "agent_reach_read"
       "workspace_info" "agent_reach_search"])
     (not
      (superchat-research-collector-diagnostic-v0--same-tool-surface-p
       ["agent_reach_search" "agent_reach_read" "workspace_publish"]))
     (equal "collector"
            (superchat-research-collector-diagnostic-v0--normalize-name
             'collector))
     (= 2
        (length
         (superchat-research-collector-diagnostic-v0--source-urls
          "A https://sqlite.org/wal.html B https://sqlite.org/lockingv3.html")))
     (equal
      "official_read_contract_not_completed"
      (superchat-research-collector-diagnostic-v0--interpret
       '(:agent_reach_search_completed 1
         :agent_reach_read_completed 1
         :workspace_publish_requested 0
         :workspace_publish_completed 0
         :artifact_classification "artifact_absent"
         :official_source_url_count 0))))
  (error "Research Collector completion diagnostic self-check failed"))

(provide 'superchat-research-collector-completion-diagnostic-v0-self-check)

;;; self-check.el ends here
