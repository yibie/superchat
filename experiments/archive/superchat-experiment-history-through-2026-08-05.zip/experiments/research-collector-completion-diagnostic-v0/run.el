;;; run.el --- Real Research Collector completion diagnostic -*- lexical-binding: t; -*-

;;; Commentary:

;; Experiment-only one-shot runner.  One Collector must search, read at least
;; two official sources, and publish one durable Artifact.  There is no
;; continuation, retry, recovery, downstream stage, or quality evaluation.

;;; Code:

(require 'cl-lib)
(require 'json)
(require 'subr-x)
(require 'superchat)
(require 'superchat-subagent)
(require 'superchat-closure)
(require 'superchat-workflow)
(require 'llm-ollama)

(defconst superchat-research-collector-diagnostic-v0--directory
  "/Users/chenyibin/Documents/emacs/package/superchat/experiments/research-collector-completion-diagnostic-v0/")

(defconst superchat-research-collector-diagnostic-v0--root
  "/private/tmp/superchat-research-collector-completion-diagnostic-v0/")

(defconst superchat-research-collector-diagnostic-v0--manifest-path
  (expand-file-name "manifest.json"
                    superchat-research-collector-diagnostic-v0--directory))

(defconst superchat-research-collector-diagnostic-v0--task-path
  (expand-file-name "task.txt"
                    superchat-research-collector-diagnostic-v0--directory))

(defconst superchat-research-collector-diagnostic-v0--execution-path
  (expand-file-name "execution-record.json"
                    superchat-research-collector-diagnostic-v0--directory))

(defconst superchat-research-collector-diagnostic-v0--prompt-path
  (expand-file-name "prompt-snapshot.json"
                    superchat-research-collector-diagnostic-v0--directory))

(defconst superchat-research-collector-diagnostic-v0--evidence-path
  (expand-file-name "evidence-bundle.json"
                    superchat-research-collector-diagnostic-v0--directory))

(defconst superchat-research-collector-diagnostic-v0--report-path
  (expand-file-name "diagnostic-report.md"
                    superchat-research-collector-diagnostic-v0--directory))

(defconst superchat-research-collector-diagnostic-v0--artifact-export-path
  (expand-file-name "artifact-export.md"
                    superchat-research-collector-diagnostic-v0--directory))

(defconst superchat-research-collector-diagnostic-v0--allowed-tools
  '("agent_reach_search" "agent_reach_read"
    "workspace_info" "workspace_publish"))

(defvar superchat-research-collector-diagnostic-v0--state nil)
(defvar superchat-research-collector-diagnostic-v0--snapshot nil)

(setq superchat-data-directory
      (expand-file-name "runtime/"
                        superchat-research-collector-diagnostic-v0--root)
      superchat-llm-backend
      (make-llm-ollama :chat-model "qwen3.6:latest")
      superchat-llm-model nil
      superchat-response-timeout 900
      superchat-subagent-timeout 1800)

(defun superchat-research-collector-diagnostic-v0--read-file (path)
  "Return PATH contents without trailing whitespace."
  (with-temp-buffer
    (insert-file-contents path)
    (string-trim-right (buffer-string))))

(defun superchat-research-collector-diagnostic-v0--read-json (path)
  "Read PATH as a plist-backed JSON object."
  (with-temp-buffer
    (insert-file-contents path)
    (json-parse-buffer :object-type 'plist :array-type 'list
                       :null-object nil :false-object json-false)))

(defun superchat-research-collector-diagnostic-v0--write-json (path value)
  "Write VALUE as JSON to PATH."
  (with-temp-file path
    (insert (json-encode value))
    (insert "\n")))

(defun superchat-research-collector-diagnostic-v0--sha256-file (path)
  "Return protocol-prefixed SHA-256 for PATH."
  (with-temp-buffer
    (set-buffer-multibyte nil)
    (insert-file-contents-literally path)
    (concat "sha256:" (secure-hash 'sha256 (current-buffer)))))

(defun superchat-research-collector-diagnostic-v0--sha256-string (value)
  "Return protocol-prefixed SHA-256 for VALUE."
  (concat "sha256:" (secure-hash 'sha256 (or value ""))))

(defun superchat-research-collector-diagnostic-v0--task ()
  "Return the frozen model-facing Collector task."
  (superchat-research-collector-diagnostic-v0--read-file
   superchat-research-collector-diagnostic-v0--task-path))

(defun superchat-research-collector-diagnostic-v0--manifest ()
  "Return the frozen diagnostic Manifest."
  (superchat-research-collector-diagnostic-v0--read-json
   superchat-research-collector-diagnostic-v0--manifest-path))

(defun superchat-research-collector-diagnostic-v0--verify-inputs ()
  "Fail unless every frozen diagnostic input still matches its hash."
  (let ((manifest (superchat-research-collector-diagnostic-v0--manifest)))
    (unless (equal "canary-authorized" (plist-get manifest :status))
      (error "Research Collector diagnostic is not authorized"))
    (unless (equal superchat-research-collector-diagnostic-v0--allowed-tools
                   (plist-get manifest :model_tool_surface))
      (error "Research Collector diagnostic tool surface changed"))
    (dolist (input (plist-get manifest :frozen_inputs))
      (let* ((path (expand-file-name
                    (plist-get input :path)
                    "/Users/chenyibin/Documents/emacs/package/superchat/"))
             (actual (and (file-readable-p path)
                          (superchat-research-collector-diagnostic-v0--sha256-file
                           path))))
        (unless (equal actual (plist-get input :sha256))
          (error "Frozen input changed or missing: %s" path))))
    manifest))

(defun superchat-research-collector-diagnostic-v0--bounded-process
    (program args max-characters)
  "Run PROGRAM with ARGS and return at most MAX-CHARACTERS."
  (with-temp-buffer
    (let ((status (apply #'call-process
                         "/opt/homebrew/bin/gtimeout" nil t nil
                         "90s" program args)))
      (unless (and (integerp status) (zerop status))
        (error "%s failed with status %s: %s"
               program status (string-trim (buffer-string))))
      (let ((text (buffer-string)))
        (if (> (length text) max-characters)
            (concat (substring text 0 max-characters)
                    "\n[Result truncated by frozen tool limit]")
          text)))))

(defun superchat-research-collector-diagnostic-v0-search
    (query &optional num-results)
  "Search the public web for QUERY through Agent Reach Exa."
  (unless (and (stringp query) (not (string-empty-p (string-trim query))))
    (error "Search query must be non-empty"))
  (let* ((count (max 1 (min 8 (truncate (or num-results 5)))))
         (call (format "exa.web_search_exa(query: %s, numResults: %d)"
                       (json-encode-string query) count)))
    (superchat-research-collector-diagnostic-v0--bounded-process
     "/Users/chenyibin/.bun/bin/mcporter" (list "call" call) 30000)))

(defun superchat-research-collector-diagnostic-v0-read (url)
  "Read public HTTP(S) URL through Agent Reach Jina Reader."
  (unless (and (stringp url) (string-match-p "\\`https?://" url))
    (error "Reader URL must use HTTP or HTTPS"))
  (superchat-research-collector-diagnostic-v0--bounded-process
   "/opt/local/bin/curl"
   (list "--silent" "--show-error" "--location" "--max-time" "80"
         (concat "https://r.jina.ai/" url))
   40000))

(defun superchat-research-collector-diagnostic-v0--external-read-effects
    (args)
  "Return frozen external-read effects for ARGS."
  (list (list :effect 'external-read :resource 'web :scope (car args))
        (list :effect 'process-exec :resource 'agent-reach
              :scope "frozen-read-only-adapter")))

(defun superchat-research-collector-diagnostic-v0--register-tools ()
  "Register the frozen Agent Reach tools."
  (superchat-register-tool
   "agent_reach_search"
   :function #'superchat-research-collector-diagnostic-v0-search
   :description
   "Search the public web through Agent Reach Exa. Prefer official or primary sources and retain URLs."
   :args (list (list :name "query" :type 'string
                     :description "Precise web search query.")
               (list :name "num-results" :type 'number :optional t
                     :description "Number of results, from 1 to 8."))
   :effects #'superchat-research-collector-diagnostic-v0--external-read-effects)
  (superchat-register-tool
   "agent_reach_read"
   :function #'superchat-research-collector-diagnostic-v0-read
   :description
   "Read one public HTTP(S) page through Agent Reach Jina Reader and return bounded Markdown."
   :args (list (list :name "url" :type 'string
                     :description "Public HTTP(S) URL to read."))
   :effects #'superchat-research-collector-diagnostic-v0--external-read-effects))

(defun superchat-research-collector-diagnostic-v0--preset ()
  "Return the frozen real Research Collector preset."
  (superchat--subagent-make-preset
   "researcher" "researcher"
   "Real Research Collector completion diagnostic"
   'agent "research"
   superchat-research-collector-diagnostic-v0--allowed-tools
   (concat
    "You are the Collector in a one-Run completion diagnostic. Complete the "
    "research in this Run: search with agent_reach_search, inspect at least "
    "two distinct official SQLite pages with agent_reach_read, distinguish "
    "evidence from inference, retain source URLs, then publish exactly one "
    "complete durable Artifact with workspace_publish using role collector. "
    "Do not narrate a future action or finish before publication succeeds.")))

(defun superchat-research-collector-diagnostic-v0--permission
    (tool-name _args)
  "Allow only the frozen model-facing TOOL-NAME surface."
  (if (member tool-name superchat-research-collector-diagnostic-v0--allowed-tools)
      'allow
    'deny))

(defun superchat-research-collector-diagnostic-v0--configure-surface ()
  "Install the diagnostic-only preset, tools, and permission hook."
  (superchat-research-collector-diagnostic-v0--register-tools)
  (setcdr (assoc "researcher" superchat--subagent-builtin-presets)
          #'superchat-research-collector-diagnostic-v0--preset)
  (setq superchat-agent-permission-functions
        '(superchat-research-collector-diagnostic-v0--permission)))

(defun superchat-research-collector-diagnostic-v0--tool-names (tools)
  "Normalize model-facing TOOLS to ordered names."
  (mapcar (lambda (tool)
            (cond ((stringp tool) tool)
                  ((symbolp tool) (symbol-name tool))
                  ((listp tool) (plist-get tool :name))
                  (t (format "%s" tool))))
          tools))

(defun superchat-research-collector-diagnostic-v0--same-tool-surface-p (tools)
  "Return non-nil when TOOLS exactly names the frozen surface."
  (and (= (length tools)
          (length superchat-research-collector-diagnostic-v0--allowed-tools))
       (null
        (cl-set-exclusive-or
         (append tools nil)
         superchat-research-collector-diagnostic-v0--allowed-tools
         :test #'equal))))

(defun superchat-research-collector-diagnostic-v0--capture-query
    (original turn &rest args)
  "Call ORIGINAL with TURN and ARGS, retaining this actor's actual query."
  (let* ((actor-id (and (boundp 'superchat--session-id)
                        superchat--session-id))
         (result (apply original turn args))
         (prompt (plist-get result :prompt)))
    (when (and actor-id
               (string-match-p
                (regexp-quote "[research-collector-completion-diagnostic-v0]")
                (or prompt "")))
      (when superchat-research-collector-diagnostic-v0--snapshot
        (error "Research Collector diagnostic observed more than one query"))
      (setq superchat-research-collector-diagnostic-v0--snapshot
            (list :attempt "collector"
                  :actor_id actor-id
                  :captured_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
                  :model_prompt prompt
                  :model_prompt_sha256
                  (superchat-research-collector-diagnostic-v0--sha256-string
                   prompt)
                  :system_prompt (plist-get result :system-prompt)
                  :system_prompt_sha256
                  (superchat-research-collector-diagnostic-v0--sha256-string
                   (plist-get result :system-prompt))
                  :target_model
                  (or (plist-get result :target-model) "qwen3.6:latest")
                  :prepared_tool_names
                  (vconcat
                   (superchat-research-collector-diagnostic-v0--tool-names
                    (plist-get result :tools)))))
      (superchat-research-collector-diagnostic-v0--write-json
       superchat-research-collector-diagnostic-v0--prompt-path
       (list :experiment_id "research-collector-completion-diagnostic-v0"
             :snapshot_count 1
             :snapshot superchat-research-collector-diagnostic-v0--snapshot)))
    result))

(defun superchat-research-collector-diagnostic-v0--event-tool-name (event)
  "Return normalized tool name from EVENT."
  (let ((payload (plist-get event :payload)))
    (or (plist-get payload :tool-name)
        (plist-get payload :tool_name))))

(defun superchat-research-collector-diagnostic-v0--normalize-name (value)
  "Return VALUE as a string when it is a symbol or string."
  (cond ((symbolp value) (symbol-name value))
        ((stringp value) value)
        (t nil)))

(defun superchat-research-collector-diagnostic-v0--source-urls (content)
  "Return distinct HTTP(S) URLs found in CONTENT."
  (let ((start 0) urls)
    (while (and content
                (string-match
                 "https?://[^][(){}<> \t\n\"']+" content start))
      (push (match-string 0 content) urls)
      (setq start (match-end 0)))
    (delete-dups (nreverse urls))))

(defun superchat-research-collector-diagnostic-v0--artifact-view (artifact)
  "Return normalized delivery and content facts for ARTIFACT."
  (let* ((view (copy-sequence
                (superchat-research-workflow--artifact-view artifact)))
         (content
          (and (eq 'deliver (plist-get view :delivery-decision))
               (plist-get view :available)
               (condition-case nil
                   (superchat-workspace-read
                    (plist-get artifact :artifact-id)
                    (plist-get artifact :workspace-id)
                    (plist-get artifact :revision))
                 (error nil))))
         (urls (superchat-research-collector-diagnostic-v0--source-urls
                content))
         (official-urls
          (cl-remove-if-not
           (lambda (url)
             (string-match-p
              "\\`https?://\\(?:www\\.\\)?sqlite\\.org/" url))
           urls)))
    (setq view
          (plist-put view :role
                     (superchat-research-collector-diagnostic-v0--normalize-name
                      (plist-get artifact :role))))
    (append view
            (list :run-id (plist-get artifact :run-id)
                  :content-sha256
                  (and content
                       (superchat-research-collector-diagnostic-v0--sha256-string
                        content))
                  :content-length (length (or content ""))
                  :source-url-count (length urls)
                  :official-source-url-count (length official-urls)))))

(defun superchat-research-collector-diagnostic-v0--tool-count
    (events type name)
  "Count EVENTS with TYPE and tool NAME."
  (cl-count-if
   (lambda (event)
     (and (equal type (plist-get event :type))
          (equal name
                 (superchat-research-collector-diagnostic-v0--event-tool-name
                  event))))
   events))

(defun superchat-research-collector-diagnostic-v0--attempt-summary ()
  "Return Closure, tool, scope, and Artifact evidence for the Collector."
  (let* ((attempt
          (plist-get superchat-research-collector-diagnostic-v0--state
                     :collector))
         (actor-id (plist-get attempt :actor_id))
         (run-id (plist-get attempt :run_id))
         (workspace-id
          (plist-get superchat-research-collector-diagnostic-v0--state
                     :workspace_id))
         (events (superchat-tape-replay-events actor-id))
         (run-events
          (cl-remove-if-not
           (lambda (event) (equal run-id (plist-get event :run-id)))
           events))
         (tool-events
          (cl-remove-if-not
           (lambda (event)
             (string-prefix-p "tool." (or (plist-get event :type) "")))
           run-events))
         (invalid-tool-identity
          (cl-count-if-not
           (lambda (event)
             (and (equal actor-id (plist-get event :actor-id))
                  (stringp (plist-get event :turn-id))
                  (not (string-empty-p (plist-get event :turn-id)))))
           tool-events))
         (invalid-scope-identity
          (cl-count-if-not
           (lambda (event)
             (and (equal actor-id (plist-get event :actor-id))
                  (equal workspace-id (plist-get event :workspace-id))
                  (equal workspace-id (plist-get event :correlation-id))
                  (null (plist-get event :parent-run-id))))
           run-events))
         (well
          (superchat-closure-judge
           (list :kind 'trace-well-formed :run-id run-id) events))
         (terminal
          (superchat-closure-judge
           (list :kind 'durable-run-terminal :run-id run-id) events))
         (artifacts
          (mapcar
           #'superchat-research-collector-diagnostic-v0--artifact-view
           (cl-remove-if-not
            (lambda (artifact) (equal run-id (plist-get artifact :run-id)))
            (superchat-workspace-artifacts workspace-id t))))
         (deliverable
          (cl-remove-if-not
           (lambda (artifact)
             (and (eq 'deliver (plist-get artifact :delivery-decision))
                  (plist-get artifact :available)
                  (equal "collector" (plist-get artifact :role))))
           artifacts))
         (classification
          (cond ((null artifacts) "artifact_absent")
                ((and (= 1 (length artifacts))
                      (= 1 (length deliverable)))
                 "artifact_closure_pass")
                (t "artifact_present_provenance_invalid"))))
    (list :attempt "collector"
          :actor_id actor-id
          :run_id run-id
          :turn_id (plist-get attempt :turn_id)
          :parent_run_id nil
          :trace_verdict (symbol-name (plist-get well :verdict))
          :terminal_verdict (symbol-name (plist-get terminal :verdict))
          :terminal_kind
          (when-let* ((judgment (plist-get terminal :judgment))
                      (kind (plist-get judgment :terminal-kind)))
            (symbol-name kind))
          :run_event_count (length run-events)
          :tool_event_count (length tool-events)
          :tool_events_invalid_identity invalid-tool-identity
          :scope_events_invalid_identity invalid-scope-identity
          :unexpected_tool_request_count
          (cl-count-if
           (lambda (event)
             (and (equal "tool.requested" (plist-get event :type))
                  (not (member
                        (superchat-research-collector-diagnostic-v0--event-tool-name
                         event)
                        superchat-research-collector-diagnostic-v0--allowed-tools))))
           tool-events)
          :agent_reach_search_requested
          (superchat-research-collector-diagnostic-v0--tool-count
           tool-events "tool.requested" "agent_reach_search")
          :agent_reach_search_completed
          (superchat-research-collector-diagnostic-v0--tool-count
           tool-events "tool.completed" "agent_reach_search")
          :agent_reach_read_requested
          (superchat-research-collector-diagnostic-v0--tool-count
           tool-events "tool.requested" "agent_reach_read")
          :agent_reach_read_completed
          (superchat-research-collector-diagnostic-v0--tool-count
           tool-events "tool.completed" "agent_reach_read")
          :workspace_publish_requested
          (superchat-research-collector-diagnostic-v0--tool-count
           tool-events "tool.requested" "workspace_publish")
          :workspace_publish_completed
          (superchat-research-collector-diagnostic-v0--tool-count
           tool-events "tool.completed" "workspace_publish")
          :tool_failed_count
          (cl-count "tool.failed" tool-events
                    :key (lambda (event) (plist-get event :type))
                    :test #'equal)
          :artifact_classification classification
          :artifact_count (length artifacts)
          :deliverable_count (length deliverable)
          :source_url_count
          (if (= 1 (length deliverable))
              (plist-get (car deliverable) :source-url-count) 0)
          :official_source_url_count
          (if (= 1 (length deliverable))
              (plist-get (car deliverable) :official-source-url-count) 0)
          :artifacts (vconcat artifacts))))

(defun superchat-research-collector-diagnostic-v0--interpret (summary)
  "Return the preregistered interpretation for SUMMARY."
  (cond
   ((zerop (plist-get summary :agent_reach_search_completed))
    "search_not_completed")
   ((< (plist-get summary :agent_reach_read_completed) 2)
    "official_read_contract_not_completed")
   ((zerop (plist-get summary :workspace_publish_requested))
    "model_did_not_select_workspace_publish")
   ((not (= 1 (plist-get summary :workspace_publish_completed)))
    "workspace_publish_not_completed_once")
   ((equal "artifact_absent" (plist-get summary :artifact_classification))
    "artifact_absent")
   ((not (equal "artifact_closure_pass"
                (plist-get summary :artifact_classification)))
    "artifact_present_provenance_invalid")
   ((< (plist-get summary :official_source_url_count) 2)
    "official_source_references_not_retained")
   (t "real_research_collector_contract_closed")))

(defun superchat-research-collector-diagnostic-v0--export-artifact (summary)
  "Export SUMMARY's sole deliverable Artifact for inspection."
  (when-let* ((artifact (and (= 1 (plist-get summary :deliverable_count))
                             (aref (plist-get summary :artifacts) 0)))
              (content
               (superchat-workspace-read
                (plist-get artifact :artifact-id)
                (plist-get artifact :workspace-id)
                (plist-get artifact :revision))))
    (with-temp-file superchat-research-collector-diagnostic-v0--artifact-export-path
      (insert content))))

(defun superchat-research-collector-diagnostic-v0--finalize ()
  "Write final evidence and report for the settled diagnostic."
  (let* ((summary (superchat-research-collector-diagnostic-v0--attempt-summary))
         (snapshot superchat-research-collector-diagnostic-v0--snapshot)
         (prior-pass
          (and snapshot
               (equal (plist-get summary :actor_id)
                      (plist-get snapshot :actor_id))
               (string-match-p
                (regexp-quote "[research-collector-completion-diagnostic-v0]")
                (or (plist-get snapshot :model_prompt) ""))
               (equal "qwen3.6:latest" (plist-get snapshot :target_model))
               (superchat-research-collector-diagnostic-v0--same-tool-surface-p
                (plist-get snapshot :prepared_tool_names))))
         (execution-pass
          (and (equal "valid" (plist-get summary :trace_verdict))
               (equal "proved" (plist-get summary :terminal_verdict))
               (equal "completed" (plist-get summary :terminal_kind))
               (zerop (plist-get summary :tool_events_invalid_identity))
               (zerop (plist-get summary :scope_events_invalid_identity))
               (zerop (plist-get summary :unexpected_tool_request_count))
               (zerop (plist-get summary :tool_failed_count))))
         (research-pass
          (and (>= (plist-get summary :agent_reach_search_completed) 1)
               (>= (plist-get summary :agent_reach_read_completed) 2)))
         (publish-pass
          (and (= 1 (plist-get summary :workspace_publish_requested))
               (= 1 (plist-get summary :workspace_publish_completed))))
         (artifact-pass
          (and (equal "artifact_closure_pass"
                      (plist-get summary :artifact_classification))
               (= 1 (plist-get summary :artifact_count))
               (= 1 (plist-get summary :deliverable_count))))
         (references-pass
          (>= (plist-get summary :official_source_url_count) 2))
         (pass (and prior-pass execution-pass research-pass publish-pass
                    artifact-pass references-pass))
         (interpretation
          (if (and prior-pass execution-pass)
              (superchat-research-collector-diagnostic-v0--interpret summary)
            (if prior-pass "execution_evidence_invalid"
              "prior_evidence_incomplete")))
         (evidence
          (list :experiment_id "research-collector-completion-diagnostic-v0"
                :generated_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
                :gates
                (vconcat
                 (list (list :name "prior" :verdict
                             (if prior-pass "pass" "blocked"))
                       (list :name "execution" :verdict
                             (if execution-pass "pass" "blocked"))
                       (list :name "research-activity" :verdict
                             (if research-pass "pass" "blocked"))
                       (list :name "publish" :verdict
                             (if publish-pass "pass" "blocked"))
                       (list :name "artifact" :verdict
                             (if artifact-pass "pass" "blocked"))
                       (list :name "source-references" :verdict
                             (if references-pass "pass" "blocked"))))
                :canary_gate (if pass "pass" "blocked")
                :interpretation interpretation
                :collector summary
                :continuation_count 0
                :retry_count 0
                :recovery_count 0
                :downstream_stages_started json-false
                :outcome_evaluation "not-evaluated"
                :stability_claim "not_evaluated"
                :effectiveness_claim "not_evaluated"
                :learning_claim "prohibited")))
    (setq superchat-research-collector-diagnostic-v0--state
          (plist-put superchat-research-collector-diagnostic-v0--state
                     :status "settled"))
    (setq superchat-research-collector-diagnostic-v0--state
          (plist-put superchat-research-collector-diagnostic-v0--state
                     :canary_gate (if pass "pass" "blocked")))
    (setq superchat-research-collector-diagnostic-v0--state
          (plist-put superchat-research-collector-diagnostic-v0--state
                     :interpretation interpretation))
    (superchat-research-collector-diagnostic-v0--write-json
     superchat-research-collector-diagnostic-v0--execution-path
     superchat-research-collector-diagnostic-v0--state)
    (superchat-research-collector-diagnostic-v0--write-json
     superchat-research-collector-diagnostic-v0--evidence-path evidence)
    (superchat-research-collector-diagnostic-v0--export-artifact summary)
    (with-temp-file superchat-research-collector-diagnostic-v0--report-path
      (insert "# Research Collector Completion Diagnostic v0\n\n")
      (insert (format "Canary Gate: **%s**\n\n"
                      (if pass "pass" "blocked")))
      (insert (format "Interpretation: `%s`.\n\n" interpretation))
      (insert
       (format
        (concat "Search completed: `%d`; reads completed: `%d`; "
                "publish requested/completed: `%d/%d`; Artifact: `%s`; "
                "official source URLs retained: `%d`.\n\n")
        (plist-get summary :agent_reach_search_completed)
        (plist-get summary :agent_reach_read_completed)
        (plist-get summary :workspace_publish_requested)
        (plist-get summary :workspace_publish_completed)
        (plist-get summary :artifact_classification)
        (plist-get summary :official_source_url_count)))
      (insert
       "No continuation, retry, recovery, downstream stage, Outcome, stability, effectiveness, Pattern, or Learning claim is authorized.\n"))
    evidence))

(defun superchat-research-collector-diagnostic-v0--finished (report)
  "Record REPORT and settle the single Collector diagnostic."
  (let ((collector
         (copy-sequence
          (plist-get superchat-research-collector-diagnostic-v0--state
                     :collector))))
    (setq collector
          (plist-put collector :response_length (length (or report ""))))
    (setq collector
          (plist-put collector :response_sha256
                     (superchat-research-collector-diagnostic-v0--sha256-string
                      report)))
    (setq superchat-research-collector-diagnostic-v0--state
          (plist-put superchat-research-collector-diagnostic-v0--state
                     :collector collector))
    (superchat-research-collector-diagnostic-v0--finalize)))

(defun superchat-research-collector-diagnostic-v0--launch (task)
  "Launch the single real Research Collector TASK."
  (let* ((canary-id
          (format "research-collector-diagnostic-%s-%06d"
                  (format-time-string "%Y%m%d-%H%M%S")
                  (random 1000000)))
         (root superchat-research-collector-diagnostic-v0--root)
         (superchat--team-id canary-id)
         (superchat--team-actor "lead")
         (superchat--workspace-binding (list :id canary-id :root root))
         (superchat--tool-execution-context
          (list :session-id canary-id
                :team-id canary-id
                :correlation-id canary-id
                :attendance 'attended
                :authority-policy "default"
                :workspace-id canary-id
                :workspace-root root)))
    (setq superchat-research-collector-diagnostic-v0--state
          (list :experiment_id "research-collector-completion-diagnostic-v0"
                :manifest_sha256
                (superchat-research-collector-diagnostic-v0--sha256-file
                 superchat-research-collector-diagnostic-v0--manifest-path)
                :status "collector-running"
                :canary_id canary-id
                :workspace_id canary-id
                :started_at (format-time-string "%Y-%m-%dT%H:%M:%S%z")
                :continuation_count 0
                :retry_count 0
                :recovery_count 0
                :historical_runs_imported json-false
                :downstream_stages_started json-false
                :outcome_evaluation "not-evaluated"
                :stability_claim "not_evaluated"
                :effectiveness_claim "not_evaluated"
                :learning_claim "prohibited"))
    (superchat-research-collector-diagnostic-v0--write-json
     superchat-research-collector-diagnostic-v0--execution-path
     superchat-research-collector-diagnostic-v0--state)
    (let* ((actor-id
            (superchat--subagent-run-async
             'researcher task nil
             #'superchat-research-collector-diagnostic-v0--finished))
           (entry (superchat--subagent-entry actor-id))
           (run-id (plist-get entry :run-id))
           (runtime (superchat-runtime-status run-id))
           (collector
            (list :attempt "collector"
                  :actor_id actor-id
                  :run_id run-id
                  :turn_id (plist-get runtime :turn-id)
                  :parent_run_id nil
                  :started_at (format-time-string "%Y-%m-%dT%H:%M:%S%z"))))
      (setq superchat-research-collector-diagnostic-v0--state
            (plist-put superchat-research-collector-diagnostic-v0--state
                       :collector collector))
      (superchat-research-collector-diagnostic-v0--write-json
       superchat-research-collector-diagnostic-v0--execution-path
       superchat-research-collector-diagnostic-v0--state)
      collector)))

;;;###autoload
(defun superchat-research-collector-diagnostic-v0-start ()
  "Start the frozen one-Run Research Collector diagnostic exactly once."
  (interactive)
  (when superchat-research-collector-diagnostic-v0--state
    (error "Research Collector diagnostic already started"))
  (when (file-exists-p
         (expand-file-name "superchat.db" superchat-data-directory))
    (error "Research Collector diagnostic Runtime database already exists"))
  (superchat-research-collector-diagnostic-v0--verify-inputs)
  (superchat-research-collector-diagnostic-v0--launch
   (superchat-research-collector-diagnostic-v0--task)))

(defun superchat-research-collector-diagnostic-v0-status ()
  "Return current diagnostic state and live Runtime status."
  (interactive)
  (let* ((collector
          (plist-get superchat-research-collector-diagnostic-v0--state
                     :collector))
         (run-id (plist-get collector :run_id)))
    (list :state superchat-research-collector-diagnostic-v0--state
          :runtime (and run-id (superchat-runtime-status run-id)))))

(make-directory superchat-research-collector-diagnostic-v0--root t)
(superchat-research-collector-diagnostic-v0--configure-surface)
(unless (advice-member-p
         #'superchat-research-collector-diagnostic-v0--capture-query
         'superchat--execute-llm-query)
  (advice-add 'superchat--execute-llm-query :around
              #'superchat-research-collector-diagnostic-v0--capture-query))

(provide 'superchat-research-collector-completion-diagnostic-v0-run)

;;; run.el ends here
