# Rollback-Journal vs WAL Mode in SQLite: Reader/Writer Behavior and Crash-Recovery Guarantees

## Source URLs

1. Write-Ahead Logging (WAL) — https://www.sqlite.org/wal.html
2. Isolation In SQLite — https://sqlite.org/isolation.html
3. Atomic Commit In SQLite — https://sqlite.org/atomiccommit.html

---

## 1. Overview of the Two Modes

SQLite provides two major journaling modes for implementing atomic commit and rollback:

- **Rollback-Journal Mode (default)**: Uses a separate "rollback journal" file. Prior to making changes, SQLite copies the original unchanged database pages into the rollback journal, then writes modified pages directly into the database file. A transaction commits when the rollback journal is deleted (or truncated/zeroed). If a crash occurs before deletion, the rollback journal is played back on next open to restore consistency. (Source: https://www.sqlite.org/wal.html; https://sqlite.org/atomiccommit.html)

- **WAL Mode (Write-Ahead Logging)**: Introduced in SQLite 3.7.0 (2010-07-21). Changes are appended to a separate WAL file instead of overwriting the database file directly. A commit is recorded by appending a special commit record to the WAL. The original database file is left unmodified during the transaction. Transferred changes are eventually moved back into the database via "checkpointing." (Source: https://www.sqlite.org/wal.html)

**Documented fact:** Both modes guarantee atomicity — transactions appear to occur instantaneously, either fully committed or fully rolled back, even across power failures or OS crashes.
**Documented fact:** WAL mode is persistent (survives closing/reopening the database), while rollback-journal modes DELETE, TRUNCATE, and PERSIST are not — they revert to default after a disconnect unless set each time. (Source: https://www.sqlite.org/wal.html)

---

## 2. Reader/Writer Behavior

### Rollback-Journal Mode

- **Exclusive access required for writes:** Before writing any changes to the database file on disk, the writer must obtain an exclusive lock, which expels all existing readers temporarily. (Source: https://sqlite.org/isolation.html)
- **Readers are blocked during write phase:** Readers can begin a transaction and hold a shared lock before the writer starts flushing. But once the writer needs to modify the database file on disk, all readers must be locked out. Only after changes are fully written, synced, and committed do readers regain access. (Source: https://sqlite.org/isolation.html)
- **No concurrent readers/writers during the on-disk write phase:** Readers and writers cannot simultaneously have active access to the database file for writing. This is a form of mutual exclusion enforced by OS-level file locking.
- **Single writer at a time even in rollback mode:** Writers serialize through locks — only one process can hold the reserved/exclusive lock necessary for modification. (Source: https://sqlite.org/isolation.html)

### WAL Mode

- **Simultaneous readers and writers are permitted:** Changes are appended to the WAL file, not written into the database file directly. Readers continue reading the original unmodified database file while the writer appends to the WAL. (Source: https://www.sqlite.org/wal.html; https://sqlite.org/isolation.html)
- **Snapshot isolation for readers:** Each reader sees a consistent snapshot of the database as it existed at the start of its read transaction. The reader checks the WAL for the latest committed version of each page up to its "end mark." Pages not found in the WAL prior to that point are read from the database file. (Source: https://www.sqlite.org/wal.html)
- **Writers can proceed without blocking readers:** Since writers append to a separate file, no database-file locks are needed for the write path during normal operation. This is the primary concurrency advantage of WAL.
- **Three primitive operations in WAL vs. two in rollback:** Reading, writing, and checkpointing (Source: https://www.sqlite.org/wal.html)

**Documented fact:** In WAL mode, there can still be only one writer at a time (only one WAL file), but multiple readers can coexist with the single writer concurrently. (Source: https://www.sqlite.org/wal.html)

---

## 3. Crash-Recovery Guarantees

### Rollback-Journal Mode

- **Recovery via hot journal playback:** After an unexpected crash or power loss, when the database is next opened, SQLite checks for a "hot" rollback journal — one that exists, is non-empty, has a well-formed (non-zeroed) header, and no reserved lock on the database. If found, SQLite rolls back by playing the original page content from the journal back into the database file. (Source: https://sqlite.org/atomiccommit.html)
- **Journal deletion = commit boundary:** A transaction is considered committed only when the rollback journal file is deleted (or truncated/zeroed). Before that point, a crash triggers recovery; after that point, all changes are assumed durable. (Source: https://sqlite.org/atomiccommit.html)
- **Durability depends on synchronous setting:** With `PRAGMA synchronous=FULL`, transactions are durable across power loss. With `synchronous=NORMAL`, WAL mode is stated to be safe from corruption but may lose durability of committed transactions after a power failure. For rollback DELETE mode with synchronous=NORMAL, there is also a non-zero risk of corruption (documented as "Maybe not durable" in the summary table). (Source: https://sqlite.org/pragma.html)

### WAL Mode

- **WAL file acts as recovery journal:** After a crash, SQLite checks for a "hot" WAL file. The checkpoint mechanism (running automatically or manually) transfers committed changes from the WAL back into the database file. If a crash occurs during an uncommitted transaction, those changes are simply not visible in subsequent reads — they never get checkpointed.
- **Checkpoint sync requirements:** Checkpointing requires fsync operations to ensure durability. The WAL must be synced before content is moved into the database file, and the database file must be synced after the checkpoint. Without proper syncs (e.g., with `synchronous=NORMAL`), committed transactions might roll back after a power loss — WAL loses durability in that configuration but remains consistent. (Source: https://www.sqlite.org/wal.html; https://sqlite.org/pragma.html)
- **Transactions durable across application crashes regardless of synchronous/journal setting:** The documentation explicitly states this for both modes — an application crash does not threaten integrity, only a power/system-level failure can. (Source: https://sqlite.org/pragma.html)
- **WAL file persistence:** The WAL and associated -shm shared-memory files are quasi-persistent. They may remain on disk after the last connection closes (e.g., via SQLITE_FCNTL_PERSIST_WAL). Separating the database from its WAL/-shm files can cause lost transactions or corruption. (Source: https://www.sqlite.org/wal.html)

---

## 4. Key Differences Summary (Evidence-Based)

| Aspect | Rollback-Journal Mode | WAL Mode |
|---|---|---|
| **Writer writes to** | Database file directly | Separate WAL file |
| **Readers during write** | Locked out during on-disk write phase | Can continue reading from database file concurrently |
| **Commit mechanism** | Delete (or truncate/zero) rollback journal | Append commit record to WAL |
| **Concurrent readers/writers** | No (during write flush phase) | Yes (readers and writers operate simultaneously) |
| **Recovery on crash** | Hot journal played back into database file | Committed pages checkpointed; uncommitted pages lost |
| **Persistence of mode setting** | Non-persistent (reverts to DELETE after disconnect) | Persistent (survives reconnects) |
| **Network filesystem support** | Yes | No (requires shared memory on same host) |
| **File format version** | Read version 1 | Read version 2 (incompatible with pre-3.7.0 readers) |
| **Checkpointing required** | No | Yes (transfers WAL changes back to database file) |

---

## 5. Inferred vs. Documented Findings

### Strictly Documented Facts (no inference applied):
1. WAL mode was introduced in SQLite 3.7.0 (2010-07-21). — Source: https://www.sqlite.org/wal.html
2. In rollback mode, all readers are expelled before any changes are made to the database file on disk. — Source: https://sqlite.org/isolation.html
3. WAL permits simultaneous readers and writers because changes go into a separate WAL file. — Source: https://sqlite.org/isolation.html
4. A hot rollback journal exists when an earlier process crashed during commit; it is recovered automatically. — Source: https://sqlite.org/atomiccommit.html
5. WAL mode database files have read version 2, preventing older SQLite versions from reading them. — Source: https://www.sqlite.org/wal.html
6. Transactions are durable across application crashes regardless of journal mode or synchronous setting. — Source: https://sqlite.org/pragma.html
7. WAL requires shared memory and does not work over network filesystems. — Source: https://www.sqlite.org/wal.html

### Inferred (but well-supported) Observations:
1. WAL's snapshot isolation means that long-running readers will never see newer committed writes from other connections until they start a new transaction — this is a consequence of the documented "end mark" mechanism but not explicitly described as a user-facing behavioral guarantee in those terms. (Inference from https://www.sqlite.org/wal.html)
2. The tradeoff in WAL mode between read performance and write performance: frequent small checkpoints favor read performance; infrequent large checkpoints favor write performance. (Inference from https://www.sqlite.org/wal.html section 2.3)
3. For very large transactions (>100 MB), rollback journal may be preferred, though as of SQLite 3.11.0 WAL handles large transactions efficiently. — Source: https://www.sqlite.org/wal.html (the strikethrough text was explicitly noted as updated by SQLite devs, so the current factual position is that both handle large transactions equally well)

---

## References

- [Write-Ahead Logging](https://www.sqlite.org/wal.html)
- [Isolation In SQLite](https://sqlite.org/isolation.html)
- [Atomic Commit In SQLite](https://sqlite.org/atomiccommit.html)
- [Pragma Statements Supported by SQLite](https://sqlite.org/pragma.html)