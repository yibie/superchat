# Research Collector Completion Diagnostic v1 — Evidence Report

## Verdict

`pass — real_research_collector_contract_closed`

One new Collector Run completed the frozen real-research contract without a
continuation, retry, recovery, task substitution, or downstream stage.

## Gate results

| Gate | Verdict | Evidence |
| --- | --- | --- |
| Prior | pass | The frozen Manifest predates execution; the captured model prompt, Actor, model, system prompt, and seven prepared tools match the standard Research surface. |
| Execution | pass | Closure reports a valid trace and proved `completed` terminal; all tool and scope identities are valid; no unexpected or failed tool event exists. |
| Research activity | pass | One `agent_reach_search` and three `agent_reach_read` calls completed. |
| Publish | pass | Exactly one `workspace_publish` request completed. |
| Artifact | pass | Exactly one readable, revision-matched, deliverable Artifact with normalized role `collector` exists. |
| Source references | pass | The Artifact retained five distinct official `sqlite.org` URLs. |

## Identities and Artifact

- Actor: `subagent-researcher-20260804-121443-109c`
- Run: `run-20260804-121443-328962-f1ce`
- Workspace/correlation: `research-collector-diagnostic-20260804-121443-205187`
- Artifact: `artifact-9261f95f-1`
- Artifact revision/content SHA-256: `6f5913ef02d7a54e39d873ee5a8770aaecd0f1081cb464c6138f2391177e6755`
- Artifact content length: `10288`

## Independent checks after daemon stop

- Daemon process: stopped
- SQLite integrity: `ok`
- Tape rows: `35`
- Tool requested/started/completed: `8/8/8`
- `workspace.artifact.added`: `1`
- `run.completed`: `1`
- `tool.failed`: `0`
- Runtime snapshot SHA-256: `7c5de43cb97102bfe7253cf9d5854323b1227e2d60be72b9df5d636b70ae4d88`
- Manifest SHA-256: `f9b2f52760676ece23d3607c2d0190e7385082ae7afb5d92382a478a72cb6ecc`
- Evidence Bundle SHA-256: `93eb6c539e57ccfc52b41c46fb9a550760cd5fd90c790b7e6ee1eb830136a6d9`
- Prompt snapshot SHA-256: `c4b178d80149fea98ff82bc4b03e6c5b817ec0c3bbcf9caea3d5fa924ef0f64c`

## Boundary

This pass proves only that one real Research Collector can close the frozen
search/read/publish contract on the tested surface. It does not establish
repeatability, research quality, intervention effectiveness, Pattern,
Learning, or promotion. The next eligible gate is a separately frozen four-run
Research Collector Calibration; Discovery remains blocked.
