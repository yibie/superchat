# Research Collector Completion Calibration v0 — Evidence Gap Report

Calibration Gate: **blocked**

The frozen attempt launched two of four samples and was stopped without retry, continuation, recovery, or manual finalization. It is historical failure evidence and must not be repaired or counted in a later Calibration.

## Observations

- `research-cal-01`: Runtime completed after one search and three reads, but no `workspace_publish` or Artifact was produced. Its 25-byte response hash exactly matches `[Empty response from llm]`. Classification: `application_completion_compliance_failure_triggered_by_empty_model_response` / `artifact_absent`.
- `research-cal-02`: four searches, five reads, and one `workspace_publish` completed. Artifact `artifact-ad9dea3c-1` exists, but the model transport process exited with status 0 while the asynchronous `plz` result remained unprocessed. No Runtime terminal event exists. Classification: `runtime_transport_finalization_gap` / `artifact_present_provenance_invalid`.
- `research-cal-03` and `research-cal-04`: not started.

Strict `4/4` evidence closure is therefore not demonstrated. The Artifact from sample 2 is retained as evidence, but it is not promoted into a passing sample because its producer Run never closed.

## Preserved evidence

- SQLite integrity: `ok`; Tape rows: `73`.
- Completed Run events: `1`; Artifact-added events: `1`.
- Manual finalize: `false`; retries: `0`; continuations: `0`; recoveries: `0`.
- Runtime snapshot SHA-256: `4813e3c4a3bf28b08767ccf15fa94de82ecf45fbf26d5d3045650d25d1f2e82e`.
- Transport gap SHA-256: `f6b894b206004de8e60a7fa032c803c3a0c5b1624f1665a7282bde8a671ed460`.
- Sample 2 Artifact revision/export SHA-256: `69c651f1edc2c276a0bab3f2d77a35149c1e11392382213a838ac18d7863a460`.

No Outcome, effectiveness, Pattern, Discovery, Learning, or promotion claim is made.
